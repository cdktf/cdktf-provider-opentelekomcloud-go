/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface LtsHostAccessV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_host_access_v3#binary_collect LtsHostAccessV3#binary_collect}
    */
    readonly binaryCollect?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_host_access_v3#host_group_ids LtsHostAccessV3#host_group_ids}
    */
    readonly hostGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_host_access_v3#id LtsHostAccessV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_host_access_v3#log_group_id LtsHostAccessV3#log_group_id}
    */
    readonly logGroupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_host_access_v3#log_split LtsHostAccessV3#log_split}
    */
    readonly logSplit?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_host_access_v3#log_stream_id LtsHostAccessV3#log_stream_id}
    */
    readonly logStreamId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_host_access_v3#name LtsHostAccessV3#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_host_access_v3#tags LtsHostAccessV3#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * access_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_host_access_v3#access_config LtsHostAccessV3#access_config}
    */
    readonly accessConfig: LtsHostAccessV3AccessConfig;
}
export interface LtsHostAccessV3AccessConfigMultiLogFormat {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_host_access_v3#mode LtsHostAccessV3#mode}
    */
    readonly mode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_host_access_v3#value LtsHostAccessV3#value}
    */
    readonly value?: string;
}
export declare function ltsHostAccessV3AccessConfigMultiLogFormatToTerraform(struct?: LtsHostAccessV3AccessConfigMultiLogFormatOutputReference | LtsHostAccessV3AccessConfigMultiLogFormat): any;
export declare function ltsHostAccessV3AccessConfigMultiLogFormatToHclTerraform(struct?: LtsHostAccessV3AccessConfigMultiLogFormatOutputReference | LtsHostAccessV3AccessConfigMultiLogFormat): any;
export declare class LtsHostAccessV3AccessConfigMultiLogFormatOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LtsHostAccessV3AccessConfigMultiLogFormat | undefined;
    set internalValue(value: LtsHostAccessV3AccessConfigMultiLogFormat | undefined);
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface LtsHostAccessV3AccessConfigSingleLogFormat {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_host_access_v3#mode LtsHostAccessV3#mode}
    */
    readonly mode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_host_access_v3#value LtsHostAccessV3#value}
    */
    readonly value?: string;
}
export declare function ltsHostAccessV3AccessConfigSingleLogFormatToTerraform(struct?: LtsHostAccessV3AccessConfigSingleLogFormatOutputReference | LtsHostAccessV3AccessConfigSingleLogFormat): any;
export declare function ltsHostAccessV3AccessConfigSingleLogFormatToHclTerraform(struct?: LtsHostAccessV3AccessConfigSingleLogFormatOutputReference | LtsHostAccessV3AccessConfigSingleLogFormat): any;
export declare class LtsHostAccessV3AccessConfigSingleLogFormatOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LtsHostAccessV3AccessConfigSingleLogFormat | undefined;
    set internalValue(value: LtsHostAccessV3AccessConfigSingleLogFormat | undefined);
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface LtsHostAccessV3AccessConfigWindowsLogInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_host_access_v3#categories LtsHostAccessV3#categories}
    */
    readonly categories: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_host_access_v3#event_level LtsHostAccessV3#event_level}
    */
    readonly eventLevel: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_host_access_v3#time_offset LtsHostAccessV3#time_offset}
    */
    readonly timeOffset: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_host_access_v3#time_offset_unit LtsHostAccessV3#time_offset_unit}
    */
    readonly timeOffsetUnit: string;
}
export declare function ltsHostAccessV3AccessConfigWindowsLogInfoToTerraform(struct?: LtsHostAccessV3AccessConfigWindowsLogInfoOutputReference | LtsHostAccessV3AccessConfigWindowsLogInfo): any;
export declare function ltsHostAccessV3AccessConfigWindowsLogInfoToHclTerraform(struct?: LtsHostAccessV3AccessConfigWindowsLogInfoOutputReference | LtsHostAccessV3AccessConfigWindowsLogInfo): any;
export declare class LtsHostAccessV3AccessConfigWindowsLogInfoOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LtsHostAccessV3AccessConfigWindowsLogInfo | undefined;
    set internalValue(value: LtsHostAccessV3AccessConfigWindowsLogInfo | undefined);
    private _categories?;
    get categories(): string[];
    set categories(value: string[]);
    get categoriesInput(): string[] | undefined;
    private _eventLevel?;
    get eventLevel(): string[];
    set eventLevel(value: string[]);
    get eventLevelInput(): string[] | undefined;
    private _timeOffset?;
    get timeOffset(): number;
    set timeOffset(value: number);
    get timeOffsetInput(): number | undefined;
    private _timeOffsetUnit?;
    get timeOffsetUnit(): string;
    set timeOffsetUnit(value: string);
    get timeOffsetUnitInput(): string | undefined;
}
export interface LtsHostAccessV3AccessConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_host_access_v3#black_paths LtsHostAccessV3#black_paths}
    */
    readonly blackPaths?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_host_access_v3#paths LtsHostAccessV3#paths}
    */
    readonly paths: string[];
    /**
    * multi_log_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_host_access_v3#multi_log_format LtsHostAccessV3#multi_log_format}
    */
    readonly multiLogFormat?: LtsHostAccessV3AccessConfigMultiLogFormat;
    /**
    * single_log_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_host_access_v3#single_log_format LtsHostAccessV3#single_log_format}
    */
    readonly singleLogFormat?: LtsHostAccessV3AccessConfigSingleLogFormat;
    /**
    * windows_log_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_host_access_v3#windows_log_info LtsHostAccessV3#windows_log_info}
    */
    readonly windowsLogInfo?: LtsHostAccessV3AccessConfigWindowsLogInfo;
}
export declare function ltsHostAccessV3AccessConfigToTerraform(struct?: LtsHostAccessV3AccessConfigOutputReference | LtsHostAccessV3AccessConfig): any;
export declare function ltsHostAccessV3AccessConfigToHclTerraform(struct?: LtsHostAccessV3AccessConfigOutputReference | LtsHostAccessV3AccessConfig): any;
export declare class LtsHostAccessV3AccessConfigOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LtsHostAccessV3AccessConfig | undefined;
    set internalValue(value: LtsHostAccessV3AccessConfig | undefined);
    private _blackPaths?;
    get blackPaths(): string[];
    set blackPaths(value: string[]);
    resetBlackPaths(): void;
    get blackPathsInput(): string[] | undefined;
    private _paths?;
    get paths(): string[];
    set paths(value: string[]);
    get pathsInput(): string[] | undefined;
    private _multiLogFormat;
    get multiLogFormat(): LtsHostAccessV3AccessConfigMultiLogFormatOutputReference;
    putMultiLogFormat(value: LtsHostAccessV3AccessConfigMultiLogFormat): void;
    resetMultiLogFormat(): void;
    get multiLogFormatInput(): LtsHostAccessV3AccessConfigMultiLogFormat | undefined;
    private _singleLogFormat;
    get singleLogFormat(): LtsHostAccessV3AccessConfigSingleLogFormatOutputReference;
    putSingleLogFormat(value: LtsHostAccessV3AccessConfigSingleLogFormat): void;
    resetSingleLogFormat(): void;
    get singleLogFormatInput(): LtsHostAccessV3AccessConfigSingleLogFormat | undefined;
    private _windowsLogInfo;
    get windowsLogInfo(): LtsHostAccessV3AccessConfigWindowsLogInfoOutputReference;
    putWindowsLogInfo(value: LtsHostAccessV3AccessConfigWindowsLogInfo): void;
    resetWindowsLogInfo(): void;
    get windowsLogInfoInput(): LtsHostAccessV3AccessConfigWindowsLogInfo | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_host_access_v3 opentelekomcloud_lts_host_access_v3}
*/
export declare class LtsHostAccessV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_lts_host_access_v3";
    /**
    * Generates CDKTF code for importing a LtsHostAccessV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LtsHostAccessV3 to import
    * @param importFromId The id of the existing LtsHostAccessV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_host_access_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LtsHostAccessV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_host_access_v3 opentelekomcloud_lts_host_access_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LtsHostAccessV3Config
    */
    constructor(scope: Construct, id: string, config: LtsHostAccessV3Config);
    get accessType(): string;
    private _binaryCollect?;
    get binaryCollect(): boolean | cdktf.IResolvable;
    set binaryCollect(value: boolean | cdktf.IResolvable);
    resetBinaryCollect(): void;
    get binaryCollectInput(): boolean | cdktf.IResolvable | undefined;
    get createdAt(): string;
    private _hostGroupIds?;
    get hostGroupIds(): string[];
    set hostGroupIds(value: string[]);
    resetHostGroupIds(): void;
    get hostGroupIdsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _logGroupId?;
    get logGroupId(): string;
    set logGroupId(value: string);
    get logGroupIdInput(): string | undefined;
    get logGroupName(): string;
    private _logSplit?;
    get logSplit(): boolean | cdktf.IResolvable;
    set logSplit(value: boolean | cdktf.IResolvable);
    resetLogSplit(): void;
    get logSplitInput(): boolean | cdktf.IResolvable | undefined;
    private _logStreamId?;
    get logStreamId(): string;
    set logStreamId(value: string);
    get logStreamIdInput(): string | undefined;
    get logStreamName(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get region(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _accessConfig;
    get accessConfig(): LtsHostAccessV3AccessConfigOutputReference;
    putAccessConfig(value: LtsHostAccessV3AccessConfig): void;
    get accessConfigInput(): LtsHostAccessV3AccessConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

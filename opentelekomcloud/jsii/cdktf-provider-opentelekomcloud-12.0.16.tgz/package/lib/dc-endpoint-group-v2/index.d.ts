/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DcEndpointGroupV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_endpoint_group_v2#description DcEndpointGroupV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_endpoint_group_v2#endpoints DcEndpointGroupV2#endpoints}
    */
    readonly endpoints: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_endpoint_group_v2#name DcEndpointGroupV2#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_endpoint_group_v2#project_id DcEndpointGroupV2#project_id}
    */
    readonly projectId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_endpoint_group_v2#type DcEndpointGroupV2#type}
    */
    readonly type: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_endpoint_group_v2#timeouts DcEndpointGroupV2#timeouts}
    */
    readonly timeouts?: DcEndpointGroupV2Timeouts;
}
export interface DcEndpointGroupV2Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_endpoint_group_v2#create DcEndpointGroupV2#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_endpoint_group_v2#delete DcEndpointGroupV2#delete}
    */
    readonly delete?: string;
}
export declare function dcEndpointGroupV2TimeoutsToTerraform(struct?: DcEndpointGroupV2Timeouts | cdktf.IResolvable): any;
export declare function dcEndpointGroupV2TimeoutsToHclTerraform(struct?: DcEndpointGroupV2Timeouts | cdktf.IResolvable): any;
export declare class DcEndpointGroupV2TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DcEndpointGroupV2Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DcEndpointGroupV2Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_endpoint_group_v2 opentelekomcloud_dc_endpoint_group_v2}
*/
export declare class DcEndpointGroupV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_dc_endpoint_group_v2";
    /**
    * Generates CDKTF code for importing a DcEndpointGroupV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DcEndpointGroupV2 to import
    * @param importFromId The id of the existing DcEndpointGroupV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_endpoint_group_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DcEndpointGroupV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_endpoint_group_v2 opentelekomcloud_dc_endpoint_group_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DcEndpointGroupV2Config
    */
    constructor(scope: Construct, id: string, config: DcEndpointGroupV2Config);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _endpoints?;
    get endpoints(): string[];
    set endpoints(value: string[]);
    get endpointsInput(): string[] | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _timeouts;
    get timeouts(): DcEndpointGroupV2TimeoutsOutputReference;
    putTimeouts(value: DcEndpointGroupV2Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DcEndpointGroupV2Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

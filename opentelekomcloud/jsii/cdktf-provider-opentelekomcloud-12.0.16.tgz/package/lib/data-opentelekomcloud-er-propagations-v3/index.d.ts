/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudErPropagationsV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/er_propagations_v3#attachment_id DataOpentelekomcloudErPropagationsV3#attachment_id}
    */
    readonly attachmentId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/er_propagations_v3#attachment_type DataOpentelekomcloudErPropagationsV3#attachment_type}
    */
    readonly attachmentType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/er_propagations_v3#id DataOpentelekomcloudErPropagationsV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/er_propagations_v3#instance_id DataOpentelekomcloudErPropagationsV3#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/er_propagations_v3#route_table_id DataOpentelekomcloudErPropagationsV3#route_table_id}
    */
    readonly routeTableId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/er_propagations_v3#status DataOpentelekomcloudErPropagationsV3#status}
    */
    readonly status?: string;
}
export interface DataOpentelekomcloudErPropagationsV3Propagations {
}
export declare function dataOpentelekomcloudErPropagationsV3PropagationsToTerraform(struct?: DataOpentelekomcloudErPropagationsV3Propagations): any;
export declare function dataOpentelekomcloudErPropagationsV3PropagationsToHclTerraform(struct?: DataOpentelekomcloudErPropagationsV3Propagations): any;
export declare class DataOpentelekomcloudErPropagationsV3PropagationsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudErPropagationsV3Propagations | undefined;
    set internalValue(value: DataOpentelekomcloudErPropagationsV3Propagations | undefined);
    get attachmentId(): string;
    get attachmentType(): string;
    get createdAt(): string;
    get id(): string;
    get instanceId(): string;
    get resourceId(): string;
    get routeTableId(): string;
    get status(): string;
    get updatedAt(): string;
}
export declare class DataOpentelekomcloudErPropagationsV3PropagationsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudErPropagationsV3PropagationsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/er_propagations_v3 opentelekomcloud_er_propagations_v3}
*/
export declare class DataOpentelekomcloudErPropagationsV3 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_er_propagations_v3";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudErPropagationsV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudErPropagationsV3 to import
    * @param importFromId The id of the existing DataOpentelekomcloudErPropagationsV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/er_propagations_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudErPropagationsV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/er_propagations_v3 opentelekomcloud_er_propagations_v3} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudErPropagationsV3Config
    */
    constructor(scope: Construct, id: string, config: DataOpentelekomcloudErPropagationsV3Config);
    private _attachmentId?;
    get attachmentId(): string;
    set attachmentId(value: string);
    resetAttachmentId(): void;
    get attachmentIdInput(): string | undefined;
    private _attachmentType?;
    get attachmentType(): string;
    set attachmentType(value: string);
    resetAttachmentType(): void;
    get attachmentTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _propagations;
    get propagations(): DataOpentelekomcloudErPropagationsV3PropagationsList;
    private _routeTableId?;
    get routeTableId(): string;
    set routeTableId(value: string);
    get routeTableIdInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

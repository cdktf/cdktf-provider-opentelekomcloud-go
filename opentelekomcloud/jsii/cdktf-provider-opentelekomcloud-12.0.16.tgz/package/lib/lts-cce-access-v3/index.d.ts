/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface LtsCceAccessV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#binary_collect LtsCceAccessV3#binary_collect}
    */
    readonly binaryCollect?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#cluster_id LtsCceAccessV3#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#host_group_ids LtsCceAccessV3#host_group_ids}
    */
    readonly hostGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#id LtsCceAccessV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#log_group_id LtsCceAccessV3#log_group_id}
    */
    readonly logGroupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#log_split LtsCceAccessV3#log_split}
    */
    readonly logSplit?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#log_stream_id LtsCceAccessV3#log_stream_id}
    */
    readonly logStreamId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#name LtsCceAccessV3#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#tags LtsCceAccessV3#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * access_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#access_config LtsCceAccessV3#access_config}
    */
    readonly accessConfig: LtsCceAccessV3AccessConfig;
}
export interface LtsCceAccessV3AccessConfigMultiLogFormat {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#mode LtsCceAccessV3#mode}
    */
    readonly mode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#value LtsCceAccessV3#value}
    */
    readonly value?: string;
}
export declare function ltsCceAccessV3AccessConfigMultiLogFormatToTerraform(struct?: LtsCceAccessV3AccessConfigMultiLogFormatOutputReference | LtsCceAccessV3AccessConfigMultiLogFormat): any;
export declare function ltsCceAccessV3AccessConfigMultiLogFormatToHclTerraform(struct?: LtsCceAccessV3AccessConfigMultiLogFormatOutputReference | LtsCceAccessV3AccessConfigMultiLogFormat): any;
export declare class LtsCceAccessV3AccessConfigMultiLogFormatOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LtsCceAccessV3AccessConfigMultiLogFormat | undefined;
    set internalValue(value: LtsCceAccessV3AccessConfigMultiLogFormat | undefined);
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface LtsCceAccessV3AccessConfigSingleLogFormat {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#mode LtsCceAccessV3#mode}
    */
    readonly mode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#value LtsCceAccessV3#value}
    */
    readonly value?: string;
}
export declare function ltsCceAccessV3AccessConfigSingleLogFormatToTerraform(struct?: LtsCceAccessV3AccessConfigSingleLogFormatOutputReference | LtsCceAccessV3AccessConfigSingleLogFormat): any;
export declare function ltsCceAccessV3AccessConfigSingleLogFormatToHclTerraform(struct?: LtsCceAccessV3AccessConfigSingleLogFormatOutputReference | LtsCceAccessV3AccessConfigSingleLogFormat): any;
export declare class LtsCceAccessV3AccessConfigSingleLogFormatOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LtsCceAccessV3AccessConfigSingleLogFormat | undefined;
    set internalValue(value: LtsCceAccessV3AccessConfigSingleLogFormat | undefined);
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface LtsCceAccessV3AccessConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#black_paths LtsCceAccessV3#black_paths}
    */
    readonly blackPaths?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#container_name_regex LtsCceAccessV3#container_name_regex}
    */
    readonly containerNameRegex?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#exclude_envs LtsCceAccessV3#exclude_envs}
    */
    readonly excludeEnvs?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#exclude_k8s_labels LtsCceAccessV3#exclude_k8s_labels}
    */
    readonly excludeK8SLabels?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#exclude_labels LtsCceAccessV3#exclude_labels}
    */
    readonly excludeLabels?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#include_envs LtsCceAccessV3#include_envs}
    */
    readonly includeEnvs?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#include_k8s_labels LtsCceAccessV3#include_k8s_labels}
    */
    readonly includeK8SLabels?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#include_labels LtsCceAccessV3#include_labels}
    */
    readonly includeLabels?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#log_envs LtsCceAccessV3#log_envs}
    */
    readonly logEnvs?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#log_k8s LtsCceAccessV3#log_k8s}
    */
    readonly logK8S?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#log_labels LtsCceAccessV3#log_labels}
    */
    readonly logLabels?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#name_space_regex LtsCceAccessV3#name_space_regex}
    */
    readonly nameSpaceRegex?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#path_type LtsCceAccessV3#path_type}
    */
    readonly pathType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#paths LtsCceAccessV3#paths}
    */
    readonly paths?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#pod_name_regex LtsCceAccessV3#pod_name_regex}
    */
    readonly podNameRegex?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#stderr LtsCceAccessV3#stderr}
    */
    readonly stderr?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#stdout LtsCceAccessV3#stdout}
    */
    readonly stdout?: boolean | cdktf.IResolvable;
    /**
    * multi_log_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#multi_log_format LtsCceAccessV3#multi_log_format}
    */
    readonly multiLogFormat?: LtsCceAccessV3AccessConfigMultiLogFormat;
    /**
    * single_log_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#single_log_format LtsCceAccessV3#single_log_format}
    */
    readonly singleLogFormat?: LtsCceAccessV3AccessConfigSingleLogFormat;
}
export declare function ltsCceAccessV3AccessConfigToTerraform(struct?: LtsCceAccessV3AccessConfigOutputReference | LtsCceAccessV3AccessConfig): any;
export declare function ltsCceAccessV3AccessConfigToHclTerraform(struct?: LtsCceAccessV3AccessConfigOutputReference | LtsCceAccessV3AccessConfig): any;
export declare class LtsCceAccessV3AccessConfigOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LtsCceAccessV3AccessConfig | undefined;
    set internalValue(value: LtsCceAccessV3AccessConfig | undefined);
    private _blackPaths?;
    get blackPaths(): string[];
    set blackPaths(value: string[]);
    resetBlackPaths(): void;
    get blackPathsInput(): string[] | undefined;
    private _containerNameRegex?;
    get containerNameRegex(): string;
    set containerNameRegex(value: string);
    resetContainerNameRegex(): void;
    get containerNameRegexInput(): string | undefined;
    private _excludeEnvs?;
    get excludeEnvs(): {
        [key: string]: string;
    };
    set excludeEnvs(value: {
        [key: string]: string;
    });
    resetExcludeEnvs(): void;
    get excludeEnvsInput(): {
        [key: string]: string;
    } | undefined;
    private _excludeK8SLabels?;
    get excludeK8SLabels(): {
        [key: string]: string;
    };
    set excludeK8SLabels(value: {
        [key: string]: string;
    });
    resetExcludeK8SLabels(): void;
    get excludeK8SLabelsInput(): {
        [key: string]: string;
    } | undefined;
    private _excludeLabels?;
    get excludeLabels(): {
        [key: string]: string;
    };
    set excludeLabels(value: {
        [key: string]: string;
    });
    resetExcludeLabels(): void;
    get excludeLabelsInput(): {
        [key: string]: string;
    } | undefined;
    private _includeEnvs?;
    get includeEnvs(): {
        [key: string]: string;
    };
    set includeEnvs(value: {
        [key: string]: string;
    });
    resetIncludeEnvs(): void;
    get includeEnvsInput(): {
        [key: string]: string;
    } | undefined;
    private _includeK8SLabels?;
    get includeK8SLabels(): {
        [key: string]: string;
    };
    set includeK8SLabels(value: {
        [key: string]: string;
    });
    resetIncludeK8SLabels(): void;
    get includeK8SLabelsInput(): {
        [key: string]: string;
    } | undefined;
    private _includeLabels?;
    get includeLabels(): {
        [key: string]: string;
    };
    set includeLabels(value: {
        [key: string]: string;
    });
    resetIncludeLabels(): void;
    get includeLabelsInput(): {
        [key: string]: string;
    } | undefined;
    private _logEnvs?;
    get logEnvs(): {
        [key: string]: string;
    };
    set logEnvs(value: {
        [key: string]: string;
    });
    resetLogEnvs(): void;
    get logEnvsInput(): {
        [key: string]: string;
    } | undefined;
    private _logK8S?;
    get logK8S(): {
        [key: string]: string;
    };
    set logK8S(value: {
        [key: string]: string;
    });
    resetLogK8S(): void;
    get logK8SInput(): {
        [key: string]: string;
    } | undefined;
    private _logLabels?;
    get logLabels(): {
        [key: string]: string;
    };
    set logLabels(value: {
        [key: string]: string;
    });
    resetLogLabels(): void;
    get logLabelsInput(): {
        [key: string]: string;
    } | undefined;
    private _nameSpaceRegex?;
    get nameSpaceRegex(): string;
    set nameSpaceRegex(value: string);
    resetNameSpaceRegex(): void;
    get nameSpaceRegexInput(): string | undefined;
    private _pathType?;
    get pathType(): string;
    set pathType(value: string);
    get pathTypeInput(): string | undefined;
    private _paths?;
    get paths(): string[];
    set paths(value: string[]);
    resetPaths(): void;
    get pathsInput(): string[] | undefined;
    private _podNameRegex?;
    get podNameRegex(): string;
    set podNameRegex(value: string);
    resetPodNameRegex(): void;
    get podNameRegexInput(): string | undefined;
    private _stderr?;
    get stderr(): boolean | cdktf.IResolvable;
    set stderr(value: boolean | cdktf.IResolvable);
    resetStderr(): void;
    get stderrInput(): boolean | cdktf.IResolvable | undefined;
    private _stdout?;
    get stdout(): boolean | cdktf.IResolvable;
    set stdout(value: boolean | cdktf.IResolvable);
    resetStdout(): void;
    get stdoutInput(): boolean | cdktf.IResolvable | undefined;
    private _multiLogFormat;
    get multiLogFormat(): LtsCceAccessV3AccessConfigMultiLogFormatOutputReference;
    putMultiLogFormat(value: LtsCceAccessV3AccessConfigMultiLogFormat): void;
    resetMultiLogFormat(): void;
    get multiLogFormatInput(): LtsCceAccessV3AccessConfigMultiLogFormat | undefined;
    private _singleLogFormat;
    get singleLogFormat(): LtsCceAccessV3AccessConfigSingleLogFormatOutputReference;
    putSingleLogFormat(value: LtsCceAccessV3AccessConfigSingleLogFormat): void;
    resetSingleLogFormat(): void;
    get singleLogFormatInput(): LtsCceAccessV3AccessConfigSingleLogFormat | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3 opentelekomcloud_lts_cce_access_v3}
*/
export declare class LtsCceAccessV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_lts_cce_access_v3";
    /**
    * Generates CDKTF code for importing a LtsCceAccessV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LtsCceAccessV3 to import
    * @param importFromId The id of the existing LtsCceAccessV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LtsCceAccessV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_cce_access_v3 opentelekomcloud_lts_cce_access_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LtsCceAccessV3Config
    */
    constructor(scope: Construct, id: string, config: LtsCceAccessV3Config);
    get accessType(): string;
    private _binaryCollect?;
    get binaryCollect(): boolean | cdktf.IResolvable;
    set binaryCollect(value: boolean | cdktf.IResolvable);
    resetBinaryCollect(): void;
    get binaryCollectInput(): boolean | cdktf.IResolvable | undefined;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    get createdAt(): string;
    private _hostGroupIds?;
    get hostGroupIds(): string[];
    set hostGroupIds(value: string[]);
    resetHostGroupIds(): void;
    get hostGroupIdsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _logGroupId?;
    get logGroupId(): string;
    set logGroupId(value: string);
    get logGroupIdInput(): string | undefined;
    get logGroupName(): string;
    private _logSplit?;
    get logSplit(): boolean | cdktf.IResolvable;
    set logSplit(value: boolean | cdktf.IResolvable);
    resetLogSplit(): void;
    get logSplitInput(): boolean | cdktf.IResolvable | undefined;
    private _logStreamId?;
    get logStreamId(): string;
    set logStreamId(value: string);
    get logStreamIdInput(): string | undefined;
    get logStreamName(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get region(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _accessConfig;
    get accessConfig(): LtsCceAccessV3AccessConfigOutputReference;
    putAccessConfig(value: LtsCceAccessV3AccessConfig): void;
    get accessConfigInput(): LtsCceAccessV3AccessConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

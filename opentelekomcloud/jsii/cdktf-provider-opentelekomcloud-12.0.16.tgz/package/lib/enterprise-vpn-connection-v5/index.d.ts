/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface EnterpriseVpnConnectionV5Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#customer_gateway_id EnterpriseVpnConnectionV5#customer_gateway_id}
    */
    readonly customerGatewayId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#enable_nqa EnterpriseVpnConnectionV5#enable_nqa}
    */
    readonly enableNqa?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#gateway_id EnterpriseVpnConnectionV5#gateway_id}
    */
    readonly gatewayId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#gateway_ip EnterpriseVpnConnectionV5#gateway_ip}
    */
    readonly gatewayIp: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#ha_role EnterpriseVpnConnectionV5#ha_role}
    */
    readonly haRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#id EnterpriseVpnConnectionV5#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#name EnterpriseVpnConnectionV5#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#peer_subnets EnterpriseVpnConnectionV5#peer_subnets}
    */
    readonly peerSubnets?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#psk EnterpriseVpnConnectionV5#psk}
    */
    readonly psk: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#tags EnterpriseVpnConnectionV5#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#tunnel_local_address EnterpriseVpnConnectionV5#tunnel_local_address}
    */
    readonly tunnelLocalAddress?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#tunnel_peer_address EnterpriseVpnConnectionV5#tunnel_peer_address}
    */
    readonly tunnelPeerAddress?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#vpn_type EnterpriseVpnConnectionV5#vpn_type}
    */
    readonly vpnType: string;
    /**
    * ikepolicy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#ikepolicy EnterpriseVpnConnectionV5#ikepolicy}
    */
    readonly ikepolicy?: EnterpriseVpnConnectionV5Ikepolicy;
    /**
    * ipsecpolicy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#ipsecpolicy EnterpriseVpnConnectionV5#ipsecpolicy}
    */
    readonly ipsecpolicy?: EnterpriseVpnConnectionV5Ipsecpolicy;
    /**
    * policy_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#policy_rules EnterpriseVpnConnectionV5#policy_rules}
    */
    readonly policyRules?: EnterpriseVpnConnectionV5PolicyRules[] | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#timeouts EnterpriseVpnConnectionV5#timeouts}
    */
    readonly timeouts?: EnterpriseVpnConnectionV5Timeouts;
}
export interface EnterpriseVpnConnectionV5IkepolicyDpd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#interval EnterpriseVpnConnectionV5#interval}
    */
    readonly interval?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#msg EnterpriseVpnConnectionV5#msg}
    */
    readonly msg?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#timeout EnterpriseVpnConnectionV5#timeout}
    */
    readonly timeout?: number;
}
export declare function enterpriseVpnConnectionV5IkepolicyDpdToTerraform(struct?: EnterpriseVpnConnectionV5IkepolicyDpdOutputReference | EnterpriseVpnConnectionV5IkepolicyDpd): any;
export declare function enterpriseVpnConnectionV5IkepolicyDpdToHclTerraform(struct?: EnterpriseVpnConnectionV5IkepolicyDpdOutputReference | EnterpriseVpnConnectionV5IkepolicyDpd): any;
export declare class EnterpriseVpnConnectionV5IkepolicyDpdOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EnterpriseVpnConnectionV5IkepolicyDpd | undefined;
    set internalValue(value: EnterpriseVpnConnectionV5IkepolicyDpd | undefined);
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
    private _msg?;
    get msg(): string;
    set msg(value: string);
    resetMsg(): void;
    get msgInput(): string | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    resetTimeout(): void;
    get timeoutInput(): number | undefined;
}
export interface EnterpriseVpnConnectionV5Ikepolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#authentication_algorithm EnterpriseVpnConnectionV5#authentication_algorithm}
    */
    readonly authenticationAlgorithm?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#authentication_method EnterpriseVpnConnectionV5#authentication_method}
    */
    readonly authenticationMethod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#dh_group EnterpriseVpnConnectionV5#dh_group}
    */
    readonly dhGroup?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#encryption_algorithm EnterpriseVpnConnectionV5#encryption_algorithm}
    */
    readonly encryptionAlgorithm?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#ike_version EnterpriseVpnConnectionV5#ike_version}
    */
    readonly ikeVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#lifetime_seconds EnterpriseVpnConnectionV5#lifetime_seconds}
    */
    readonly lifetimeSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#local_id EnterpriseVpnConnectionV5#local_id}
    */
    readonly localId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#local_id_type EnterpriseVpnConnectionV5#local_id_type}
    */
    readonly localIdType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#peer_id EnterpriseVpnConnectionV5#peer_id}
    */
    readonly peerId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#peer_id_type EnterpriseVpnConnectionV5#peer_id_type}
    */
    readonly peerIdType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#phase_one_negotiation_mode EnterpriseVpnConnectionV5#phase_one_negotiation_mode}
    */
    readonly phaseOneNegotiationMode?: string;
    /**
    * dpd block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#dpd EnterpriseVpnConnectionV5#dpd}
    */
    readonly dpd?: EnterpriseVpnConnectionV5IkepolicyDpd;
}
export declare function enterpriseVpnConnectionV5IkepolicyToTerraform(struct?: EnterpriseVpnConnectionV5IkepolicyOutputReference | EnterpriseVpnConnectionV5Ikepolicy): any;
export declare function enterpriseVpnConnectionV5IkepolicyToHclTerraform(struct?: EnterpriseVpnConnectionV5IkepolicyOutputReference | EnterpriseVpnConnectionV5Ikepolicy): any;
export declare class EnterpriseVpnConnectionV5IkepolicyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EnterpriseVpnConnectionV5Ikepolicy | undefined;
    set internalValue(value: EnterpriseVpnConnectionV5Ikepolicy | undefined);
    private _authenticationAlgorithm?;
    get authenticationAlgorithm(): string;
    set authenticationAlgorithm(value: string);
    resetAuthenticationAlgorithm(): void;
    get authenticationAlgorithmInput(): string | undefined;
    private _authenticationMethod?;
    get authenticationMethod(): string;
    set authenticationMethod(value: string);
    resetAuthenticationMethod(): void;
    get authenticationMethodInput(): string | undefined;
    private _dhGroup?;
    get dhGroup(): string;
    set dhGroup(value: string);
    resetDhGroup(): void;
    get dhGroupInput(): string | undefined;
    private _encryptionAlgorithm?;
    get encryptionAlgorithm(): string;
    set encryptionAlgorithm(value: string);
    resetEncryptionAlgorithm(): void;
    get encryptionAlgorithmInput(): string | undefined;
    private _ikeVersion?;
    get ikeVersion(): string;
    set ikeVersion(value: string);
    resetIkeVersion(): void;
    get ikeVersionInput(): string | undefined;
    private _lifetimeSeconds?;
    get lifetimeSeconds(): number;
    set lifetimeSeconds(value: number);
    resetLifetimeSeconds(): void;
    get lifetimeSecondsInput(): number | undefined;
    private _localId?;
    get localId(): string;
    set localId(value: string);
    resetLocalId(): void;
    get localIdInput(): string | undefined;
    private _localIdType?;
    get localIdType(): string;
    set localIdType(value: string);
    resetLocalIdType(): void;
    get localIdTypeInput(): string | undefined;
    private _peerId?;
    get peerId(): string;
    set peerId(value: string);
    resetPeerId(): void;
    get peerIdInput(): string | undefined;
    private _peerIdType?;
    get peerIdType(): string;
    set peerIdType(value: string);
    resetPeerIdType(): void;
    get peerIdTypeInput(): string | undefined;
    private _phaseOneNegotiationMode?;
    get phaseOneNegotiationMode(): string;
    set phaseOneNegotiationMode(value: string);
    resetPhaseOneNegotiationMode(): void;
    get phaseOneNegotiationModeInput(): string | undefined;
    private _dpd;
    get dpd(): EnterpriseVpnConnectionV5IkepolicyDpdOutputReference;
    putDpd(value: EnterpriseVpnConnectionV5IkepolicyDpd): void;
    resetDpd(): void;
    get dpdInput(): EnterpriseVpnConnectionV5IkepolicyDpd | undefined;
}
export interface EnterpriseVpnConnectionV5Ipsecpolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#authentication_algorithm EnterpriseVpnConnectionV5#authentication_algorithm}
    */
    readonly authenticationAlgorithm?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#encapsulation_mode EnterpriseVpnConnectionV5#encapsulation_mode}
    */
    readonly encapsulationMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#encryption_algorithm EnterpriseVpnConnectionV5#encryption_algorithm}
    */
    readonly encryptionAlgorithm?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#lifetime_seconds EnterpriseVpnConnectionV5#lifetime_seconds}
    */
    readonly lifetimeSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#pfs EnterpriseVpnConnectionV5#pfs}
    */
    readonly pfs?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#transform_protocol EnterpriseVpnConnectionV5#transform_protocol}
    */
    readonly transformProtocol?: string;
}
export declare function enterpriseVpnConnectionV5IpsecpolicyToTerraform(struct?: EnterpriseVpnConnectionV5IpsecpolicyOutputReference | EnterpriseVpnConnectionV5Ipsecpolicy): any;
export declare function enterpriseVpnConnectionV5IpsecpolicyToHclTerraform(struct?: EnterpriseVpnConnectionV5IpsecpolicyOutputReference | EnterpriseVpnConnectionV5Ipsecpolicy): any;
export declare class EnterpriseVpnConnectionV5IpsecpolicyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EnterpriseVpnConnectionV5Ipsecpolicy | undefined;
    set internalValue(value: EnterpriseVpnConnectionV5Ipsecpolicy | undefined);
    private _authenticationAlgorithm?;
    get authenticationAlgorithm(): string;
    set authenticationAlgorithm(value: string);
    resetAuthenticationAlgorithm(): void;
    get authenticationAlgorithmInput(): string | undefined;
    private _encapsulationMode?;
    get encapsulationMode(): string;
    set encapsulationMode(value: string);
    resetEncapsulationMode(): void;
    get encapsulationModeInput(): string | undefined;
    private _encryptionAlgorithm?;
    get encryptionAlgorithm(): string;
    set encryptionAlgorithm(value: string);
    resetEncryptionAlgorithm(): void;
    get encryptionAlgorithmInput(): string | undefined;
    private _lifetimeSeconds?;
    get lifetimeSeconds(): number;
    set lifetimeSeconds(value: number);
    resetLifetimeSeconds(): void;
    get lifetimeSecondsInput(): number | undefined;
    private _pfs?;
    get pfs(): string;
    set pfs(value: string);
    resetPfs(): void;
    get pfsInput(): string | undefined;
    private _transformProtocol?;
    get transformProtocol(): string;
    set transformProtocol(value: string);
    resetTransformProtocol(): void;
    get transformProtocolInput(): string | undefined;
}
export interface EnterpriseVpnConnectionV5PolicyRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#destination EnterpriseVpnConnectionV5#destination}
    */
    readonly destination?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#source EnterpriseVpnConnectionV5#source}
    */
    readonly source?: string;
}
export declare function enterpriseVpnConnectionV5PolicyRulesToTerraform(struct?: EnterpriseVpnConnectionV5PolicyRules | cdktf.IResolvable): any;
export declare function enterpriseVpnConnectionV5PolicyRulesToHclTerraform(struct?: EnterpriseVpnConnectionV5PolicyRules | cdktf.IResolvable): any;
export declare class EnterpriseVpnConnectionV5PolicyRulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EnterpriseVpnConnectionV5PolicyRules | cdktf.IResolvable | undefined;
    set internalValue(value: EnterpriseVpnConnectionV5PolicyRules | cdktf.IResolvable | undefined);
    private _destination?;
    get destination(): string[];
    set destination(value: string[]);
    resetDestination(): void;
    get destinationInput(): string[] | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
}
export declare class EnterpriseVpnConnectionV5PolicyRulesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EnterpriseVpnConnectionV5PolicyRules[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EnterpriseVpnConnectionV5PolicyRulesOutputReference;
}
export interface EnterpriseVpnConnectionV5Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#create EnterpriseVpnConnectionV5#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#delete EnterpriseVpnConnectionV5#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#update EnterpriseVpnConnectionV5#update}
    */
    readonly update?: string;
}
export declare function enterpriseVpnConnectionV5TimeoutsToTerraform(struct?: EnterpriseVpnConnectionV5Timeouts | cdktf.IResolvable): any;
export declare function enterpriseVpnConnectionV5TimeoutsToHclTerraform(struct?: EnterpriseVpnConnectionV5Timeouts | cdktf.IResolvable): any;
export declare class EnterpriseVpnConnectionV5TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EnterpriseVpnConnectionV5Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: EnterpriseVpnConnectionV5Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5 opentelekomcloud_enterprise_vpn_connection_v5}
*/
export declare class EnterpriseVpnConnectionV5 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_enterprise_vpn_connection_v5";
    /**
    * Generates CDKTF code for importing a EnterpriseVpnConnectionV5 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EnterpriseVpnConnectionV5 to import
    * @param importFromId The id of the existing EnterpriseVpnConnectionV5 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EnterpriseVpnConnectionV5 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_connection_v5 opentelekomcloud_enterprise_vpn_connection_v5} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EnterpriseVpnConnectionV5Config
    */
    constructor(scope: Construct, id: string, config: EnterpriseVpnConnectionV5Config);
    get createdAt(): string;
    private _customerGatewayId?;
    get customerGatewayId(): string;
    set customerGatewayId(value: string);
    get customerGatewayIdInput(): string | undefined;
    private _enableNqa?;
    get enableNqa(): boolean | cdktf.IResolvable;
    set enableNqa(value: boolean | cdktf.IResolvable);
    resetEnableNqa(): void;
    get enableNqaInput(): boolean | cdktf.IResolvable | undefined;
    private _gatewayId?;
    get gatewayId(): string;
    set gatewayId(value: string);
    get gatewayIdInput(): string | undefined;
    private _gatewayIp?;
    get gatewayIp(): string;
    set gatewayIp(value: string);
    get gatewayIpInput(): string | undefined;
    private _haRole?;
    get haRole(): string;
    set haRole(value: string);
    resetHaRole(): void;
    get haRoleInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _peerSubnets?;
    get peerSubnets(): string[];
    set peerSubnets(value: string[]);
    resetPeerSubnets(): void;
    get peerSubnetsInput(): string[] | undefined;
    private _psk?;
    get psk(): string;
    set psk(value: string);
    get pskInput(): string | undefined;
    get region(): string;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tunnelLocalAddress?;
    get tunnelLocalAddress(): string;
    set tunnelLocalAddress(value: string);
    resetTunnelLocalAddress(): void;
    get tunnelLocalAddressInput(): string | undefined;
    private _tunnelPeerAddress?;
    get tunnelPeerAddress(): string;
    set tunnelPeerAddress(value: string);
    resetTunnelPeerAddress(): void;
    get tunnelPeerAddressInput(): string | undefined;
    get updatedAt(): string;
    private _vpnType?;
    get vpnType(): string;
    set vpnType(value: string);
    get vpnTypeInput(): string | undefined;
    private _ikepolicy;
    get ikepolicy(): EnterpriseVpnConnectionV5IkepolicyOutputReference;
    putIkepolicy(value: EnterpriseVpnConnectionV5Ikepolicy): void;
    resetIkepolicy(): void;
    get ikepolicyInput(): EnterpriseVpnConnectionV5Ikepolicy | undefined;
    private _ipsecpolicy;
    get ipsecpolicy(): EnterpriseVpnConnectionV5IpsecpolicyOutputReference;
    putIpsecpolicy(value: EnterpriseVpnConnectionV5Ipsecpolicy): void;
    resetIpsecpolicy(): void;
    get ipsecpolicyInput(): EnterpriseVpnConnectionV5Ipsecpolicy | undefined;
    private _policyRules;
    get policyRules(): EnterpriseVpnConnectionV5PolicyRulesList;
    putPolicyRules(value: EnterpriseVpnConnectionV5PolicyRules[] | cdktf.IResolvable): void;
    resetPolicyRules(): void;
    get policyRulesInput(): cdktf.IResolvable | EnterpriseVpnConnectionV5PolicyRules[] | undefined;
    private _timeouts;
    get timeouts(): EnterpriseVpnConnectionV5TimeoutsOutputReference;
    putTimeouts(value: EnterpriseVpnConnectionV5Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | EnterpriseVpnConnectionV5Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

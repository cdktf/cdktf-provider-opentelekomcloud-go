/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CssClusterRestartV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_restart_v1#cluster_id CssClusterRestartV1#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_restart_v1#id CssClusterRestartV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_restart_v1#timeouts CssClusterRestartV1#timeouts}
    */
    readonly timeouts?: CssClusterRestartV1Timeouts;
}
export interface CssClusterRestartV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_restart_v1#create CssClusterRestartV1#create}
    */
    readonly create?: string;
}
export declare function cssClusterRestartV1TimeoutsToTerraform(struct?: CssClusterRestartV1Timeouts | cdktf.IResolvable): any;
export declare function cssClusterRestartV1TimeoutsToHclTerraform(struct?: CssClusterRestartV1Timeouts | cdktf.IResolvable): any;
export declare class CssClusterRestartV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CssClusterRestartV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: CssClusterRestartV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_restart_v1 opentelekomcloud_css_cluster_restart_v1}
*/
export declare class CssClusterRestartV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_css_cluster_restart_v1";
    /**
    * Generates CDKTF code for importing a CssClusterRestartV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CssClusterRestartV1 to import
    * @param importFromId The id of the existing CssClusterRestartV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_restart_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CssClusterRestartV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_restart_v1 opentelekomcloud_css_cluster_restart_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CssClusterRestartV1Config
    */
    constructor(scope: Construct, id: string, config: CssClusterRestartV1Config);
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get region(): string;
    private _timeouts;
    get timeouts(): CssClusterRestartV1TimeoutsOutputReference;
    putTimeouts(value: CssClusterRestartV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | CssClusterRestartV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

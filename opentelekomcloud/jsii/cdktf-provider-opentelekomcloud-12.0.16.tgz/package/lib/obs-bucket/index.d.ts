/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ObsBucketConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#acl ObsBucket#acl}
    */
    readonly acl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#bucket ObsBucket#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#force_destroy ObsBucket#force_destroy}
    */
    readonly forceDestroy?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#id ObsBucket#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#parallel_fs ObsBucket#parallel_fs}
    */
    readonly parallelFs?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#region ObsBucket#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#storage_class ObsBucket#storage_class}
    */
    readonly storageClass?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#tags ObsBucket#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#user_domain_names ObsBucket#user_domain_names}
    */
    readonly userDomainNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#versioning ObsBucket#versioning}
    */
    readonly versioning?: boolean | cdktf.IResolvable;
    /**
    * cors_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#cors_rule ObsBucket#cors_rule}
    */
    readonly corsRule?: ObsBucketCorsRule[] | cdktf.IResolvable;
    /**
    * event_notifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#event_notifications ObsBucket#event_notifications}
    */
    readonly eventNotifications?: ObsBucketEventNotifications[] | cdktf.IResolvable;
    /**
    * lifecycle_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#lifecycle_rule ObsBucket#lifecycle_rule}
    */
    readonly lifecycleRule?: ObsBucketLifecycleRule[] | cdktf.IResolvable;
    /**
    * logging block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#logging ObsBucket#logging}
    */
    readonly logging?: ObsBucketLogging[] | cdktf.IResolvable;
    /**
    * server_side_encryption block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#server_side_encryption ObsBucket#server_side_encryption}
    */
    readonly serverSideEncryption?: ObsBucketServerSideEncryption;
    /**
    * website block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#website ObsBucket#website}
    */
    readonly website?: ObsBucketWebsite;
    /**
    * worm_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#worm_policy ObsBucket#worm_policy}
    */
    readonly wormPolicy?: ObsBucketWormPolicy;
}
export interface ObsBucketCorsRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#allowed_headers ObsBucket#allowed_headers}
    */
    readonly allowedHeaders?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#allowed_methods ObsBucket#allowed_methods}
    */
    readonly allowedMethods: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#allowed_origins ObsBucket#allowed_origins}
    */
    readonly allowedOrigins: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#expose_headers ObsBucket#expose_headers}
    */
    readonly exposeHeaders?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#max_age_seconds ObsBucket#max_age_seconds}
    */
    readonly maxAgeSeconds?: number;
}
export declare function obsBucketCorsRuleToTerraform(struct?: ObsBucketCorsRule | cdktf.IResolvable): any;
export declare function obsBucketCorsRuleToHclTerraform(struct?: ObsBucketCorsRule | cdktf.IResolvable): any;
export declare class ObsBucketCorsRuleOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObsBucketCorsRule | cdktf.IResolvable | undefined;
    set internalValue(value: ObsBucketCorsRule | cdktf.IResolvable | undefined);
    private _allowedHeaders?;
    get allowedHeaders(): string[];
    set allowedHeaders(value: string[]);
    resetAllowedHeaders(): void;
    get allowedHeadersInput(): string[] | undefined;
    private _allowedMethods?;
    get allowedMethods(): string[];
    set allowedMethods(value: string[]);
    get allowedMethodsInput(): string[] | undefined;
    private _allowedOrigins?;
    get allowedOrigins(): string[];
    set allowedOrigins(value: string[]);
    get allowedOriginsInput(): string[] | undefined;
    private _exposeHeaders?;
    get exposeHeaders(): string[];
    set exposeHeaders(value: string[]);
    resetExposeHeaders(): void;
    get exposeHeadersInput(): string[] | undefined;
    private _maxAgeSeconds?;
    get maxAgeSeconds(): number;
    set maxAgeSeconds(value: number);
    resetMaxAgeSeconds(): void;
    get maxAgeSecondsInput(): number | undefined;
}
export declare class ObsBucketCorsRuleList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ObsBucketCorsRule[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObsBucketCorsRuleOutputReference;
}
export interface ObsBucketEventNotificationsFilterRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#name ObsBucket#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#value ObsBucket#value}
    */
    readonly value?: string;
}
export declare function obsBucketEventNotificationsFilterRuleToTerraform(struct?: ObsBucketEventNotificationsFilterRule | cdktf.IResolvable): any;
export declare function obsBucketEventNotificationsFilterRuleToHclTerraform(struct?: ObsBucketEventNotificationsFilterRule | cdktf.IResolvable): any;
export declare class ObsBucketEventNotificationsFilterRuleOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObsBucketEventNotificationsFilterRule | cdktf.IResolvable | undefined;
    set internalValue(value: ObsBucketEventNotificationsFilterRule | cdktf.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ObsBucketEventNotificationsFilterRuleList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ObsBucketEventNotificationsFilterRule[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObsBucketEventNotificationsFilterRuleOutputReference;
}
export interface ObsBucketEventNotifications {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#events ObsBucket#events}
    */
    readonly events: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#id ObsBucket#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#topic ObsBucket#topic}
    */
    readonly topic: string;
    /**
    * filter_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#filter_rule ObsBucket#filter_rule}
    */
    readonly filterRule?: ObsBucketEventNotificationsFilterRule[] | cdktf.IResolvable;
}
export declare function obsBucketEventNotificationsToTerraform(struct?: ObsBucketEventNotifications | cdktf.IResolvable): any;
export declare function obsBucketEventNotificationsToHclTerraform(struct?: ObsBucketEventNotifications | cdktf.IResolvable): any;
export declare class ObsBucketEventNotificationsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObsBucketEventNotifications | cdktf.IResolvable | undefined;
    set internalValue(value: ObsBucketEventNotifications | cdktf.IResolvable | undefined);
    private _events?;
    get events(): string[];
    set events(value: string[]);
    get eventsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _topic?;
    get topic(): string;
    set topic(value: string);
    get topicInput(): string | undefined;
    private _filterRule;
    get filterRule(): ObsBucketEventNotificationsFilterRuleList;
    putFilterRule(value: ObsBucketEventNotificationsFilterRule[] | cdktf.IResolvable): void;
    resetFilterRule(): void;
    get filterRuleInput(): cdktf.IResolvable | ObsBucketEventNotificationsFilterRule[] | undefined;
}
export declare class ObsBucketEventNotificationsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ObsBucketEventNotifications[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObsBucketEventNotificationsOutputReference;
}
export interface ObsBucketLifecycleRuleAbortIncompleteMultipartUpload {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#days ObsBucket#days}
    */
    readonly days: number;
}
export declare function obsBucketLifecycleRuleAbortIncompleteMultipartUploadToTerraform(struct?: ObsBucketLifecycleRuleAbortIncompleteMultipartUpload | cdktf.IResolvable): any;
export declare function obsBucketLifecycleRuleAbortIncompleteMultipartUploadToHclTerraform(struct?: ObsBucketLifecycleRuleAbortIncompleteMultipartUpload | cdktf.IResolvable): any;
export declare class ObsBucketLifecycleRuleAbortIncompleteMultipartUploadOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObsBucketLifecycleRuleAbortIncompleteMultipartUpload | cdktf.IResolvable | undefined;
    set internalValue(value: ObsBucketLifecycleRuleAbortIncompleteMultipartUpload | cdktf.IResolvable | undefined);
    private _days?;
    get days(): number;
    set days(value: number);
    get daysInput(): number | undefined;
}
export declare class ObsBucketLifecycleRuleAbortIncompleteMultipartUploadList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ObsBucketLifecycleRuleAbortIncompleteMultipartUpload[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObsBucketLifecycleRuleAbortIncompleteMultipartUploadOutputReference;
}
export interface ObsBucketLifecycleRuleExpiration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#days ObsBucket#days}
    */
    readonly days: number;
}
export declare function obsBucketLifecycleRuleExpirationToTerraform(struct?: ObsBucketLifecycleRuleExpiration | cdktf.IResolvable): any;
export declare function obsBucketLifecycleRuleExpirationToHclTerraform(struct?: ObsBucketLifecycleRuleExpiration | cdktf.IResolvable): any;
export declare class ObsBucketLifecycleRuleExpirationOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObsBucketLifecycleRuleExpiration | cdktf.IResolvable | undefined;
    set internalValue(value: ObsBucketLifecycleRuleExpiration | cdktf.IResolvable | undefined);
    private _days?;
    get days(): number;
    set days(value: number);
    get daysInput(): number | undefined;
}
export declare class ObsBucketLifecycleRuleExpirationList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ObsBucketLifecycleRuleExpiration[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObsBucketLifecycleRuleExpirationOutputReference;
}
export interface ObsBucketLifecycleRuleNoncurrentVersionExpiration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#days ObsBucket#days}
    */
    readonly days: number;
}
export declare function obsBucketLifecycleRuleNoncurrentVersionExpirationToTerraform(struct?: ObsBucketLifecycleRuleNoncurrentVersionExpiration | cdktf.IResolvable): any;
export declare function obsBucketLifecycleRuleNoncurrentVersionExpirationToHclTerraform(struct?: ObsBucketLifecycleRuleNoncurrentVersionExpiration | cdktf.IResolvable): any;
export declare class ObsBucketLifecycleRuleNoncurrentVersionExpirationOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObsBucketLifecycleRuleNoncurrentVersionExpiration | cdktf.IResolvable | undefined;
    set internalValue(value: ObsBucketLifecycleRuleNoncurrentVersionExpiration | cdktf.IResolvable | undefined);
    private _days?;
    get days(): number;
    set days(value: number);
    get daysInput(): number | undefined;
}
export declare class ObsBucketLifecycleRuleNoncurrentVersionExpirationList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ObsBucketLifecycleRuleNoncurrentVersionExpiration[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObsBucketLifecycleRuleNoncurrentVersionExpirationOutputReference;
}
export interface ObsBucketLifecycleRuleNoncurrentVersionTransition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#days ObsBucket#days}
    */
    readonly days: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#storage_class ObsBucket#storage_class}
    */
    readonly storageClass: string;
}
export declare function obsBucketLifecycleRuleNoncurrentVersionTransitionToTerraform(struct?: ObsBucketLifecycleRuleNoncurrentVersionTransition | cdktf.IResolvable): any;
export declare function obsBucketLifecycleRuleNoncurrentVersionTransitionToHclTerraform(struct?: ObsBucketLifecycleRuleNoncurrentVersionTransition | cdktf.IResolvable): any;
export declare class ObsBucketLifecycleRuleNoncurrentVersionTransitionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObsBucketLifecycleRuleNoncurrentVersionTransition | cdktf.IResolvable | undefined;
    set internalValue(value: ObsBucketLifecycleRuleNoncurrentVersionTransition | cdktf.IResolvable | undefined);
    private _days?;
    get days(): number;
    set days(value: number);
    get daysInput(): number | undefined;
    private _storageClass?;
    get storageClass(): string;
    set storageClass(value: string);
    get storageClassInput(): string | undefined;
}
export declare class ObsBucketLifecycleRuleNoncurrentVersionTransitionList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ObsBucketLifecycleRuleNoncurrentVersionTransition[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObsBucketLifecycleRuleNoncurrentVersionTransitionOutputReference;
}
export interface ObsBucketLifecycleRuleTag {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#key ObsBucket#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#value ObsBucket#value}
    */
    readonly value: string;
}
export declare function obsBucketLifecycleRuleTagToTerraform(struct?: ObsBucketLifecycleRuleTag | cdktf.IResolvable): any;
export declare function obsBucketLifecycleRuleTagToHclTerraform(struct?: ObsBucketLifecycleRuleTag | cdktf.IResolvable): any;
export declare class ObsBucketLifecycleRuleTagOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObsBucketLifecycleRuleTag | cdktf.IResolvable | undefined;
    set internalValue(value: ObsBucketLifecycleRuleTag | cdktf.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ObsBucketLifecycleRuleTagList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ObsBucketLifecycleRuleTag[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObsBucketLifecycleRuleTagOutputReference;
}
export interface ObsBucketLifecycleRuleTransition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#days ObsBucket#days}
    */
    readonly days: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#storage_class ObsBucket#storage_class}
    */
    readonly storageClass: string;
}
export declare function obsBucketLifecycleRuleTransitionToTerraform(struct?: ObsBucketLifecycleRuleTransition | cdktf.IResolvable): any;
export declare function obsBucketLifecycleRuleTransitionToHclTerraform(struct?: ObsBucketLifecycleRuleTransition | cdktf.IResolvable): any;
export declare class ObsBucketLifecycleRuleTransitionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObsBucketLifecycleRuleTransition | cdktf.IResolvable | undefined;
    set internalValue(value: ObsBucketLifecycleRuleTransition | cdktf.IResolvable | undefined);
    private _days?;
    get days(): number;
    set days(value: number);
    get daysInput(): number | undefined;
    private _storageClass?;
    get storageClass(): string;
    set storageClass(value: string);
    get storageClassInput(): string | undefined;
}
export declare class ObsBucketLifecycleRuleTransitionList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ObsBucketLifecycleRuleTransition[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObsBucketLifecycleRuleTransitionOutputReference;
}
export interface ObsBucketLifecycleRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#enabled ObsBucket#enabled}
    */
    readonly enabled: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#name ObsBucket#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#prefix ObsBucket#prefix}
    */
    readonly prefix?: string;
    /**
    * abort_incomplete_multipart_upload block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#abort_incomplete_multipart_upload ObsBucket#abort_incomplete_multipart_upload}
    */
    readonly abortIncompleteMultipartUpload?: ObsBucketLifecycleRuleAbortIncompleteMultipartUpload[] | cdktf.IResolvable;
    /**
    * expiration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#expiration ObsBucket#expiration}
    */
    readonly expiration?: ObsBucketLifecycleRuleExpiration[] | cdktf.IResolvable;
    /**
    * noncurrent_version_expiration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#noncurrent_version_expiration ObsBucket#noncurrent_version_expiration}
    */
    readonly noncurrentVersionExpiration?: ObsBucketLifecycleRuleNoncurrentVersionExpiration[] | cdktf.IResolvable;
    /**
    * noncurrent_version_transition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#noncurrent_version_transition ObsBucket#noncurrent_version_transition}
    */
    readonly noncurrentVersionTransition?: ObsBucketLifecycleRuleNoncurrentVersionTransition[] | cdktf.IResolvable;
    /**
    * tag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#tag ObsBucket#tag}
    */
    readonly tag?: ObsBucketLifecycleRuleTag[] | cdktf.IResolvable;
    /**
    * transition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#transition ObsBucket#transition}
    */
    readonly transition?: ObsBucketLifecycleRuleTransition[] | cdktf.IResolvable;
}
export declare function obsBucketLifecycleRuleToTerraform(struct?: ObsBucketLifecycleRule | cdktf.IResolvable): any;
export declare function obsBucketLifecycleRuleToHclTerraform(struct?: ObsBucketLifecycleRule | cdktf.IResolvable): any;
export declare class ObsBucketLifecycleRuleOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObsBucketLifecycleRule | cdktf.IResolvable | undefined;
    set internalValue(value: ObsBucketLifecycleRule | cdktf.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    resetPrefix(): void;
    get prefixInput(): string | undefined;
    private _abortIncompleteMultipartUpload;
    get abortIncompleteMultipartUpload(): ObsBucketLifecycleRuleAbortIncompleteMultipartUploadList;
    putAbortIncompleteMultipartUpload(value: ObsBucketLifecycleRuleAbortIncompleteMultipartUpload[] | cdktf.IResolvable): void;
    resetAbortIncompleteMultipartUpload(): void;
    get abortIncompleteMultipartUploadInput(): cdktf.IResolvable | ObsBucketLifecycleRuleAbortIncompleteMultipartUpload[] | undefined;
    private _expiration;
    get expiration(): ObsBucketLifecycleRuleExpirationList;
    putExpiration(value: ObsBucketLifecycleRuleExpiration[] | cdktf.IResolvable): void;
    resetExpiration(): void;
    get expirationInput(): cdktf.IResolvable | ObsBucketLifecycleRuleExpiration[] | undefined;
    private _noncurrentVersionExpiration;
    get noncurrentVersionExpiration(): ObsBucketLifecycleRuleNoncurrentVersionExpirationList;
    putNoncurrentVersionExpiration(value: ObsBucketLifecycleRuleNoncurrentVersionExpiration[] | cdktf.IResolvable): void;
    resetNoncurrentVersionExpiration(): void;
    get noncurrentVersionExpirationInput(): cdktf.IResolvable | ObsBucketLifecycleRuleNoncurrentVersionExpiration[] | undefined;
    private _noncurrentVersionTransition;
    get noncurrentVersionTransition(): ObsBucketLifecycleRuleNoncurrentVersionTransitionList;
    putNoncurrentVersionTransition(value: ObsBucketLifecycleRuleNoncurrentVersionTransition[] | cdktf.IResolvable): void;
    resetNoncurrentVersionTransition(): void;
    get noncurrentVersionTransitionInput(): cdktf.IResolvable | ObsBucketLifecycleRuleNoncurrentVersionTransition[] | undefined;
    private _tag;
    get tag(): ObsBucketLifecycleRuleTagList;
    putTag(value: ObsBucketLifecycleRuleTag[] | cdktf.IResolvable): void;
    resetTag(): void;
    get tagInput(): cdktf.IResolvable | ObsBucketLifecycleRuleTag[] | undefined;
    private _transition;
    get transition(): ObsBucketLifecycleRuleTransitionList;
    putTransition(value: ObsBucketLifecycleRuleTransition[] | cdktf.IResolvable): void;
    resetTransition(): void;
    get transitionInput(): cdktf.IResolvable | ObsBucketLifecycleRuleTransition[] | undefined;
}
export declare class ObsBucketLifecycleRuleList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ObsBucketLifecycleRule[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObsBucketLifecycleRuleOutputReference;
}
export interface ObsBucketLogging {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#agency ObsBucket#agency}
    */
    readonly agency?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#target_bucket ObsBucket#target_bucket}
    */
    readonly targetBucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#target_prefix ObsBucket#target_prefix}
    */
    readonly targetPrefix?: string;
}
export declare function obsBucketLoggingToTerraform(struct?: ObsBucketLogging | cdktf.IResolvable): any;
export declare function obsBucketLoggingToHclTerraform(struct?: ObsBucketLogging | cdktf.IResolvable): any;
export declare class ObsBucketLoggingOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObsBucketLogging | cdktf.IResolvable | undefined;
    set internalValue(value: ObsBucketLogging | cdktf.IResolvable | undefined);
    private _agency?;
    get agency(): string;
    set agency(value: string);
    resetAgency(): void;
    get agencyInput(): string | undefined;
    private _targetBucket?;
    get targetBucket(): string;
    set targetBucket(value: string);
    get targetBucketInput(): string | undefined;
    private _targetPrefix?;
    get targetPrefix(): string;
    set targetPrefix(value: string);
    resetTargetPrefix(): void;
    get targetPrefixInput(): string | undefined;
}
export declare class ObsBucketLoggingList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ObsBucketLogging[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObsBucketLoggingOutputReference;
}
export interface ObsBucketServerSideEncryption {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#algorithm ObsBucket#algorithm}
    */
    readonly algorithm: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#kms_key_id ObsBucket#kms_key_id}
    */
    readonly kmsKeyId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#kms_project_id ObsBucket#kms_project_id}
    */
    readonly kmsProjectId?: string;
}
export declare function obsBucketServerSideEncryptionToTerraform(struct?: ObsBucketServerSideEncryptionOutputReference | ObsBucketServerSideEncryption): any;
export declare function obsBucketServerSideEncryptionToHclTerraform(struct?: ObsBucketServerSideEncryptionOutputReference | ObsBucketServerSideEncryption): any;
export declare class ObsBucketServerSideEncryptionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ObsBucketServerSideEncryption | undefined;
    set internalValue(value: ObsBucketServerSideEncryption | undefined);
    private _algorithm?;
    get algorithm(): string;
    set algorithm(value: string);
    get algorithmInput(): string | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    get kmsKeyIdInput(): string | undefined;
    private _kmsProjectId?;
    get kmsProjectId(): string;
    set kmsProjectId(value: string);
    resetKmsProjectId(): void;
    get kmsProjectIdInput(): string | undefined;
}
export interface ObsBucketWebsite {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#error_document ObsBucket#error_document}
    */
    readonly errorDocument?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#index_document ObsBucket#index_document}
    */
    readonly indexDocument?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#redirect_all_requests_to ObsBucket#redirect_all_requests_to}
    */
    readonly redirectAllRequestsTo?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#routing_rules ObsBucket#routing_rules}
    */
    readonly routingRules?: string;
}
export declare function obsBucketWebsiteToTerraform(struct?: ObsBucketWebsiteOutputReference | ObsBucketWebsite): any;
export declare function obsBucketWebsiteToHclTerraform(struct?: ObsBucketWebsiteOutputReference | ObsBucketWebsite): any;
export declare class ObsBucketWebsiteOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ObsBucketWebsite | undefined;
    set internalValue(value: ObsBucketWebsite | undefined);
    private _errorDocument?;
    get errorDocument(): string;
    set errorDocument(value: string);
    resetErrorDocument(): void;
    get errorDocumentInput(): string | undefined;
    private _indexDocument?;
    get indexDocument(): string;
    set indexDocument(value: string);
    resetIndexDocument(): void;
    get indexDocumentInput(): string | undefined;
    private _redirectAllRequestsTo?;
    get redirectAllRequestsTo(): string;
    set redirectAllRequestsTo(value: string);
    resetRedirectAllRequestsTo(): void;
    get redirectAllRequestsToInput(): string | undefined;
    private _routingRules?;
    get routingRules(): string;
    set routingRules(value: string);
    resetRoutingRules(): void;
    get routingRulesInput(): string | undefined;
}
export interface ObsBucketWormPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#days ObsBucket#days}
    */
    readonly days?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#years ObsBucket#years}
    */
    readonly years?: number;
}
export declare function obsBucketWormPolicyToTerraform(struct?: ObsBucketWormPolicyOutputReference | ObsBucketWormPolicy): any;
export declare function obsBucketWormPolicyToHclTerraform(struct?: ObsBucketWormPolicyOutputReference | ObsBucketWormPolicy): any;
export declare class ObsBucketWormPolicyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ObsBucketWormPolicy | undefined;
    set internalValue(value: ObsBucketWormPolicy | undefined);
    private _days?;
    get days(): number;
    set days(value: number);
    resetDays(): void;
    get daysInput(): number | undefined;
    private _years?;
    get years(): number;
    set years(value: number);
    resetYears(): void;
    get yearsInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket opentelekomcloud_obs_bucket}
*/
export declare class ObsBucket extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_obs_bucket";
    /**
    * Generates CDKTF code for importing a ObsBucket resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ObsBucket to import
    * @param importFromId The id of the existing ObsBucket that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ObsBucket to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket opentelekomcloud_obs_bucket} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ObsBucketConfig
    */
    constructor(scope: Construct, id: string, config: ObsBucketConfig);
    private _acl?;
    get acl(): string;
    set acl(value: string);
    resetAcl(): void;
    get aclInput(): string | undefined;
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    get bucketDomainName(): string;
    get bucketVersion(): string;
    private _forceDestroy?;
    get forceDestroy(): boolean | cdktf.IResolvable;
    set forceDestroy(value: boolean | cdktf.IResolvable);
    resetForceDestroy(): void;
    get forceDestroyInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _parallelFs?;
    get parallelFs(): boolean | cdktf.IResolvable;
    set parallelFs(value: boolean | cdktf.IResolvable);
    resetParallelFs(): void;
    get parallelFsInput(): boolean | cdktf.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _storageClass?;
    get storageClass(): string;
    set storageClass(value: string);
    resetStorageClass(): void;
    get storageClassInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _userDomainNames?;
    get userDomainNames(): string[];
    set userDomainNames(value: string[]);
    resetUserDomainNames(): void;
    get userDomainNamesInput(): string[] | undefined;
    private _versioning?;
    get versioning(): boolean | cdktf.IResolvable;
    set versioning(value: boolean | cdktf.IResolvable);
    resetVersioning(): void;
    get versioningInput(): boolean | cdktf.IResolvable | undefined;
    private _corsRule;
    get corsRule(): ObsBucketCorsRuleList;
    putCorsRule(value: ObsBucketCorsRule[] | cdktf.IResolvable): void;
    resetCorsRule(): void;
    get corsRuleInput(): cdktf.IResolvable | ObsBucketCorsRule[] | undefined;
    private _eventNotifications;
    get eventNotifications(): ObsBucketEventNotificationsList;
    putEventNotifications(value: ObsBucketEventNotifications[] | cdktf.IResolvable): void;
    resetEventNotifications(): void;
    get eventNotificationsInput(): cdktf.IResolvable | ObsBucketEventNotifications[] | undefined;
    private _lifecycleRule;
    get lifecycleRule(): ObsBucketLifecycleRuleList;
    putLifecycleRule(value: ObsBucketLifecycleRule[] | cdktf.IResolvable): void;
    resetLifecycleRule(): void;
    get lifecycleRuleInput(): cdktf.IResolvable | ObsBucketLifecycleRule[] | undefined;
    private _logging;
    get logging(): ObsBucketLoggingList;
    putLogging(value: ObsBucketLogging[] | cdktf.IResolvable): void;
    resetLogging(): void;
    get loggingInput(): cdktf.IResolvable | ObsBucketLogging[] | undefined;
    private _serverSideEncryption;
    get serverSideEncryption(): ObsBucketServerSideEncryptionOutputReference;
    putServerSideEncryption(value: ObsBucketServerSideEncryption): void;
    resetServerSideEncryption(): void;
    get serverSideEncryptionInput(): ObsBucketServerSideEncryption | undefined;
    private _website;
    get website(): ObsBucketWebsiteOutputReference;
    putWebsite(value: ObsBucketWebsite): void;
    resetWebsite(): void;
    get websiteInput(): ObsBucketWebsite | undefined;
    private _wormPolicy;
    get wormPolicy(): ObsBucketWormPolicyOutputReference;
    putWormPolicy(value: ObsBucketWormPolicy): void;
    resetWormPolicy(): void;
    get wormPolicyInput(): ObsBucketWormPolicy | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

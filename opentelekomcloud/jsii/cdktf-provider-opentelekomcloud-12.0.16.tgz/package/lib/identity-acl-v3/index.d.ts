/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface IdentityAclV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_acl_v3#id IdentityAclV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_acl_v3#type IdentityAclV3#type}
    */
    readonly type: string;
    /**
    * ip_cidrs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_acl_v3#ip_cidrs IdentityAclV3#ip_cidrs}
    */
    readonly ipCidrs?: IdentityAclV3IpCidrs[] | cdktf.IResolvable;
    /**
    * ip_ranges block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_acl_v3#ip_ranges IdentityAclV3#ip_ranges}
    */
    readonly ipRanges?: IdentityAclV3IpRanges[] | cdktf.IResolvable;
}
export interface IdentityAclV3IpCidrs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_acl_v3#cidr IdentityAclV3#cidr}
    */
    readonly cidr: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_acl_v3#description IdentityAclV3#description}
    */
    readonly description?: string;
}
export declare function identityAclV3IpCidrsToTerraform(struct?: IdentityAclV3IpCidrs | cdktf.IResolvable): any;
export declare function identityAclV3IpCidrsToHclTerraform(struct?: IdentityAclV3IpCidrs | cdktf.IResolvable): any;
export declare class IdentityAclV3IpCidrsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IdentityAclV3IpCidrs | cdktf.IResolvable | undefined;
    set internalValue(value: IdentityAclV3IpCidrs | cdktf.IResolvable | undefined);
    private _cidr?;
    get cidr(): string;
    set cidr(value: string);
    get cidrInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
}
export declare class IdentityAclV3IpCidrsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: IdentityAclV3IpCidrs[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IdentityAclV3IpCidrsOutputReference;
}
export interface IdentityAclV3IpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_acl_v3#description IdentityAclV3#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_acl_v3#range IdentityAclV3#range}
    */
    readonly range: string;
}
export declare function identityAclV3IpRangesToTerraform(struct?: IdentityAclV3IpRanges | cdktf.IResolvable): any;
export declare function identityAclV3IpRangesToHclTerraform(struct?: IdentityAclV3IpRanges | cdktf.IResolvable): any;
export declare class IdentityAclV3IpRangesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IdentityAclV3IpRanges | cdktf.IResolvable | undefined;
    set internalValue(value: IdentityAclV3IpRanges | cdktf.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _range?;
    get range(): string;
    set range(value: string);
    get rangeInput(): string | undefined;
}
export declare class IdentityAclV3IpRangesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: IdentityAclV3IpRanges[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IdentityAclV3IpRangesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_acl_v3 opentelekomcloud_identity_acl_v3}
*/
export declare class IdentityAclV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_identity_acl_v3";
    /**
    * Generates CDKTF code for importing a IdentityAclV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IdentityAclV3 to import
    * @param importFromId The id of the existing IdentityAclV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_acl_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IdentityAclV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_acl_v3 opentelekomcloud_identity_acl_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IdentityAclV3Config
    */
    constructor(scope: Construct, id: string, config: IdentityAclV3Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _ipCidrs;
    get ipCidrs(): IdentityAclV3IpCidrsList;
    putIpCidrs(value: IdentityAclV3IpCidrs[] | cdktf.IResolvable): void;
    resetIpCidrs(): void;
    get ipCidrsInput(): cdktf.IResolvable | IdentityAclV3IpCidrs[] | undefined;
    private _ipRanges;
    get ipRanges(): IdentityAclV3IpRangesList;
    putIpRanges(value: IdentityAclV3IpRanges[] | cdktf.IResolvable): void;
    resetIpRanges(): void;
    get ipRangesInput(): cdktf.IResolvable | IdentityAclV3IpRanges[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

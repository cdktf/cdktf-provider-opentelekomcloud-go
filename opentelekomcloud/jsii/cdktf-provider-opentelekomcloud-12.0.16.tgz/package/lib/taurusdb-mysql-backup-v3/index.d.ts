/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface TaurusdbMysqlBackupV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_backup_v3#description TaurusdbMysqlBackupV3#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_backup_v3#id TaurusdbMysqlBackupV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_backup_v3#instance_id TaurusdbMysqlBackupV3#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_backup_v3#name TaurusdbMysqlBackupV3#name}
    */
    readonly name: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_backup_v3#timeouts TaurusdbMysqlBackupV3#timeouts}
    */
    readonly timeouts?: TaurusdbMysqlBackupV3Timeouts;
}
export interface TaurusdbMysqlBackupV3Datastore {
}
export declare function taurusdbMysqlBackupV3DatastoreToTerraform(struct?: TaurusdbMysqlBackupV3Datastore): any;
export declare function taurusdbMysqlBackupV3DatastoreToHclTerraform(struct?: TaurusdbMysqlBackupV3Datastore): any;
export declare class TaurusdbMysqlBackupV3DatastoreOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): TaurusdbMysqlBackupV3Datastore | undefined;
    set internalValue(value: TaurusdbMysqlBackupV3Datastore | undefined);
    get type(): string;
    get version(): string;
}
export declare class TaurusdbMysqlBackupV3DatastoreList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): TaurusdbMysqlBackupV3DatastoreOutputReference;
}
export interface TaurusdbMysqlBackupV3Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_backup_v3#create TaurusdbMysqlBackupV3#create}
    */
    readonly create?: string;
}
export declare function taurusdbMysqlBackupV3TimeoutsToTerraform(struct?: TaurusdbMysqlBackupV3Timeouts | cdktf.IResolvable): any;
export declare function taurusdbMysqlBackupV3TimeoutsToHclTerraform(struct?: TaurusdbMysqlBackupV3Timeouts | cdktf.IResolvable): any;
export declare class TaurusdbMysqlBackupV3TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TaurusdbMysqlBackupV3Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: TaurusdbMysqlBackupV3Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_backup_v3 opentelekomcloud_taurusdb_mysql_backup_v3}
*/
export declare class TaurusdbMysqlBackupV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_taurusdb_mysql_backup_v3";
    /**
    * Generates CDKTF code for importing a TaurusdbMysqlBackupV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TaurusdbMysqlBackupV3 to import
    * @param importFromId The id of the existing TaurusdbMysqlBackupV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_backup_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TaurusdbMysqlBackupV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_backup_v3 opentelekomcloud_taurusdb_mysql_backup_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TaurusdbMysqlBackupV3Config
    */
    constructor(scope: Construct, id: string, config: TaurusdbMysqlBackupV3Config);
    get beginTime(): string;
    private _datastore;
    get datastore(): TaurusdbMysqlBackupV3DatastoreList;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get endTime(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get region(): string;
    get size(): number;
    get takeUpTime(): number;
    private _timeouts;
    get timeouts(): TaurusdbMysqlBackupV3TimeoutsOutputReference;
    putTimeouts(value: TaurusdbMysqlBackupV3Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | TaurusdbMysqlBackupV3Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

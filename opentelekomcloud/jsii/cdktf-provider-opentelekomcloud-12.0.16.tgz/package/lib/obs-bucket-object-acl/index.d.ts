/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ObsBucketObjectAclConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_object_acl#bucket ObsBucketObjectAcl#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_object_acl#id ObsBucketObjectAcl#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_object_acl#key ObsBucketObjectAcl#key}
    */
    readonly key: string;
    /**
    * account_permission block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_object_acl#account_permission ObsBucketObjectAcl#account_permission}
    */
    readonly accountPermission?: ObsBucketObjectAclAccountPermission[] | cdktf.IResolvable;
    /**
    * public_permission block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_object_acl#public_permission ObsBucketObjectAcl#public_permission}
    */
    readonly publicPermission?: ObsBucketObjectAclPublicPermission;
}
export interface ObsBucketObjectAclOwnerPermission {
}
export declare function obsBucketObjectAclOwnerPermissionToTerraform(struct?: ObsBucketObjectAclOwnerPermission): any;
export declare function obsBucketObjectAclOwnerPermissionToHclTerraform(struct?: ObsBucketObjectAclOwnerPermission): any;
export declare class ObsBucketObjectAclOwnerPermissionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObsBucketObjectAclOwnerPermission | undefined;
    set internalValue(value: ObsBucketObjectAclOwnerPermission | undefined);
    get accessToAcl(): string[];
    get accessToObject(): string[];
}
export declare class ObsBucketObjectAclOwnerPermissionList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObsBucketObjectAclOwnerPermissionOutputReference;
}
export interface ObsBucketObjectAclAccountPermission {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_object_acl#access_to_acl ObsBucketObjectAcl#access_to_acl}
    */
    readonly accessToAcl?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_object_acl#access_to_object ObsBucketObjectAcl#access_to_object}
    */
    readonly accessToObject?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_object_acl#account_id ObsBucketObjectAcl#account_id}
    */
    readonly accountId: string;
}
export declare function obsBucketObjectAclAccountPermissionToTerraform(struct?: ObsBucketObjectAclAccountPermission | cdktf.IResolvable): any;
export declare function obsBucketObjectAclAccountPermissionToHclTerraform(struct?: ObsBucketObjectAclAccountPermission | cdktf.IResolvable): any;
export declare class ObsBucketObjectAclAccountPermissionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObsBucketObjectAclAccountPermission | cdktf.IResolvable | undefined;
    set internalValue(value: ObsBucketObjectAclAccountPermission | cdktf.IResolvable | undefined);
    private _accessToAcl?;
    get accessToAcl(): string[];
    set accessToAcl(value: string[]);
    resetAccessToAcl(): void;
    get accessToAclInput(): string[] | undefined;
    private _accessToObject?;
    get accessToObject(): string[];
    set accessToObject(value: string[]);
    resetAccessToObject(): void;
    get accessToObjectInput(): string[] | undefined;
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
}
export declare class ObsBucketObjectAclAccountPermissionList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ObsBucketObjectAclAccountPermission[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObsBucketObjectAclAccountPermissionOutputReference;
}
export interface ObsBucketObjectAclPublicPermission {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_object_acl#access_to_acl ObsBucketObjectAcl#access_to_acl}
    */
    readonly accessToAcl?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_object_acl#access_to_object ObsBucketObjectAcl#access_to_object}
    */
    readonly accessToObject?: string[];
}
export declare function obsBucketObjectAclPublicPermissionToTerraform(struct?: ObsBucketObjectAclPublicPermissionOutputReference | ObsBucketObjectAclPublicPermission): any;
export declare function obsBucketObjectAclPublicPermissionToHclTerraform(struct?: ObsBucketObjectAclPublicPermissionOutputReference | ObsBucketObjectAclPublicPermission): any;
export declare class ObsBucketObjectAclPublicPermissionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ObsBucketObjectAclPublicPermission | undefined;
    set internalValue(value: ObsBucketObjectAclPublicPermission | undefined);
    private _accessToAcl?;
    get accessToAcl(): string[];
    set accessToAcl(value: string[]);
    resetAccessToAcl(): void;
    get accessToAclInput(): string[] | undefined;
    private _accessToObject?;
    get accessToObject(): string[];
    set accessToObject(value: string[]);
    resetAccessToObject(): void;
    get accessToObjectInput(): string[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_object_acl opentelekomcloud_obs_bucket_object_acl}
*/
export declare class ObsBucketObjectAcl extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_obs_bucket_object_acl";
    /**
    * Generates CDKTF code for importing a ObsBucketObjectAcl resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ObsBucketObjectAcl to import
    * @param importFromId The id of the existing ObsBucketObjectAcl that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_object_acl#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ObsBucketObjectAcl to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_object_acl opentelekomcloud_obs_bucket_object_acl} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ObsBucketObjectAclConfig
    */
    constructor(scope: Construct, id: string, config: ObsBucketObjectAclConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _ownerPermission;
    get ownerPermission(): ObsBucketObjectAclOwnerPermissionList;
    get region(): string;
    private _accountPermission;
    get accountPermission(): ObsBucketObjectAclAccountPermissionList;
    putAccountPermission(value: ObsBucketObjectAclAccountPermission[] | cdktf.IResolvable): void;
    resetAccountPermission(): void;
    get accountPermissionInput(): cdktf.IResolvable | ObsBucketObjectAclAccountPermission[] | undefined;
    private _publicPermission;
    get publicPermission(): ObsBucketObjectAclPublicPermissionOutputReference;
    putPublicPermission(value: ObsBucketObjectAclPublicPermission): void;
    resetPublicPermission(): void;
    get publicPermissionInput(): ObsBucketObjectAclPublicPermission | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ObsBucketInventoryConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_inventory#bucket ObsBucketInventory#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_inventory#configuration_id ObsBucketInventory#configuration_id}
    */
    readonly configurationId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_inventory#filter_prefix ObsBucketInventory#filter_prefix}
    */
    readonly filterPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_inventory#frequency ObsBucketInventory#frequency}
    */
    readonly frequency: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_inventory#id ObsBucketInventory#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_inventory#included_object_versions ObsBucketInventory#included_object_versions}
    */
    readonly includedObjectVersions: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_inventory#is_enabled ObsBucketInventory#is_enabled}
    */
    readonly isEnabled: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_inventory#optional_fields ObsBucketInventory#optional_fields}
    */
    readonly optionalFields?: string[];
    /**
    * destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_inventory#destination ObsBucketInventory#destination}
    */
    readonly destination: ObsBucketInventoryDestination;
}
export interface ObsBucketInventoryDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_inventory#bucket ObsBucketInventory#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_inventory#format ObsBucketInventory#format}
    */
    readonly format: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_inventory#prefix ObsBucketInventory#prefix}
    */
    readonly prefix?: string;
}
export declare function obsBucketInventoryDestinationToTerraform(struct?: ObsBucketInventoryDestinationOutputReference | ObsBucketInventoryDestination): any;
export declare function obsBucketInventoryDestinationToHclTerraform(struct?: ObsBucketInventoryDestinationOutputReference | ObsBucketInventoryDestination): any;
export declare class ObsBucketInventoryDestinationOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ObsBucketInventoryDestination | undefined;
    set internalValue(value: ObsBucketInventoryDestination | undefined);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _format?;
    get format(): string;
    set format(value: string);
    get formatInput(): string | undefined;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    resetPrefix(): void;
    get prefixInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_inventory opentelekomcloud_obs_bucket_inventory}
*/
export declare class ObsBucketInventory extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_obs_bucket_inventory";
    /**
    * Generates CDKTF code for importing a ObsBucketInventory resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ObsBucketInventory to import
    * @param importFromId The id of the existing ObsBucketInventory that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_inventory#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ObsBucketInventory to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_inventory opentelekomcloud_obs_bucket_inventory} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ObsBucketInventoryConfig
    */
    constructor(scope: Construct, id: string, config: ObsBucketInventoryConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _configurationId?;
    get configurationId(): string;
    set configurationId(value: string);
    get configurationIdInput(): string | undefined;
    private _filterPrefix?;
    get filterPrefix(): string;
    set filterPrefix(value: string);
    resetFilterPrefix(): void;
    get filterPrefixInput(): string | undefined;
    private _frequency?;
    get frequency(): string;
    set frequency(value: string);
    get frequencyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _includedObjectVersions?;
    get includedObjectVersions(): string;
    set includedObjectVersions(value: string);
    get includedObjectVersionsInput(): string | undefined;
    private _isEnabled?;
    get isEnabled(): boolean | cdktf.IResolvable;
    set isEnabled(value: boolean | cdktf.IResolvable);
    get isEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _optionalFields?;
    get optionalFields(): string[];
    set optionalFields(value: string[]);
    resetOptionalFields(): void;
    get optionalFieldsInput(): string[] | undefined;
    get region(): string;
    private _destination;
    get destination(): ObsBucketInventoryDestinationOutputReference;
    putDestination(value: ObsBucketInventoryDestination): void;
    get destinationInput(): ObsBucketInventoryDestination | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

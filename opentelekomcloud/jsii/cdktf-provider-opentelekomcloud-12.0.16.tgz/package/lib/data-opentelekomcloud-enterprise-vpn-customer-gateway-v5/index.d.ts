/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudEnterpriseVpnCustomerGatewayV5Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/enterprise_vpn_customer_gateway_v5#id DataOpentelekomcloudEnterpriseVpnCustomerGatewayV5#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/enterprise_vpn_customer_gateway_v5 opentelekomcloud_enterprise_vpn_customer_gateway_v5}
*/
export declare class DataOpentelekomcloudEnterpriseVpnCustomerGatewayV5 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_enterprise_vpn_customer_gateway_v5";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudEnterpriseVpnCustomerGatewayV5 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudEnterpriseVpnCustomerGatewayV5 to import
    * @param importFromId The id of the existing DataOpentelekomcloudEnterpriseVpnCustomerGatewayV5 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/enterprise_vpn_customer_gateway_v5#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudEnterpriseVpnCustomerGatewayV5 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/enterprise_vpn_customer_gateway_v5 opentelekomcloud_enterprise_vpn_customer_gateway_v5} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudEnterpriseVpnCustomerGatewayV5Config
    */
    constructor(scope: Construct, id: string, config: DataOpentelekomcloudEnterpriseVpnCustomerGatewayV5Config);
    get asn(): number;
    get createdAt(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get idType(): string;
    get idValue(): string;
    get ip(): string;
    get name(): string;
    get region(): string;
    get routeMode(): string;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

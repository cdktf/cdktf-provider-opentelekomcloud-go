/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudCesEventsV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_events_v1#event_name DataOpentelekomcloudCesEventsV1#event_name}
    */
    readonly eventName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_events_v1#event_type DataOpentelekomcloudCesEventsV1#event_type}
    */
    readonly eventType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_events_v1#from DataOpentelekomcloudCesEventsV1#from}
    */
    readonly from?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_events_v1#id DataOpentelekomcloudCesEventsV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_events_v1#limit DataOpentelekomcloudCesEventsV1#limit}
    */
    readonly limit?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_events_v1#to DataOpentelekomcloudCesEventsV1#to}
    */
    readonly to?: number;
}
export interface DataOpentelekomcloudCesEventsV1Events {
}
export declare function dataOpentelekomcloudCesEventsV1EventsToTerraform(struct?: DataOpentelekomcloudCesEventsV1Events): any;
export declare function dataOpentelekomcloudCesEventsV1EventsToHclTerraform(struct?: DataOpentelekomcloudCesEventsV1Events): any;
export declare class DataOpentelekomcloudCesEventsV1EventsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudCesEventsV1Events | undefined;
    set internalValue(value: DataOpentelekomcloudCesEventsV1Events | undefined);
    get eventCount(): number;
    get eventName(): string;
    get eventType(): string;
    get latestEventSource(): string;
    get latestOccurTime(): number;
}
export declare class DataOpentelekomcloudCesEventsV1EventsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudCesEventsV1EventsOutputReference;
}
export interface DataOpentelekomcloudCesEventsV1MetaData {
}
export declare function dataOpentelekomcloudCesEventsV1MetaDataToTerraform(struct?: DataOpentelekomcloudCesEventsV1MetaData): any;
export declare function dataOpentelekomcloudCesEventsV1MetaDataToHclTerraform(struct?: DataOpentelekomcloudCesEventsV1MetaData): any;
export declare class DataOpentelekomcloudCesEventsV1MetaDataOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudCesEventsV1MetaData | undefined;
    set internalValue(value: DataOpentelekomcloudCesEventsV1MetaData | undefined);
    get total(): number;
}
export declare class DataOpentelekomcloudCesEventsV1MetaDataList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudCesEventsV1MetaDataOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_events_v1 opentelekomcloud_ces_events_v1}
*/
export declare class DataOpentelekomcloudCesEventsV1 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_ces_events_v1";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudCesEventsV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudCesEventsV1 to import
    * @param importFromId The id of the existing DataOpentelekomcloudCesEventsV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_events_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudCesEventsV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_events_v1 opentelekomcloud_ces_events_v1} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudCesEventsV1Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudCesEventsV1Config);
    private _eventName?;
    get eventName(): string;
    set eventName(value: string);
    resetEventName(): void;
    get eventNameInput(): string | undefined;
    private _eventType?;
    get eventType(): string;
    set eventType(value: string);
    resetEventType(): void;
    get eventTypeInput(): string | undefined;
    private _events;
    get events(): DataOpentelekomcloudCesEventsV1EventsList;
    private _from?;
    get from(): number;
    set from(value: number);
    resetFrom(): void;
    get fromInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _metaData;
    get metaData(): DataOpentelekomcloudCesEventsV1MetaDataList;
    private _to?;
    get to(): number;
    set to(value: number);
    resetTo(): void;
    get toInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface PrivateNatSnatRuleV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_snat_rule_v3#cidr PrivateNatSnatRuleV3#cidr}
    */
    readonly cidr?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_snat_rule_v3#description PrivateNatSnatRuleV3#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_snat_rule_v3#gateway_id PrivateNatSnatRuleV3#gateway_id}
    */
    readonly gatewayId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_snat_rule_v3#id PrivateNatSnatRuleV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_snat_rule_v3#transit_ip_ids PrivateNatSnatRuleV3#transit_ip_ids}
    */
    readonly transitIpIds: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_snat_rule_v3#virsubnet_id PrivateNatSnatRuleV3#virsubnet_id}
    */
    readonly virsubnetId?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_snat_rule_v3#timeouts PrivateNatSnatRuleV3#timeouts}
    */
    readonly timeouts?: PrivateNatSnatRuleV3Timeouts;
}
export interface PrivateNatSnatRuleV3TransitIpAssociations {
}
export declare function privateNatSnatRuleV3TransitIpAssociationsToTerraform(struct?: PrivateNatSnatRuleV3TransitIpAssociations): any;
export declare function privateNatSnatRuleV3TransitIpAssociationsToHclTerraform(struct?: PrivateNatSnatRuleV3TransitIpAssociations): any;
export declare class PrivateNatSnatRuleV3TransitIpAssociationsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PrivateNatSnatRuleV3TransitIpAssociations | undefined;
    set internalValue(value: PrivateNatSnatRuleV3TransitIpAssociations | undefined);
    get transitIpAddress(): string;
    get transitIpId(): string;
}
export declare class PrivateNatSnatRuleV3TransitIpAssociationsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PrivateNatSnatRuleV3TransitIpAssociationsOutputReference;
}
export interface PrivateNatSnatRuleV3Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_snat_rule_v3#create PrivateNatSnatRuleV3#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_snat_rule_v3#delete PrivateNatSnatRuleV3#delete}
    */
    readonly delete?: string;
}
export declare function privateNatSnatRuleV3TimeoutsToTerraform(struct?: PrivateNatSnatRuleV3Timeouts | cdktf.IResolvable): any;
export declare function privateNatSnatRuleV3TimeoutsToHclTerraform(struct?: PrivateNatSnatRuleV3Timeouts | cdktf.IResolvable): any;
export declare class PrivateNatSnatRuleV3TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PrivateNatSnatRuleV3Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: PrivateNatSnatRuleV3Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_snat_rule_v3 opentelekomcloud_private_nat_snat_rule_v3}
*/
export declare class PrivateNatSnatRuleV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_private_nat_snat_rule_v3";
    /**
    * Generates CDKTF code for importing a PrivateNatSnatRuleV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PrivateNatSnatRuleV3 to import
    * @param importFromId The id of the existing PrivateNatSnatRuleV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_snat_rule_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PrivateNatSnatRuleV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_snat_rule_v3 opentelekomcloud_private_nat_snat_rule_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PrivateNatSnatRuleV3Config
    */
    constructor(scope: Construct, id: string, config: PrivateNatSnatRuleV3Config);
    private _cidr?;
    get cidr(): string;
    set cidr(value: string);
    resetCidr(): void;
    get cidrInput(): string | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get enterpriseProjectId(): string;
    private _gatewayId?;
    get gatewayId(): string;
    set gatewayId(value: string);
    get gatewayIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get projectId(): string;
    get status(): string;
    private _transitIpAssociations;
    get transitIpAssociations(): PrivateNatSnatRuleV3TransitIpAssociationsList;
    private _transitIpIds?;
    get transitIpIds(): string[];
    set transitIpIds(value: string[]);
    get transitIpIdsInput(): string[] | undefined;
    get updatedAt(): string;
    private _virsubnetId?;
    get virsubnetId(): string;
    set virsubnetId(value: string);
    resetVirsubnetId(): void;
    get virsubnetIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): PrivateNatSnatRuleV3TimeoutsOutputReference;
    putTimeouts(value: PrivateNatSnatRuleV3Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | PrivateNatSnatRuleV3Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

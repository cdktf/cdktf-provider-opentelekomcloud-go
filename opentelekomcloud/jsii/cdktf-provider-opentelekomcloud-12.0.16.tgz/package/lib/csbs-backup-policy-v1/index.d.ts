/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CsbsBackupPolicyV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1#common CsbsBackupPolicyV1#common}
    */
    readonly common?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1#description CsbsBackupPolicyV1#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1#id CsbsBackupPolicyV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1#name CsbsBackupPolicyV1#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1#provider_id CsbsBackupPolicyV1#provider_id}
    */
    readonly providerId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1#region CsbsBackupPolicyV1#region}
    */
    readonly region?: string;
    /**
    * resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1#resource CsbsBackupPolicyV1#resource}
    */
    readonly resource: CsbsBackupPolicyV1Resource[] | cdktf.IResolvable;
    /**
    * scheduled_operation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1#scheduled_operation CsbsBackupPolicyV1#scheduled_operation}
    */
    readonly scheduledOperation: CsbsBackupPolicyV1ScheduledOperation;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1#tags CsbsBackupPolicyV1#tags}
    */
    readonly tags?: CsbsBackupPolicyV1Tags[] | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1#timeouts CsbsBackupPolicyV1#timeouts}
    */
    readonly timeouts?: CsbsBackupPolicyV1Timeouts;
}
export interface CsbsBackupPolicyV1Resource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1#id CsbsBackupPolicyV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1#name CsbsBackupPolicyV1#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1#type CsbsBackupPolicyV1#type}
    */
    readonly type: string;
}
export declare function csbsBackupPolicyV1ResourceToTerraform(struct?: CsbsBackupPolicyV1Resource | cdktf.IResolvable): any;
export declare function csbsBackupPolicyV1ResourceToHclTerraform(struct?: CsbsBackupPolicyV1Resource | cdktf.IResolvable): any;
export declare class CsbsBackupPolicyV1ResourceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CsbsBackupPolicyV1Resource | cdktf.IResolvable | undefined;
    set internalValue(value: CsbsBackupPolicyV1Resource | cdktf.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class CsbsBackupPolicyV1ResourceList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: CsbsBackupPolicyV1Resource[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CsbsBackupPolicyV1ResourceOutputReference;
}
export interface CsbsBackupPolicyV1ScheduledOperation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1#day_backups CsbsBackupPolicyV1#day_backups}
    */
    readonly dayBackups?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1#description CsbsBackupPolicyV1#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1#enabled CsbsBackupPolicyV1#enabled}
    */
    readonly enabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1#max_backups CsbsBackupPolicyV1#max_backups}
    */
    readonly maxBackups?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1#month_backups CsbsBackupPolicyV1#month_backups}
    */
    readonly monthBackups?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1#name CsbsBackupPolicyV1#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1#operation_type CsbsBackupPolicyV1#operation_type}
    */
    readonly operationType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1#permanent CsbsBackupPolicyV1#permanent}
    */
    readonly permanent?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1#retention_duration_days CsbsBackupPolicyV1#retention_duration_days}
    */
    readonly retentionDurationDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1#timezone CsbsBackupPolicyV1#timezone}
    */
    readonly timezone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1#trigger_pattern CsbsBackupPolicyV1#trigger_pattern}
    */
    readonly triggerPattern: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1#week_backups CsbsBackupPolicyV1#week_backups}
    */
    readonly weekBackups?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1#year_backups CsbsBackupPolicyV1#year_backups}
    */
    readonly yearBackups?: number;
}
export declare function csbsBackupPolicyV1ScheduledOperationToTerraform(struct?: CsbsBackupPolicyV1ScheduledOperationOutputReference | CsbsBackupPolicyV1ScheduledOperation): any;
export declare function csbsBackupPolicyV1ScheduledOperationToHclTerraform(struct?: CsbsBackupPolicyV1ScheduledOperationOutputReference | CsbsBackupPolicyV1ScheduledOperation): any;
export declare class CsbsBackupPolicyV1ScheduledOperationOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CsbsBackupPolicyV1ScheduledOperation | undefined;
    set internalValue(value: CsbsBackupPolicyV1ScheduledOperation | undefined);
    private _dayBackups?;
    get dayBackups(): number;
    set dayBackups(value: number);
    resetDayBackups(): void;
    get dayBackupsInput(): number | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    get id(): string;
    private _maxBackups?;
    get maxBackups(): number;
    set maxBackups(value: number);
    resetMaxBackups(): void;
    get maxBackupsInput(): number | undefined;
    private _monthBackups?;
    get monthBackups(): number;
    set monthBackups(value: number);
    resetMonthBackups(): void;
    get monthBackupsInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _operationType?;
    get operationType(): string;
    set operationType(value: string);
    get operationTypeInput(): string | undefined;
    private _permanent?;
    get permanent(): boolean | cdktf.IResolvable;
    set permanent(value: boolean | cdktf.IResolvable);
    resetPermanent(): void;
    get permanentInput(): boolean | cdktf.IResolvable | undefined;
    private _retentionDurationDays?;
    get retentionDurationDays(): number;
    set retentionDurationDays(value: number);
    resetRetentionDurationDays(): void;
    get retentionDurationDaysInput(): number | undefined;
    private _timezone?;
    get timezone(): string;
    set timezone(value: string);
    resetTimezone(): void;
    get timezoneInput(): string | undefined;
    get triggerId(): string;
    get triggerName(): string;
    private _triggerPattern?;
    get triggerPattern(): string;
    set triggerPattern(value: string);
    get triggerPatternInput(): string | undefined;
    get triggerType(): string;
    private _weekBackups?;
    get weekBackups(): number;
    set weekBackups(value: number);
    resetWeekBackups(): void;
    get weekBackupsInput(): number | undefined;
    private _yearBackups?;
    get yearBackups(): number;
    set yearBackups(value: number);
    resetYearBackups(): void;
    get yearBackupsInput(): number | undefined;
}
export interface CsbsBackupPolicyV1Tags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1#key CsbsBackupPolicyV1#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1#value CsbsBackupPolicyV1#value}
    */
    readonly value: string;
}
export declare function csbsBackupPolicyV1TagsToTerraform(struct?: CsbsBackupPolicyV1Tags | cdktf.IResolvable): any;
export declare function csbsBackupPolicyV1TagsToHclTerraform(struct?: CsbsBackupPolicyV1Tags | cdktf.IResolvable): any;
export declare class CsbsBackupPolicyV1TagsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CsbsBackupPolicyV1Tags | cdktf.IResolvable | undefined;
    set internalValue(value: CsbsBackupPolicyV1Tags | cdktf.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class CsbsBackupPolicyV1TagsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: CsbsBackupPolicyV1Tags[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CsbsBackupPolicyV1TagsOutputReference;
}
export interface CsbsBackupPolicyV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1#create CsbsBackupPolicyV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1#delete CsbsBackupPolicyV1#delete}
    */
    readonly delete?: string;
}
export declare function csbsBackupPolicyV1TimeoutsToTerraform(struct?: CsbsBackupPolicyV1Timeouts | cdktf.IResolvable): any;
export declare function csbsBackupPolicyV1TimeoutsToHclTerraform(struct?: CsbsBackupPolicyV1Timeouts | cdktf.IResolvable): any;
export declare class CsbsBackupPolicyV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CsbsBackupPolicyV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: CsbsBackupPolicyV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1 opentelekomcloud_csbs_backup_policy_v1}
*/
export declare class CsbsBackupPolicyV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_csbs_backup_policy_v1";
    /**
    * Generates CDKTF code for importing a CsbsBackupPolicyV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CsbsBackupPolicyV1 to import
    * @param importFromId The id of the existing CsbsBackupPolicyV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CsbsBackupPolicyV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_policy_v1 opentelekomcloud_csbs_backup_policy_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CsbsBackupPolicyV1Config
    */
    constructor(scope: Construct, id: string, config: CsbsBackupPolicyV1Config);
    private _common?;
    get common(): {
        [key: string]: string;
    };
    set common(value: {
        [key: string]: string;
    });
    resetCommon(): void;
    get commonInput(): {
        [key: string]: string;
    } | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerId?;
    get providerId(): string;
    set providerId(value: string);
    resetProviderId(): void;
    get providerIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _resource;
    get resource(): CsbsBackupPolicyV1ResourceList;
    putResource(value: CsbsBackupPolicyV1Resource[] | cdktf.IResolvable): void;
    get resourceInput(): cdktf.IResolvable | CsbsBackupPolicyV1Resource[] | undefined;
    private _scheduledOperation;
    get scheduledOperation(): CsbsBackupPolicyV1ScheduledOperationOutputReference;
    putScheduledOperation(value: CsbsBackupPolicyV1ScheduledOperation): void;
    get scheduledOperationInput(): CsbsBackupPolicyV1ScheduledOperation | undefined;
    private _tags;
    get tags(): CsbsBackupPolicyV1TagsList;
    putTags(value: CsbsBackupPolicyV1Tags[] | cdktf.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktf.IResolvable | CsbsBackupPolicyV1Tags[] | undefined;
    private _timeouts;
    get timeouts(): CsbsBackupPolicyV1TimeoutsOutputReference;
    putTimeouts(value: CsbsBackupPolicyV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | CsbsBackupPolicyV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

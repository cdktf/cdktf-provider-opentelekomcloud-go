/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CsbsBackupV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_v1#backup_name CsbsBackupV1#backup_name}
    */
    readonly backupName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_v1#description CsbsBackupV1#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_v1#id CsbsBackupV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_v1#region CsbsBackupV1#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_v1#resource_id CsbsBackupV1#resource_id}
    */
    readonly resourceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_v1#resource_type CsbsBackupV1#resource_type}
    */
    readonly resourceType?: string;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_v1#tags CsbsBackupV1#tags}
    */
    readonly tags?: CsbsBackupV1Tags[] | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_v1#timeouts CsbsBackupV1#timeouts}
    */
    readonly timeouts?: CsbsBackupV1Timeouts;
}
export interface CsbsBackupV1VmMetadata {
}
export declare function csbsBackupV1VmMetadataToTerraform(struct?: CsbsBackupV1VmMetadata): any;
export declare function csbsBackupV1VmMetadataToHclTerraform(struct?: CsbsBackupV1VmMetadata): any;
export declare class CsbsBackupV1VmMetadataOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CsbsBackupV1VmMetadata | undefined;
    set internalValue(value: CsbsBackupV1VmMetadata | undefined);
    get cloudServiceType(): string;
    get disk(): number;
    get eip(): string;
    get imageType(): string;
    get name(): string;
    get privateIp(): string;
    get ram(): number;
    get vcpus(): number;
}
export declare class CsbsBackupV1VmMetadataList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CsbsBackupV1VmMetadataOutputReference;
}
export interface CsbsBackupV1VolumeBackups {
}
export declare function csbsBackupV1VolumeBackupsToTerraform(struct?: CsbsBackupV1VolumeBackups): any;
export declare function csbsBackupV1VolumeBackupsToHclTerraform(struct?: CsbsBackupV1VolumeBackups): any;
export declare class CsbsBackupV1VolumeBackupsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CsbsBackupV1VolumeBackups | undefined;
    set internalValue(value: CsbsBackupV1VolumeBackups | undefined);
    get averageSpeed(): number;
    get bootable(): cdktf.IResolvable;
    get id(): string;
    get imageType(): string;
    get incremental(): cdktf.IResolvable;
    get name(): string;
    get size(): number;
    get snapshotId(): string;
    get sourceVolumeId(): string;
    get sourceVolumeName(): string;
    get sourceVolumeSize(): number;
    get spaceSavingRatio(): number;
    get status(): string;
}
export declare class CsbsBackupV1VolumeBackupsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CsbsBackupV1VolumeBackupsOutputReference;
}
export interface CsbsBackupV1Tags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_v1#key CsbsBackupV1#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_v1#value CsbsBackupV1#value}
    */
    readonly value: string;
}
export declare function csbsBackupV1TagsToTerraform(struct?: CsbsBackupV1Tags | cdktf.IResolvable): any;
export declare function csbsBackupV1TagsToHclTerraform(struct?: CsbsBackupV1Tags | cdktf.IResolvable): any;
export declare class CsbsBackupV1TagsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CsbsBackupV1Tags | cdktf.IResolvable | undefined;
    set internalValue(value: CsbsBackupV1Tags | cdktf.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class CsbsBackupV1TagsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: CsbsBackupV1Tags[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CsbsBackupV1TagsOutputReference;
}
export interface CsbsBackupV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_v1#create CsbsBackupV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_v1#delete CsbsBackupV1#delete}
    */
    readonly delete?: string;
}
export declare function csbsBackupV1TimeoutsToTerraform(struct?: CsbsBackupV1Timeouts | cdktf.IResolvable): any;
export declare function csbsBackupV1TimeoutsToHclTerraform(struct?: CsbsBackupV1Timeouts | cdktf.IResolvable): any;
export declare class CsbsBackupV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CsbsBackupV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: CsbsBackupV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_v1 opentelekomcloud_csbs_backup_v1}
*/
export declare class CsbsBackupV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_csbs_backup_v1";
    /**
    * Generates CDKTF code for importing a CsbsBackupV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CsbsBackupV1 to import
    * @param importFromId The id of the existing CsbsBackupV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CsbsBackupV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/csbs_backup_v1 opentelekomcloud_csbs_backup_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CsbsBackupV1Config
    */
    constructor(scope: Construct, id: string, config: CsbsBackupV1Config);
    private _backupName?;
    get backupName(): string;
    set backupName(value: string);
    resetBackupName(): void;
    get backupNameInput(): string | undefined;
    get backupRecordId(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    get resourceIdInput(): string | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    resetResourceType(): void;
    get resourceTypeInput(): string | undefined;
    get status(): string;
    private _vmMetadata;
    get vmMetadata(): CsbsBackupV1VmMetadataList;
    private _volumeBackups;
    get volumeBackups(): CsbsBackupV1VolumeBackupsList;
    private _tags;
    get tags(): CsbsBackupV1TagsList;
    putTags(value: CsbsBackupV1Tags[] | cdktf.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktf.IResolvable | CsbsBackupV1Tags[] | undefined;
    private _timeouts;
    get timeouts(): CsbsBackupV1TimeoutsOutputReference;
    putTimeouts(value: CsbsBackupV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | CsbsBackupV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

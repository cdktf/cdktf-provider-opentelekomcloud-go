/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface GaussdbMysqlInstanceV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gaussdb_mysql_instance_v3#availability_zone_mode GaussdbMysqlInstanceV3#availability_zone_mode}
    */
    readonly availabilityZoneMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gaussdb_mysql_instance_v3#configuration_id GaussdbMysqlInstanceV3#configuration_id}
    */
    readonly configurationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gaussdb_mysql_instance_v3#configuration_name GaussdbMysqlInstanceV3#configuration_name}
    */
    readonly configurationName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gaussdb_mysql_instance_v3#dedicated_resource_id GaussdbMysqlInstanceV3#dedicated_resource_id}
    */
    readonly dedicatedResourceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gaussdb_mysql_instance_v3#dedicated_resource_name GaussdbMysqlInstanceV3#dedicated_resource_name}
    */
    readonly dedicatedResourceName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gaussdb_mysql_instance_v3#flavor GaussdbMysqlInstanceV3#flavor}
    */
    readonly flavor: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gaussdb_mysql_instance_v3#id GaussdbMysqlInstanceV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gaussdb_mysql_instance_v3#master_availability_zone GaussdbMysqlInstanceV3#master_availability_zone}
    */
    readonly masterAvailabilityZone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gaussdb_mysql_instance_v3#name GaussdbMysqlInstanceV3#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gaussdb_mysql_instance_v3#password GaussdbMysqlInstanceV3#password}
    */
    readonly password: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gaussdb_mysql_instance_v3#read_replicas GaussdbMysqlInstanceV3#read_replicas}
    */
    readonly readReplicas?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gaussdb_mysql_instance_v3#region GaussdbMysqlInstanceV3#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gaussdb_mysql_instance_v3#security_group_id GaussdbMysqlInstanceV3#security_group_id}
    */
    readonly securityGroupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gaussdb_mysql_instance_v3#subnet_id GaussdbMysqlInstanceV3#subnet_id}
    */
    readonly subnetId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gaussdb_mysql_instance_v3#time_zone GaussdbMysqlInstanceV3#time_zone}
    */
    readonly timeZone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gaussdb_mysql_instance_v3#vpc_id GaussdbMysqlInstanceV3#vpc_id}
    */
    readonly vpcId: string;
    /**
    * backup_strategy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gaussdb_mysql_instance_v3#backup_strategy GaussdbMysqlInstanceV3#backup_strategy}
    */
    readonly backupStrategy?: GaussdbMysqlInstanceV3BackupStrategy;
    /**
    * datastore block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gaussdb_mysql_instance_v3#datastore GaussdbMysqlInstanceV3#datastore}
    */
    readonly datastore?: GaussdbMysqlInstanceV3Datastore;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gaussdb_mysql_instance_v3#timeouts GaussdbMysqlInstanceV3#timeouts}
    */
    readonly timeouts?: GaussdbMysqlInstanceV3Timeouts;
}
export interface GaussdbMysqlInstanceV3Nodes {
}
export declare function gaussdbMysqlInstanceV3NodesToTerraform(struct?: GaussdbMysqlInstanceV3Nodes): any;
export declare function gaussdbMysqlInstanceV3NodesToHclTerraform(struct?: GaussdbMysqlInstanceV3Nodes): any;
export declare class GaussdbMysqlInstanceV3NodesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GaussdbMysqlInstanceV3Nodes | undefined;
    set internalValue(value: GaussdbMysqlInstanceV3Nodes | undefined);
    get azCode(): string;
    get created(): string;
    get flavorRef(): string;
    get id(): string;
    get maxConnections(): string;
    get name(): string;
    get needRestart(): cdktf.IResolvable;
    get port(): number;
    get priority(): number;
    get privateReadIps(): string[];
    get ram(): string;
    get regionCode(): string;
    get status(): string;
    get type(): string;
    get updated(): string;
    get vcpus(): string;
}
export declare class GaussdbMysqlInstanceV3NodesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GaussdbMysqlInstanceV3NodesOutputReference;
}
export interface GaussdbMysqlInstanceV3BackupStrategy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gaussdb_mysql_instance_v3#keep_days GaussdbMysqlInstanceV3#keep_days}
    */
    readonly keepDays?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gaussdb_mysql_instance_v3#start_time GaussdbMysqlInstanceV3#start_time}
    */
    readonly startTime: string;
}
export declare function gaussdbMysqlInstanceV3BackupStrategyToTerraform(struct?: GaussdbMysqlInstanceV3BackupStrategyOutputReference | GaussdbMysqlInstanceV3BackupStrategy): any;
export declare function gaussdbMysqlInstanceV3BackupStrategyToHclTerraform(struct?: GaussdbMysqlInstanceV3BackupStrategyOutputReference | GaussdbMysqlInstanceV3BackupStrategy): any;
export declare class GaussdbMysqlInstanceV3BackupStrategyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GaussdbMysqlInstanceV3BackupStrategy | undefined;
    set internalValue(value: GaussdbMysqlInstanceV3BackupStrategy | undefined);
    private _keepDays?;
    get keepDays(): string;
    set keepDays(value: string);
    resetKeepDays(): void;
    get keepDaysInput(): string | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    get startTimeInput(): string | undefined;
}
export interface GaussdbMysqlInstanceV3Datastore {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gaussdb_mysql_instance_v3#engine GaussdbMysqlInstanceV3#engine}
    */
    readonly engine: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gaussdb_mysql_instance_v3#version GaussdbMysqlInstanceV3#version}
    */
    readonly version?: string;
}
export declare function gaussdbMysqlInstanceV3DatastoreToTerraform(struct?: GaussdbMysqlInstanceV3DatastoreOutputReference | GaussdbMysqlInstanceV3Datastore): any;
export declare function gaussdbMysqlInstanceV3DatastoreToHclTerraform(struct?: GaussdbMysqlInstanceV3DatastoreOutputReference | GaussdbMysqlInstanceV3Datastore): any;
export declare class GaussdbMysqlInstanceV3DatastoreOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GaussdbMysqlInstanceV3Datastore | undefined;
    set internalValue(value: GaussdbMysqlInstanceV3Datastore | undefined);
    private _engine?;
    get engine(): string;
    set engine(value: string);
    get engineInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export interface GaussdbMysqlInstanceV3Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gaussdb_mysql_instance_v3#create GaussdbMysqlInstanceV3#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gaussdb_mysql_instance_v3#delete GaussdbMysqlInstanceV3#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gaussdb_mysql_instance_v3#update GaussdbMysqlInstanceV3#update}
    */
    readonly update?: string;
}
export declare function gaussdbMysqlInstanceV3TimeoutsToTerraform(struct?: GaussdbMysqlInstanceV3Timeouts | cdktf.IResolvable): any;
export declare function gaussdbMysqlInstanceV3TimeoutsToHclTerraform(struct?: GaussdbMysqlInstanceV3Timeouts | cdktf.IResolvable): any;
export declare class GaussdbMysqlInstanceV3TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GaussdbMysqlInstanceV3Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: GaussdbMysqlInstanceV3Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gaussdb_mysql_instance_v3 opentelekomcloud_gaussdb_mysql_instance_v3}
*/
export declare class GaussdbMysqlInstanceV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_gaussdb_mysql_instance_v3";
    /**
    * Generates CDKTF code for importing a GaussdbMysqlInstanceV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GaussdbMysqlInstanceV3 to import
    * @param importFromId The id of the existing GaussdbMysqlInstanceV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gaussdb_mysql_instance_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GaussdbMysqlInstanceV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gaussdb_mysql_instance_v3 opentelekomcloud_gaussdb_mysql_instance_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GaussdbMysqlInstanceV3Config
    */
    constructor(scope: Construct, id: string, config: GaussdbMysqlInstanceV3Config);
    get alias(): string;
    private _availabilityZoneMode?;
    get availabilityZoneMode(): string;
    set availabilityZoneMode(value: string);
    resetAvailabilityZoneMode(): void;
    get availabilityZoneModeInput(): string | undefined;
    get chargingMode(): string;
    private _configurationId?;
    get configurationId(): string;
    set configurationId(value: string);
    resetConfigurationId(): void;
    get configurationIdInput(): string | undefined;
    private _configurationName?;
    get configurationName(): string;
    set configurationName(value: string);
    resetConfigurationName(): void;
    get configurationNameInput(): string | undefined;
    get created(): string;
    get dbUserName(): string;
    private _dedicatedResourceId?;
    get dedicatedResourceId(): string;
    set dedicatedResourceId(value: string);
    resetDedicatedResourceId(): void;
    get dedicatedResourceIdInput(): string | undefined;
    private _dedicatedResourceName?;
    get dedicatedResourceName(): string;
    set dedicatedResourceName(value: string);
    resetDedicatedResourceName(): void;
    get dedicatedResourceNameInput(): string | undefined;
    private _flavor?;
    get flavor(): string;
    set flavor(value: string);
    get flavorInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _masterAvailabilityZone?;
    get masterAvailabilityZone(): string;
    set masterAvailabilityZone(value: string);
    resetMasterAvailabilityZone(): void;
    get masterAvailabilityZoneInput(): string | undefined;
    get mode(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get nodeCount(): number;
    private _nodes;
    get nodes(): GaussdbMysqlInstanceV3NodesList;
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    get port(): number;
    get privateWriteIp(): string[];
    get projectId(): string;
    get publicIp(): string;
    private _readReplicas?;
    get readReplicas(): number;
    set readReplicas(value: number);
    resetReadReplicas(): void;
    get readReplicasInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _securityGroupId?;
    get securityGroupId(): string;
    set securityGroupId(value: string);
    resetSecurityGroupId(): void;
    get securityGroupIdInput(): string | undefined;
    get status(): string;
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    get subnetIdInput(): string | undefined;
    private _timeZone?;
    get timeZone(): string;
    set timeZone(value: string);
    resetTimeZone(): void;
    get timeZoneInput(): string | undefined;
    get updated(): string;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    get vpcIdInput(): string | undefined;
    private _backupStrategy;
    get backupStrategy(): GaussdbMysqlInstanceV3BackupStrategyOutputReference;
    putBackupStrategy(value: GaussdbMysqlInstanceV3BackupStrategy): void;
    resetBackupStrategy(): void;
    get backupStrategyInput(): GaussdbMysqlInstanceV3BackupStrategy | undefined;
    private _datastore;
    get datastore(): GaussdbMysqlInstanceV3DatastoreOutputReference;
    putDatastore(value: GaussdbMysqlInstanceV3Datastore): void;
    resetDatastore(): void;
    get datastoreInput(): GaussdbMysqlInstanceV3Datastore | undefined;
    private _timeouts;
    get timeouts(): GaussdbMysqlInstanceV3TimeoutsOutputReference;
    putTimeouts(value: GaussdbMysqlInstanceV3Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | GaussdbMysqlInstanceV3Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

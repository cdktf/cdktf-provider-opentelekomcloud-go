/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudSfsTurboShareV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/sfs_turbo_share_v1#id DataOpentelekomcloudSfsTurboShareV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/sfs_turbo_share_v1#name DataOpentelekomcloudSfsTurboShareV1#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/sfs_turbo_share_v1 opentelekomcloud_sfs_turbo_share_v1}
*/
export declare class DataOpentelekomcloudSfsTurboShareV1 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_sfs_turbo_share_v1";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudSfsTurboShareV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudSfsTurboShareV1 to import
    * @param importFromId The id of the existing DataOpentelekomcloudSfsTurboShareV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/sfs_turbo_share_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudSfsTurboShareV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/sfs_turbo_share_v1 opentelekomcloud_sfs_turbo_share_v1} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudSfsTurboShareV1Config
    */
    constructor(scope: Construct, id: string, config: DataOpentelekomcloudSfsTurboShareV1Config);
    get availabilityZone(): string;
    get availableCapacity(): string;
    get cryptKeyId(): string;
    get expandType(): string;
    get exportLocation(): string;
    get hpcBw(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get region(): string;
    get securityGroupId(): string;
    get shareProto(): string;
    get shareType(): string;
    get size(): number;
    get subnetId(): string;
    get version(): string;
    get vpcId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

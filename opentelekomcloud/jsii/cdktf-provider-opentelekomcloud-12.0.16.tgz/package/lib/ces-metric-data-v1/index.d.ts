/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CesMetricDataV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_metric_data_v1#collect_time CesMetricDataV1#collect_time}
    */
    readonly collectTime: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_metric_data_v1#id CesMetricDataV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_metric_data_v1#ttl CesMetricDataV1#ttl}
    */
    readonly ttl: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_metric_data_v1#type CesMetricDataV1#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_metric_data_v1#unit CesMetricDataV1#unit}
    */
    readonly unit?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_metric_data_v1#value CesMetricDataV1#value}
    */
    readonly value: number;
    /**
    * metric block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_metric_data_v1#metric CesMetricDataV1#metric}
    */
    readonly metric: CesMetricDataV1Metric;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_metric_data_v1#timeouts CesMetricDataV1#timeouts}
    */
    readonly timeouts?: CesMetricDataV1Timeouts;
}
export interface CesMetricDataV1MetricDimensions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_metric_data_v1#name CesMetricDataV1#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_metric_data_v1#value CesMetricDataV1#value}
    */
    readonly value: string;
}
export declare function cesMetricDataV1MetricDimensionsToTerraform(struct?: CesMetricDataV1MetricDimensions | cdktf.IResolvable): any;
export declare function cesMetricDataV1MetricDimensionsToHclTerraform(struct?: CesMetricDataV1MetricDimensions | cdktf.IResolvable): any;
export declare class CesMetricDataV1MetricDimensionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesMetricDataV1MetricDimensions | cdktf.IResolvable | undefined;
    set internalValue(value: CesMetricDataV1MetricDimensions | cdktf.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class CesMetricDataV1MetricDimensionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: CesMetricDataV1MetricDimensions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesMetricDataV1MetricDimensionsOutputReference;
}
export interface CesMetricDataV1Metric {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_metric_data_v1#metric_name CesMetricDataV1#metric_name}
    */
    readonly metricName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_metric_data_v1#namespace CesMetricDataV1#namespace}
    */
    readonly namespace: string;
    /**
    * dimensions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_metric_data_v1#dimensions CesMetricDataV1#dimensions}
    */
    readonly dimensions: CesMetricDataV1MetricDimensions[] | cdktf.IResolvable;
}
export declare function cesMetricDataV1MetricToTerraform(struct?: CesMetricDataV1MetricOutputReference | CesMetricDataV1Metric): any;
export declare function cesMetricDataV1MetricToHclTerraform(struct?: CesMetricDataV1MetricOutputReference | CesMetricDataV1Metric): any;
export declare class CesMetricDataV1MetricOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesMetricDataV1Metric | undefined;
    set internalValue(value: CesMetricDataV1Metric | undefined);
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    get metricNameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    get namespaceInput(): string | undefined;
    private _dimensions;
    get dimensions(): CesMetricDataV1MetricDimensionsList;
    putDimensions(value: CesMetricDataV1MetricDimensions[] | cdktf.IResolvable): void;
    get dimensionsInput(): cdktf.IResolvable | CesMetricDataV1MetricDimensions[] | undefined;
}
export interface CesMetricDataV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_metric_data_v1#create CesMetricDataV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_metric_data_v1#delete CesMetricDataV1#delete}
    */
    readonly delete?: string;
}
export declare function cesMetricDataV1TimeoutsToTerraform(struct?: CesMetricDataV1Timeouts | cdktf.IResolvable): any;
export declare function cesMetricDataV1TimeoutsToHclTerraform(struct?: CesMetricDataV1Timeouts | cdktf.IResolvable): any;
export declare class CesMetricDataV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesMetricDataV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: CesMetricDataV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_metric_data_v1 opentelekomcloud_ces_metric_data_v1}
*/
export declare class CesMetricDataV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_ces_metric_data_v1";
    /**
    * Generates CDKTF code for importing a CesMetricDataV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CesMetricDataV1 to import
    * @param importFromId The id of the existing CesMetricDataV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_metric_data_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CesMetricDataV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_metric_data_v1 opentelekomcloud_ces_metric_data_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CesMetricDataV1Config
    */
    constructor(scope: Construct, id: string, config: CesMetricDataV1Config);
    private _collectTime?;
    get collectTime(): number;
    set collectTime(value: number);
    get collectTimeInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ttl?;
    get ttl(): number;
    set ttl(value: number);
    get ttlInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
    private _metric;
    get metric(): CesMetricDataV1MetricOutputReference;
    putMetric(value: CesMetricDataV1Metric): void;
    get metricInput(): CesMetricDataV1Metric | undefined;
    private _timeouts;
    get timeouts(): CesMetricDataV1TimeoutsOutputReference;
    putTimeouts(value: CesMetricDataV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | CesMetricDataV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DwsClusterV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dws_cluster_v1#availability_zone DwsClusterV1#availability_zone}
    */
    readonly availabilityZone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dws_cluster_v1#id DwsClusterV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dws_cluster_v1#keep_last_manual_snapshot DwsClusterV1#keep_last_manual_snapshot}
    */
    readonly keepLastManualSnapshot?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dws_cluster_v1#name DwsClusterV1#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dws_cluster_v1#network_id DwsClusterV1#network_id}
    */
    readonly networkId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dws_cluster_v1#node_type DwsClusterV1#node_type}
    */
    readonly nodeType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dws_cluster_v1#number_of_cn DwsClusterV1#number_of_cn}
    */
    readonly numberOfCn?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dws_cluster_v1#number_of_node DwsClusterV1#number_of_node}
    */
    readonly numberOfNode: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dws_cluster_v1#port DwsClusterV1#port}
    */
    readonly port?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dws_cluster_v1#security_group_id DwsClusterV1#security_group_id}
    */
    readonly securityGroupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dws_cluster_v1#user_name DwsClusterV1#user_name}
    */
    readonly userName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dws_cluster_v1#user_pwd DwsClusterV1#user_pwd}
    */
    readonly userPwd: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dws_cluster_v1#vpc_id DwsClusterV1#vpc_id}
    */
    readonly vpcId: string;
    /**
    * endpoints block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dws_cluster_v1#endpoints DwsClusterV1#endpoints}
    */
    readonly endpoints?: DwsClusterV1Endpoints[] | cdktf.IResolvable;
    /**
    * public_endpoints block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dws_cluster_v1#public_endpoints DwsClusterV1#public_endpoints}
    */
    readonly publicEndpoints?: DwsClusterV1PublicEndpoints[] | cdktf.IResolvable;
    /**
    * public_ip block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dws_cluster_v1#public_ip DwsClusterV1#public_ip}
    */
    readonly publicIp?: DwsClusterV1PublicIp;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dws_cluster_v1#timeouts DwsClusterV1#timeouts}
    */
    readonly timeouts?: DwsClusterV1Timeouts;
}
export interface DwsClusterV1Endpoints {
}
export declare function dwsClusterV1EndpointsToTerraform(struct?: DwsClusterV1Endpoints | cdktf.IResolvable): any;
export declare function dwsClusterV1EndpointsToHclTerraform(struct?: DwsClusterV1Endpoints | cdktf.IResolvable): any;
export declare class DwsClusterV1EndpointsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DwsClusterV1Endpoints | cdktf.IResolvable | undefined;
    set internalValue(value: DwsClusterV1Endpoints | cdktf.IResolvable | undefined);
    get connectInfo(): string;
    get jdbcUrl(): string;
}
export declare class DwsClusterV1EndpointsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DwsClusterV1Endpoints[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DwsClusterV1EndpointsOutputReference;
}
export interface DwsClusterV1PublicEndpoints {
}
export declare function dwsClusterV1PublicEndpointsToTerraform(struct?: DwsClusterV1PublicEndpoints | cdktf.IResolvable): any;
export declare function dwsClusterV1PublicEndpointsToHclTerraform(struct?: DwsClusterV1PublicEndpoints | cdktf.IResolvable): any;
export declare class DwsClusterV1PublicEndpointsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DwsClusterV1PublicEndpoints | cdktf.IResolvable | undefined;
    set internalValue(value: DwsClusterV1PublicEndpoints | cdktf.IResolvable | undefined);
    get jdbcUrl(): string;
    get publicConnectInfo(): string;
}
export declare class DwsClusterV1PublicEndpointsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DwsClusterV1PublicEndpoints[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DwsClusterV1PublicEndpointsOutputReference;
}
export interface DwsClusterV1PublicIp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dws_cluster_v1#eip_id DwsClusterV1#eip_id}
    */
    readonly eipId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dws_cluster_v1#public_bind_type DwsClusterV1#public_bind_type}
    */
    readonly publicBindType?: string;
}
export declare function dwsClusterV1PublicIpToTerraform(struct?: DwsClusterV1PublicIpOutputReference | DwsClusterV1PublicIp): any;
export declare function dwsClusterV1PublicIpToHclTerraform(struct?: DwsClusterV1PublicIpOutputReference | DwsClusterV1PublicIp): any;
export declare class DwsClusterV1PublicIpOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DwsClusterV1PublicIp | undefined;
    set internalValue(value: DwsClusterV1PublicIp | undefined);
    private _eipId?;
    get eipId(): string;
    set eipId(value: string);
    resetEipId(): void;
    get eipIdInput(): string | undefined;
    private _publicBindType?;
    get publicBindType(): string;
    set publicBindType(value: string);
    resetPublicBindType(): void;
    get publicBindTypeInput(): string | undefined;
}
export interface DwsClusterV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dws_cluster_v1#create DwsClusterV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dws_cluster_v1#delete DwsClusterV1#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dws_cluster_v1#update DwsClusterV1#update}
    */
    readonly update?: string;
}
export declare function dwsClusterV1TimeoutsToTerraform(struct?: DwsClusterV1Timeouts | cdktf.IResolvable): any;
export declare function dwsClusterV1TimeoutsToHclTerraform(struct?: DwsClusterV1Timeouts | cdktf.IResolvable): any;
export declare class DwsClusterV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DwsClusterV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DwsClusterV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dws_cluster_v1 opentelekomcloud_dws_cluster_v1}
*/
export declare class DwsClusterV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_dws_cluster_v1";
    /**
    * Generates CDKTF code for importing a DwsClusterV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DwsClusterV1 to import
    * @param importFromId The id of the existing DwsClusterV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dws_cluster_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DwsClusterV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dws_cluster_v1 opentelekomcloud_dws_cluster_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DwsClusterV1Config
    */
    constructor(scope: Construct, id: string, config: DwsClusterV1Config);
    private _availabilityZone?;
    get availabilityZone(): string;
    set availabilityZone(value: string);
    resetAvailabilityZone(): void;
    get availabilityZoneInput(): string | undefined;
    get created(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _keepLastManualSnapshot?;
    get keepLastManualSnapshot(): number;
    set keepLastManualSnapshot(value: number);
    resetKeepLastManualSnapshot(): void;
    get keepLastManualSnapshotInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _networkId?;
    get networkId(): string;
    set networkId(value: string);
    get networkIdInput(): string | undefined;
    private _nodeType?;
    get nodeType(): string;
    set nodeType(value: string);
    get nodeTypeInput(): string | undefined;
    private _numberOfCn?;
    get numberOfCn(): number;
    set numberOfCn(value: number);
    resetNumberOfCn(): void;
    get numberOfCnInput(): number | undefined;
    private _numberOfNode?;
    get numberOfNode(): number;
    set numberOfNode(value: number);
    get numberOfNodeInput(): number | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    get privateIp(): string[];
    get recentEvent(): number;
    private _securityGroupId?;
    get securityGroupId(): string;
    set securityGroupId(value: string);
    get securityGroupIdInput(): string | undefined;
    get status(): string;
    get subStatus(): string;
    get taskStatus(): string;
    get updated(): string;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    get userNameInput(): string | undefined;
    private _userPwd?;
    get userPwd(): string;
    set userPwd(value: string);
    get userPwdInput(): string | undefined;
    get version(): string;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    get vpcIdInput(): string | undefined;
    private _endpoints;
    get endpoints(): DwsClusterV1EndpointsList;
    putEndpoints(value: DwsClusterV1Endpoints[] | cdktf.IResolvable): void;
    resetEndpoints(): void;
    get endpointsInput(): cdktf.IResolvable | DwsClusterV1Endpoints[] | undefined;
    private _publicEndpoints;
    get publicEndpoints(): DwsClusterV1PublicEndpointsList;
    putPublicEndpoints(value: DwsClusterV1PublicEndpoints[] | cdktf.IResolvable): void;
    resetPublicEndpoints(): void;
    get publicEndpointsInput(): cdktf.IResolvable | DwsClusterV1PublicEndpoints[] | undefined;
    private _publicIp;
    get publicIp(): DwsClusterV1PublicIpOutputReference;
    putPublicIp(value: DwsClusterV1PublicIp): void;
    resetPublicIp(): void;
    get publicIpInput(): DwsClusterV1PublicIp | undefined;
    private _timeouts;
    get timeouts(): DwsClusterV1TimeoutsOutputReference;
    putTimeouts(value: DwsClusterV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DwsClusterV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

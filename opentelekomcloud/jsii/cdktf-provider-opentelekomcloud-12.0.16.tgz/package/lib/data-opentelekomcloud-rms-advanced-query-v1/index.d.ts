/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudRmsAdvancedQueryV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/rms_advanced_query_v1#expression DataOpentelekomcloudRmsAdvancedQueryV1#expression}
    */
    readonly expression: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/rms_advanced_query_v1#id DataOpentelekomcloudRmsAdvancedQueryV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataOpentelekomcloudRmsAdvancedQueryV1QueryInfo {
}
export declare function dataOpentelekomcloudRmsAdvancedQueryV1QueryInfoToTerraform(struct?: DataOpentelekomcloudRmsAdvancedQueryV1QueryInfo): any;
export declare function dataOpentelekomcloudRmsAdvancedQueryV1QueryInfoToHclTerraform(struct?: DataOpentelekomcloudRmsAdvancedQueryV1QueryInfo): any;
export declare class DataOpentelekomcloudRmsAdvancedQueryV1QueryInfoOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudRmsAdvancedQueryV1QueryInfo | undefined;
    set internalValue(value: DataOpentelekomcloudRmsAdvancedQueryV1QueryInfo | undefined);
    get selectFields(): string[];
}
export declare class DataOpentelekomcloudRmsAdvancedQueryV1QueryInfoList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudRmsAdvancedQueryV1QueryInfoOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/rms_advanced_query_v1 opentelekomcloud_rms_advanced_query_v1}
*/
export declare class DataOpentelekomcloudRmsAdvancedQueryV1 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_rms_advanced_query_v1";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudRmsAdvancedQueryV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudRmsAdvancedQueryV1 to import
    * @param importFromId The id of the existing DataOpentelekomcloudRmsAdvancedQueryV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/rms_advanced_query_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudRmsAdvancedQueryV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/rms_advanced_query_v1 opentelekomcloud_rms_advanced_query_v1} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudRmsAdvancedQueryV1Config
    */
    constructor(scope: Construct, id: string, config: DataOpentelekomcloudRmsAdvancedQueryV1Config);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _queryInfo;
    get queryInfo(): DataOpentelekomcloudRmsAdvancedQueryV1QueryInfoList;
    private _results;
    get results(): cdktf.StringMapList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CfwServiceGroupV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_service_group_v1#description CfwServiceGroupV1#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_service_group_v1#name CfwServiceGroupV1#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_service_group_v1#object_id CfwServiceGroupV1#object_id}
    */
    readonly objectId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_service_group_v1#timeouts CfwServiceGroupV1#timeouts}
    */
    readonly timeouts?: CfwServiceGroupV1Timeouts;
}
export interface CfwServiceGroupV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_service_group_v1#create CfwServiceGroupV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_service_group_v1#delete CfwServiceGroupV1#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_service_group_v1#update CfwServiceGroupV1#update}
    */
    readonly update?: string;
}
export declare function cfwServiceGroupV1TimeoutsToTerraform(struct?: CfwServiceGroupV1Timeouts | cdktf.IResolvable): any;
export declare function cfwServiceGroupV1TimeoutsToHclTerraform(struct?: CfwServiceGroupV1Timeouts | cdktf.IResolvable): any;
export declare class CfwServiceGroupV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CfwServiceGroupV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: CfwServiceGroupV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_service_group_v1 opentelekomcloud_cfw_service_group_v1}
*/
export declare class CfwServiceGroupV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_cfw_service_group_v1";
    /**
    * Generates CDKTF code for importing a CfwServiceGroupV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CfwServiceGroupV1 to import
    * @param importFromId The id of the existing CfwServiceGroupV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_service_group_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CfwServiceGroupV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_service_group_v1 opentelekomcloud_cfw_service_group_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CfwServiceGroupV1Config
    */
    constructor(scope: Construct, id: string, config: CfwServiceGroupV1Config);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _objectId?;
    get objectId(): string;
    set objectId(value: string);
    get objectIdInput(): string | undefined;
    get serviceSetType(): number;
    private _timeouts;
    get timeouts(): CfwServiceGroupV1TimeoutsOutputReference;
    putTimeouts(value: CfwServiceGroupV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | CfwServiceGroupV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

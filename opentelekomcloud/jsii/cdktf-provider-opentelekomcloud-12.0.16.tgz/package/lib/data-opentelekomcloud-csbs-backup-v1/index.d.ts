/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudCsbsBackupV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/csbs_backup_v1#backup_name DataOpentelekomcloudCsbsBackupV1#backup_name}
    */
    readonly backupName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/csbs_backup_v1#backup_record_id DataOpentelekomcloudCsbsBackupV1#backup_record_id}
    */
    readonly backupRecordId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/csbs_backup_v1#id DataOpentelekomcloudCsbsBackupV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/csbs_backup_v1#policy_id DataOpentelekomcloudCsbsBackupV1#policy_id}
    */
    readonly policyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/csbs_backup_v1#region DataOpentelekomcloudCsbsBackupV1#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/csbs_backup_v1#resource_id DataOpentelekomcloudCsbsBackupV1#resource_id}
    */
    readonly resourceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/csbs_backup_v1#resource_name DataOpentelekomcloudCsbsBackupV1#resource_name}
    */
    readonly resourceName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/csbs_backup_v1#resource_type DataOpentelekomcloudCsbsBackupV1#resource_type}
    */
    readonly resourceType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/csbs_backup_v1#status DataOpentelekomcloudCsbsBackupV1#status}
    */
    readonly status?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/csbs_backup_v1#vm_ip DataOpentelekomcloudCsbsBackupV1#vm_ip}
    */
    readonly vmIp?: string;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/csbs_backup_v1#tags DataOpentelekomcloudCsbsBackupV1#tags}
    */
    readonly tags?: DataOpentelekomcloudCsbsBackupV1Tags[] | cdktf.IResolvable;
}
export interface DataOpentelekomcloudCsbsBackupV1VmMetadata {
}
export declare function dataOpentelekomcloudCsbsBackupV1VmMetadataToTerraform(struct?: DataOpentelekomcloudCsbsBackupV1VmMetadata): any;
export declare function dataOpentelekomcloudCsbsBackupV1VmMetadataToHclTerraform(struct?: DataOpentelekomcloudCsbsBackupV1VmMetadata): any;
export declare class DataOpentelekomcloudCsbsBackupV1VmMetadataOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudCsbsBackupV1VmMetadata | undefined;
    set internalValue(value: DataOpentelekomcloudCsbsBackupV1VmMetadata | undefined);
    get cloudServiceType(): string;
    get disk(): number;
    get eip(): string;
    get imageType(): string;
    get name(): string;
    get privateIp(): string;
    get ram(): number;
    get vcpus(): number;
}
export declare class DataOpentelekomcloudCsbsBackupV1VmMetadataList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudCsbsBackupV1VmMetadataOutputReference;
}
export interface DataOpentelekomcloudCsbsBackupV1VolumeBackups {
}
export declare function dataOpentelekomcloudCsbsBackupV1VolumeBackupsToTerraform(struct?: DataOpentelekomcloudCsbsBackupV1VolumeBackups): any;
export declare function dataOpentelekomcloudCsbsBackupV1VolumeBackupsToHclTerraform(struct?: DataOpentelekomcloudCsbsBackupV1VolumeBackups): any;
export declare class DataOpentelekomcloudCsbsBackupV1VolumeBackupsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudCsbsBackupV1VolumeBackups | undefined;
    set internalValue(value: DataOpentelekomcloudCsbsBackupV1VolumeBackups | undefined);
    get averageSpeed(): number;
    get bootable(): cdktf.IResolvable;
    get id(): string;
    get imageType(): string;
    get incremental(): cdktf.IResolvable;
    get name(): string;
    get size(): number;
    get snapshotId(): string;
    get sourceVolumeId(): string;
    get sourceVolumeName(): string;
    get sourceVolumeSize(): number;
    get spaceSavingRatio(): number;
    get status(): string;
}
export declare class DataOpentelekomcloudCsbsBackupV1VolumeBackupsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudCsbsBackupV1VolumeBackupsOutputReference;
}
export interface DataOpentelekomcloudCsbsBackupV1Tags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/csbs_backup_v1#key DataOpentelekomcloudCsbsBackupV1#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/csbs_backup_v1#value DataOpentelekomcloudCsbsBackupV1#value}
    */
    readonly value: string;
}
export declare function dataOpentelekomcloudCsbsBackupV1TagsToTerraform(struct?: DataOpentelekomcloudCsbsBackupV1Tags | cdktf.IResolvable): any;
export declare function dataOpentelekomcloudCsbsBackupV1TagsToHclTerraform(struct?: DataOpentelekomcloudCsbsBackupV1Tags | cdktf.IResolvable): any;
export declare class DataOpentelekomcloudCsbsBackupV1TagsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudCsbsBackupV1Tags | cdktf.IResolvable | undefined;
    set internalValue(value: DataOpentelekomcloudCsbsBackupV1Tags | cdktf.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class DataOpentelekomcloudCsbsBackupV1TagsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataOpentelekomcloudCsbsBackupV1Tags[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudCsbsBackupV1TagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/csbs_backup_v1 opentelekomcloud_csbs_backup_v1}
*/
export declare class DataOpentelekomcloudCsbsBackupV1 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_csbs_backup_v1";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudCsbsBackupV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudCsbsBackupV1 to import
    * @param importFromId The id of the existing DataOpentelekomcloudCsbsBackupV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/csbs_backup_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudCsbsBackupV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/csbs_backup_v1 opentelekomcloud_csbs_backup_v1} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudCsbsBackupV1Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudCsbsBackupV1Config);
    get autoTrigger(): cdktf.IResolvable;
    get averageSpeed(): number;
    private _backupName?;
    get backupName(): string;
    set backupName(value: string);
    resetBackupName(): void;
    get backupNameInput(): string | undefined;
    private _backupRecordId?;
    get backupRecordId(): string;
    set backupRecordId(value: string);
    resetBackupRecordId(): void;
    get backupRecordIdInput(): string | undefined;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    resetPolicyId(): void;
    get policyIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    resetResourceId(): void;
    get resourceIdInput(): string | undefined;
    private _resourceName?;
    get resourceName(): string;
    set resourceName(value: string);
    resetResourceName(): void;
    get resourceNameInput(): string | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    resetResourceType(): void;
    get resourceTypeInput(): string | undefined;
    get size(): number;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _vmIp?;
    get vmIp(): string;
    set vmIp(value: string);
    resetVmIp(): void;
    get vmIpInput(): string | undefined;
    private _vmMetadata;
    get vmMetadata(): DataOpentelekomcloudCsbsBackupV1VmMetadataList;
    private _volumeBackups;
    get volumeBackups(): DataOpentelekomcloudCsbsBackupV1VolumeBackupsList;
    private _tags;
    get tags(): DataOpentelekomcloudCsbsBackupV1TagsList;
    putTags(value: DataOpentelekomcloudCsbsBackupV1Tags[] | cdktf.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktf.IResolvable | DataOpentelekomcloudCsbsBackupV1Tags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

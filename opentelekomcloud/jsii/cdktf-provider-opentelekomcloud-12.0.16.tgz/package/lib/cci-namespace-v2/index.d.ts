/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CciNamespaceV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cci_namespace_v2#id CciNamespaceV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cci_namespace_v2#name CciNamespaceV2#name}
    */
    readonly name: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cci_namespace_v2#timeouts CciNamespaceV2#timeouts}
    */
    readonly timeouts?: CciNamespaceV2Timeouts;
}
export interface CciNamespaceV2Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cci_namespace_v2#create CciNamespaceV2#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cci_namespace_v2#delete CciNamespaceV2#delete}
    */
    readonly delete?: string;
}
export declare function cciNamespaceV2TimeoutsToTerraform(struct?: CciNamespaceV2Timeouts | cdktf.IResolvable): any;
export declare function cciNamespaceV2TimeoutsToHclTerraform(struct?: CciNamespaceV2Timeouts | cdktf.IResolvable): any;
export declare class CciNamespaceV2TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CciNamespaceV2Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: CciNamespaceV2Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cci_namespace_v2 opentelekomcloud_cci_namespace_v2}
*/
export declare class CciNamespaceV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_cci_namespace_v2";
    /**
    * Generates CDKTF code for importing a CciNamespaceV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CciNamespaceV2 to import
    * @param importFromId The id of the existing CciNamespaceV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cci_namespace_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CciNamespaceV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cci_namespace_v2 opentelekomcloud_cci_namespace_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CciNamespaceV2Config
    */
    constructor(scope: Construct, id: string, config: CciNamespaceV2Config);
    private _annotations;
    get annotations(): cdktf.StringMap;
    get apiVersion(): string;
    get creationTimestamp(): string;
    get finalizers(): string[];
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get kind(): string;
    private _labels;
    get labels(): cdktf.StringMap;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get region(): string;
    get resourceVersion(): string;
    get status(): string;
    get uid(): string;
    private _timeouts;
    get timeouts(): CciNamespaceV2TimeoutsOutputReference;
    putTimeouts(value: CciNamespaceV2Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | CciNamespaceV2Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

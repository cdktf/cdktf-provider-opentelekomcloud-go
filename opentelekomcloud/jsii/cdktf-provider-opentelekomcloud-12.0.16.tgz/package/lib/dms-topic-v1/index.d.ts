/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DmsTopicV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_topic_v1#id DmsTopicV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_topic_v1#instance_id DmsTopicV1#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_topic_v1#max_partitions DmsTopicV1#max_partitions}
    */
    readonly maxPartitions?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_topic_v1#name DmsTopicV1#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_topic_v1#partition DmsTopicV1#partition}
    */
    readonly partition?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_topic_v1#remain_partitions DmsTopicV1#remain_partitions}
    */
    readonly remainPartitions?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_topic_v1#replication DmsTopicV1#replication}
    */
    readonly replication?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_topic_v1#retention_time DmsTopicV1#retention_time}
    */
    readonly retentionTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_topic_v1#size DmsTopicV1#size}
    */
    readonly size?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_topic_v1#sync_message_flush DmsTopicV1#sync_message_flush}
    */
    readonly syncMessageFlush?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_topic_v1#sync_replication DmsTopicV1#sync_replication}
    */
    readonly syncReplication?: boolean | cdktf.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_topic_v1 opentelekomcloud_dms_topic_v1}
*/
export declare class DmsTopicV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_dms_topic_v1";
    /**
    * Generates CDKTF code for importing a DmsTopicV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DmsTopicV1 to import
    * @param importFromId The id of the existing DmsTopicV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_topic_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DmsTopicV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_topic_v1 opentelekomcloud_dms_topic_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DmsTopicV1Config
    */
    constructor(scope: Construct, id: string, config: DmsTopicV1Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _maxPartitions?;
    get maxPartitions(): number;
    set maxPartitions(value: number);
    resetMaxPartitions(): void;
    get maxPartitionsInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _partition?;
    get partition(): number;
    set partition(value: number);
    resetPartition(): void;
    get partitionInput(): number | undefined;
    private _remainPartitions?;
    get remainPartitions(): number;
    set remainPartitions(value: number);
    resetRemainPartitions(): void;
    get remainPartitionsInput(): number | undefined;
    private _replication?;
    get replication(): number;
    set replication(value: number);
    resetReplication(): void;
    get replicationInput(): number | undefined;
    private _retentionTime?;
    get retentionTime(): number;
    set retentionTime(value: number);
    resetRetentionTime(): void;
    get retentionTimeInput(): number | undefined;
    private _size?;
    get size(): number;
    set size(value: number);
    resetSize(): void;
    get sizeInput(): number | undefined;
    private _syncMessageFlush?;
    get syncMessageFlush(): boolean | cdktf.IResolvable;
    set syncMessageFlush(value: boolean | cdktf.IResolvable);
    resetSyncMessageFlush(): void;
    get syncMessageFlushInput(): boolean | cdktf.IResolvable | undefined;
    private _syncReplication?;
    get syncReplication(): boolean | cdktf.IResolvable;
    set syncReplication(value: boolean | cdktf.IResolvable);
    resetSyncReplication(): void;
    get syncReplicationInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DcsInstanceV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#access_user DcsInstanceV2#access_user}
    */
    readonly accessUser?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#availability_zones DcsInstanceV2#availability_zones}
    */
    readonly availabilityZones: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#capacity DcsInstanceV2#capacity}
    */
    readonly capacity: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#deleted_nodes DcsInstanceV2#deleted_nodes}
    */
    readonly deletedNodes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#description DcsInstanceV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#enable_whitelist DcsInstanceV2#enable_whitelist}
    */
    readonly enableWhitelist?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#engine DcsInstanceV2#engine}
    */
    readonly engine: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#engine_version DcsInstanceV2#engine_version}
    */
    readonly engineVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#flavor DcsInstanceV2#flavor}
    */
    readonly flavor: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#id DcsInstanceV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#maintain_begin DcsInstanceV2#maintain_begin}
    */
    readonly maintainBegin?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#maintain_end DcsInstanceV2#maintain_end}
    */
    readonly maintainEnd?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#name DcsInstanceV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#password DcsInstanceV2#password}
    */
    readonly password?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#port DcsInstanceV2#port}
    */
    readonly port?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#private_ip DcsInstanceV2#private_ip}
    */
    readonly privateIp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#rename_commands DcsInstanceV2#rename_commands}
    */
    readonly renameCommands?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#reserved_ips DcsInstanceV2#reserved_ips}
    */
    readonly reservedIps?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#security_group_id DcsInstanceV2#security_group_id}
    */
    readonly securityGroupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#ssl_enable DcsInstanceV2#ssl_enable}
    */
    readonly sslEnable?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#subnet_id DcsInstanceV2#subnet_id}
    */
    readonly subnetId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#tags DcsInstanceV2#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#template_id DcsInstanceV2#template_id}
    */
    readonly templateId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#vpc_id DcsInstanceV2#vpc_id}
    */
    readonly vpcId: string;
    /**
    * backup_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#backup_policy DcsInstanceV2#backup_policy}
    */
    readonly backupPolicy?: DcsInstanceV2BackupPolicy;
    /**
    * parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#parameters DcsInstanceV2#parameters}
    */
    readonly parameters?: DcsInstanceV2Parameters[] | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#timeouts DcsInstanceV2#timeouts}
    */
    readonly timeouts?: DcsInstanceV2Timeouts;
    /**
    * whitelist block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#whitelist DcsInstanceV2#whitelist}
    */
    readonly whitelist?: DcsInstanceV2WhitelistStruct[] | cdktf.IResolvable;
}
export interface DcsInstanceV2BandwidthInfo {
}
export declare function dcsInstanceV2BandwidthInfoToTerraform(struct?: DcsInstanceV2BandwidthInfo): any;
export declare function dcsInstanceV2BandwidthInfoToHclTerraform(struct?: DcsInstanceV2BandwidthInfo): any;
export declare class DcsInstanceV2BandwidthInfoOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DcsInstanceV2BandwidthInfo | undefined;
    set internalValue(value: DcsInstanceV2BandwidthInfo | undefined);
    get bandwidth(): number;
    get beginTime(): string;
    get currentTime(): string;
    get endTime(): string;
    get expandCount(): number;
    get expandEffectTime(): number;
    get expandIntervalTime(): number;
    get maxExpandCount(): number;
    get nextExpandTime(): string;
    get taskRunning(): cdktf.IResolvable;
}
export declare class DcsInstanceV2BandwidthInfoList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DcsInstanceV2BandwidthInfoOutputReference;
}
export interface DcsInstanceV2BackupPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#backup_at DcsInstanceV2#backup_at}
    */
    readonly backupAt: number[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#backup_type DcsInstanceV2#backup_type}
    */
    readonly backupType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#begin_at DcsInstanceV2#begin_at}
    */
    readonly beginAt: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#period_type DcsInstanceV2#period_type}
    */
    readonly periodType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#save_days DcsInstanceV2#save_days}
    */
    readonly saveDays?: number;
}
export declare function dcsInstanceV2BackupPolicyToTerraform(struct?: DcsInstanceV2BackupPolicyOutputReference | DcsInstanceV2BackupPolicy): any;
export declare function dcsInstanceV2BackupPolicyToHclTerraform(struct?: DcsInstanceV2BackupPolicyOutputReference | DcsInstanceV2BackupPolicy): any;
export declare class DcsInstanceV2BackupPolicyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DcsInstanceV2BackupPolicy | undefined;
    set internalValue(value: DcsInstanceV2BackupPolicy | undefined);
    private _backupAt?;
    get backupAt(): number[];
    set backupAt(value: number[]);
    get backupAtInput(): number[] | undefined;
    private _backupType?;
    get backupType(): string;
    set backupType(value: string);
    resetBackupType(): void;
    get backupTypeInput(): string | undefined;
    private _beginAt?;
    get beginAt(): string;
    set beginAt(value: string);
    get beginAtInput(): string | undefined;
    private _periodType?;
    get periodType(): string;
    set periodType(value: string);
    resetPeriodType(): void;
    get periodTypeInput(): string | undefined;
    private _saveDays?;
    get saveDays(): number;
    set saveDays(value: number);
    resetSaveDays(): void;
    get saveDaysInput(): number | undefined;
}
export interface DcsInstanceV2Parameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#id DcsInstanceV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#name DcsInstanceV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#value DcsInstanceV2#value}
    */
    readonly value: string;
}
export declare function dcsInstanceV2ParametersToTerraform(struct?: DcsInstanceV2Parameters | cdktf.IResolvable): any;
export declare function dcsInstanceV2ParametersToHclTerraform(struct?: DcsInstanceV2Parameters | cdktf.IResolvable): any;
export declare class DcsInstanceV2ParametersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DcsInstanceV2Parameters | cdktf.IResolvable | undefined;
    set internalValue(value: DcsInstanceV2Parameters | cdktf.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class DcsInstanceV2ParametersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DcsInstanceV2Parameters[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DcsInstanceV2ParametersOutputReference;
}
export interface DcsInstanceV2Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#create DcsInstanceV2#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#delete DcsInstanceV2#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#update DcsInstanceV2#update}
    */
    readonly update?: string;
}
export declare function dcsInstanceV2TimeoutsToTerraform(struct?: DcsInstanceV2Timeouts | cdktf.IResolvable): any;
export declare function dcsInstanceV2TimeoutsToHclTerraform(struct?: DcsInstanceV2Timeouts | cdktf.IResolvable): any;
export declare class DcsInstanceV2TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DcsInstanceV2Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DcsInstanceV2Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface DcsInstanceV2WhitelistStruct {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#group_name DcsInstanceV2#group_name}
    */
    readonly groupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#ip_list DcsInstanceV2#ip_list}
    */
    readonly ipList: string[];
}
export declare function dcsInstanceV2WhitelistStructToTerraform(struct?: DcsInstanceV2WhitelistStruct | cdktf.IResolvable): any;
export declare function dcsInstanceV2WhitelistStructToHclTerraform(struct?: DcsInstanceV2WhitelistStruct | cdktf.IResolvable): any;
export declare class DcsInstanceV2WhitelistStructOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DcsInstanceV2WhitelistStruct | cdktf.IResolvable | undefined;
    set internalValue(value: DcsInstanceV2WhitelistStruct | cdktf.IResolvable | undefined);
    private _groupName?;
    get groupName(): string;
    set groupName(value: string);
    get groupNameInput(): string | undefined;
    private _ipList?;
    get ipList(): string[];
    set ipList(value: string[]);
    get ipListInput(): string[] | undefined;
}
export declare class DcsInstanceV2WhitelistStructList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DcsInstanceV2WhitelistStruct[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DcsInstanceV2WhitelistStructOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2 opentelekomcloud_dcs_instance_v2}
*/
export declare class DcsInstanceV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_dcs_instance_v2";
    /**
    * Generates CDKTF code for importing a DcsInstanceV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DcsInstanceV2 to import
    * @param importFromId The id of the existing DcsInstanceV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DcsInstanceV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dcs_instance_v2 opentelekomcloud_dcs_instance_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DcsInstanceV2Config
    */
    constructor(scope: Construct, id: string, config: DcsInstanceV2Config);
    private _accessUser?;
    get accessUser(): string;
    set accessUser(value: string);
    resetAccessUser(): void;
    get accessUserInput(): string | undefined;
    private _availabilityZones?;
    get availabilityZones(): string[];
    set availabilityZones(value: string[]);
    get availabilityZonesInput(): string[] | undefined;
    private _bandwidthInfo;
    get bandwidthInfo(): DcsInstanceV2BandwidthInfoList;
    get cacheMode(): string;
    private _capacity?;
    get capacity(): number;
    set capacity(value: number);
    get capacityInput(): number | undefined;
    get cpuType(): string;
    get createdAt(): string;
    private _deletedNodes?;
    get deletedNodes(): string[];
    set deletedNodes(value: string[]);
    resetDeletedNodes(): void;
    get deletedNodesInput(): string[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get domainName(): string;
    private _enableWhitelist?;
    get enableWhitelist(): boolean | cdktf.IResolvable;
    set enableWhitelist(value: boolean | cdktf.IResolvable);
    resetEnableWhitelist(): void;
    get enableWhitelistInput(): boolean | cdktf.IResolvable | undefined;
    private _engine?;
    get engine(): string;
    set engine(value: string);
    get engineInput(): string | undefined;
    private _engineVersion?;
    get engineVersion(): string;
    set engineVersion(value: string);
    resetEngineVersion(): void;
    get engineVersionInput(): string | undefined;
    private _flavor?;
    get flavor(): string;
    set flavor(value: string);
    get flavorInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get launchedAt(): string;
    private _maintainBegin?;
    get maintainBegin(): string;
    set maintainBegin(value: string);
    resetMaintainBegin(): void;
    get maintainBeginInput(): string | undefined;
    private _maintainEnd?;
    get maintainEnd(): string;
    set maintainEnd(value: string);
    resetMaintainEnd(): void;
    get maintainEndInput(): string | undefined;
    get maxMemory(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _privateIp?;
    get privateIp(): string;
    set privateIp(value: string);
    resetPrivateIp(): void;
    get privateIpInput(): string | undefined;
    get productType(): string;
    get readonlyDomainName(): string;
    get region(): string;
    private _renameCommands?;
    get renameCommands(): {
        [key: string]: string;
    };
    set renameCommands(value: {
        [key: string]: string;
    });
    resetRenameCommands(): void;
    get renameCommandsInput(): {
        [key: string]: string;
    } | undefined;
    get replicaCount(): number;
    private _reservedIps?;
    get reservedIps(): string[];
    set reservedIps(value: string[]);
    resetReservedIps(): void;
    get reservedIpsInput(): string[] | undefined;
    private _securityGroupId?;
    get securityGroupId(): string;
    set securityGroupId(value: string);
    resetSecurityGroupId(): void;
    get securityGroupIdInput(): string | undefined;
    get securityGroupName(): string;
    get shardingCount(): number;
    private _sslEnable?;
    get sslEnable(): boolean | cdktf.IResolvable;
    set sslEnable(value: boolean | cdktf.IResolvable);
    resetSslEnable(): void;
    get sslEnableInput(): boolean | cdktf.IResolvable | undefined;
    get status(): string;
    get subnetCidr(): string;
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    get subnetIdInput(): string | undefined;
    get subnetName(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _templateId?;
    get templateId(): string;
    set templateId(value: string);
    resetTemplateId(): void;
    get templateIdInput(): string | undefined;
    get transparentClientIpEnable(): cdktf.IResolvable;
    get usedMemory(): number;
    get userId(): string;
    get userName(): string;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    get vpcIdInput(): string | undefined;
    get vpcName(): string;
    private _backupPolicy;
    get backupPolicy(): DcsInstanceV2BackupPolicyOutputReference;
    putBackupPolicy(value: DcsInstanceV2BackupPolicy): void;
    resetBackupPolicy(): void;
    get backupPolicyInput(): DcsInstanceV2BackupPolicy | undefined;
    private _parameters;
    get parameters(): DcsInstanceV2ParametersList;
    putParameters(value: DcsInstanceV2Parameters[] | cdktf.IResolvable): void;
    resetParameters(): void;
    get parametersInput(): cdktf.IResolvable | DcsInstanceV2Parameters[] | undefined;
    private _timeouts;
    get timeouts(): DcsInstanceV2TimeoutsOutputReference;
    putTimeouts(value: DcsInstanceV2Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DcsInstanceV2Timeouts | undefined;
    private _whitelist;
    get whitelist(): DcsInstanceV2WhitelistStructList;
    putWhitelist(value: DcsInstanceV2WhitelistStruct[] | cdktf.IResolvable): void;
    resetWhitelist(): void;
    get whitelistInput(): cdktf.IResolvable | DcsInstanceV2WhitelistStruct[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

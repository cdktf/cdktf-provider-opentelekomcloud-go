/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface RdsInstanceV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#availability_zone RdsInstanceV3#availability_zone}
    */
    readonly availabilityZone: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#flavor RdsInstanceV3#flavor}
    */
    readonly flavor: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#ha_replication_mode RdsInstanceV3#ha_replication_mode}
    */
    readonly haReplicationMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#id RdsInstanceV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#lower_case_table_names RdsInstanceV3#lower_case_table_names}
    */
    readonly lowerCaseTableNames?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#name RdsInstanceV3#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#param_group_id RdsInstanceV3#param_group_id}
    */
    readonly paramGroupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#parameters RdsInstanceV3#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#private_ip RdsInstanceV3#private_ip}
    */
    readonly privateIp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#public_ips RdsInstanceV3#public_ips}
    */
    readonly publicIps?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#security_group_id RdsInstanceV3#security_group_id}
    */
    readonly securityGroupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#ssl_enable RdsInstanceV3#ssl_enable}
    */
    readonly sslEnable?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#subnet_id RdsInstanceV3#subnet_id}
    */
    readonly subnetId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#tag RdsInstanceV3#tag}
    */
    readonly tag?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#tags RdsInstanceV3#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#time_zone RdsInstanceV3#time_zone}
    */
    readonly timeZone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#vpc_id RdsInstanceV3#vpc_id}
    */
    readonly vpcId: string;
    /**
    * backup_strategy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#backup_strategy RdsInstanceV3#backup_strategy}
    */
    readonly backupStrategy?: RdsInstanceV3BackupStrategy;
    /**
    * db block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#db RdsInstanceV3#db}
    */
    readonly db: RdsInstanceV3Db;
    /**
    * restore_from_backup block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#restore_from_backup RdsInstanceV3#restore_from_backup}
    */
    readonly restoreFromBackup?: RdsInstanceV3RestoreFromBackup;
    /**
    * restore_point block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#restore_point RdsInstanceV3#restore_point}
    */
    readonly restorePoint?: RdsInstanceV3RestorePoint;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#timeouts RdsInstanceV3#timeouts}
    */
    readonly timeouts?: RdsInstanceV3Timeouts;
    /**
    * volume block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#volume RdsInstanceV3#volume}
    */
    readonly volume: RdsInstanceV3Volume;
}
export interface RdsInstanceV3Nodes {
}
export declare function rdsInstanceV3NodesToTerraform(struct?: RdsInstanceV3Nodes): any;
export declare function rdsInstanceV3NodesToHclTerraform(struct?: RdsInstanceV3Nodes): any;
export declare class RdsInstanceV3NodesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RdsInstanceV3Nodes | undefined;
    set internalValue(value: RdsInstanceV3Nodes | undefined);
    get availabilityZone(): string;
    get id(): string;
    get name(): string;
    get role(): string;
    get status(): string;
}
export declare class RdsInstanceV3NodesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RdsInstanceV3NodesOutputReference;
}
export interface RdsInstanceV3BackupStrategy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#keep_days RdsInstanceV3#keep_days}
    */
    readonly keepDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#period RdsInstanceV3#period}
    */
    readonly period?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#start_time RdsInstanceV3#start_time}
    */
    readonly startTime: string;
}
export declare function rdsInstanceV3BackupStrategyToTerraform(struct?: RdsInstanceV3BackupStrategyOutputReference | RdsInstanceV3BackupStrategy): any;
export declare function rdsInstanceV3BackupStrategyToHclTerraform(struct?: RdsInstanceV3BackupStrategyOutputReference | RdsInstanceV3BackupStrategy): any;
export declare class RdsInstanceV3BackupStrategyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RdsInstanceV3BackupStrategy | undefined;
    set internalValue(value: RdsInstanceV3BackupStrategy | undefined);
    private _keepDays?;
    get keepDays(): number;
    set keepDays(value: number);
    resetKeepDays(): void;
    get keepDaysInput(): number | undefined;
    private _period?;
    get period(): string;
    set period(value: string);
    resetPeriod(): void;
    get periodInput(): string | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    get startTimeInput(): string | undefined;
}
export interface RdsInstanceV3Db {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#password RdsInstanceV3#password}
    */
    readonly password: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#port RdsInstanceV3#port}
    */
    readonly port?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#type RdsInstanceV3#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#version RdsInstanceV3#version}
    */
    readonly version?: string;
}
export declare function rdsInstanceV3DbToTerraform(struct?: RdsInstanceV3DbOutputReference | RdsInstanceV3Db): any;
export declare function rdsInstanceV3DbToHclTerraform(struct?: RdsInstanceV3DbOutputReference | RdsInstanceV3Db): any;
export declare class RdsInstanceV3DbOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RdsInstanceV3Db | undefined;
    set internalValue(value: RdsInstanceV3Db | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    get userName(): string;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export interface RdsInstanceV3RestoreFromBackup {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#backup_id RdsInstanceV3#backup_id}
    */
    readonly backupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#restore_time RdsInstanceV3#restore_time}
    */
    readonly restoreTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#source_instance_id RdsInstanceV3#source_instance_id}
    */
    readonly sourceInstanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#type RdsInstanceV3#type}
    */
    readonly type: string;
}
export declare function rdsInstanceV3RestoreFromBackupToTerraform(struct?: RdsInstanceV3RestoreFromBackupOutputReference | RdsInstanceV3RestoreFromBackup): any;
export declare function rdsInstanceV3RestoreFromBackupToHclTerraform(struct?: RdsInstanceV3RestoreFromBackupOutputReference | RdsInstanceV3RestoreFromBackup): any;
export declare class RdsInstanceV3RestoreFromBackupOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RdsInstanceV3RestoreFromBackup | undefined;
    set internalValue(value: RdsInstanceV3RestoreFromBackup | undefined);
    private _backupId?;
    get backupId(): string;
    set backupId(value: string);
    resetBackupId(): void;
    get backupIdInput(): string | undefined;
    private _restoreTime?;
    get restoreTime(): number;
    set restoreTime(value: number);
    resetRestoreTime(): void;
    get restoreTimeInput(): number | undefined;
    private _sourceInstanceId?;
    get sourceInstanceId(): string;
    set sourceInstanceId(value: string);
    get sourceInstanceIdInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface RdsInstanceV3RestorePoint {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#backup_id RdsInstanceV3#backup_id}
    */
    readonly backupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#instance_id RdsInstanceV3#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#restore_time RdsInstanceV3#restore_time}
    */
    readonly restoreTime?: number;
}
export declare function rdsInstanceV3RestorePointToTerraform(struct?: RdsInstanceV3RestorePointOutputReference | RdsInstanceV3RestorePoint): any;
export declare function rdsInstanceV3RestorePointToHclTerraform(struct?: RdsInstanceV3RestorePointOutputReference | RdsInstanceV3RestorePoint): any;
export declare class RdsInstanceV3RestorePointOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RdsInstanceV3RestorePoint | undefined;
    set internalValue(value: RdsInstanceV3RestorePoint | undefined);
    private _backupId?;
    get backupId(): string;
    set backupId(value: string);
    resetBackupId(): void;
    get backupIdInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _restoreTime?;
    get restoreTime(): number;
    set restoreTime(value: number);
    resetRestoreTime(): void;
    get restoreTimeInput(): number | undefined;
}
export interface RdsInstanceV3Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#create RdsInstanceV3#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#update RdsInstanceV3#update}
    */
    readonly update?: string;
}
export declare function rdsInstanceV3TimeoutsToTerraform(struct?: RdsInstanceV3Timeouts | cdktf.IResolvable): any;
export declare function rdsInstanceV3TimeoutsToHclTerraform(struct?: RdsInstanceV3Timeouts | cdktf.IResolvable): any;
export declare class RdsInstanceV3TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RdsInstanceV3Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: RdsInstanceV3Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface RdsInstanceV3Volume {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#disk_encryption_id RdsInstanceV3#disk_encryption_id}
    */
    readonly diskEncryptionId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#limit_size RdsInstanceV3#limit_size}
    */
    readonly limitSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#size RdsInstanceV3#size}
    */
    readonly size: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#trigger_threshold RdsInstanceV3#trigger_threshold}
    */
    readonly triggerThreshold?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#type RdsInstanceV3#type}
    */
    readonly type: string;
}
export declare function rdsInstanceV3VolumeToTerraform(struct?: RdsInstanceV3VolumeOutputReference | RdsInstanceV3Volume): any;
export declare function rdsInstanceV3VolumeToHclTerraform(struct?: RdsInstanceV3VolumeOutputReference | RdsInstanceV3Volume): any;
export declare class RdsInstanceV3VolumeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RdsInstanceV3Volume | undefined;
    set internalValue(value: RdsInstanceV3Volume | undefined);
    private _diskEncryptionId?;
    get diskEncryptionId(): string;
    set diskEncryptionId(value: string);
    resetDiskEncryptionId(): void;
    get diskEncryptionIdInput(): string | undefined;
    private _limitSize?;
    get limitSize(): number;
    set limitSize(value: number);
    resetLimitSize(): void;
    get limitSizeInput(): number | undefined;
    private _size?;
    get size(): number;
    set size(value: number);
    get sizeInput(): number | undefined;
    private _triggerThreshold?;
    get triggerThreshold(): number;
    set triggerThreshold(value: number);
    resetTriggerThreshold(): void;
    get triggerThresholdInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3 opentelekomcloud_rds_instance_v3}
*/
export declare class RdsInstanceV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_rds_instance_v3";
    /**
    * Generates CDKTF code for importing a RdsInstanceV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RdsInstanceV3 to import
    * @param importFromId The id of the existing RdsInstanceV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RdsInstanceV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_instance_v3 opentelekomcloud_rds_instance_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RdsInstanceV3Config
    */
    constructor(scope: Construct, id: string, config: RdsInstanceV3Config);
    get autoscalingEnabled(): cdktf.IResolvable;
    private _availabilityZone?;
    get availabilityZone(): string[];
    set availabilityZone(value: string[]);
    get availabilityZoneInput(): string[] | undefined;
    get availabilityZones(): string[];
    get created(): string;
    private _flavor?;
    get flavor(): string;
    set flavor(value: string);
    get flavorInput(): string | undefined;
    private _haReplicationMode?;
    get haReplicationMode(): string;
    set haReplicationMode(value: string);
    resetHaReplicationMode(): void;
    get haReplicationModeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _lowerCaseTableNames?;
    get lowerCaseTableNames(): string;
    set lowerCaseTableNames(value: string);
    resetLowerCaseTableNames(): void;
    get lowerCaseTableNamesInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _nodes;
    get nodes(): RdsInstanceV3NodesList;
    private _paramGroupId?;
    get paramGroupId(): string;
    set paramGroupId(value: string);
    resetParamGroupId(): void;
    get paramGroupIdInput(): string | undefined;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _privateIp?;
    get privateIp(): string;
    set privateIp(value: string);
    resetPrivateIp(): void;
    get privateIpInput(): string | undefined;
    get privateIps(): string[];
    private _publicIps?;
    get publicIps(): string[];
    set publicIps(value: string[]);
    resetPublicIps(): void;
    get publicIpsInput(): string[] | undefined;
    get restoredBackupId(): string;
    private _securityGroupId?;
    get securityGroupId(): string;
    set securityGroupId(value: string);
    get securityGroupIdInput(): string | undefined;
    private _sslEnable?;
    get sslEnable(): boolean | cdktf.IResolvable;
    set sslEnable(value: boolean | cdktf.IResolvable);
    resetSslEnable(): void;
    get sslEnableInput(): boolean | cdktf.IResolvable | undefined;
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    get subnetIdInput(): string | undefined;
    private _tag?;
    get tag(): {
        [key: string]: string;
    };
    set tag(value: {
        [key: string]: string;
    });
    resetTag(): void;
    get tagInput(): {
        [key: string]: string;
    } | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _timeZone?;
    get timeZone(): string;
    set timeZone(value: string);
    resetTimeZone(): void;
    get timeZoneInput(): string | undefined;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    get vpcIdInput(): string | undefined;
    private _backupStrategy;
    get backupStrategy(): RdsInstanceV3BackupStrategyOutputReference;
    putBackupStrategy(value: RdsInstanceV3BackupStrategy): void;
    resetBackupStrategy(): void;
    get backupStrategyInput(): RdsInstanceV3BackupStrategy | undefined;
    private _db;
    get db(): RdsInstanceV3DbOutputReference;
    putDb(value: RdsInstanceV3Db): void;
    get dbInput(): RdsInstanceV3Db | undefined;
    private _restoreFromBackup;
    get restoreFromBackup(): RdsInstanceV3RestoreFromBackupOutputReference;
    putRestoreFromBackup(value: RdsInstanceV3RestoreFromBackup): void;
    resetRestoreFromBackup(): void;
    get restoreFromBackupInput(): RdsInstanceV3RestoreFromBackup | undefined;
    private _restorePoint;
    get restorePoint(): RdsInstanceV3RestorePointOutputReference;
    putRestorePoint(value: RdsInstanceV3RestorePoint): void;
    resetRestorePoint(): void;
    get restorePointInput(): RdsInstanceV3RestorePoint | undefined;
    private _timeouts;
    get timeouts(): RdsInstanceV3TimeoutsOutputReference;
    putTimeouts(value: RdsInstanceV3Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | RdsInstanceV3Timeouts | undefined;
    private _volume;
    get volume(): RdsInstanceV3VolumeOutputReference;
    putVolume(value: RdsInstanceV3Volume): void;
    get volumeInput(): RdsInstanceV3Volume | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

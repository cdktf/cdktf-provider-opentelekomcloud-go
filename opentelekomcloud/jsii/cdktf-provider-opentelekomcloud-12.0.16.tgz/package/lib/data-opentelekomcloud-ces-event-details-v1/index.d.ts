/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudCesEventDetailsV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_event_details_v1#event_level DataOpentelekomcloudCesEventDetailsV1#event_level}
    */
    readonly eventLevel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_event_details_v1#event_name DataOpentelekomcloudCesEventDetailsV1#event_name}
    */
    readonly eventName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_event_details_v1#event_source DataOpentelekomcloudCesEventDetailsV1#event_source}
    */
    readonly eventSource?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_event_details_v1#event_state DataOpentelekomcloudCesEventDetailsV1#event_state}
    */
    readonly eventState?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_event_details_v1#event_type DataOpentelekomcloudCesEventDetailsV1#event_type}
    */
    readonly eventType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_event_details_v1#event_user DataOpentelekomcloudCesEventDetailsV1#event_user}
    */
    readonly eventUser?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_event_details_v1#from DataOpentelekomcloudCesEventDetailsV1#from}
    */
    readonly from?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_event_details_v1#id DataOpentelekomcloudCesEventDetailsV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_event_details_v1#limit DataOpentelekomcloudCesEventDetailsV1#limit}
    */
    readonly limit?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_event_details_v1#to DataOpentelekomcloudCesEventDetailsV1#to}
    */
    readonly to?: number;
}
export interface DataOpentelekomcloudCesEventDetailsV1EventInfoDetail {
}
export declare function dataOpentelekomcloudCesEventDetailsV1EventInfoDetailToTerraform(struct?: DataOpentelekomcloudCesEventDetailsV1EventInfoDetail): any;
export declare function dataOpentelekomcloudCesEventDetailsV1EventInfoDetailToHclTerraform(struct?: DataOpentelekomcloudCesEventDetailsV1EventInfoDetail): any;
export declare class DataOpentelekomcloudCesEventDetailsV1EventInfoDetailOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudCesEventDetailsV1EventInfoDetail | undefined;
    set internalValue(value: DataOpentelekomcloudCesEventDetailsV1EventInfoDetail | undefined);
    get content(): string;
    get eventLevel(): string;
    get eventState(): string;
    get eventType(): string;
    get eventUser(): string;
    get groupId(): string;
    get resourceId(): string;
    get resourceName(): string;
}
export declare class DataOpentelekomcloudCesEventDetailsV1EventInfoDetailList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudCesEventDetailsV1EventInfoDetailOutputReference;
}
export interface DataOpentelekomcloudCesEventDetailsV1EventInfo {
}
export declare function dataOpentelekomcloudCesEventDetailsV1EventInfoToTerraform(struct?: DataOpentelekomcloudCesEventDetailsV1EventInfo): any;
export declare function dataOpentelekomcloudCesEventDetailsV1EventInfoToHclTerraform(struct?: DataOpentelekomcloudCesEventDetailsV1EventInfo): any;
export declare class DataOpentelekomcloudCesEventDetailsV1EventInfoOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudCesEventDetailsV1EventInfo | undefined;
    set internalValue(value: DataOpentelekomcloudCesEventDetailsV1EventInfo | undefined);
    private _detail;
    get detail(): DataOpentelekomcloudCesEventDetailsV1EventInfoDetailList;
    get eventId(): string;
    get eventName(): string;
    get eventSource(): string;
    get time(): number;
}
export declare class DataOpentelekomcloudCesEventDetailsV1EventInfoList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudCesEventDetailsV1EventInfoOutputReference;
}
export interface DataOpentelekomcloudCesEventDetailsV1MetaData {
}
export declare function dataOpentelekomcloudCesEventDetailsV1MetaDataToTerraform(struct?: DataOpentelekomcloudCesEventDetailsV1MetaData): any;
export declare function dataOpentelekomcloudCesEventDetailsV1MetaDataToHclTerraform(struct?: DataOpentelekomcloudCesEventDetailsV1MetaData): any;
export declare class DataOpentelekomcloudCesEventDetailsV1MetaDataOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudCesEventDetailsV1MetaData | undefined;
    set internalValue(value: DataOpentelekomcloudCesEventDetailsV1MetaData | undefined);
    get total(): number;
}
export declare class DataOpentelekomcloudCesEventDetailsV1MetaDataList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudCesEventDetailsV1MetaDataOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_event_details_v1 opentelekomcloud_ces_event_details_v1}
*/
export declare class DataOpentelekomcloudCesEventDetailsV1 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_ces_event_details_v1";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudCesEventDetailsV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudCesEventDetailsV1 to import
    * @param importFromId The id of the existing DataOpentelekomcloudCesEventDetailsV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_event_details_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudCesEventDetailsV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_event_details_v1 opentelekomcloud_ces_event_details_v1} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudCesEventDetailsV1Config
    */
    constructor(scope: Construct, id: string, config: DataOpentelekomcloudCesEventDetailsV1Config);
    private _eventInfo;
    get eventInfo(): DataOpentelekomcloudCesEventDetailsV1EventInfoList;
    private _eventLevel?;
    get eventLevel(): string;
    set eventLevel(value: string);
    resetEventLevel(): void;
    get eventLevelInput(): string | undefined;
    private _eventName?;
    get eventName(): string;
    set eventName(value: string);
    get eventNameInput(): string | undefined;
    private _eventSource?;
    get eventSource(): string;
    set eventSource(value: string);
    resetEventSource(): void;
    get eventSourceInput(): string | undefined;
    get eventSources(): string[];
    private _eventState?;
    get eventState(): string;
    set eventState(value: string);
    resetEventState(): void;
    get eventStateInput(): string | undefined;
    private _eventType?;
    get eventType(): string;
    set eventType(value: string);
    get eventTypeInput(): string | undefined;
    private _eventUser?;
    get eventUser(): string;
    set eventUser(value: string);
    resetEventUser(): void;
    get eventUserInput(): string | undefined;
    get eventUsers(): string[];
    private _from?;
    get from(): number;
    set from(value: number);
    resetFrom(): void;
    get fromInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _metaData;
    get metaData(): DataOpentelekomcloudCesEventDetailsV1MetaDataList;
    private _to?;
    get to(): number;
    set to(value: number);
    resetTo(): void;
    get toInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DmsSmartConnectV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_v2#bandwidth DmsSmartConnectV2#bandwidth}
    */
    readonly bandwidth?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_v2#id DmsSmartConnectV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_v2#instance_id DmsSmartConnectV2#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_v2#node_count DmsSmartConnectV2#node_count}
    */
    readonly nodeCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_v2#storage_spec_code DmsSmartConnectV2#storage_spec_code}
    */
    readonly storageSpecCode?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_v2#timeouts DmsSmartConnectV2#timeouts}
    */
    readonly timeouts?: DmsSmartConnectV2Timeouts;
}
export interface DmsSmartConnectV2Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_v2#create DmsSmartConnectV2#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_v2#delete DmsSmartConnectV2#delete}
    */
    readonly delete?: string;
}
export declare function dmsSmartConnectV2TimeoutsToTerraform(struct?: DmsSmartConnectV2Timeouts | cdktf.IResolvable): any;
export declare function dmsSmartConnectV2TimeoutsToHclTerraform(struct?: DmsSmartConnectV2Timeouts | cdktf.IResolvable): any;
export declare class DmsSmartConnectV2TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DmsSmartConnectV2Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DmsSmartConnectV2Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_v2 opentelekomcloud_dms_smart_connect_v2}
*/
export declare class DmsSmartConnectV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_dms_smart_connect_v2";
    /**
    * Generates CDKTF code for importing a DmsSmartConnectV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DmsSmartConnectV2 to import
    * @param importFromId The id of the existing DmsSmartConnectV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DmsSmartConnectV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_v2 opentelekomcloud_dms_smart_connect_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DmsSmartConnectV2Config
    */
    constructor(scope: Construct, id: string, config: DmsSmartConnectV2Config);
    private _bandwidth?;
    get bandwidth(): string;
    set bandwidth(value: string);
    resetBandwidth(): void;
    get bandwidthInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _nodeCount?;
    get nodeCount(): number;
    set nodeCount(value: number);
    resetNodeCount(): void;
    get nodeCountInput(): number | undefined;
    get region(): string;
    private _storageSpecCode?;
    get storageSpecCode(): string;
    set storageSpecCode(value: string);
    resetStorageSpecCode(): void;
    get storageSpecCodeInput(): string | undefined;
    private _timeouts;
    get timeouts(): DmsSmartConnectV2TimeoutsOutputReference;
    putTimeouts(value: DmsSmartConnectV2Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DmsSmartConnectV2Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudVpcRouteTablesV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/vpc_route_tables_v1#id DataOpentelekomcloudVpcRouteTablesV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/vpc_route_tables_v1#subnet_id DataOpentelekomcloudVpcRouteTablesV1#subnet_id}
    */
    readonly subnetId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/vpc_route_tables_v1#vpc_id DataOpentelekomcloudVpcRouteTablesV1#vpc_id}
    */
    readonly vpcId?: string;
}
export interface DataOpentelekomcloudVpcRouteTablesV1RoutetablesRoutes {
}
export declare function dataOpentelekomcloudVpcRouteTablesV1RoutetablesRoutesToTerraform(struct?: DataOpentelekomcloudVpcRouteTablesV1RoutetablesRoutes): any;
export declare function dataOpentelekomcloudVpcRouteTablesV1RoutetablesRoutesToHclTerraform(struct?: DataOpentelekomcloudVpcRouteTablesV1RoutetablesRoutes): any;
export declare class DataOpentelekomcloudVpcRouteTablesV1RoutetablesRoutesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudVpcRouteTablesV1RoutetablesRoutes | undefined;
    set internalValue(value: DataOpentelekomcloudVpcRouteTablesV1RoutetablesRoutes | undefined);
    get description(): string;
    get destination(): string;
    get nexthop(): string;
    get type(): string;
}
export declare class DataOpentelekomcloudVpcRouteTablesV1RoutetablesRoutesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudVpcRouteTablesV1RoutetablesRoutesOutputReference;
}
export interface DataOpentelekomcloudVpcRouteTablesV1Routetables {
}
export declare function dataOpentelekomcloudVpcRouteTablesV1RoutetablesToTerraform(struct?: DataOpentelekomcloudVpcRouteTablesV1Routetables): any;
export declare function dataOpentelekomcloudVpcRouteTablesV1RoutetablesToHclTerraform(struct?: DataOpentelekomcloudVpcRouteTablesV1Routetables): any;
export declare class DataOpentelekomcloudVpcRouteTablesV1RoutetablesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudVpcRouteTablesV1Routetables | undefined;
    set internalValue(value: DataOpentelekomcloudVpcRouteTablesV1Routetables | undefined);
    get default(): cdktf.IResolvable;
    get description(): string;
    get id(): string;
    get name(): string;
    private _routes;
    get routes(): DataOpentelekomcloudVpcRouteTablesV1RoutetablesRoutesList;
    get subnets(): string[];
    get tenantId(): string;
    get vpcId(): string;
}
export declare class DataOpentelekomcloudVpcRouteTablesV1RoutetablesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudVpcRouteTablesV1RoutetablesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/vpc_route_tables_v1 opentelekomcloud_vpc_route_tables_v1}
*/
export declare class DataOpentelekomcloudVpcRouteTablesV1 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_vpc_route_tables_v1";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudVpcRouteTablesV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudVpcRouteTablesV1 to import
    * @param importFromId The id of the existing DataOpentelekomcloudVpcRouteTablesV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/vpc_route_tables_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudVpcRouteTablesV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/vpc_route_tables_v1 opentelekomcloud_vpc_route_tables_v1} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudVpcRouteTablesV1Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudVpcRouteTablesV1Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _routetables;
    get routetables(): DataOpentelekomcloudVpcRouteTablesV1RoutetablesList;
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    resetSubnetId(): void;
    get subnetIdInput(): string | undefined;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    resetVpcId(): void;
    get vpcIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

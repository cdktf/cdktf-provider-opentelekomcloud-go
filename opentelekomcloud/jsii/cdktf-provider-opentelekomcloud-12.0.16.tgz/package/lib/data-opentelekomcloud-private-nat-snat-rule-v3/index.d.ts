/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudPrivateNatSnatRuleV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/private_nat_snat_rule_v3#id DataOpentelekomcloudPrivateNatSnatRuleV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataOpentelekomcloudPrivateNatSnatRuleV3SnatRulesTransitIpAssociations {
}
export declare function dataOpentelekomcloudPrivateNatSnatRuleV3SnatRulesTransitIpAssociationsToTerraform(struct?: DataOpentelekomcloudPrivateNatSnatRuleV3SnatRulesTransitIpAssociations): any;
export declare function dataOpentelekomcloudPrivateNatSnatRuleV3SnatRulesTransitIpAssociationsToHclTerraform(struct?: DataOpentelekomcloudPrivateNatSnatRuleV3SnatRulesTransitIpAssociations): any;
export declare class DataOpentelekomcloudPrivateNatSnatRuleV3SnatRulesTransitIpAssociationsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudPrivateNatSnatRuleV3SnatRulesTransitIpAssociations | undefined;
    set internalValue(value: DataOpentelekomcloudPrivateNatSnatRuleV3SnatRulesTransitIpAssociations | undefined);
    get transitIpAddress(): string;
    get transitIpId(): string;
}
export declare class DataOpentelekomcloudPrivateNatSnatRuleV3SnatRulesTransitIpAssociationsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudPrivateNatSnatRuleV3SnatRulesTransitIpAssociationsOutputReference;
}
export interface DataOpentelekomcloudPrivateNatSnatRuleV3SnatRules {
}
export declare function dataOpentelekomcloudPrivateNatSnatRuleV3SnatRulesToTerraform(struct?: DataOpentelekomcloudPrivateNatSnatRuleV3SnatRules): any;
export declare function dataOpentelekomcloudPrivateNatSnatRuleV3SnatRulesToHclTerraform(struct?: DataOpentelekomcloudPrivateNatSnatRuleV3SnatRules): any;
export declare class DataOpentelekomcloudPrivateNatSnatRuleV3SnatRulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudPrivateNatSnatRuleV3SnatRules | undefined;
    set internalValue(value: DataOpentelekomcloudPrivateNatSnatRuleV3SnatRules | undefined);
    get cidr(): string;
    get createdAt(): string;
    get description(): string;
    get enterpriseProjectId(): string;
    get gatewayId(): string;
    get id(): string;
    get projectId(): string;
    get status(): string;
    private _transitIpAssociations;
    get transitIpAssociations(): DataOpentelekomcloudPrivateNatSnatRuleV3SnatRulesTransitIpAssociationsList;
    get transitIpIds(): string[];
    get updatedAt(): string;
    get virsubnetId(): string;
}
export declare class DataOpentelekomcloudPrivateNatSnatRuleV3SnatRulesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudPrivateNatSnatRuleV3SnatRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/private_nat_snat_rule_v3 opentelekomcloud_private_nat_snat_rule_v3}
*/
export declare class DataOpentelekomcloudPrivateNatSnatRuleV3 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_private_nat_snat_rule_v3";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudPrivateNatSnatRuleV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudPrivateNatSnatRuleV3 to import
    * @param importFromId The id of the existing DataOpentelekomcloudPrivateNatSnatRuleV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/private_nat_snat_rule_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudPrivateNatSnatRuleV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/private_nat_snat_rule_v3 opentelekomcloud_private_nat_snat_rule_v3} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudPrivateNatSnatRuleV3Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudPrivateNatSnatRuleV3Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _snatRules;
    get snatRules(): DataOpentelekomcloudPrivateNatSnatRuleV3SnatRulesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

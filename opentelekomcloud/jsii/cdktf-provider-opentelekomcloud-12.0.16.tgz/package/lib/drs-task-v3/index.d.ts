/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DrsTaskV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#action DrsTaskV3#action}
    */
    readonly action?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#description DrsTaskV3#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#destination_db_readonly DrsTaskV3#destination_db_readonly}
    */
    readonly destinationDbReadonly?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#direction DrsTaskV3#direction}
    */
    readonly direction: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#engine_type DrsTaskV3#engine_type}
    */
    readonly engineType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#expired_days DrsTaskV3#expired_days}
    */
    readonly expiredDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#force_destroy DrsTaskV3#force_destroy}
    */
    readonly forceDestroy?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#id DrsTaskV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#migrate_definer DrsTaskV3#migrate_definer}
    */
    readonly migrateDefiner?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#migration_type DrsTaskV3#migration_type}
    */
    readonly migrationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#multi_write DrsTaskV3#multi_write}
    */
    readonly multiWrite?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#name DrsTaskV3#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#net_type DrsTaskV3#net_type}
    */
    readonly netType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#node_num DrsTaskV3#node_num}
    */
    readonly nodeNum?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#start_time DrsTaskV3#start_time}
    */
    readonly startTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#tags DrsTaskV3#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#type DrsTaskV3#type}
    */
    readonly type: string;
    /**
    * destination_db block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#destination_db DrsTaskV3#destination_db}
    */
    readonly destinationDb: DrsTaskV3DestinationDb;
    /**
    * limit_speed block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#limit_speed DrsTaskV3#limit_speed}
    */
    readonly limitSpeed?: DrsTaskV3LimitSpeed[] | cdktf.IResolvable;
    /**
    * source_db block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#source_db DrsTaskV3#source_db}
    */
    readonly sourceDb: DrsTaskV3SourceDb;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#timeouts DrsTaskV3#timeouts}
    */
    readonly timeouts?: DrsTaskV3Timeouts;
}
export interface DrsTaskV3DestinationDb {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#engine_type DrsTaskV3#engine_type}
    */
    readonly engineType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#instance_id DrsTaskV3#instance_id}
    */
    readonly instanceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#ip DrsTaskV3#ip}
    */
    readonly ip: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#name DrsTaskV3#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#password DrsTaskV3#password}
    */
    readonly password: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#port DrsTaskV3#port}
    */
    readonly port: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#region DrsTaskV3#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#ssl_cert_check_sum DrsTaskV3#ssl_cert_check_sum}
    */
    readonly sslCertCheckSum?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#ssl_cert_key DrsTaskV3#ssl_cert_key}
    */
    readonly sslCertKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#ssl_cert_name DrsTaskV3#ssl_cert_name}
    */
    readonly sslCertName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#ssl_cert_password DrsTaskV3#ssl_cert_password}
    */
    readonly sslCertPassword?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#ssl_enabled DrsTaskV3#ssl_enabled}
    */
    readonly sslEnabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#subnet_id DrsTaskV3#subnet_id}
    */
    readonly subnetId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#user DrsTaskV3#user}
    */
    readonly user: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#vpc_id DrsTaskV3#vpc_id}
    */
    readonly vpcId?: string;
}
export declare function drsTaskV3DestinationDbToTerraform(struct?: DrsTaskV3DestinationDbOutputReference | DrsTaskV3DestinationDb): any;
export declare function drsTaskV3DestinationDbToHclTerraform(struct?: DrsTaskV3DestinationDbOutputReference | DrsTaskV3DestinationDb): any;
export declare class DrsTaskV3DestinationDbOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DrsTaskV3DestinationDb | undefined;
    set internalValue(value: DrsTaskV3DestinationDb | undefined);
    private _engineType?;
    get engineType(): string;
    set engineType(value: string);
    get engineTypeInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    resetInstanceId(): void;
    get instanceIdInput(): string | undefined;
    private _ip?;
    get ip(): string;
    set ip(value: string);
    get ipInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
    get privateIp(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _sslCertCheckSum?;
    get sslCertCheckSum(): string;
    set sslCertCheckSum(value: string);
    resetSslCertCheckSum(): void;
    get sslCertCheckSumInput(): string | undefined;
    private _sslCertKey?;
    get sslCertKey(): string;
    set sslCertKey(value: string);
    resetSslCertKey(): void;
    get sslCertKeyInput(): string | undefined;
    private _sslCertName?;
    get sslCertName(): string;
    set sslCertName(value: string);
    resetSslCertName(): void;
    get sslCertNameInput(): string | undefined;
    private _sslCertPassword?;
    get sslCertPassword(): string;
    set sslCertPassword(value: string);
    resetSslCertPassword(): void;
    get sslCertPasswordInput(): string | undefined;
    private _sslEnabled?;
    get sslEnabled(): boolean | cdktf.IResolvable;
    set sslEnabled(value: boolean | cdktf.IResolvable);
    resetSslEnabled(): void;
    get sslEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    resetSubnetId(): void;
    get subnetIdInput(): string | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    get userInput(): string | undefined;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    resetVpcId(): void;
    get vpcIdInput(): string | undefined;
}
export interface DrsTaskV3LimitSpeed {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#end_time DrsTaskV3#end_time}
    */
    readonly endTime: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#speed DrsTaskV3#speed}
    */
    readonly speed: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#start_time DrsTaskV3#start_time}
    */
    readonly startTime: string;
}
export declare function drsTaskV3LimitSpeedToTerraform(struct?: DrsTaskV3LimitSpeed | cdktf.IResolvable): any;
export declare function drsTaskV3LimitSpeedToHclTerraform(struct?: DrsTaskV3LimitSpeed | cdktf.IResolvable): any;
export declare class DrsTaskV3LimitSpeedOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DrsTaskV3LimitSpeed | cdktf.IResolvable | undefined;
    set internalValue(value: DrsTaskV3LimitSpeed | cdktf.IResolvable | undefined);
    private _endTime?;
    get endTime(): string;
    set endTime(value: string);
    get endTimeInput(): string | undefined;
    private _speed?;
    get speed(): string;
    set speed(value: string);
    get speedInput(): string | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    get startTimeInput(): string | undefined;
}
export declare class DrsTaskV3LimitSpeedList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DrsTaskV3LimitSpeed[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DrsTaskV3LimitSpeedOutputReference;
}
export interface DrsTaskV3SourceDb {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#engine_type DrsTaskV3#engine_type}
    */
    readonly engineType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#instance_id DrsTaskV3#instance_id}
    */
    readonly instanceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#ip DrsTaskV3#ip}
    */
    readonly ip: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#name DrsTaskV3#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#password DrsTaskV3#password}
    */
    readonly password: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#port DrsTaskV3#port}
    */
    readonly port: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#region DrsTaskV3#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#ssl_cert_check_sum DrsTaskV3#ssl_cert_check_sum}
    */
    readonly sslCertCheckSum?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#ssl_cert_key DrsTaskV3#ssl_cert_key}
    */
    readonly sslCertKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#ssl_cert_name DrsTaskV3#ssl_cert_name}
    */
    readonly sslCertName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#ssl_cert_password DrsTaskV3#ssl_cert_password}
    */
    readonly sslCertPassword?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#ssl_enabled DrsTaskV3#ssl_enabled}
    */
    readonly sslEnabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#subnet_id DrsTaskV3#subnet_id}
    */
    readonly subnetId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#user DrsTaskV3#user}
    */
    readonly user: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#vpc_id DrsTaskV3#vpc_id}
    */
    readonly vpcId?: string;
}
export declare function drsTaskV3SourceDbToTerraform(struct?: DrsTaskV3SourceDbOutputReference | DrsTaskV3SourceDb): any;
export declare function drsTaskV3SourceDbToHclTerraform(struct?: DrsTaskV3SourceDbOutputReference | DrsTaskV3SourceDb): any;
export declare class DrsTaskV3SourceDbOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DrsTaskV3SourceDb | undefined;
    set internalValue(value: DrsTaskV3SourceDb | undefined);
    private _engineType?;
    get engineType(): string;
    set engineType(value: string);
    get engineTypeInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    resetInstanceId(): void;
    get instanceIdInput(): string | undefined;
    private _ip?;
    get ip(): string;
    set ip(value: string);
    get ipInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
    get privateIp(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _sslCertCheckSum?;
    get sslCertCheckSum(): string;
    set sslCertCheckSum(value: string);
    resetSslCertCheckSum(): void;
    get sslCertCheckSumInput(): string | undefined;
    private _sslCertKey?;
    get sslCertKey(): string;
    set sslCertKey(value: string);
    resetSslCertKey(): void;
    get sslCertKeyInput(): string | undefined;
    private _sslCertName?;
    get sslCertName(): string;
    set sslCertName(value: string);
    resetSslCertName(): void;
    get sslCertNameInput(): string | undefined;
    private _sslCertPassword?;
    get sslCertPassword(): string;
    set sslCertPassword(value: string);
    resetSslCertPassword(): void;
    get sslCertPasswordInput(): string | undefined;
    private _sslEnabled?;
    get sslEnabled(): boolean | cdktf.IResolvable;
    set sslEnabled(value: boolean | cdktf.IResolvable);
    resetSslEnabled(): void;
    get sslEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    resetSubnetId(): void;
    get subnetIdInput(): string | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    get userInput(): string | undefined;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    resetVpcId(): void;
    get vpcIdInput(): string | undefined;
}
export interface DrsTaskV3Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#create DrsTaskV3#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#delete DrsTaskV3#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#update DrsTaskV3#update}
    */
    readonly update?: string;
}
export declare function drsTaskV3TimeoutsToTerraform(struct?: DrsTaskV3Timeouts | cdktf.IResolvable): any;
export declare function drsTaskV3TimeoutsToHclTerraform(struct?: DrsTaskV3Timeouts | cdktf.IResolvable): any;
export declare class DrsTaskV3TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DrsTaskV3Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DrsTaskV3Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3 opentelekomcloud_drs_task_v3}
*/
export declare class DrsTaskV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_drs_task_v3";
    /**
    * Generates CDKTF code for importing a DrsTaskV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DrsTaskV3 to import
    * @param importFromId The id of the existing DrsTaskV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DrsTaskV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/drs_task_v3 opentelekomcloud_drs_task_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DrsTaskV3Config
    */
    constructor(scope: Construct, id: string, config: DrsTaskV3Config);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _destinationDbReadonly?;
    get destinationDbReadonly(): boolean | cdktf.IResolvable;
    set destinationDbReadonly(value: boolean | cdktf.IResolvable);
    resetDestinationDbReadonly(): void;
    get destinationDbReadonlyInput(): boolean | cdktf.IResolvable | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    get directionInput(): string | undefined;
    private _engineType?;
    get engineType(): string;
    set engineType(value: string);
    get engineTypeInput(): string | undefined;
    private _expiredDays?;
    get expiredDays(): number;
    set expiredDays(value: number);
    resetExpiredDays(): void;
    get expiredDaysInput(): number | undefined;
    private _forceDestroy?;
    get forceDestroy(): boolean | cdktf.IResolvable;
    set forceDestroy(value: boolean | cdktf.IResolvable);
    resetForceDestroy(): void;
    get forceDestroyInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _migrateDefiner?;
    get migrateDefiner(): boolean | cdktf.IResolvable;
    set migrateDefiner(value: boolean | cdktf.IResolvable);
    resetMigrateDefiner(): void;
    get migrateDefinerInput(): boolean | cdktf.IResolvable | undefined;
    private _migrationType?;
    get migrationType(): string;
    set migrationType(value: string);
    resetMigrationType(): void;
    get migrationTypeInput(): string | undefined;
    private _multiWrite?;
    get multiWrite(): boolean | cdktf.IResolvable;
    set multiWrite(value: boolean | cdktf.IResolvable);
    resetMultiWrite(): void;
    get multiWriteInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _netType?;
    get netType(): string;
    set netType(value: string);
    resetNetType(): void;
    get netTypeInput(): string | undefined;
    private _nodeNum?;
    get nodeNum(): number;
    set nodeNum(value: number);
    resetNodeNum(): void;
    get nodeNumInput(): number | undefined;
    get privateIp(): string;
    get publicIp(): string;
    get region(): string;
    get securityGroupId(): string;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    resetStartTime(): void;
    get startTimeInput(): string | undefined;
    get status(): string;
    get subnetId(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    get vpcId(): string;
    private _destinationDb;
    get destinationDb(): DrsTaskV3DestinationDbOutputReference;
    putDestinationDb(value: DrsTaskV3DestinationDb): void;
    get destinationDbInput(): DrsTaskV3DestinationDb | undefined;
    private _limitSpeed;
    get limitSpeed(): DrsTaskV3LimitSpeedList;
    putLimitSpeed(value: DrsTaskV3LimitSpeed[] | cdktf.IResolvable): void;
    resetLimitSpeed(): void;
    get limitSpeedInput(): cdktf.IResolvable | DrsTaskV3LimitSpeed[] | undefined;
    private _sourceDb;
    get sourceDb(): DrsTaskV3SourceDbOutputReference;
    putSourceDb(value: DrsTaskV3SourceDb): void;
    get sourceDbInput(): DrsTaskV3SourceDb | undefined;
    private _timeouts;
    get timeouts(): DrsTaskV3TimeoutsOutputReference;
    putTimeouts(value: DrsTaskV3Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DrsTaskV3Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

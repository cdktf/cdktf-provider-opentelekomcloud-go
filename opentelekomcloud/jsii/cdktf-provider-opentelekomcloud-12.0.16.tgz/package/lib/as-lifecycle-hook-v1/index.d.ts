/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AsLifecycleHookV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_lifecycle_hook_v1#default_result AsLifecycleHookV1#default_result}
    */
    readonly defaultResult?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_lifecycle_hook_v1#default_timeout AsLifecycleHookV1#default_timeout}
    */
    readonly defaultTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_lifecycle_hook_v1#id AsLifecycleHookV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_lifecycle_hook_v1#notification_metadata AsLifecycleHookV1#notification_metadata}
    */
    readonly notificationMetadata?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_lifecycle_hook_v1#notification_topic_urn AsLifecycleHookV1#notification_topic_urn}
    */
    readonly notificationTopicUrn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_lifecycle_hook_v1#scaling_group_id AsLifecycleHookV1#scaling_group_id}
    */
    readonly scalingGroupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_lifecycle_hook_v1#scaling_lifecycle_hook_name AsLifecycleHookV1#scaling_lifecycle_hook_name}
    */
    readonly scalingLifecycleHookName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_lifecycle_hook_v1#scaling_lifecycle_hook_type AsLifecycleHookV1#scaling_lifecycle_hook_type}
    */
    readonly scalingLifecycleHookType: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_lifecycle_hook_v1 opentelekomcloud_as_lifecycle_hook_v1}
*/
export declare class AsLifecycleHookV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_as_lifecycle_hook_v1";
    /**
    * Generates CDKTF code for importing a AsLifecycleHookV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AsLifecycleHookV1 to import
    * @param importFromId The id of the existing AsLifecycleHookV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_lifecycle_hook_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AsLifecycleHookV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_lifecycle_hook_v1 opentelekomcloud_as_lifecycle_hook_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AsLifecycleHookV1Config
    */
    constructor(scope: Construct, id: string, config: AsLifecycleHookV1Config);
    get createTime(): string;
    private _defaultResult?;
    get defaultResult(): string;
    set defaultResult(value: string);
    resetDefaultResult(): void;
    get defaultResultInput(): string | undefined;
    private _defaultTimeout?;
    get defaultTimeout(): number;
    set defaultTimeout(value: number);
    resetDefaultTimeout(): void;
    get defaultTimeoutInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _notificationMetadata?;
    get notificationMetadata(): string;
    set notificationMetadata(value: string);
    resetNotificationMetadata(): void;
    get notificationMetadataInput(): string | undefined;
    get notificationTopicName(): string;
    private _notificationTopicUrn?;
    get notificationTopicUrn(): string;
    set notificationTopicUrn(value: string);
    get notificationTopicUrnInput(): string | undefined;
    get region(): string;
    private _scalingGroupId?;
    get scalingGroupId(): string;
    set scalingGroupId(value: string);
    get scalingGroupIdInput(): string | undefined;
    private _scalingLifecycleHookName?;
    get scalingLifecycleHookName(): string;
    set scalingLifecycleHookName(value: string);
    get scalingLifecycleHookNameInput(): string | undefined;
    private _scalingLifecycleHookType?;
    get scalingLifecycleHookType(): string;
    set scalingLifecycleHookType(value: string);
    get scalingLifecycleHookTypeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DirectConnectV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/direct_connect_v2#admin_state_up DirectConnectV2#admin_state_up}
    */
    readonly adminStateUp?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/direct_connect_v2#bandwidth DirectConnectV2#bandwidth}
    */
    readonly bandwidth?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/direct_connect_v2#charge_mode DirectConnectV2#charge_mode}
    */
    readonly chargeMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/direct_connect_v2#description DirectConnectV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/direct_connect_v2#device_id DirectConnectV2#device_id}
    */
    readonly deviceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/direct_connect_v2#hosting_id DirectConnectV2#hosting_id}
    */
    readonly hostingId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/direct_connect_v2#interface_name DirectConnectV2#interface_name}
    */
    readonly interfaceName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/direct_connect_v2#location DirectConnectV2#location}
    */
    readonly location?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/direct_connect_v2#name DirectConnectV2#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/direct_connect_v2#order_id DirectConnectV2#order_id}
    */
    readonly orderId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/direct_connect_v2#peer_location DirectConnectV2#peer_location}
    */
    readonly peerLocation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/direct_connect_v2#port_type DirectConnectV2#port_type}
    */
    readonly portType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/direct_connect_v2#product_id DirectConnectV2#product_id}
    */
    readonly productId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/direct_connect_v2#provider_name DirectConnectV2#provider_name}
    */
    readonly providerName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/direct_connect_v2#provider_status DirectConnectV2#provider_status}
    */
    readonly providerStatus?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/direct_connect_v2#redundant_id DirectConnectV2#redundant_id}
    */
    readonly redundantId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/direct_connect_v2#status DirectConnectV2#status}
    */
    readonly status?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/direct_connect_v2#tenant_id DirectConnectV2#tenant_id}
    */
    readonly tenantId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/direct_connect_v2#type DirectConnectV2#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/direct_connect_v2#vlan DirectConnectV2#vlan}
    */
    readonly vlan?: number;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/direct_connect_v2#timeouts DirectConnectV2#timeouts}
    */
    readonly timeouts?: DirectConnectV2Timeouts;
}
export interface DirectConnectV2Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/direct_connect_v2#create DirectConnectV2#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/direct_connect_v2#delete DirectConnectV2#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/direct_connect_v2#update DirectConnectV2#update}
    */
    readonly update?: string;
}
export declare function directConnectV2TimeoutsToTerraform(struct?: DirectConnectV2Timeouts | cdktf.IResolvable): any;
export declare function directConnectV2TimeoutsToHclTerraform(struct?: DirectConnectV2Timeouts | cdktf.IResolvable): any;
export declare class DirectConnectV2TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DirectConnectV2Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DirectConnectV2Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/direct_connect_v2 opentelekomcloud_direct_connect_v2}
*/
export declare class DirectConnectV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_direct_connect_v2";
    /**
    * Generates CDKTF code for importing a DirectConnectV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DirectConnectV2 to import
    * @param importFromId The id of the existing DirectConnectV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/direct_connect_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DirectConnectV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/direct_connect_v2 opentelekomcloud_direct_connect_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DirectConnectV2Config
    */
    constructor(scope: Construct, id: string, config: DirectConnectV2Config);
    private _adminStateUp?;
    get adminStateUp(): boolean | cdktf.IResolvable;
    set adminStateUp(value: boolean | cdktf.IResolvable);
    resetAdminStateUp(): void;
    get adminStateUpInput(): boolean | cdktf.IResolvable | undefined;
    get applicant(): string;
    get applyTime(): string;
    private _bandwidth?;
    get bandwidth(): number;
    set bandwidth(value: number);
    resetBandwidth(): void;
    get bandwidthInput(): number | undefined;
    get buildingLineProductId(): string;
    get cableLabel(): string;
    private _chargeMode?;
    get chargeMode(): string;
    set chargeMode(value: string);
    resetChargeMode(): void;
    get chargeModeInput(): string | undefined;
    get createTime(): string;
    get deleteTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _deviceId?;
    get deviceId(): string;
    set deviceId(value: string);
    resetDeviceId(): void;
    get deviceIdInput(): string | undefined;
    get email(): string;
    private _hostingId?;
    get hostingId(): string;
    set hostingId(value: string);
    resetHostingId(): void;
    get hostingIdInput(): string | undefined;
    get id(): string;
    private _interfaceName?;
    get interfaceName(): string;
    set interfaceName(value: string);
    resetInterfaceName(): void;
    get interfaceNameInput(): string | undefined;
    get lagId(): string;
    get lastOnestopProductId(): string;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    get mobile(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get onestopProductId(): string;
    private _orderId?;
    get orderId(): string;
    set orderId(value: string);
    resetOrderId(): void;
    get orderIdInput(): string | undefined;
    private _peerLocation?;
    get peerLocation(): string;
    set peerLocation(value: string);
    resetPeerLocation(): void;
    get peerLocationInput(): string | undefined;
    get peerPortType(): string;
    get peerProvider(): string;
    get periodNum(): number;
    get periodType(): number;
    private _portType?;
    get portType(): string;
    set portType(value: string);
    resetPortType(): void;
    get portTypeInput(): string | undefined;
    private _productId?;
    get productId(): string;
    set productId(value: string);
    resetProductId(): void;
    get productIdInput(): string | undefined;
    private _providerName?;
    get providerName(): string;
    set providerName(value: string);
    get providerNameInput(): string | undefined;
    private _providerStatus?;
    get providerStatus(): string;
    set providerStatus(value: string);
    resetProviderStatus(): void;
    get providerStatusInput(): string | undefined;
    get reason(): string;
    private _redundantId?;
    get redundantId(): string;
    set redundantId(value: string);
    resetRedundantId(): void;
    get redundantIdInput(): string | undefined;
    get regionId(): string;
    get serviceKey(): string;
    get specCode(): string;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _tenantId?;
    get tenantId(): string;
    set tenantId(value: string);
    resetTenantId(): void;
    get tenantIdInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    get vgwType(): string;
    private _vlan?;
    get vlan(): number;
    set vlan(value: number);
    resetVlan(): void;
    get vlanInput(): number | undefined;
    private _timeouts;
    get timeouts(): DirectConnectV2TimeoutsOutputReference;
    putTimeouts(value: DirectConnectV2Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DirectConnectV2Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

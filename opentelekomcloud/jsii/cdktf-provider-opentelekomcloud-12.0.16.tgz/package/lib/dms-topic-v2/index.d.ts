/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DmsTopicV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_topic_v2#id DmsTopicV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_topic_v2#instance_id DmsTopicV2#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_topic_v2#max_partitions DmsTopicV2#max_partitions}
    */
    readonly maxPartitions?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_topic_v2#name DmsTopicV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_topic_v2#partition DmsTopicV2#partition}
    */
    readonly partition?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_topic_v2#remain_partitions DmsTopicV2#remain_partitions}
    */
    readonly remainPartitions?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_topic_v2#replication DmsTopicV2#replication}
    */
    readonly replication?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_topic_v2#retention_time DmsTopicV2#retention_time}
    */
    readonly retentionTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_topic_v2#size DmsTopicV2#size}
    */
    readonly size?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_topic_v2#sync_message_flush DmsTopicV2#sync_message_flush}
    */
    readonly syncMessageFlush?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_topic_v2#sync_replication DmsTopicV2#sync_replication}
    */
    readonly syncReplication?: boolean | cdktf.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_topic_v2 opentelekomcloud_dms_topic_v2}
*/
export declare class DmsTopicV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_dms_topic_v2";
    /**
    * Generates CDKTF code for importing a DmsTopicV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DmsTopicV2 to import
    * @param importFromId The id of the existing DmsTopicV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_topic_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DmsTopicV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_topic_v2 opentelekomcloud_dms_topic_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DmsTopicV2Config
    */
    constructor(scope: Construct, id: string, config: DmsTopicV2Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _maxPartitions?;
    get maxPartitions(): number;
    set maxPartitions(value: number);
    resetMaxPartitions(): void;
    get maxPartitionsInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _partition?;
    get partition(): number;
    set partition(value: number);
    resetPartition(): void;
    get partitionInput(): number | undefined;
    private _remainPartitions?;
    get remainPartitions(): number;
    set remainPartitions(value: number);
    resetRemainPartitions(): void;
    get remainPartitionsInput(): number | undefined;
    private _replication?;
    get replication(): number;
    set replication(value: number);
    resetReplication(): void;
    get replicationInput(): number | undefined;
    private _retentionTime?;
    get retentionTime(): number;
    set retentionTime(value: number);
    resetRetentionTime(): void;
    get retentionTimeInput(): number | undefined;
    private _size?;
    get size(): number;
    set size(value: number);
    resetSize(): void;
    get sizeInput(): number | undefined;
    private _syncMessageFlush?;
    get syncMessageFlush(): boolean | cdktf.IResolvable;
    set syncMessageFlush(value: boolean | cdktf.IResolvable);
    resetSyncMessageFlush(): void;
    get syncMessageFlushInput(): boolean | cdktf.IResolvable | undefined;
    private _syncReplication?;
    get syncReplication(): boolean | cdktf.IResolvable;
    set syncReplication(value: boolean | cdktf.IResolvable);
    resetSyncReplication(): void;
    get syncReplicationInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ObsBucketAclConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_acl#bucket ObsBucketAcl#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_acl#id ObsBucketAcl#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * account_permission block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_acl#account_permission ObsBucketAcl#account_permission}
    */
    readonly accountPermission?: ObsBucketAclAccountPermission[] | cdktf.IResolvable;
    /**
    * log_delivery_user_permission block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_acl#log_delivery_user_permission ObsBucketAcl#log_delivery_user_permission}
    */
    readonly logDeliveryUserPermission?: ObsBucketAclLogDeliveryUserPermission;
    /**
    * owner_permission block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_acl#owner_permission ObsBucketAcl#owner_permission}
    */
    readonly ownerPermission?: ObsBucketAclOwnerPermission;
    /**
    * public_permission block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_acl#public_permission ObsBucketAcl#public_permission}
    */
    readonly publicPermission?: ObsBucketAclPublicPermission;
}
export interface ObsBucketAclAccountPermission {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_acl#access_to_acl ObsBucketAcl#access_to_acl}
    */
    readonly accessToAcl?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_acl#access_to_bucket ObsBucketAcl#access_to_bucket}
    */
    readonly accessToBucket?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_acl#account_id ObsBucketAcl#account_id}
    */
    readonly accountId: string;
}
export declare function obsBucketAclAccountPermissionToTerraform(struct?: ObsBucketAclAccountPermission | cdktf.IResolvable): any;
export declare function obsBucketAclAccountPermissionToHclTerraform(struct?: ObsBucketAclAccountPermission | cdktf.IResolvable): any;
export declare class ObsBucketAclAccountPermissionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObsBucketAclAccountPermission | cdktf.IResolvable | undefined;
    set internalValue(value: ObsBucketAclAccountPermission | cdktf.IResolvable | undefined);
    private _accessToAcl?;
    get accessToAcl(): string[];
    set accessToAcl(value: string[]);
    resetAccessToAcl(): void;
    get accessToAclInput(): string[] | undefined;
    private _accessToBucket?;
    get accessToBucket(): string[];
    set accessToBucket(value: string[]);
    resetAccessToBucket(): void;
    get accessToBucketInput(): string[] | undefined;
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
}
export declare class ObsBucketAclAccountPermissionList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ObsBucketAclAccountPermission[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObsBucketAclAccountPermissionOutputReference;
}
export interface ObsBucketAclLogDeliveryUserPermission {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_acl#access_to_acl ObsBucketAcl#access_to_acl}
    */
    readonly accessToAcl?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_acl#access_to_bucket ObsBucketAcl#access_to_bucket}
    */
    readonly accessToBucket?: string[];
}
export declare function obsBucketAclLogDeliveryUserPermissionToTerraform(struct?: ObsBucketAclLogDeliveryUserPermissionOutputReference | ObsBucketAclLogDeliveryUserPermission): any;
export declare function obsBucketAclLogDeliveryUserPermissionToHclTerraform(struct?: ObsBucketAclLogDeliveryUserPermissionOutputReference | ObsBucketAclLogDeliveryUserPermission): any;
export declare class ObsBucketAclLogDeliveryUserPermissionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ObsBucketAclLogDeliveryUserPermission | undefined;
    set internalValue(value: ObsBucketAclLogDeliveryUserPermission | undefined);
    private _accessToAcl?;
    get accessToAcl(): string[];
    set accessToAcl(value: string[]);
    resetAccessToAcl(): void;
    get accessToAclInput(): string[] | undefined;
    private _accessToBucket?;
    get accessToBucket(): string[];
    set accessToBucket(value: string[]);
    resetAccessToBucket(): void;
    get accessToBucketInput(): string[] | undefined;
}
export interface ObsBucketAclOwnerPermission {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_acl#access_to_acl ObsBucketAcl#access_to_acl}
    */
    readonly accessToAcl?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_acl#access_to_bucket ObsBucketAcl#access_to_bucket}
    */
    readonly accessToBucket?: string[];
}
export declare function obsBucketAclOwnerPermissionToTerraform(struct?: ObsBucketAclOwnerPermissionOutputReference | ObsBucketAclOwnerPermission): any;
export declare function obsBucketAclOwnerPermissionToHclTerraform(struct?: ObsBucketAclOwnerPermissionOutputReference | ObsBucketAclOwnerPermission): any;
export declare class ObsBucketAclOwnerPermissionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ObsBucketAclOwnerPermission | undefined;
    set internalValue(value: ObsBucketAclOwnerPermission | undefined);
    private _accessToAcl?;
    get accessToAcl(): string[];
    set accessToAcl(value: string[]);
    resetAccessToAcl(): void;
    get accessToAclInput(): string[] | undefined;
    private _accessToBucket?;
    get accessToBucket(): string[];
    set accessToBucket(value: string[]);
    resetAccessToBucket(): void;
    get accessToBucketInput(): string[] | undefined;
}
export interface ObsBucketAclPublicPermission {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_acl#access_to_acl ObsBucketAcl#access_to_acl}
    */
    readonly accessToAcl?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_acl#access_to_bucket ObsBucketAcl#access_to_bucket}
    */
    readonly accessToBucket?: string[];
}
export declare function obsBucketAclPublicPermissionToTerraform(struct?: ObsBucketAclPublicPermissionOutputReference | ObsBucketAclPublicPermission): any;
export declare function obsBucketAclPublicPermissionToHclTerraform(struct?: ObsBucketAclPublicPermissionOutputReference | ObsBucketAclPublicPermission): any;
export declare class ObsBucketAclPublicPermissionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ObsBucketAclPublicPermission | undefined;
    set internalValue(value: ObsBucketAclPublicPermission | undefined);
    private _accessToAcl?;
    get accessToAcl(): string[];
    set accessToAcl(value: string[]);
    resetAccessToAcl(): void;
    get accessToAclInput(): string[] | undefined;
    private _accessToBucket?;
    get accessToBucket(): string[];
    set accessToBucket(value: string[]);
    resetAccessToBucket(): void;
    get accessToBucketInput(): string[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_acl opentelekomcloud_obs_bucket_acl}
*/
export declare class ObsBucketAcl extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_obs_bucket_acl";
    /**
    * Generates CDKTF code for importing a ObsBucketAcl resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ObsBucketAcl to import
    * @param importFromId The id of the existing ObsBucketAcl that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_acl#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ObsBucketAcl to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/obs_bucket_acl opentelekomcloud_obs_bucket_acl} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ObsBucketAclConfig
    */
    constructor(scope: Construct, id: string, config: ObsBucketAclConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get region(): string;
    private _accountPermission;
    get accountPermission(): ObsBucketAclAccountPermissionList;
    putAccountPermission(value: ObsBucketAclAccountPermission[] | cdktf.IResolvable): void;
    resetAccountPermission(): void;
    get accountPermissionInput(): cdktf.IResolvable | ObsBucketAclAccountPermission[] | undefined;
    private _logDeliveryUserPermission;
    get logDeliveryUserPermission(): ObsBucketAclLogDeliveryUserPermissionOutputReference;
    putLogDeliveryUserPermission(value: ObsBucketAclLogDeliveryUserPermission): void;
    resetLogDeliveryUserPermission(): void;
    get logDeliveryUserPermissionInput(): ObsBucketAclLogDeliveryUserPermission | undefined;
    private _ownerPermission;
    get ownerPermission(): ObsBucketAclOwnerPermissionOutputReference;
    putOwnerPermission(value: ObsBucketAclOwnerPermission): void;
    resetOwnerPermission(): void;
    get ownerPermissionInput(): ObsBucketAclOwnerPermission | undefined;
    private _publicPermission;
    get publicPermission(): ObsBucketAclPublicPermissionOutputReference;
    putPublicPermission(value: ObsBucketAclPublicPermission): void;
    resetPublicPermission(): void;
    get publicPermissionInput(): ObsBucketAclPublicPermission | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

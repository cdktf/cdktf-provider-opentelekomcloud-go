/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface PrivateNatGatewayV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_gateway_v3#description PrivateNatGatewayV3#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_gateway_v3#enterprise_project_id PrivateNatGatewayV3#enterprise_project_id}
    */
    readonly enterpriseProjectId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_gateway_v3#name PrivateNatGatewayV3#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_gateway_v3#spec PrivateNatGatewayV3#spec}
    */
    readonly spec?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_gateway_v3#tags PrivateNatGatewayV3#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * downlink_vpcs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_gateway_v3#downlink_vpcs PrivateNatGatewayV3#downlink_vpcs}
    */
    readonly downlinkVpcs: PrivateNatGatewayV3DownlinkVpcs[] | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_gateway_v3#timeouts PrivateNatGatewayV3#timeouts}
    */
    readonly timeouts?: PrivateNatGatewayV3Timeouts;
}
export interface PrivateNatGatewayV3DownlinkVpcs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_gateway_v3#ngport_ip_address PrivateNatGatewayV3#ngport_ip_address}
    */
    readonly ngportIpAddress?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_gateway_v3#virsubnet_id PrivateNatGatewayV3#virsubnet_id}
    */
    readonly virsubnetId: string;
}
export declare function privateNatGatewayV3DownlinkVpcsToTerraform(struct?: PrivateNatGatewayV3DownlinkVpcs | cdktf.IResolvable): any;
export declare function privateNatGatewayV3DownlinkVpcsToHclTerraform(struct?: PrivateNatGatewayV3DownlinkVpcs | cdktf.IResolvable): any;
export declare class PrivateNatGatewayV3DownlinkVpcsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PrivateNatGatewayV3DownlinkVpcs | cdktf.IResolvable | undefined;
    set internalValue(value: PrivateNatGatewayV3DownlinkVpcs | cdktf.IResolvable | undefined);
    private _ngportIpAddress?;
    get ngportIpAddress(): string;
    set ngportIpAddress(value: string);
    resetNgportIpAddress(): void;
    get ngportIpAddressInput(): string | undefined;
    private _virsubnetId?;
    get virsubnetId(): string;
    set virsubnetId(value: string);
    get virsubnetIdInput(): string | undefined;
    get vpcId(): string;
}
export declare class PrivateNatGatewayV3DownlinkVpcsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: PrivateNatGatewayV3DownlinkVpcs[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PrivateNatGatewayV3DownlinkVpcsOutputReference;
}
export interface PrivateNatGatewayV3Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_gateway_v3#create PrivateNatGatewayV3#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_gateway_v3#delete PrivateNatGatewayV3#delete}
    */
    readonly delete?: string;
}
export declare function privateNatGatewayV3TimeoutsToTerraform(struct?: PrivateNatGatewayV3Timeouts | cdktf.IResolvable): any;
export declare function privateNatGatewayV3TimeoutsToHclTerraform(struct?: PrivateNatGatewayV3Timeouts | cdktf.IResolvable): any;
export declare class PrivateNatGatewayV3TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PrivateNatGatewayV3Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: PrivateNatGatewayV3Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_gateway_v3 opentelekomcloud_private_nat_gateway_v3}
*/
export declare class PrivateNatGatewayV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_private_nat_gateway_v3";
    /**
    * Generates CDKTF code for importing a PrivateNatGatewayV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PrivateNatGatewayV3 to import
    * @param importFromId The id of the existing PrivateNatGatewayV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_gateway_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PrivateNatGatewayV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_gateway_v3 opentelekomcloud_private_nat_gateway_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PrivateNatGatewayV3Config
    */
    constructor(scope: Construct, id: string, config: PrivateNatGatewayV3Config);
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enterpriseProjectId?;
    get enterpriseProjectId(): string;
    set enterpriseProjectId(value: string);
    resetEnterpriseProjectId(): void;
    get enterpriseProjectIdInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get projectId(): string;
    get ruleMax(): number;
    private _spec?;
    get spec(): string;
    set spec(value: string);
    resetSpec(): void;
    get specInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get transitIpPoolSizeMax(): number;
    get updatedAt(): string;
    private _downlinkVpcs;
    get downlinkVpcs(): PrivateNatGatewayV3DownlinkVpcsList;
    putDownlinkVpcs(value: PrivateNatGatewayV3DownlinkVpcs[] | cdktf.IResolvable): void;
    get downlinkVpcsInput(): cdktf.IResolvable | PrivateNatGatewayV3DownlinkVpcs[] | undefined;
    private _timeouts;
    get timeouts(): PrivateNatGatewayV3TimeoutsOutputReference;
    putTimeouts(value: PrivateNatGatewayV3Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | PrivateNatGatewayV3Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

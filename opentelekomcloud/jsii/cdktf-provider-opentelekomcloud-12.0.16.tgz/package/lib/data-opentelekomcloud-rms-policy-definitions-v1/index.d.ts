/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudRmsPolicyDefinitionsV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/rms_policy_definitions_v1#id DataOpentelekomcloudRmsPolicyDefinitionsV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/rms_policy_definitions_v1#keywords DataOpentelekomcloudRmsPolicyDefinitionsV1#keywords}
    */
    readonly keywords?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/rms_policy_definitions_v1#name DataOpentelekomcloudRmsPolicyDefinitionsV1#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/rms_policy_definitions_v1#policy_rule_type DataOpentelekomcloudRmsPolicyDefinitionsV1#policy_rule_type}
    */
    readonly policyRuleType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/rms_policy_definitions_v1#policy_type DataOpentelekomcloudRmsPolicyDefinitionsV1#policy_type}
    */
    readonly policyType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/rms_policy_definitions_v1#trigger_type DataOpentelekomcloudRmsPolicyDefinitionsV1#trigger_type}
    */
    readonly triggerType?: string;
}
export interface DataOpentelekomcloudRmsPolicyDefinitionsV1Definitions {
}
export declare function dataOpentelekomcloudRmsPolicyDefinitionsV1DefinitionsToTerraform(struct?: DataOpentelekomcloudRmsPolicyDefinitionsV1Definitions): any;
export declare function dataOpentelekomcloudRmsPolicyDefinitionsV1DefinitionsToHclTerraform(struct?: DataOpentelekomcloudRmsPolicyDefinitionsV1Definitions): any;
export declare class DataOpentelekomcloudRmsPolicyDefinitionsV1DefinitionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudRmsPolicyDefinitionsV1Definitions | undefined;
    set internalValue(value: DataOpentelekomcloudRmsPolicyDefinitionsV1Definitions | undefined);
    get description(): string;
    get id(): string;
    get keywords(): string[];
    get name(): string;
    private _parameters;
    get parameters(): cdktf.StringMap;
    get policyRule(): string;
    get policyRuleType(): string;
    get policyType(): string;
    get triggerType(): string;
}
export declare class DataOpentelekomcloudRmsPolicyDefinitionsV1DefinitionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudRmsPolicyDefinitionsV1DefinitionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/rms_policy_definitions_v1 opentelekomcloud_rms_policy_definitions_v1}
*/
export declare class DataOpentelekomcloudRmsPolicyDefinitionsV1 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_rms_policy_definitions_v1";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudRmsPolicyDefinitionsV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudRmsPolicyDefinitionsV1 to import
    * @param importFromId The id of the existing DataOpentelekomcloudRmsPolicyDefinitionsV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/rms_policy_definitions_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudRmsPolicyDefinitionsV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/rms_policy_definitions_v1 opentelekomcloud_rms_policy_definitions_v1} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudRmsPolicyDefinitionsV1Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudRmsPolicyDefinitionsV1Config);
    private _definitions;
    get definitions(): DataOpentelekomcloudRmsPolicyDefinitionsV1DefinitionsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _keywords?;
    get keywords(): string[];
    set keywords(value: string[]);
    resetKeywords(): void;
    get keywordsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _policyRuleType?;
    get policyRuleType(): string;
    set policyRuleType(value: string);
    resetPolicyRuleType(): void;
    get policyRuleTypeInput(): string | undefined;
    private _policyType?;
    get policyType(): string;
    set policyType(value: string);
    resetPolicyType(): void;
    get policyTypeInput(): string | undefined;
    private _triggerType?;
    get triggerType(): string;
    set triggerType(value: string);
    resetTriggerType(): void;
    get triggerTypeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

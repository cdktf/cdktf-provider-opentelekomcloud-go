/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudImagesImageV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/images_image_v2#most_recent DataOpentelekomcloudImagesImageV2#most_recent}
    */
    readonly mostRecent?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/images_image_v2#name DataOpentelekomcloudImagesImageV2#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/images_image_v2#name_regex DataOpentelekomcloudImagesImageV2#name_regex}
    */
    readonly nameRegex?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/images_image_v2#owner DataOpentelekomcloudImagesImageV2#owner}
    */
    readonly owner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/images_image_v2#size_max DataOpentelekomcloudImagesImageV2#size_max}
    */
    readonly sizeMax?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/images_image_v2#size_min DataOpentelekomcloudImagesImageV2#size_min}
    */
    readonly sizeMin?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/images_image_v2#sort_direction DataOpentelekomcloudImagesImageV2#sort_direction}
    */
    readonly sortDirection?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/images_image_v2#sort_key DataOpentelekomcloudImagesImageV2#sort_key}
    */
    readonly sortKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/images_image_v2#tag DataOpentelekomcloudImagesImageV2#tag}
    */
    readonly tag?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/images_image_v2#visibility DataOpentelekomcloudImagesImageV2#visibility}
    */
    readonly visibility?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/images_image_v2 opentelekomcloud_images_image_v2}
*/
export declare class DataOpentelekomcloudImagesImageV2 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_images_image_v2";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudImagesImageV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudImagesImageV2 to import
    * @param importFromId The id of the existing DataOpentelekomcloudImagesImageV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/images_image_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudImagesImageV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/images_image_v2 opentelekomcloud_images_image_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudImagesImageV2Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudImagesImageV2Config);
    get backupId(): string;
    get checksum(): string;
    get containerFormat(): string;
    get createdAt(): string;
    get dataOrigin(): string;
    get description(): string;
    get diskFormat(): string;
    get file(): string;
    get hwFirmwareType(): string;
    get id(): string;
    get imageSourceType(): string;
    get imageType(): string;
    get isRegistered(): string;
    get loginUser(): string;
    get minDisk(): number;
    get minRam(): number;
    private _mostRecent?;
    get mostRecent(): boolean | cdktf.IResolvable;
    set mostRecent(value: boolean | cdktf.IResolvable);
    resetMostRecent(): void;
    get mostRecentInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _nameRegex?;
    get nameRegex(): string;
    set nameRegex(value: string);
    resetNameRegex(): void;
    get nameRegexInput(): string | undefined;
    get originalImageName(): string;
    get osBit(): string;
    get osType(): string;
    get osVersion(): string;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    get platform(): string;
    get protected(): cdktf.IResolvable;
    get schema(): string;
    get sizeBytes(): number;
    private _sizeMax?;
    get sizeMax(): number;
    set sizeMax(value: number);
    resetSizeMax(): void;
    get sizeMaxInput(): number | undefined;
    private _sizeMin?;
    get sizeMin(): number;
    set sizeMin(value: number);
    resetSizeMin(): void;
    get sizeMinInput(): number | undefined;
    private _sortDirection?;
    get sortDirection(): string;
    set sortDirection(value: string);
    resetSortDirection(): void;
    get sortDirectionInput(): string | undefined;
    private _sortKey?;
    get sortKey(): string;
    set sortKey(value: string);
    resetSortKey(): void;
    get sortKeyInput(): string | undefined;
    get status(): string;
    get supportDiskIntensive(): string;
    get supportHighPerformance(): string;
    get supportKvm(): string;
    get supportKvmGpuType(): string;
    get supportKvmInfiniband(): string;
    get supportLargeMemory(): string;
    get supportXen(): string;
    get supportXenGpuType(): string;
    get supportXenHana(): string;
    get systemCmkId(): string;
    private _tag?;
    get tag(): string;
    set tag(value: string);
    resetTag(): void;
    get tagInput(): string | undefined;
    get tags(): string[];
    get updatedAt(): string;
    get virtualEnvType(): string;
    private _visibility?;
    get visibility(): string;
    set visibility(value: string);
    resetVisibility(): void;
    get visibilityInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudCesMetricsV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_metrics_v1#dim DataOpentelekomcloudCesMetricsV1#dim}
    */
    readonly dim?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_metrics_v1#id DataOpentelekomcloudCesMetricsV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_metrics_v1#limit DataOpentelekomcloudCesMetricsV1#limit}
    */
    readonly limit?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_metrics_v1#metric_name DataOpentelekomcloudCesMetricsV1#metric_name}
    */
    readonly metricName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_metrics_v1#namespace DataOpentelekomcloudCesMetricsV1#namespace}
    */
    readonly namespace?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_metrics_v1#order DataOpentelekomcloudCesMetricsV1#order}
    */
    readonly order?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_metrics_v1#start DataOpentelekomcloudCesMetricsV1#start}
    */
    readonly start?: string;
}
export interface DataOpentelekomcloudCesMetricsV1MetaData {
}
export declare function dataOpentelekomcloudCesMetricsV1MetaDataToTerraform(struct?: DataOpentelekomcloudCesMetricsV1MetaData): any;
export declare function dataOpentelekomcloudCesMetricsV1MetaDataToHclTerraform(struct?: DataOpentelekomcloudCesMetricsV1MetaData): any;
export declare class DataOpentelekomcloudCesMetricsV1MetaDataOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudCesMetricsV1MetaData | undefined;
    set internalValue(value: DataOpentelekomcloudCesMetricsV1MetaData | undefined);
    get count(): number;
    get marker(): string;
    get total(): number;
}
export declare class DataOpentelekomcloudCesMetricsV1MetaDataList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudCesMetricsV1MetaDataOutputReference;
}
export interface DataOpentelekomcloudCesMetricsV1MetricsDimensions {
}
export declare function dataOpentelekomcloudCesMetricsV1MetricsDimensionsToTerraform(struct?: DataOpentelekomcloudCesMetricsV1MetricsDimensions): any;
export declare function dataOpentelekomcloudCesMetricsV1MetricsDimensionsToHclTerraform(struct?: DataOpentelekomcloudCesMetricsV1MetricsDimensions): any;
export declare class DataOpentelekomcloudCesMetricsV1MetricsDimensionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudCesMetricsV1MetricsDimensions | undefined;
    set internalValue(value: DataOpentelekomcloudCesMetricsV1MetricsDimensions | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataOpentelekomcloudCesMetricsV1MetricsDimensionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudCesMetricsV1MetricsDimensionsOutputReference;
}
export interface DataOpentelekomcloudCesMetricsV1Metrics {
}
export declare function dataOpentelekomcloudCesMetricsV1MetricsToTerraform(struct?: DataOpentelekomcloudCesMetricsV1Metrics): any;
export declare function dataOpentelekomcloudCesMetricsV1MetricsToHclTerraform(struct?: DataOpentelekomcloudCesMetricsV1Metrics): any;
export declare class DataOpentelekomcloudCesMetricsV1MetricsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudCesMetricsV1Metrics | undefined;
    set internalValue(value: DataOpentelekomcloudCesMetricsV1Metrics | undefined);
    private _dimensions;
    get dimensions(): DataOpentelekomcloudCesMetricsV1MetricsDimensionsList;
    get metricName(): string;
    get namespace(): string;
    get unit(): string;
}
export declare class DataOpentelekomcloudCesMetricsV1MetricsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudCesMetricsV1MetricsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_metrics_v1 opentelekomcloud_ces_metrics_v1}
*/
export declare class DataOpentelekomcloudCesMetricsV1 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_ces_metrics_v1";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudCesMetricsV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudCesMetricsV1 to import
    * @param importFromId The id of the existing DataOpentelekomcloudCesMetricsV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_metrics_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudCesMetricsV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_metrics_v1 opentelekomcloud_ces_metrics_v1} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudCesMetricsV1Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudCesMetricsV1Config);
    private _dim?;
    get dim(): string;
    set dim(value: string);
    resetDim(): void;
    get dimInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _metaData;
    get metaData(): DataOpentelekomcloudCesMetricsV1MetaDataList;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    resetMetricName(): void;
    get metricNameInput(): string | undefined;
    private _metrics;
    get metrics(): DataOpentelekomcloudCesMetricsV1MetricsList;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
    private _start?;
    get start(): string;
    set start(value: string);
    resetStart(): void;
    get startInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

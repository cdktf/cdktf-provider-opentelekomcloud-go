/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface VbsBackupPolicyV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vbs_backup_policy_v2#frequency VbsBackupPolicyV2#frequency}
    */
    readonly frequency?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vbs_backup_policy_v2#id VbsBackupPolicyV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vbs_backup_policy_v2#name VbsBackupPolicyV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vbs_backup_policy_v2#region VbsBackupPolicyV2#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vbs_backup_policy_v2#rentention_day VbsBackupPolicyV2#rentention_day}
    */
    readonly rententionDay?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vbs_backup_policy_v2#rentention_num VbsBackupPolicyV2#rentention_num}
    */
    readonly rententionNum?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vbs_backup_policy_v2#resources VbsBackupPolicyV2#resources}
    */
    readonly resources?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vbs_backup_policy_v2#retain_first_backup VbsBackupPolicyV2#retain_first_backup}
    */
    readonly retainFirstBackup: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vbs_backup_policy_v2#start_time VbsBackupPolicyV2#start_time}
    */
    readonly startTime: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vbs_backup_policy_v2#status VbsBackupPolicyV2#status}
    */
    readonly status?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vbs_backup_policy_v2#week_frequency VbsBackupPolicyV2#week_frequency}
    */
    readonly weekFrequency?: string[];
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vbs_backup_policy_v2#tags VbsBackupPolicyV2#tags}
    */
    readonly tags?: VbsBackupPolicyV2Tags[] | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vbs_backup_policy_v2#timeouts VbsBackupPolicyV2#timeouts}
    */
    readonly timeouts?: VbsBackupPolicyV2Timeouts;
}
export interface VbsBackupPolicyV2Tags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vbs_backup_policy_v2#key VbsBackupPolicyV2#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vbs_backup_policy_v2#value VbsBackupPolicyV2#value}
    */
    readonly value: string;
}
export declare function vbsBackupPolicyV2TagsToTerraform(struct?: VbsBackupPolicyV2Tags | cdktf.IResolvable): any;
export declare function vbsBackupPolicyV2TagsToHclTerraform(struct?: VbsBackupPolicyV2Tags | cdktf.IResolvable): any;
export declare class VbsBackupPolicyV2TagsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): VbsBackupPolicyV2Tags | cdktf.IResolvable | undefined;
    set internalValue(value: VbsBackupPolicyV2Tags | cdktf.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class VbsBackupPolicyV2TagsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: VbsBackupPolicyV2Tags[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): VbsBackupPolicyV2TagsOutputReference;
}
export interface VbsBackupPolicyV2Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vbs_backup_policy_v2#create VbsBackupPolicyV2#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vbs_backup_policy_v2#delete VbsBackupPolicyV2#delete}
    */
    readonly delete?: string;
}
export declare function vbsBackupPolicyV2TimeoutsToTerraform(struct?: VbsBackupPolicyV2Timeouts | cdktf.IResolvable): any;
export declare function vbsBackupPolicyV2TimeoutsToHclTerraform(struct?: VbsBackupPolicyV2Timeouts | cdktf.IResolvable): any;
export declare class VbsBackupPolicyV2TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VbsBackupPolicyV2Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: VbsBackupPolicyV2Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vbs_backup_policy_v2 opentelekomcloud_vbs_backup_policy_v2}
*/
export declare class VbsBackupPolicyV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_vbs_backup_policy_v2";
    /**
    * Generates CDKTF code for importing a VbsBackupPolicyV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VbsBackupPolicyV2 to import
    * @param importFromId The id of the existing VbsBackupPolicyV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vbs_backup_policy_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VbsBackupPolicyV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vbs_backup_policy_v2 opentelekomcloud_vbs_backup_policy_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VbsBackupPolicyV2Config
    */
    constructor(scope: Construct, id: string, config: VbsBackupPolicyV2Config);
    private _frequency?;
    get frequency(): number;
    set frequency(value: number);
    resetFrequency(): void;
    get frequencyInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get policyResourceCount(): number;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rententionDay?;
    get rententionDay(): number;
    set rententionDay(value: number);
    resetRententionDay(): void;
    get rententionDayInput(): number | undefined;
    private _rententionNum?;
    get rententionNum(): number;
    set rententionNum(value: number);
    resetRententionNum(): void;
    get rententionNumInput(): number | undefined;
    private _resources?;
    get resources(): string[];
    set resources(value: string[]);
    resetResources(): void;
    get resourcesInput(): string[] | undefined;
    private _retainFirstBackup?;
    get retainFirstBackup(): string;
    set retainFirstBackup(value: string);
    get retainFirstBackupInput(): string | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    get startTimeInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _weekFrequency?;
    get weekFrequency(): string[];
    set weekFrequency(value: string[]);
    resetWeekFrequency(): void;
    get weekFrequencyInput(): string[] | undefined;
    private _tags;
    get tags(): VbsBackupPolicyV2TagsList;
    putTags(value: VbsBackupPolicyV2Tags[] | cdktf.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktf.IResolvable | VbsBackupPolicyV2Tags[] | undefined;
    private _timeouts;
    get timeouts(): VbsBackupPolicyV2TimeoutsOutputReference;
    putTimeouts(value: VbsBackupPolicyV2Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | VbsBackupPolicyV2Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

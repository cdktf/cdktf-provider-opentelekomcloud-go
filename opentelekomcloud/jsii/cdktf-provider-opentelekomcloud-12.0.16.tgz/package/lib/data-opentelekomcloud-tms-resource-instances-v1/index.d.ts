/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudTmsResourceInstancesV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/tms_resource_instances_v1#id DataOpentelekomcloudTmsResourceInstancesV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/tms_resource_instances_v1#project_id DataOpentelekomcloudTmsResourceInstancesV1#project_id}
    */
    readonly projectId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/tms_resource_instances_v1#resource_types DataOpentelekomcloudTmsResourceInstancesV1#resource_types}
    */
    readonly resourceTypes: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/tms_resource_instances_v1#without_any_tag DataOpentelekomcloudTmsResourceInstancesV1#without_any_tag}
    */
    readonly withoutAnyTag?: boolean | cdktf.IResolvable;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/tms_resource_instances_v1#tags DataOpentelekomcloudTmsResourceInstancesV1#tags}
    */
    readonly tags: DataOpentelekomcloudTmsResourceInstancesV1Tags[] | cdktf.IResolvable;
}
export interface DataOpentelekomcloudTmsResourceInstancesV1Resources {
}
export declare function dataOpentelekomcloudTmsResourceInstancesV1ResourcesToTerraform(struct?: DataOpentelekomcloudTmsResourceInstancesV1Resources): any;
export declare function dataOpentelekomcloudTmsResourceInstancesV1ResourcesToHclTerraform(struct?: DataOpentelekomcloudTmsResourceInstancesV1Resources): any;
export declare class DataOpentelekomcloudTmsResourceInstancesV1ResourcesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudTmsResourceInstancesV1Resources | undefined;
    set internalValue(value: DataOpentelekomcloudTmsResourceInstancesV1Resources | undefined);
    get projectId(): string;
    get projectName(): string;
    get resourceId(): string;
    get resourceName(): string;
    get resourceType(): string;
    private _tags;
    get tags(): cdktf.StringMap;
}
export declare class DataOpentelekomcloudTmsResourceInstancesV1ResourcesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudTmsResourceInstancesV1ResourcesOutputReference;
}
export interface DataOpentelekomcloudTmsResourceInstancesV1Tags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/tms_resource_instances_v1#key DataOpentelekomcloudTmsResourceInstancesV1#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/tms_resource_instances_v1#values DataOpentelekomcloudTmsResourceInstancesV1#values}
    */
    readonly values: string[];
}
export declare function dataOpentelekomcloudTmsResourceInstancesV1TagsToTerraform(struct?: DataOpentelekomcloudTmsResourceInstancesV1Tags | cdktf.IResolvable): any;
export declare function dataOpentelekomcloudTmsResourceInstancesV1TagsToHclTerraform(struct?: DataOpentelekomcloudTmsResourceInstancesV1Tags | cdktf.IResolvable): any;
export declare class DataOpentelekomcloudTmsResourceInstancesV1TagsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudTmsResourceInstancesV1Tags | cdktf.IResolvable | undefined;
    set internalValue(value: DataOpentelekomcloudTmsResourceInstancesV1Tags | cdktf.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class DataOpentelekomcloudTmsResourceInstancesV1TagsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataOpentelekomcloudTmsResourceInstancesV1Tags[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudTmsResourceInstancesV1TagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/tms_resource_instances_v1 opentelekomcloud_tms_resource_instances_v1}
*/
export declare class DataOpentelekomcloudTmsResourceInstancesV1 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_tms_resource_instances_v1";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudTmsResourceInstancesV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudTmsResourceInstancesV1 to import
    * @param importFromId The id of the existing DataOpentelekomcloudTmsResourceInstancesV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/tms_resource_instances_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudTmsResourceInstancesV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/tms_resource_instances_v1 opentelekomcloud_tms_resource_instances_v1} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudTmsResourceInstancesV1Config
    */
    constructor(scope: Construct, id: string, config: DataOpentelekomcloudTmsResourceInstancesV1Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _resourceTypes?;
    get resourceTypes(): string[];
    set resourceTypes(value: string[]);
    get resourceTypesInput(): string[] | undefined;
    private _resources;
    get resources(): DataOpentelekomcloudTmsResourceInstancesV1ResourcesList;
    private _withoutAnyTag?;
    get withoutAnyTag(): boolean | cdktf.IResolvable;
    set withoutAnyTag(value: boolean | cdktf.IResolvable);
    resetWithoutAnyTag(): void;
    get withoutAnyTagInput(): boolean | cdktf.IResolvable | undefined;
    private _tags;
    get tags(): DataOpentelekomcloudTmsResourceInstancesV1TagsList;
    putTags(value: DataOpentelekomcloudTmsResourceInstancesV1Tags[] | cdktf.IResolvable): void;
    get tagsInput(): cdktf.IResolvable | DataOpentelekomcloudTmsResourceInstancesV1Tags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

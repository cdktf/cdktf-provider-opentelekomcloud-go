/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudSfsFileSystemV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/sfs_file_system_v2#id DataOpentelekomcloudSfsFileSystemV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/sfs_file_system_v2#name DataOpentelekomcloudSfsFileSystemV2#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/sfs_file_system_v2#region DataOpentelekomcloudSfsFileSystemV2#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/sfs_file_system_v2#status DataOpentelekomcloudSfsFileSystemV2#status}
    */
    readonly status?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/sfs_file_system_v2 opentelekomcloud_sfs_file_system_v2}
*/
export declare class DataOpentelekomcloudSfsFileSystemV2 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_sfs_file_system_v2";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudSfsFileSystemV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudSfsFileSystemV2 to import
    * @param importFromId The id of the existing DataOpentelekomcloudSfsFileSystemV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/sfs_file_system_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudSfsFileSystemV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/sfs_file_system_v2 opentelekomcloud_sfs_file_system_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudSfsFileSystemV2Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudSfsFileSystemV2Config);
    get accessLevel(): string;
    get accessTo(): string;
    get accessType(): string;
    get availabilityZone(): string;
    get description(): string;
    get exportLocation(): string;
    get exportLocations(): string[];
    get host(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get isPublic(): cdktf.IResolvable;
    private _metadata;
    get metadata(): cdktf.StringMap;
    get mountId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get preferred(): cdktf.IResolvable;
    get projectId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get shareAccessId(): string;
    get shareInstanceId(): string;
    get shareProto(): string;
    get shareType(): string;
    get size(): number;
    get state(): string;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    get volumeType(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

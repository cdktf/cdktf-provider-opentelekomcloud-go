/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DmsDedicatedInstanceV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#access_user DmsDedicatedInstanceV2#access_user}
    */
    readonly accessUser?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#arch_type DmsDedicatedInstanceV2#arch_type}
    */
    readonly archType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#available_zones DmsDedicatedInstanceV2#available_zones}
    */
    readonly availableZones?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#broker_num DmsDedicatedInstanceV2#broker_num}
    */
    readonly brokerNum: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#description DmsDedicatedInstanceV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#disk_encrypted_enable DmsDedicatedInstanceV2#disk_encrypted_enable}
    */
    readonly diskEncryptedEnable?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#disk_encrypted_key DmsDedicatedInstanceV2#disk_encrypted_key}
    */
    readonly diskEncryptedKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#enable_publicip DmsDedicatedInstanceV2#enable_publicip}
    */
    readonly enablePublicip?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#enabled_mechanisms DmsDedicatedInstanceV2#enabled_mechanisms}
    */
    readonly enabledMechanisms?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#engine_version DmsDedicatedInstanceV2#engine_version}
    */
    readonly engineVersion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#flavor_id DmsDedicatedInstanceV2#flavor_id}
    */
    readonly flavorId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#id DmsDedicatedInstanceV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#ipv6_enable DmsDedicatedInstanceV2#ipv6_enable}
    */
    readonly ipv6Enable?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#maintain_begin DmsDedicatedInstanceV2#maintain_begin}
    */
    readonly maintainBegin?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#maintain_end DmsDedicatedInstanceV2#maintain_end}
    */
    readonly maintainEnd?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#name DmsDedicatedInstanceV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#network_id DmsDedicatedInstanceV2#network_id}
    */
    readonly networkId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#new_tenant_ips DmsDedicatedInstanceV2#new_tenant_ips}
    */
    readonly newTenantIps?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#password DmsDedicatedInstanceV2#password}
    */
    readonly password?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#publicip_id DmsDedicatedInstanceV2#publicip_id}
    */
    readonly publicipId?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#retention_policy DmsDedicatedInstanceV2#retention_policy}
    */
    readonly retentionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#security_group_id DmsDedicatedInstanceV2#security_group_id}
    */
    readonly securityGroupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#security_protocol DmsDedicatedInstanceV2#security_protocol}
    */
    readonly securityProtocol?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#ssl_enable DmsDedicatedInstanceV2#ssl_enable}
    */
    readonly sslEnable?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#storage_space DmsDedicatedInstanceV2#storage_space}
    */
    readonly storageSpace: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#storage_spec_code DmsDedicatedInstanceV2#storage_spec_code}
    */
    readonly storageSpecCode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#tags DmsDedicatedInstanceV2#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#vpc_id DmsDedicatedInstanceV2#vpc_id}
    */
    readonly vpcId: string;
    /**
    * cross_vpc_accesses block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#cross_vpc_accesses DmsDedicatedInstanceV2#cross_vpc_accesses}
    */
    readonly crossVpcAccesses?: DmsDedicatedInstanceV2CrossVpcAccesses[] | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#timeouts DmsDedicatedInstanceV2#timeouts}
    */
    readonly timeouts?: DmsDedicatedInstanceV2Timeouts;
}
export interface DmsDedicatedInstanceV2CrossVpcAccesses {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#advertised_ip DmsDedicatedInstanceV2#advertised_ip}
    */
    readonly advertisedIp?: string;
}
export declare function dmsDedicatedInstanceV2CrossVpcAccessesToTerraform(struct?: DmsDedicatedInstanceV2CrossVpcAccesses | cdktf.IResolvable): any;
export declare function dmsDedicatedInstanceV2CrossVpcAccessesToHclTerraform(struct?: DmsDedicatedInstanceV2CrossVpcAccesses | cdktf.IResolvable): any;
export declare class DmsDedicatedInstanceV2CrossVpcAccessesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DmsDedicatedInstanceV2CrossVpcAccesses | cdktf.IResolvable | undefined;
    set internalValue(value: DmsDedicatedInstanceV2CrossVpcAccesses | cdktf.IResolvable | undefined);
    private _advertisedIp?;
    get advertisedIp(): string;
    set advertisedIp(value: string);
    resetAdvertisedIp(): void;
    get advertisedIpInput(): string | undefined;
    get listenerIp(): string;
    get port(): number;
    get portId(): string;
}
export declare class DmsDedicatedInstanceV2CrossVpcAccessesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DmsDedicatedInstanceV2CrossVpcAccesses[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DmsDedicatedInstanceV2CrossVpcAccessesOutputReference;
}
export interface DmsDedicatedInstanceV2Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#create DmsDedicatedInstanceV2#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#delete DmsDedicatedInstanceV2#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#update DmsDedicatedInstanceV2#update}
    */
    readonly update?: string;
}
export declare function dmsDedicatedInstanceV2TimeoutsToTerraform(struct?: DmsDedicatedInstanceV2Timeouts | cdktf.IResolvable): any;
export declare function dmsDedicatedInstanceV2TimeoutsToHclTerraform(struct?: DmsDedicatedInstanceV2Timeouts | cdktf.IResolvable): any;
export declare class DmsDedicatedInstanceV2TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DmsDedicatedInstanceV2Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DmsDedicatedInstanceV2Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2 opentelekomcloud_dms_dedicated_instance_v2}
*/
export declare class DmsDedicatedInstanceV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_dms_dedicated_instance_v2";
    /**
    * Generates CDKTF code for importing a DmsDedicatedInstanceV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DmsDedicatedInstanceV2 to import
    * @param importFromId The id of the existing DmsDedicatedInstanceV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DmsDedicatedInstanceV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_dedicated_instance_v2 opentelekomcloud_dms_dedicated_instance_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DmsDedicatedInstanceV2Config
    */
    constructor(scope: Construct, id: string, config: DmsDedicatedInstanceV2Config);
    private _accessUser?;
    get accessUser(): string;
    set accessUser(value: string);
    resetAccessUser(): void;
    get accessUserInput(): string | undefined;
    private _archType?;
    get archType(): string;
    set archType(value: string);
    resetArchType(): void;
    get archTypeInput(): string | undefined;
    private _availableZones?;
    get availableZones(): string[];
    set availableZones(value: string[]);
    resetAvailableZones(): void;
    get availableZonesInput(): string[] | undefined;
    get bandwidth(): string;
    private _brokerNum?;
    get brokerNum(): number;
    set brokerNum(value: number);
    get brokerNumInput(): number | undefined;
    get certReplaced(): cdktf.IResolvable;
    get connectAddress(): string;
    get connectorNodeNum(): number;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _diskEncryptedEnable?;
    get diskEncryptedEnable(): boolean | cdktf.IResolvable;
    set diskEncryptedEnable(value: boolean | cdktf.IResolvable);
    resetDiskEncryptedEnable(): void;
    get diskEncryptedEnableInput(): boolean | cdktf.IResolvable | undefined;
    private _diskEncryptedKey?;
    get diskEncryptedKey(): string;
    set diskEncryptedKey(value: string);
    resetDiskEncryptedKey(): void;
    get diskEncryptedKeyInput(): string | undefined;
    get dumping(): cdktf.IResolvable;
    private _enablePublicip?;
    get enablePublicip(): boolean | cdktf.IResolvable;
    set enablePublicip(value: boolean | cdktf.IResolvable);
    resetEnablePublicip(): void;
    get enablePublicipInput(): boolean | cdktf.IResolvable | undefined;
    private _enabledMechanisms?;
    get enabledMechanisms(): string[];
    set enabledMechanisms(value: string[]);
    resetEnabledMechanisms(): void;
    get enabledMechanismsInput(): string[] | undefined;
    get engine(): string;
    private _engineVersion?;
    get engineVersion(): string;
    set engineVersion(value: string);
    get engineVersionInput(): string | undefined;
    private _flavorId?;
    get flavorId(): string;
    set flavorId(value: string);
    get flavorIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipv6Enable?;
    get ipv6Enable(): boolean | cdktf.IResolvable;
    set ipv6Enable(value: boolean | cdktf.IResolvable);
    resetIpv6Enable(): void;
    get ipv6EnableInput(): boolean | cdktf.IResolvable | undefined;
    private _maintainBegin?;
    get maintainBegin(): string;
    set maintainBegin(value: string);
    resetMaintainBegin(): void;
    get maintainBeginInput(): string | undefined;
    private _maintainEnd?;
    get maintainEnd(): string;
    set maintainEnd(value: string);
    resetMaintainEnd(): void;
    get maintainEndInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _networkId?;
    get networkId(): string;
    set networkId(value: string);
    get networkIdInput(): string | undefined;
    private _newTenantIps?;
    get newTenantIps(): string[];
    set newTenantIps(value: string[]);
    resetNewTenantIps(): void;
    get newTenantIpsInput(): string[] | undefined;
    get nodeNum(): number;
    get partitionNum(): number;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    get podConnectAddress(): string;
    get port(): number;
    get publicBandwidth(): number;
    get publicIpAddress(): string;
    private _publicipId?;
    get publicipId(): string[];
    set publicipId(value: string[]);
    resetPublicipId(): void;
    get publicipIdInput(): string[] | undefined;
    get region(): string;
    get resourceSpecCode(): string;
    private _retentionPolicy?;
    get retentionPolicy(): string;
    set retentionPolicy(value: string);
    resetRetentionPolicy(): void;
    get retentionPolicyInput(): string | undefined;
    private _securityGroupId?;
    get securityGroupId(): string;
    set securityGroupId(value: string);
    get securityGroupIdInput(): string | undefined;
    private _securityProtocol?;
    get securityProtocol(): string;
    set securityProtocol(value: string);
    resetSecurityProtocol(): void;
    get securityProtocolInput(): string | undefined;
    private _sslEnable?;
    get sslEnable(): boolean | cdktf.IResolvable;
    set sslEnable(value: boolean | cdktf.IResolvable);
    resetSslEnable(): void;
    get sslEnableInput(): boolean | cdktf.IResolvable | undefined;
    get sslTwoWayEnable(): cdktf.IResolvable;
    get status(): string;
    get storageResourceId(): string;
    private _storageSpace?;
    get storageSpace(): number;
    set storageSpace(value: number);
    get storageSpaceInput(): number | undefined;
    private _storageSpecCode?;
    get storageSpecCode(): string;
    set storageSpecCode(value: string);
    get storageSpecCodeInput(): string | undefined;
    get storageType(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get type(): string;
    get usedStorageSpace(): number;
    get userId(): string;
    get userName(): string;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    get vpcIdInput(): string | undefined;
    private _crossVpcAccesses;
    get crossVpcAccesses(): DmsDedicatedInstanceV2CrossVpcAccessesList;
    putCrossVpcAccesses(value: DmsDedicatedInstanceV2CrossVpcAccesses[] | cdktf.IResolvable): void;
    resetCrossVpcAccesses(): void;
    get crossVpcAccessesInput(): cdktf.IResolvable | DmsDedicatedInstanceV2CrossVpcAccesses[] | undefined;
    private _timeouts;
    get timeouts(): DmsDedicatedInstanceV2TimeoutsOutputReference;
    putTimeouts(value: DmsDedicatedInstanceV2Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DmsDedicatedInstanceV2Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

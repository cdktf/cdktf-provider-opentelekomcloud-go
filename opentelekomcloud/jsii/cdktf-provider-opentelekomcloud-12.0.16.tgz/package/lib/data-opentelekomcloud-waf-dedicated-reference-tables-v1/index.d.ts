/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudWafDedicatedReferenceTablesV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/waf_dedicated_reference_tables_v1#id DataOpentelekomcloudWafDedicatedReferenceTablesV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/waf_dedicated_reference_tables_v1#name DataOpentelekomcloudWafDedicatedReferenceTablesV1#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/waf_dedicated_reference_tables_v1#region DataOpentelekomcloudWafDedicatedReferenceTablesV1#region}
    */
    readonly region?: string;
}
export interface DataOpentelekomcloudWafDedicatedReferenceTablesV1Tables {
}
export declare function dataOpentelekomcloudWafDedicatedReferenceTablesV1TablesToTerraform(struct?: DataOpentelekomcloudWafDedicatedReferenceTablesV1Tables): any;
export declare function dataOpentelekomcloudWafDedicatedReferenceTablesV1TablesToHclTerraform(struct?: DataOpentelekomcloudWafDedicatedReferenceTablesV1Tables): any;
export declare class DataOpentelekomcloudWafDedicatedReferenceTablesV1TablesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudWafDedicatedReferenceTablesV1Tables | undefined;
    set internalValue(value: DataOpentelekomcloudWafDedicatedReferenceTablesV1Tables | undefined);
    get conditions(): string[];
    get createdAt(): string;
    get description(): string;
    get id(): string;
    get name(): string;
    get type(): string;
}
export declare class DataOpentelekomcloudWafDedicatedReferenceTablesV1TablesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudWafDedicatedReferenceTablesV1TablesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/waf_dedicated_reference_tables_v1 opentelekomcloud_waf_dedicated_reference_tables_v1}
*/
export declare class DataOpentelekomcloudWafDedicatedReferenceTablesV1 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_waf_dedicated_reference_tables_v1";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudWafDedicatedReferenceTablesV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudWafDedicatedReferenceTablesV1 to import
    * @param importFromId The id of the existing DataOpentelekomcloudWafDedicatedReferenceTablesV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/waf_dedicated_reference_tables_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudWafDedicatedReferenceTablesV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/waf_dedicated_reference_tables_v1 opentelekomcloud_waf_dedicated_reference_tables_v1} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudWafDedicatedReferenceTablesV1Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudWafDedicatedReferenceTablesV1Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tables;
    get tables(): DataOpentelekomcloudWafDedicatedReferenceTablesV1TablesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

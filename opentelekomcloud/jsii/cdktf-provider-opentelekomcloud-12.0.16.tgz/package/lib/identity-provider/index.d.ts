/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface IdentityProviderConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_provider#description IdentityProvider#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_provider#id IdentityProvider#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_provider#mapping_rules IdentityProvider#mapping_rules}
    */
    readonly mappingRules?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_provider#metadata IdentityProvider#metadata}
    */
    readonly metadata?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_provider#name IdentityProvider#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_provider#protocol IdentityProvider#protocol}
    */
    readonly protocol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_provider#status IdentityProvider#status}
    */
    readonly status?: boolean | cdktf.IResolvable;
    /**
    * access_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_provider#access_config IdentityProvider#access_config}
    */
    readonly accessConfig?: IdentityProviderAccessConfig;
}
export interface IdentityProviderConversionRulesLocal {
}
export declare function identityProviderConversionRulesLocalToTerraform(struct?: IdentityProviderConversionRulesLocal): any;
export declare function identityProviderConversionRulesLocalToHclTerraform(struct?: IdentityProviderConversionRulesLocal): any;
export declare class IdentityProviderConversionRulesLocalOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IdentityProviderConversionRulesLocal | undefined;
    set internalValue(value: IdentityProviderConversionRulesLocal | undefined);
    get group(): string;
    get groups(): string;
    get username(): string;
}
export declare class IdentityProviderConversionRulesLocalList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IdentityProviderConversionRulesLocalOutputReference;
}
export interface IdentityProviderConversionRulesRemote {
}
export declare function identityProviderConversionRulesRemoteToTerraform(struct?: IdentityProviderConversionRulesRemote): any;
export declare function identityProviderConversionRulesRemoteToHclTerraform(struct?: IdentityProviderConversionRulesRemote): any;
export declare class IdentityProviderConversionRulesRemoteOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IdentityProviderConversionRulesRemote | undefined;
    set internalValue(value: IdentityProviderConversionRulesRemote | undefined);
    get attribute(): string;
    get condition(): string;
    get value(): string[];
}
export declare class IdentityProviderConversionRulesRemoteList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IdentityProviderConversionRulesRemoteOutputReference;
}
export interface IdentityProviderConversionRules {
}
export declare function identityProviderConversionRulesToTerraform(struct?: IdentityProviderConversionRules): any;
export declare function identityProviderConversionRulesToHclTerraform(struct?: IdentityProviderConversionRules): any;
export declare class IdentityProviderConversionRulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IdentityProviderConversionRules | undefined;
    set internalValue(value: IdentityProviderConversionRules | undefined);
    private _local;
    get local(): IdentityProviderConversionRulesLocalList;
    private _remote;
    get remote(): IdentityProviderConversionRulesRemoteList;
}
export declare class IdentityProviderConversionRulesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IdentityProviderConversionRulesOutputReference;
}
export interface IdentityProviderAccessConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_provider#access_type IdentityProvider#access_type}
    */
    readonly accessType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_provider#authorization_endpoint IdentityProvider#authorization_endpoint}
    */
    readonly authorizationEndpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_provider#client_id IdentityProvider#client_id}
    */
    readonly clientId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_provider#provider_url IdentityProvider#provider_url}
    */
    readonly providerUrl: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_provider#response_mode IdentityProvider#response_mode}
    */
    readonly responseMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_provider#response_type IdentityProvider#response_type}
    */
    readonly responseType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_provider#scopes IdentityProvider#scopes}
    */
    readonly scopes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_provider#signing_key IdentityProvider#signing_key}
    */
    readonly signingKey: string;
}
export declare function identityProviderAccessConfigToTerraform(struct?: IdentityProviderAccessConfigOutputReference | IdentityProviderAccessConfig): any;
export declare function identityProviderAccessConfigToHclTerraform(struct?: IdentityProviderAccessConfigOutputReference | IdentityProviderAccessConfig): any;
export declare class IdentityProviderAccessConfigOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IdentityProviderAccessConfig | undefined;
    set internalValue(value: IdentityProviderAccessConfig | undefined);
    private _accessType?;
    get accessType(): string;
    set accessType(value: string);
    get accessTypeInput(): string | undefined;
    private _authorizationEndpoint?;
    get authorizationEndpoint(): string;
    set authorizationEndpoint(value: string);
    resetAuthorizationEndpoint(): void;
    get authorizationEndpointInput(): string | undefined;
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    get clientIdInput(): string | undefined;
    private _providerUrl?;
    get providerUrl(): string;
    set providerUrl(value: string);
    get providerUrlInput(): string | undefined;
    private _responseMode?;
    get responseMode(): string;
    set responseMode(value: string);
    resetResponseMode(): void;
    get responseModeInput(): string | undefined;
    private _responseType?;
    get responseType(): string;
    set responseType(value: string);
    resetResponseType(): void;
    get responseTypeInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
    private _signingKey?;
    get signingKey(): string;
    set signingKey(value: string);
    get signingKeyInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_provider opentelekomcloud_identity_provider}
*/
export declare class IdentityProvider extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_identity_provider";
    /**
    * Generates CDKTF code for importing a IdentityProvider resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IdentityProvider to import
    * @param importFromId The id of the existing IdentityProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_provider#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IdentityProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_provider opentelekomcloud_identity_provider} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IdentityProviderConfig
    */
    constructor(scope: Construct, id: string, config: IdentityProviderConfig);
    private _conversionRules;
    get conversionRules(): IdentityProviderConversionRulesList;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _links;
    get links(): cdktf.StringMap;
    get loginLink(): string;
    private _mappingRules?;
    get mappingRules(): string;
    set mappingRules(value: string);
    resetMappingRules(): void;
    get mappingRulesInput(): string | undefined;
    private _metadata?;
    get metadata(): string;
    set metadata(value: string);
    resetMetadata(): void;
    get metadataInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    get protocolInput(): string | undefined;
    private _status?;
    get status(): boolean | cdktf.IResolvable;
    set status(value: boolean | cdktf.IResolvable);
    resetStatus(): void;
    get statusInput(): boolean | cdktf.IResolvable | undefined;
    private _accessConfig;
    get accessConfig(): IdentityProviderAccessConfigOutputReference;
    putAccessConfig(value: IdentityProviderAccessConfig): void;
    resetAccessConfig(): void;
    get accessConfigInput(): IdentityProviderAccessConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

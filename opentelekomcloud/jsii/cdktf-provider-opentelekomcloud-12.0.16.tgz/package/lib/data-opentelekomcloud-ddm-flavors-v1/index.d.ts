/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudDdmFlavorsV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ddm_flavors_v1#engine_id DataOpentelekomcloudDdmFlavorsV1#engine_id}
    */
    readonly engineId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ddm_flavors_v1#id DataOpentelekomcloudDdmFlavorsV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataOpentelekomcloudDdmFlavorsV1FlavorGroupsFlavors {
}
export declare function dataOpentelekomcloudDdmFlavorsV1FlavorGroupsFlavorsToTerraform(struct?: DataOpentelekomcloudDdmFlavorsV1FlavorGroupsFlavors): any;
export declare function dataOpentelekomcloudDdmFlavorsV1FlavorGroupsFlavorsToHclTerraform(struct?: DataOpentelekomcloudDdmFlavorsV1FlavorGroupsFlavors): any;
export declare class DataOpentelekomcloudDdmFlavorsV1FlavorGroupsFlavorsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudDdmFlavorsV1FlavorGroupsFlavors | undefined;
    set internalValue(value: DataOpentelekomcloudDdmFlavorsV1FlavorGroupsFlavors | undefined);
    get architecture(): string;
    private _azStatus;
    get azStatus(): cdktf.StringMap;
    get code(): string;
    get cpu(): string;
    get iaasCode(): string;
    get id(): string;
    get maxConnections(): string;
    get memory(): string;
    get serverType(): string;
    get typeCode(): string;
}
export declare class DataOpentelekomcloudDdmFlavorsV1FlavorGroupsFlavorsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudDdmFlavorsV1FlavorGroupsFlavorsOutputReference;
}
export interface DataOpentelekomcloudDdmFlavorsV1FlavorGroups {
}
export declare function dataOpentelekomcloudDdmFlavorsV1FlavorGroupsToTerraform(struct?: DataOpentelekomcloudDdmFlavorsV1FlavorGroups): any;
export declare function dataOpentelekomcloudDdmFlavorsV1FlavorGroupsToHclTerraform(struct?: DataOpentelekomcloudDdmFlavorsV1FlavorGroups): any;
export declare class DataOpentelekomcloudDdmFlavorsV1FlavorGroupsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudDdmFlavorsV1FlavorGroups | undefined;
    set internalValue(value: DataOpentelekomcloudDdmFlavorsV1FlavorGroups | undefined);
    private _flavors;
    get flavors(): DataOpentelekomcloudDdmFlavorsV1FlavorGroupsFlavorsList;
    get type(): string;
}
export declare class DataOpentelekomcloudDdmFlavorsV1FlavorGroupsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudDdmFlavorsV1FlavorGroupsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ddm_flavors_v1 opentelekomcloud_ddm_flavors_v1}
*/
export declare class DataOpentelekomcloudDdmFlavorsV1 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_ddm_flavors_v1";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudDdmFlavorsV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudDdmFlavorsV1 to import
    * @param importFromId The id of the existing DataOpentelekomcloudDdmFlavorsV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ddm_flavors_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudDdmFlavorsV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ddm_flavors_v1 opentelekomcloud_ddm_flavors_v1} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudDdmFlavorsV1Config
    */
    constructor(scope: Construct, id: string, config: DataOpentelekomcloudDdmFlavorsV1Config);
    private _engineId?;
    get engineId(): string;
    set engineId(value: string);
    get engineIdInput(): string | undefined;
    private _flavorGroups;
    get flavorGroups(): DataOpentelekomcloudDdmFlavorsV1FlavorGroupsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get region(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

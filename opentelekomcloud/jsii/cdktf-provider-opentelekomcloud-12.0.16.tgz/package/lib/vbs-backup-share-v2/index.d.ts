/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface VbsBackupShareV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vbs_backup_share_v2#backup_id VbsBackupShareV2#backup_id}
    */
    readonly backupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vbs_backup_share_v2#id VbsBackupShareV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vbs_backup_share_v2#region VbsBackupShareV2#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vbs_backup_share_v2#to_project_ids VbsBackupShareV2#to_project_ids}
    */
    readonly toProjectIds: string[];
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vbs_backup_share_v2#timeouts VbsBackupShareV2#timeouts}
    */
    readonly timeouts?: VbsBackupShareV2Timeouts;
}
export interface VbsBackupShareV2Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vbs_backup_share_v2#create VbsBackupShareV2#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vbs_backup_share_v2#delete VbsBackupShareV2#delete}
    */
    readonly delete?: string;
}
export declare function vbsBackupShareV2TimeoutsToTerraform(struct?: VbsBackupShareV2Timeouts | cdktf.IResolvable): any;
export declare function vbsBackupShareV2TimeoutsToHclTerraform(struct?: VbsBackupShareV2Timeouts | cdktf.IResolvable): any;
export declare class VbsBackupShareV2TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VbsBackupShareV2Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: VbsBackupShareV2Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vbs_backup_share_v2 opentelekomcloud_vbs_backup_share_v2}
*/
export declare class VbsBackupShareV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_vbs_backup_share_v2";
    /**
    * Generates CDKTF code for importing a VbsBackupShareV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VbsBackupShareV2 to import
    * @param importFromId The id of the existing VbsBackupShareV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vbs_backup_share_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VbsBackupShareV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vbs_backup_share_v2 opentelekomcloud_vbs_backup_share_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VbsBackupShareV2Config
    */
    constructor(scope: Construct, id: string, config: VbsBackupShareV2Config);
    get availabilityZone(): string;
    private _backupId?;
    get backupId(): string;
    set backupId(value: string);
    get backupIdInput(): string | undefined;
    get backupName(): string;
    get backupStatus(): string;
    get container(): string;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get serviceMetadata(): string;
    get shareIds(): string[];
    get size(): number;
    get snapshotId(): string;
    private _toProjectIds?;
    get toProjectIds(): string[];
    set toProjectIds(value: string[]);
    get toProjectIdsInput(): string[] | undefined;
    get volumeId(): string;
    private _timeouts;
    get timeouts(): VbsBackupShareV2TimeoutsOutputReference;
    putTimeouts(value: VbsBackupShareV2Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | VbsBackupShareV2Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

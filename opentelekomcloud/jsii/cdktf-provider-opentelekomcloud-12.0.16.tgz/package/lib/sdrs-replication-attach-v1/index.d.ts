/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface SdrsReplicationAttachV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/sdrs_replication_attach_v1#device SdrsReplicationAttachV1#device}
    */
    readonly device: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/sdrs_replication_attach_v1#id SdrsReplicationAttachV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/sdrs_replication_attach_v1#instance_id SdrsReplicationAttachV1#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/sdrs_replication_attach_v1#replication_id SdrsReplicationAttachV1#replication_id}
    */
    readonly replicationId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/sdrs_replication_attach_v1#timeouts SdrsReplicationAttachV1#timeouts}
    */
    readonly timeouts?: SdrsReplicationAttachV1Timeouts;
}
export interface SdrsReplicationAttachV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/sdrs_replication_attach_v1#create SdrsReplicationAttachV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/sdrs_replication_attach_v1#delete SdrsReplicationAttachV1#delete}
    */
    readonly delete?: string;
}
export declare function sdrsReplicationAttachV1TimeoutsToTerraform(struct?: SdrsReplicationAttachV1Timeouts | cdktf.IResolvable): any;
export declare function sdrsReplicationAttachV1TimeoutsToHclTerraform(struct?: SdrsReplicationAttachV1Timeouts | cdktf.IResolvable): any;
export declare class SdrsReplicationAttachV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SdrsReplicationAttachV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: SdrsReplicationAttachV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/sdrs_replication_attach_v1 opentelekomcloud_sdrs_replication_attach_v1}
*/
export declare class SdrsReplicationAttachV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_sdrs_replication_attach_v1";
    /**
    * Generates CDKTF code for importing a SdrsReplicationAttachV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SdrsReplicationAttachV1 to import
    * @param importFromId The id of the existing SdrsReplicationAttachV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/sdrs_replication_attach_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SdrsReplicationAttachV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/sdrs_replication_attach_v1 opentelekomcloud_sdrs_replication_attach_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SdrsReplicationAttachV1Config
    */
    constructor(scope: Construct, id: string, config: SdrsReplicationAttachV1Config);
    private _device?;
    get device(): string;
    set device(value: string);
    get deviceInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get region(): string;
    private _replicationId?;
    get replicationId(): string;
    set replicationId(value: string);
    get replicationIdInput(): string | undefined;
    get status(): string;
    private _timeouts;
    get timeouts(): SdrsReplicationAttachV1TimeoutsOutputReference;
    putTimeouts(value: SdrsReplicationAttachV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | SdrsReplicationAttachV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

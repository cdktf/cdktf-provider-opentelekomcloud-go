/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CfwIpsProtectionV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_ips_protection_v1#feature_status CfwIpsProtectionV1#feature_status}
    */
    readonly featureStatus: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_ips_protection_v1#id CfwIpsProtectionV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_ips_protection_v1#ips_type CfwIpsProtectionV1#ips_type}
    */
    readonly ipsType?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_ips_protection_v1#mode CfwIpsProtectionV1#mode}
    */
    readonly mode: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_ips_protection_v1#object_id CfwIpsProtectionV1#object_id}
    */
    readonly objectId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_ips_protection_v1#timeouts CfwIpsProtectionV1#timeouts}
    */
    readonly timeouts?: CfwIpsProtectionV1Timeouts;
}
export interface CfwIpsProtectionV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_ips_protection_v1#create CfwIpsProtectionV1#create}
    */
    readonly create?: string;
}
export declare function cfwIpsProtectionV1TimeoutsToTerraform(struct?: CfwIpsProtectionV1Timeouts | cdktf.IResolvable): any;
export declare function cfwIpsProtectionV1TimeoutsToHclTerraform(struct?: CfwIpsProtectionV1Timeouts | cdktf.IResolvable): any;
export declare class CfwIpsProtectionV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CfwIpsProtectionV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: CfwIpsProtectionV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_ips_protection_v1 opentelekomcloud_cfw_ips_protection_v1}
*/
export declare class CfwIpsProtectionV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_cfw_ips_protection_v1";
    /**
    * Generates CDKTF code for importing a CfwIpsProtectionV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CfwIpsProtectionV1 to import
    * @param importFromId The id of the existing CfwIpsProtectionV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_ips_protection_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CfwIpsProtectionV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_ips_protection_v1 opentelekomcloud_cfw_ips_protection_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CfwIpsProtectionV1Config
    */
    constructor(scope: Construct, id: string, config: CfwIpsProtectionV1Config);
    get basicDefenseStatus(): number;
    private _featureStatus?;
    get featureStatus(): number;
    set featureStatus(value: number);
    get featureStatusInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ipsProtectionModeId(): string;
    get ipsSwitchId(): string;
    private _ipsType?;
    get ipsType(): number;
    set ipsType(value: number);
    resetIpsType(): void;
    get ipsTypeInput(): number | undefined;
    private _mode?;
    get mode(): number;
    set mode(value: number);
    get modeInput(): number | undefined;
    private _objectId?;
    get objectId(): string;
    set objectId(value: string);
    get objectIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): CfwIpsProtectionV1TimeoutsOutputReference;
    putTimeouts(value: CfwIpsProtectionV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | CfwIpsProtectionV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface KmsKeyV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/kms_key_v1#allow_cancel_deletion KmsKeyV1#allow_cancel_deletion}
    */
    readonly allowCancelDeletion?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/kms_key_v1#id KmsKeyV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/kms_key_v1#is_enabled KmsKeyV1#is_enabled}
    */
    readonly isEnabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/kms_key_v1#key_alias KmsKeyV1#key_alias}
    */
    readonly keyAlias: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/kms_key_v1#key_description KmsKeyV1#key_description}
    */
    readonly keyDescription?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/kms_key_v1#origin KmsKeyV1#origin}
    */
    readonly origin?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/kms_key_v1#pending_days KmsKeyV1#pending_days}
    */
    readonly pendingDays?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/kms_key_v1#realm KmsKeyV1#realm}
    */
    readonly realm?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/kms_key_v1#rotation_enabled KmsKeyV1#rotation_enabled}
    */
    readonly rotationEnabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/kms_key_v1#rotation_interval KmsKeyV1#rotation_interval}
    */
    readonly rotationInterval?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/kms_key_v1#tags KmsKeyV1#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/kms_key_v1 opentelekomcloud_kms_key_v1}
*/
export declare class KmsKeyV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_kms_key_v1";
    /**
    * Generates CDKTF code for importing a KmsKeyV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the KmsKeyV1 to import
    * @param importFromId The id of the existing KmsKeyV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/kms_key_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the KmsKeyV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/kms_key_v1 opentelekomcloud_kms_key_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options KmsKeyV1Config
    */
    constructor(scope: Construct, id: string, config: KmsKeyV1Config);
    private _allowCancelDeletion?;
    get allowCancelDeletion(): boolean | cdktf.IResolvable;
    set allowCancelDeletion(value: boolean | cdktf.IResolvable);
    resetAllowCancelDeletion(): void;
    get allowCancelDeletionInput(): boolean | cdktf.IResolvable | undefined;
    get creationDate(): string;
    get defaultKeyFlag(): string;
    get domainId(): string;
    get expirationTime(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isEnabled?;
    get isEnabled(): boolean | cdktf.IResolvable;
    set isEnabled(value: boolean | cdktf.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _keyAlias?;
    get keyAlias(): string;
    set keyAlias(value: string);
    get keyAliasInput(): string | undefined;
    private _keyDescription?;
    get keyDescription(): string;
    set keyDescription(value: string);
    resetKeyDescription(): void;
    get keyDescriptionInput(): string | undefined;
    get keyState(): string;
    private _origin?;
    get origin(): string;
    set origin(value: string);
    resetOrigin(): void;
    get originInput(): string | undefined;
    private _pendingDays?;
    get pendingDays(): string;
    set pendingDays(value: string);
    resetPendingDays(): void;
    get pendingDaysInput(): string | undefined;
    private _realm?;
    get realm(): string;
    set realm(value: string);
    resetRealm(): void;
    get realmInput(): string | undefined;
    private _rotationEnabled?;
    get rotationEnabled(): boolean | cdktf.IResolvable;
    set rotationEnabled(value: boolean | cdktf.IResolvable);
    resetRotationEnabled(): void;
    get rotationEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _rotationInterval?;
    get rotationInterval(): number;
    set rotationInterval(value: number);
    resetRotationInterval(): void;
    get rotationIntervalInput(): number | undefined;
    get rotationNumber(): number;
    get scheduledDeletionDate(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DisStreamV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_stream_v2#auto_scale_max_partition_count DisStreamV2#auto_scale_max_partition_count}
    */
    readonly autoScaleMaxPartitionCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_stream_v2#auto_scale_min_partition_count DisStreamV2#auto_scale_min_partition_count}
    */
    readonly autoScaleMinPartitionCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_stream_v2#compression_format DisStreamV2#compression_format}
    */
    readonly compressionFormat?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_stream_v2#data_type DisStreamV2#data_type}
    */
    readonly dataType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_stream_v2#id DisStreamV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_stream_v2#name DisStreamV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_stream_v2#partition_count DisStreamV2#partition_count}
    */
    readonly partitionCount: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_stream_v2#retention_period DisStreamV2#retention_period}
    */
    readonly retentionPeriod?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_stream_v2#stream_type DisStreamV2#stream_type}
    */
    readonly streamType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_stream_v2#tags DisStreamV2#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_stream_v2#timeouts DisStreamV2#timeouts}
    */
    readonly timeouts?: DisStreamV2Timeouts;
}
export interface DisStreamV2Partitions {
}
export declare function disStreamV2PartitionsToTerraform(struct?: DisStreamV2Partitions): any;
export declare function disStreamV2PartitionsToHclTerraform(struct?: DisStreamV2Partitions): any;
export declare class DisStreamV2PartitionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DisStreamV2Partitions | undefined;
    set internalValue(value: DisStreamV2Partitions | undefined);
    get hashRange(): string;
    get id(): string;
    get parentPartitions(): string;
    get sequenceNumberRange(): string;
    get status(): string;
}
export declare class DisStreamV2PartitionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DisStreamV2PartitionsOutputReference;
}
export interface DisStreamV2Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_stream_v2#update DisStreamV2#update}
    */
    readonly update?: string;
}
export declare function disStreamV2TimeoutsToTerraform(struct?: DisStreamV2Timeouts | cdktf.IResolvable): any;
export declare function disStreamV2TimeoutsToHclTerraform(struct?: DisStreamV2Timeouts | cdktf.IResolvable): any;
export declare class DisStreamV2TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DisStreamV2Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DisStreamV2Timeouts | cdktf.IResolvable | undefined);
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_stream_v2 opentelekomcloud_dis_stream_v2}
*/
export declare class DisStreamV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_dis_stream_v2";
    /**
    * Generates CDKTF code for importing a DisStreamV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DisStreamV2 to import
    * @param importFromId The id of the existing DisStreamV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_stream_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DisStreamV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_stream_v2 opentelekomcloud_dis_stream_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DisStreamV2Config
    */
    constructor(scope: Construct, id: string, config: DisStreamV2Config);
    private _autoScaleMaxPartitionCount?;
    get autoScaleMaxPartitionCount(): number;
    set autoScaleMaxPartitionCount(value: number);
    resetAutoScaleMaxPartitionCount(): void;
    get autoScaleMaxPartitionCountInput(): number | undefined;
    private _autoScaleMinPartitionCount?;
    get autoScaleMinPartitionCount(): number;
    set autoScaleMinPartitionCount(value: number);
    resetAutoScaleMinPartitionCount(): void;
    get autoScaleMinPartitionCountInput(): number | undefined;
    private _compressionFormat?;
    get compressionFormat(): string;
    set compressionFormat(value: string);
    resetCompressionFormat(): void;
    get compressionFormatInput(): string | undefined;
    get created(): number;
    private _dataType?;
    get dataType(): string;
    set dataType(value: string);
    resetDataType(): void;
    get dataTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _partitionCount?;
    get partitionCount(): number;
    set partitionCount(value: number);
    get partitionCountInput(): number | undefined;
    private _partitions;
    get partitions(): DisStreamV2PartitionsList;
    get readablePartitionCount(): number;
    private _retentionPeriod?;
    get retentionPeriod(): number;
    set retentionPeriod(value: number);
    resetRetentionPeriod(): void;
    get retentionPeriodInput(): number | undefined;
    get status(): string;
    get streamId(): string;
    private _streamType?;
    get streamType(): string;
    set streamType(value: string);
    resetStreamType(): void;
    get streamTypeInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get writablePartitionCount(): number;
    private _timeouts;
    get timeouts(): DisStreamV2TimeoutsOutputReference;
    putTimeouts(value: DisStreamV2Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DisStreamV2Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface IdentityProtectionPolicyV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protection_policy_v3#enable_operation_protection_policy IdentityProtectionPolicyV3#enable_operation_protection_policy}
    */
    readonly enableOperationProtectionPolicy?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protection_policy_v3#id IdentityProtectionPolicyV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protection_policy_v3#verification_email IdentityProtectionPolicyV3#verification_email}
    */
    readonly verificationEmail?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protection_policy_v3#verification_mobile IdentityProtectionPolicyV3#verification_mobile}
    */
    readonly verificationMobile?: string;
    /**
    * self_management block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protection_policy_v3#self_management IdentityProtectionPolicyV3#self_management}
    */
    readonly selfManagement?: IdentityProtectionPolicyV3SelfManagement;
}
export interface IdentityProtectionPolicyV3SelfManagement {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protection_policy_v3#access_key IdentityProtectionPolicyV3#access_key}
    */
    readonly accessKey?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protection_policy_v3#email IdentityProtectionPolicyV3#email}
    */
    readonly email?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protection_policy_v3#mobile IdentityProtectionPolicyV3#mobile}
    */
    readonly mobile?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protection_policy_v3#password IdentityProtectionPolicyV3#password}
    */
    readonly password?: boolean | cdktf.IResolvable;
}
export declare function identityProtectionPolicyV3SelfManagementToTerraform(struct?: IdentityProtectionPolicyV3SelfManagementOutputReference | IdentityProtectionPolicyV3SelfManagement): any;
export declare function identityProtectionPolicyV3SelfManagementToHclTerraform(struct?: IdentityProtectionPolicyV3SelfManagementOutputReference | IdentityProtectionPolicyV3SelfManagement): any;
export declare class IdentityProtectionPolicyV3SelfManagementOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IdentityProtectionPolicyV3SelfManagement | undefined;
    set internalValue(value: IdentityProtectionPolicyV3SelfManagement | undefined);
    private _accessKey?;
    get accessKey(): boolean | cdktf.IResolvable;
    set accessKey(value: boolean | cdktf.IResolvable);
    resetAccessKey(): void;
    get accessKeyInput(): boolean | cdktf.IResolvable | undefined;
    private _email?;
    get email(): boolean | cdktf.IResolvable;
    set email(value: boolean | cdktf.IResolvable);
    resetEmail(): void;
    get emailInput(): boolean | cdktf.IResolvable | undefined;
    private _mobile?;
    get mobile(): boolean | cdktf.IResolvable;
    set mobile(value: boolean | cdktf.IResolvable);
    resetMobile(): void;
    get mobileInput(): boolean | cdktf.IResolvable | undefined;
    private _password?;
    get password(): boolean | cdktf.IResolvable;
    set password(value: boolean | cdktf.IResolvable);
    resetPassword(): void;
    get passwordInput(): boolean | cdktf.IResolvable | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protection_policy_v3 opentelekomcloud_identity_protection_policy_v3}
*/
export declare class IdentityProtectionPolicyV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_identity_protection_policy_v3";
    /**
    * Generates CDKTF code for importing a IdentityProtectionPolicyV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IdentityProtectionPolicyV3 to import
    * @param importFromId The id of the existing IdentityProtectionPolicyV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protection_policy_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IdentityProtectionPolicyV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protection_policy_v3 opentelekomcloud_identity_protection_policy_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IdentityProtectionPolicyV3Config = {}
    */
    constructor(scope: Construct, id: string, config?: IdentityProtectionPolicyV3Config);
    private _enableOperationProtectionPolicy?;
    get enableOperationProtectionPolicy(): boolean | cdktf.IResolvable;
    set enableOperationProtectionPolicy(value: boolean | cdktf.IResolvable);
    resetEnableOperationProtectionPolicy(): void;
    get enableOperationProtectionPolicyInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get selfVerification(): cdktf.IResolvable;
    private _verificationEmail?;
    get verificationEmail(): string;
    set verificationEmail(value: string);
    resetVerificationEmail(): void;
    get verificationEmailInput(): string | undefined;
    private _verificationMobile?;
    get verificationMobile(): string;
    set verificationMobile(value: string);
    resetVerificationMobile(): void;
    get verificationMobileInput(): string | undefined;
    private _selfManagement;
    get selfManagement(): IdentityProtectionPolicyV3SelfManagementOutputReference;
    putSelfManagement(value: IdentityProtectionPolicyV3SelfManagement): void;
    resetSelfManagement(): void;
    get selfManagementInput(): IdentityProtectionPolicyV3SelfManagement | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudTaurusdbMysqlErrorLogsV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_error_logs_v3#end_time DataOpentelekomcloudTaurusdbMysqlErrorLogsV3#end_time}
    */
    readonly endTime: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_error_logs_v3#id DataOpentelekomcloudTaurusdbMysqlErrorLogsV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_error_logs_v3#instance_id DataOpentelekomcloudTaurusdbMysqlErrorLogsV3#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_error_logs_v3#level DataOpentelekomcloudTaurusdbMysqlErrorLogsV3#level}
    */
    readonly level?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_error_logs_v3#node_id DataOpentelekomcloudTaurusdbMysqlErrorLogsV3#node_id}
    */
    readonly nodeId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_error_logs_v3#start_time DataOpentelekomcloudTaurusdbMysqlErrorLogsV3#start_time}
    */
    readonly startTime: string;
}
export interface DataOpentelekomcloudTaurusdbMysqlErrorLogsV3ErrorLogListStruct {
}
export declare function dataOpentelekomcloudTaurusdbMysqlErrorLogsV3ErrorLogListStructToTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlErrorLogsV3ErrorLogListStruct): any;
export declare function dataOpentelekomcloudTaurusdbMysqlErrorLogsV3ErrorLogListStructToHclTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlErrorLogsV3ErrorLogListStruct): any;
export declare class DataOpentelekomcloudTaurusdbMysqlErrorLogsV3ErrorLogListStructOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudTaurusdbMysqlErrorLogsV3ErrorLogListStruct | undefined;
    set internalValue(value: DataOpentelekomcloudTaurusdbMysqlErrorLogsV3ErrorLogListStruct | undefined);
    get content(): string;
    get level(): string;
    get nodeId(): string;
    get time(): string;
}
export declare class DataOpentelekomcloudTaurusdbMysqlErrorLogsV3ErrorLogListStructList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudTaurusdbMysqlErrorLogsV3ErrorLogListStructOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_error_logs_v3 opentelekomcloud_taurusdb_mysql_error_logs_v3}
*/
export declare class DataOpentelekomcloudTaurusdbMysqlErrorLogsV3 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_taurusdb_mysql_error_logs_v3";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudTaurusdbMysqlErrorLogsV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudTaurusdbMysqlErrorLogsV3 to import
    * @param importFromId The id of the existing DataOpentelekomcloudTaurusdbMysqlErrorLogsV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_error_logs_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudTaurusdbMysqlErrorLogsV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_error_logs_v3 opentelekomcloud_taurusdb_mysql_error_logs_v3} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudTaurusdbMysqlErrorLogsV3Config
    */
    constructor(scope: Construct, id: string, config: DataOpentelekomcloudTaurusdbMysqlErrorLogsV3Config);
    private _endTime?;
    get endTime(): string;
    set endTime(value: string);
    get endTimeInput(): string | undefined;
    private _errorLogList;
    get errorLogList(): DataOpentelekomcloudTaurusdbMysqlErrorLogsV3ErrorLogListStructList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _level?;
    get level(): string;
    set level(value: string);
    resetLevel(): void;
    get levelInput(): string | undefined;
    private _nodeId?;
    get nodeId(): string;
    set nodeId(value: string);
    get nodeIdInput(): string | undefined;
    get region(): string;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    get startTimeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

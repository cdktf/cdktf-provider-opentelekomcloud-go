/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ErStaticRouteV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/er_static_route_v3#attachment_id ErStaticRouteV3#attachment_id}
    */
    readonly attachmentId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/er_static_route_v3#destination ErStaticRouteV3#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/er_static_route_v3#id ErStaticRouteV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/er_static_route_v3#is_blackhole ErStaticRouteV3#is_blackhole}
    */
    readonly isBlackhole?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/er_static_route_v3#route_table_id ErStaticRouteV3#route_table_id}
    */
    readonly routeTableId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/er_static_route_v3#timeouts ErStaticRouteV3#timeouts}
    */
    readonly timeouts?: ErStaticRouteV3Timeouts;
}
export interface ErStaticRouteV3Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/er_static_route_v3#create ErStaticRouteV3#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/er_static_route_v3#delete ErStaticRouteV3#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/er_static_route_v3#update ErStaticRouteV3#update}
    */
    readonly update?: string;
}
export declare function erStaticRouteV3TimeoutsToTerraform(struct?: ErStaticRouteV3Timeouts | cdktf.IResolvable): any;
export declare function erStaticRouteV3TimeoutsToHclTerraform(struct?: ErStaticRouteV3Timeouts | cdktf.IResolvable): any;
export declare class ErStaticRouteV3TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ErStaticRouteV3Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: ErStaticRouteV3Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/er_static_route_v3 opentelekomcloud_er_static_route_v3}
*/
export declare class ErStaticRouteV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_er_static_route_v3";
    /**
    * Generates CDKTF code for importing a ErStaticRouteV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ErStaticRouteV3 to import
    * @param importFromId The id of the existing ErStaticRouteV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/er_static_route_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ErStaticRouteV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/er_static_route_v3 opentelekomcloud_er_static_route_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ErStaticRouteV3Config
    */
    constructor(scope: Construct, id: string, config: ErStaticRouteV3Config);
    private _attachmentId?;
    get attachmentId(): string;
    set attachmentId(value: string);
    resetAttachmentId(): void;
    get attachmentIdInput(): string | undefined;
    get createdAt(): string;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isBlackhole?;
    get isBlackhole(): boolean | cdktf.IResolvable;
    set isBlackhole(value: boolean | cdktf.IResolvable);
    resetIsBlackhole(): void;
    get isBlackholeInput(): boolean | cdktf.IResolvable | undefined;
    get region(): string;
    private _routeTableId?;
    get routeTableId(): string;
    set routeTableId(value: string);
    get routeTableIdInput(): string | undefined;
    get status(): string;
    get type(): string;
    get updatedAt(): string;
    private _timeouts;
    get timeouts(): ErStaticRouteV3TimeoutsOutputReference;
    putTimeouts(value: ErStaticRouteV3Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | ErStaticRouteV3Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

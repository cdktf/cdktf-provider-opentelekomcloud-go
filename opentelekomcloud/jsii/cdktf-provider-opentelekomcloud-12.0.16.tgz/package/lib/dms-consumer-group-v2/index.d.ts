/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DmsConsumerGroupV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_consumer_group_v2#description DmsConsumerGroupV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_consumer_group_v2#group_name DmsConsumerGroupV2#group_name}
    */
    readonly groupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_consumer_group_v2#id DmsConsumerGroupV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_consumer_group_v2#instance_id DmsConsumerGroupV2#instance_id}
    */
    readonly instanceId: string;
}
export interface DmsConsumerGroupV2GroupMessageOffsets {
}
export declare function dmsConsumerGroupV2GroupMessageOffsetsToTerraform(struct?: DmsConsumerGroupV2GroupMessageOffsets): any;
export declare function dmsConsumerGroupV2GroupMessageOffsetsToHclTerraform(struct?: DmsConsumerGroupV2GroupMessageOffsets): any;
export declare class DmsConsumerGroupV2GroupMessageOffsetsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DmsConsumerGroupV2GroupMessageOffsets | undefined;
    set internalValue(value: DmsConsumerGroupV2GroupMessageOffsets | undefined);
    get lag(): number;
    get messageCurrentOffset(): number;
    get messageLogEndOffset(): number;
    get partition(): number;
    get topic(): string;
}
export declare class DmsConsumerGroupV2GroupMessageOffsetsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DmsConsumerGroupV2GroupMessageOffsetsOutputReference;
}
export interface DmsConsumerGroupV2MembersAssignments {
}
export declare function dmsConsumerGroupV2MembersAssignmentsToTerraform(struct?: DmsConsumerGroupV2MembersAssignments): any;
export declare function dmsConsumerGroupV2MembersAssignmentsToHclTerraform(struct?: DmsConsumerGroupV2MembersAssignments): any;
export declare class DmsConsumerGroupV2MembersAssignmentsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DmsConsumerGroupV2MembersAssignments | undefined;
    set internalValue(value: DmsConsumerGroupV2MembersAssignments | undefined);
    get partitions(): number[];
    get topic(): string;
}
export declare class DmsConsumerGroupV2MembersAssignmentsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DmsConsumerGroupV2MembersAssignmentsOutputReference;
}
export interface DmsConsumerGroupV2Members {
}
export declare function dmsConsumerGroupV2MembersToTerraform(struct?: DmsConsumerGroupV2Members): any;
export declare function dmsConsumerGroupV2MembersToHclTerraform(struct?: DmsConsumerGroupV2Members): any;
export declare class DmsConsumerGroupV2MembersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DmsConsumerGroupV2Members | undefined;
    set internalValue(value: DmsConsumerGroupV2Members | undefined);
    private _assignments;
    get assignments(): DmsConsumerGroupV2MembersAssignmentsList;
    get clientId(): string;
    get host(): string;
    get memberId(): string;
}
export declare class DmsConsumerGroupV2MembersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DmsConsumerGroupV2MembersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_consumer_group_v2 opentelekomcloud_dms_consumer_group_v2}
*/
export declare class DmsConsumerGroupV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_dms_consumer_group_v2";
    /**
    * Generates CDKTF code for importing a DmsConsumerGroupV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DmsConsumerGroupV2 to import
    * @param importFromId The id of the existing DmsConsumerGroupV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_consumer_group_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DmsConsumerGroupV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_consumer_group_v2 opentelekomcloud_dms_consumer_group_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DmsConsumerGroupV2Config
    */
    constructor(scope: Construct, id: string, config: DmsConsumerGroupV2Config);
    get assignmentStrategy(): string;
    get coordinatorId(): number;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _groupMessageOffsets;
    get groupMessageOffsets(): DmsConsumerGroupV2GroupMessageOffsetsList;
    private _groupName?;
    get groupName(): string;
    set groupName(value: string);
    get groupNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _members;
    get members(): DmsConsumerGroupV2MembersList;
    get region(): string;
    get state(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

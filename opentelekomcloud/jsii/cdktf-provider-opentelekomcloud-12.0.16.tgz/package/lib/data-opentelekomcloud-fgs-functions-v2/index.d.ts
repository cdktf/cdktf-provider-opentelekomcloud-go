/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudFgsFunctionsV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/fgs_functions_v2#enterprise_project_id DataOpentelekomcloudFgsFunctionsV2#enterprise_project_id}
    */
    readonly enterpriseProjectId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/fgs_functions_v2#id DataOpentelekomcloudFgsFunctionsV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/fgs_functions_v2#name DataOpentelekomcloudFgsFunctionsV2#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/fgs_functions_v2#package_name DataOpentelekomcloudFgsFunctionsV2#package_name}
    */
    readonly packageName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/fgs_functions_v2#runtime DataOpentelekomcloudFgsFunctionsV2#runtime}
    */
    readonly runtime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/fgs_functions_v2#urn DataOpentelekomcloudFgsFunctionsV2#urn}
    */
    readonly urn?: string;
}
export interface DataOpentelekomcloudFgsFunctionsV2Functions {
}
export declare function dataOpentelekomcloudFgsFunctionsV2FunctionsToTerraform(struct?: DataOpentelekomcloudFgsFunctionsV2Functions): any;
export declare function dataOpentelekomcloudFgsFunctionsV2FunctionsToHclTerraform(struct?: DataOpentelekomcloudFgsFunctionsV2Functions): any;
export declare class DataOpentelekomcloudFgsFunctionsV2FunctionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudFgsFunctionsV2Functions | undefined;
    set internalValue(value: DataOpentelekomcloudFgsFunctionsV2Functions | undefined);
    get appAgency(): string;
    get codeFilename(): string;
    get codeType(): string;
    get codeUrl(): string;
    get description(): string;
    get encryptedUserData(): string;
    get enterpriseProjectId(): string;
    get functiongraphVersion(): string;
    get handler(): string;
    get initializerHandler(): string;
    get initializerTimeout(): number;
    get logGroupId(): string;
    get logStreamId(): string;
    get maxInstanceNum(): number;
    get memorySize(): number;
    get name(): string;
    get networkId(): string;
    get package(): string;
    get runtime(): string;
    get timeout(): number;
    get urn(): string;
    get userData(): string;
    get version(): string;
    get vpcId(): string;
}
export declare class DataOpentelekomcloudFgsFunctionsV2FunctionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudFgsFunctionsV2FunctionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/fgs_functions_v2 opentelekomcloud_fgs_functions_v2}
*/
export declare class DataOpentelekomcloudFgsFunctionsV2 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_fgs_functions_v2";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudFgsFunctionsV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudFgsFunctionsV2 to import
    * @param importFromId The id of the existing DataOpentelekomcloudFgsFunctionsV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/fgs_functions_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudFgsFunctionsV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/fgs_functions_v2 opentelekomcloud_fgs_functions_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudFgsFunctionsV2Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudFgsFunctionsV2Config);
    private _enterpriseProjectId?;
    get enterpriseProjectId(): string;
    set enterpriseProjectId(value: string);
    resetEnterpriseProjectId(): void;
    get enterpriseProjectIdInput(): string | undefined;
    private _functions;
    get functions(): DataOpentelekomcloudFgsFunctionsV2FunctionsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _packageName?;
    get packageName(): string;
    set packageName(value: string);
    resetPackageName(): void;
    get packageNameInput(): string | undefined;
    get region(): string;
    private _runtime?;
    get runtime(): string;
    set runtime(value: string);
    resetRuntime(): void;
    get runtimeInput(): string | undefined;
    private _urn?;
    get urn(): string;
    set urn(value: string);
    resetUrn(): void;
    get urnInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

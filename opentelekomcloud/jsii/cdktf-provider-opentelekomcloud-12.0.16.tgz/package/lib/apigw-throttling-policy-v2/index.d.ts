/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ApigwThrottlingPolicyV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_throttling_policy_v2#description ApigwThrottlingPolicyV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_throttling_policy_v2#id ApigwThrottlingPolicyV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_throttling_policy_v2#instance_id ApigwThrottlingPolicyV2#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_throttling_policy_v2#max_api_requests ApigwThrottlingPolicyV2#max_api_requests}
    */
    readonly maxApiRequests: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_throttling_policy_v2#max_app_requests ApigwThrottlingPolicyV2#max_app_requests}
    */
    readonly maxAppRequests?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_throttling_policy_v2#max_ip_requests ApigwThrottlingPolicyV2#max_ip_requests}
    */
    readonly maxIpRequests?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_throttling_policy_v2#max_user_requests ApigwThrottlingPolicyV2#max_user_requests}
    */
    readonly maxUserRequests?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_throttling_policy_v2#name ApigwThrottlingPolicyV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_throttling_policy_v2#period ApigwThrottlingPolicyV2#period}
    */
    readonly period: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_throttling_policy_v2#period_unit ApigwThrottlingPolicyV2#period_unit}
    */
    readonly periodUnit?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_throttling_policy_v2#type ApigwThrottlingPolicyV2#type}
    */
    readonly type?: string;
    /**
    * app_throttles block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_throttling_policy_v2#app_throttles ApigwThrottlingPolicyV2#app_throttles}
    */
    readonly appThrottles?: ApigwThrottlingPolicyV2AppThrottles[] | cdktf.IResolvable;
    /**
    * user_throttles block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_throttling_policy_v2#user_throttles ApigwThrottlingPolicyV2#user_throttles}
    */
    readonly userThrottles?: ApigwThrottlingPolicyV2UserThrottles[] | cdktf.IResolvable;
}
export interface ApigwThrottlingPolicyV2AppThrottles {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_throttling_policy_v2#max_api_requests ApigwThrottlingPolicyV2#max_api_requests}
    */
    readonly maxApiRequests: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_throttling_policy_v2#throttling_object_id ApigwThrottlingPolicyV2#throttling_object_id}
    */
    readonly throttlingObjectId: string;
}
export declare function apigwThrottlingPolicyV2AppThrottlesToTerraform(struct?: ApigwThrottlingPolicyV2AppThrottles | cdktf.IResolvable): any;
export declare function apigwThrottlingPolicyV2AppThrottlesToHclTerraform(struct?: ApigwThrottlingPolicyV2AppThrottles | cdktf.IResolvable): any;
export declare class ApigwThrottlingPolicyV2AppThrottlesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigwThrottlingPolicyV2AppThrottles | cdktf.IResolvable | undefined;
    set internalValue(value: ApigwThrottlingPolicyV2AppThrottles | cdktf.IResolvable | undefined);
    get id(): string;
    private _maxApiRequests?;
    get maxApiRequests(): number;
    set maxApiRequests(value: number);
    get maxApiRequestsInput(): number | undefined;
    private _throttlingObjectId?;
    get throttlingObjectId(): string;
    set throttlingObjectId(value: string);
    get throttlingObjectIdInput(): string | undefined;
    get throttlingObjectName(): string;
}
export declare class ApigwThrottlingPolicyV2AppThrottlesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ApigwThrottlingPolicyV2AppThrottles[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigwThrottlingPolicyV2AppThrottlesOutputReference;
}
export interface ApigwThrottlingPolicyV2UserThrottles {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_throttling_policy_v2#max_api_requests ApigwThrottlingPolicyV2#max_api_requests}
    */
    readonly maxApiRequests: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_throttling_policy_v2#throttling_object_id ApigwThrottlingPolicyV2#throttling_object_id}
    */
    readonly throttlingObjectId: string;
}
export declare function apigwThrottlingPolicyV2UserThrottlesToTerraform(struct?: ApigwThrottlingPolicyV2UserThrottles | cdktf.IResolvable): any;
export declare function apigwThrottlingPolicyV2UserThrottlesToHclTerraform(struct?: ApigwThrottlingPolicyV2UserThrottles | cdktf.IResolvable): any;
export declare class ApigwThrottlingPolicyV2UserThrottlesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigwThrottlingPolicyV2UserThrottles | cdktf.IResolvable | undefined;
    set internalValue(value: ApigwThrottlingPolicyV2UserThrottles | cdktf.IResolvable | undefined);
    get id(): string;
    private _maxApiRequests?;
    get maxApiRequests(): number;
    set maxApiRequests(value: number);
    get maxApiRequestsInput(): number | undefined;
    private _throttlingObjectId?;
    get throttlingObjectId(): string;
    set throttlingObjectId(value: string);
    get throttlingObjectIdInput(): string | undefined;
    get throttlingObjectName(): string;
}
export declare class ApigwThrottlingPolicyV2UserThrottlesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ApigwThrottlingPolicyV2UserThrottles[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigwThrottlingPolicyV2UserThrottlesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_throttling_policy_v2 opentelekomcloud_apigw_throttling_policy_v2}
*/
export declare class ApigwThrottlingPolicyV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_apigw_throttling_policy_v2";
    /**
    * Generates CDKTF code for importing a ApigwThrottlingPolicyV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigwThrottlingPolicyV2 to import
    * @param importFromId The id of the existing ApigwThrottlingPolicyV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_throttling_policy_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigwThrottlingPolicyV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_throttling_policy_v2 opentelekomcloud_apigw_throttling_policy_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigwThrottlingPolicyV2Config
    */
    constructor(scope: Construct, id: string, config: ApigwThrottlingPolicyV2Config);
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _maxApiRequests?;
    get maxApiRequests(): number;
    set maxApiRequests(value: number);
    get maxApiRequestsInput(): number | undefined;
    private _maxAppRequests?;
    get maxAppRequests(): number;
    set maxAppRequests(value: number);
    resetMaxAppRequests(): void;
    get maxAppRequestsInput(): number | undefined;
    private _maxIpRequests?;
    get maxIpRequests(): number;
    set maxIpRequests(value: number);
    resetMaxIpRequests(): void;
    get maxIpRequestsInput(): number | undefined;
    private _maxUserRequests?;
    get maxUserRequests(): number;
    set maxUserRequests(value: number);
    resetMaxUserRequests(): void;
    get maxUserRequestsInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _period?;
    get period(): number;
    set period(value: number);
    get periodInput(): number | undefined;
    private _periodUnit?;
    get periodUnit(): string;
    set periodUnit(value: string);
    resetPeriodUnit(): void;
    get periodUnitInput(): string | undefined;
    get region(): string;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _appThrottles;
    get appThrottles(): ApigwThrottlingPolicyV2AppThrottlesList;
    putAppThrottles(value: ApigwThrottlingPolicyV2AppThrottles[] | cdktf.IResolvable): void;
    resetAppThrottles(): void;
    get appThrottlesInput(): cdktf.IResolvable | ApigwThrottlingPolicyV2AppThrottles[] | undefined;
    private _userThrottles;
    get userThrottles(): ApigwThrottlingPolicyV2UserThrottlesList;
    putUserThrottles(value: ApigwThrottlingPolicyV2UserThrottles[] | cdktf.IResolvable): void;
    resetUserThrottles(): void;
    get userThrottlesInput(): cdktf.IResolvable | ApigwThrottlingPolicyV2UserThrottles[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

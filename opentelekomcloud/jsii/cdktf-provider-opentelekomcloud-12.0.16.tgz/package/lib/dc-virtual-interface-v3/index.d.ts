/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DcVirtualInterfaceV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v3#address_family DcVirtualInterfaceV3#address_family}
    */
    readonly addressFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v3#asn DcVirtualInterfaceV3#asn}
    */
    readonly asn?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v3#bandwidth DcVirtualInterfaceV3#bandwidth}
    */
    readonly bandwidth: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v3#bgp_md5 DcVirtualInterfaceV3#bgp_md5}
    */
    readonly bgpMd5?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v3#description DcVirtualInterfaceV3#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v3#direct_connect_id DcVirtualInterfaceV3#direct_connect_id}
    */
    readonly directConnectId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v3#enable_bfd DcVirtualInterfaceV3#enable_bfd}
    */
    readonly enableBfd?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v3#enable_nqa DcVirtualInterfaceV3#enable_nqa}
    */
    readonly enableNqa?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v3#id DcVirtualInterfaceV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v3#lag_id DcVirtualInterfaceV3#lag_id}
    */
    readonly lagId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v3#local_gateway_v4_ip DcVirtualInterfaceV3#local_gateway_v4_ip}
    */
    readonly localGatewayV4Ip?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v3#local_gateway_v6_ip DcVirtualInterfaceV3#local_gateway_v6_ip}
    */
    readonly localGatewayV6Ip?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v3#name DcVirtualInterfaceV3#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v3#remote_ep_group DcVirtualInterfaceV3#remote_ep_group}
    */
    readonly remoteEpGroup: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v3#remote_gateway_v4_ip DcVirtualInterfaceV3#remote_gateway_v4_ip}
    */
    readonly remoteGatewayV4Ip?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v3#remote_gateway_v6_ip DcVirtualInterfaceV3#remote_gateway_v6_ip}
    */
    readonly remoteGatewayV6Ip?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v3#resource_tenant_id DcVirtualInterfaceV3#resource_tenant_id}
    */
    readonly resourceTenantId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v3#route_mode DcVirtualInterfaceV3#route_mode}
    */
    readonly routeMode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v3#service_ep_group DcVirtualInterfaceV3#service_ep_group}
    */
    readonly serviceEpGroup?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v3#type DcVirtualInterfaceV3#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v3#vgw_id DcVirtualInterfaceV3#vgw_id}
    */
    readonly vgwId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v3#vlan DcVirtualInterfaceV3#vlan}
    */
    readonly vlan: number;
}
export interface DcVirtualInterfaceV3VifPeers {
}
export declare function dcVirtualInterfaceV3VifPeersToTerraform(struct?: DcVirtualInterfaceV3VifPeers): any;
export declare function dcVirtualInterfaceV3VifPeersToHclTerraform(struct?: DcVirtualInterfaceV3VifPeers): any;
export declare class DcVirtualInterfaceV3VifPeersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DcVirtualInterfaceV3VifPeers | undefined;
    set internalValue(value: DcVirtualInterfaceV3VifPeers | undefined);
    get addressFamily(): string;
    get bgpAsn(): number;
    get bgpMd5(): string;
    get bgpRouteLimit(): number;
    get bgpStatus(): string;
    get description(): string;
    get deviceId(): string;
    get enableBfd(): cdktf.IResolvable;
    get enableNqa(): cdktf.IResolvable;
    get id(): string;
    get localGatewayIp(): string;
    get name(): string;
    get receiveRouteNum(): number;
    get remoteEpGroup(): string[];
    get remoteGatewayIp(): string;
    get routeMode(): string;
    get serviceEpGroup(): string[];
    get status(): string;
    get tenantId(): string;
    get vifId(): string;
}
export declare class DcVirtualInterfaceV3VifPeersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DcVirtualInterfaceV3VifPeersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v3 opentelekomcloud_dc_virtual_interface_v3}
*/
export declare class DcVirtualInterfaceV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_dc_virtual_interface_v3";
    /**
    * Generates CDKTF code for importing a DcVirtualInterfaceV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DcVirtualInterfaceV3 to import
    * @param importFromId The id of the existing DcVirtualInterfaceV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DcVirtualInterfaceV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v3 opentelekomcloud_dc_virtual_interface_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DcVirtualInterfaceV3Config
    */
    constructor(scope: Construct, id: string, config: DcVirtualInterfaceV3Config);
    private _addressFamily?;
    get addressFamily(): string;
    set addressFamily(value: string);
    resetAddressFamily(): void;
    get addressFamilyInput(): string | undefined;
    private _asn?;
    get asn(): number;
    set asn(value: number);
    resetAsn(): void;
    get asnInput(): number | undefined;
    private _bandwidth?;
    get bandwidth(): number;
    set bandwidth(value: number);
    get bandwidthInput(): number | undefined;
    private _bgpMd5?;
    get bgpMd5(): string;
    set bgpMd5(value: string);
    resetBgpMd5(): void;
    get bgpMd5Input(): string | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get deviceId(): string;
    private _directConnectId?;
    get directConnectId(): string;
    set directConnectId(value: string);
    get directConnectIdInput(): string | undefined;
    private _enableBfd?;
    get enableBfd(): boolean | cdktf.IResolvable;
    set enableBfd(value: boolean | cdktf.IResolvable);
    resetEnableBfd(): void;
    get enableBfdInput(): boolean | cdktf.IResolvable | undefined;
    private _enableNqa?;
    get enableNqa(): boolean | cdktf.IResolvable;
    set enableNqa(value: boolean | cdktf.IResolvable);
    resetEnableNqa(): void;
    get enableNqaInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _lagId?;
    get lagId(): string;
    set lagId(value: string);
    resetLagId(): void;
    get lagIdInput(): string | undefined;
    private _localGatewayV4Ip?;
    get localGatewayV4Ip(): string;
    set localGatewayV4Ip(value: string);
    resetLocalGatewayV4Ip(): void;
    get localGatewayV4IpInput(): string | undefined;
    private _localGatewayV6Ip?;
    get localGatewayV6Ip(): string;
    set localGatewayV6Ip(value: string);
    resetLocalGatewayV6Ip(): void;
    get localGatewayV6IpInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get region(): string;
    private _remoteEpGroup?;
    get remoteEpGroup(): string[];
    set remoteEpGroup(value: string[]);
    get remoteEpGroupInput(): string[] | undefined;
    private _remoteGatewayV4Ip?;
    get remoteGatewayV4Ip(): string;
    set remoteGatewayV4Ip(value: string);
    resetRemoteGatewayV4Ip(): void;
    get remoteGatewayV4IpInput(): string | undefined;
    private _remoteGatewayV6Ip?;
    get remoteGatewayV6Ip(): string;
    set remoteGatewayV6Ip(value: string);
    resetRemoteGatewayV6Ip(): void;
    get remoteGatewayV6IpInput(): string | undefined;
    private _resourceTenantId?;
    get resourceTenantId(): string;
    set resourceTenantId(value: string);
    resetResourceTenantId(): void;
    get resourceTenantIdInput(): string | undefined;
    private _routeMode?;
    get routeMode(): string;
    set routeMode(value: string);
    get routeModeInput(): string | undefined;
    private _serviceEpGroup?;
    get serviceEpGroup(): string[];
    set serviceEpGroup(value: string[]);
    resetServiceEpGroup(): void;
    get serviceEpGroupInput(): string[] | undefined;
    get status(): string;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    get updatedAt(): string;
    private _vgwId?;
    get vgwId(): string;
    set vgwId(value: string);
    get vgwIdInput(): string | undefined;
    private _vifPeers;
    get vifPeers(): DcVirtualInterfaceV3VifPeersList;
    private _vlan?;
    get vlan(): number;
    set vlan(value: number);
    get vlanInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

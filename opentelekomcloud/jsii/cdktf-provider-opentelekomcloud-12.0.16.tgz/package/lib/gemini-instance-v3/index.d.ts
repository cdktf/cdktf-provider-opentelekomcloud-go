/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface GeminiInstanceV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gemini_instance_v3#availability_zone GeminiInstanceV3#availability_zone}
    */
    readonly availabilityZone: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gemini_instance_v3#configuration_id GeminiInstanceV3#configuration_id}
    */
    readonly configurationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gemini_instance_v3#flavor GeminiInstanceV3#flavor}
    */
    readonly flavor: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gemini_instance_v3#id GeminiInstanceV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gemini_instance_v3#name GeminiInstanceV3#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gemini_instance_v3#node_num GeminiInstanceV3#node_num}
    */
    readonly nodeNum?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gemini_instance_v3#password GeminiInstanceV3#password}
    */
    readonly password: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gemini_instance_v3#period GeminiInstanceV3#period}
    */
    readonly period?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gemini_instance_v3#security_group_id GeminiInstanceV3#security_group_id}
    */
    readonly securityGroupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gemini_instance_v3#ssl GeminiInstanceV3#ssl}
    */
    readonly ssl?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gemini_instance_v3#subnet_id GeminiInstanceV3#subnet_id}
    */
    readonly subnetId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gemini_instance_v3#tags GeminiInstanceV3#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gemini_instance_v3#volume_size GeminiInstanceV3#volume_size}
    */
    readonly volumeSize: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gemini_instance_v3#vpc_id GeminiInstanceV3#vpc_id}
    */
    readonly vpcId: string;
    /**
    * backup_strategy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gemini_instance_v3#backup_strategy GeminiInstanceV3#backup_strategy}
    */
    readonly backupStrategy?: GeminiInstanceV3BackupStrategy;
    /**
    * datastore block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gemini_instance_v3#datastore GeminiInstanceV3#datastore}
    */
    readonly datastore?: GeminiInstanceV3Datastore;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gemini_instance_v3#timeouts GeminiInstanceV3#timeouts}
    */
    readonly timeouts?: GeminiInstanceV3Timeouts;
}
export interface GeminiInstanceV3Nodes {
}
export declare function geminiInstanceV3NodesToTerraform(struct?: GeminiInstanceV3Nodes): any;
export declare function geminiInstanceV3NodesToHclTerraform(struct?: GeminiInstanceV3Nodes): any;
export declare class GeminiInstanceV3NodesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GeminiInstanceV3Nodes | undefined;
    set internalValue(value: GeminiInstanceV3Nodes | undefined);
    get id(): string;
    get name(): string;
    get privateIp(): string;
    get status(): string;
    get supportReduce(): cdktf.IResolvable;
}
export declare class GeminiInstanceV3NodesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GeminiInstanceV3NodesOutputReference;
}
export interface GeminiInstanceV3BackupStrategy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gemini_instance_v3#keep_days GeminiInstanceV3#keep_days}
    */
    readonly keepDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gemini_instance_v3#start_time GeminiInstanceV3#start_time}
    */
    readonly startTime: string;
}
export declare function geminiInstanceV3BackupStrategyToTerraform(struct?: GeminiInstanceV3BackupStrategyOutputReference | GeminiInstanceV3BackupStrategy): any;
export declare function geminiInstanceV3BackupStrategyToHclTerraform(struct?: GeminiInstanceV3BackupStrategyOutputReference | GeminiInstanceV3BackupStrategy): any;
export declare class GeminiInstanceV3BackupStrategyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GeminiInstanceV3BackupStrategy | undefined;
    set internalValue(value: GeminiInstanceV3BackupStrategy | undefined);
    private _keepDays?;
    get keepDays(): number;
    set keepDays(value: number);
    resetKeepDays(): void;
    get keepDaysInput(): number | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    get startTimeInput(): string | undefined;
}
export interface GeminiInstanceV3Datastore {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gemini_instance_v3#engine GeminiInstanceV3#engine}
    */
    readonly engine: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gemini_instance_v3#storage_engine GeminiInstanceV3#storage_engine}
    */
    readonly storageEngine: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gemini_instance_v3#version GeminiInstanceV3#version}
    */
    readonly version: string;
}
export declare function geminiInstanceV3DatastoreToTerraform(struct?: GeminiInstanceV3DatastoreOutputReference | GeminiInstanceV3Datastore): any;
export declare function geminiInstanceV3DatastoreToHclTerraform(struct?: GeminiInstanceV3DatastoreOutputReference | GeminiInstanceV3Datastore): any;
export declare class GeminiInstanceV3DatastoreOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GeminiInstanceV3Datastore | undefined;
    set internalValue(value: GeminiInstanceV3Datastore | undefined);
    private _engine?;
    get engine(): string;
    set engine(value: string);
    get engineInput(): string | undefined;
    private _storageEngine?;
    get storageEngine(): string;
    set storageEngine(value: string);
    get storageEngineInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
}
export interface GeminiInstanceV3Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gemini_instance_v3#create GeminiInstanceV3#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gemini_instance_v3#delete GeminiInstanceV3#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gemini_instance_v3#update GeminiInstanceV3#update}
    */
    readonly update?: string;
}
export declare function geminiInstanceV3TimeoutsToTerraform(struct?: GeminiInstanceV3Timeouts | cdktf.IResolvable): any;
export declare function geminiInstanceV3TimeoutsToHclTerraform(struct?: GeminiInstanceV3Timeouts | cdktf.IResolvable): any;
export declare class GeminiInstanceV3TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GeminiInstanceV3Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: GeminiInstanceV3Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gemini_instance_v3 opentelekomcloud_gemini_instance_v3}
*/
export declare class GeminiInstanceV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_gemini_instance_v3";
    /**
    * Generates CDKTF code for importing a GeminiInstanceV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GeminiInstanceV3 to import
    * @param importFromId The id of the existing GeminiInstanceV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gemini_instance_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GeminiInstanceV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/gemini_instance_v3 opentelekomcloud_gemini_instance_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GeminiInstanceV3Config
    */
    constructor(scope: Construct, id: string, config: GeminiInstanceV3Config);
    private _availabilityZone?;
    get availabilityZone(): string;
    set availabilityZone(value: string);
    get availabilityZoneInput(): string | undefined;
    private _configurationId?;
    get configurationId(): string;
    set configurationId(value: string);
    resetConfigurationId(): void;
    get configurationIdInput(): string | undefined;
    get dbUserName(): string;
    private _flavor?;
    get flavor(): string;
    set flavor(value: string);
    get flavorInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get mode(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _nodeNum?;
    get nodeNum(): number;
    set nodeNum(value: number);
    resetNodeNum(): void;
    get nodeNumInput(): number | undefined;
    private _nodes;
    get nodes(): GeminiInstanceV3NodesList;
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    private _period?;
    get period(): number;
    set period(value: number);
    resetPeriod(): void;
    get periodInput(): number | undefined;
    get port(): number;
    get privateIps(): string[];
    get region(): string;
    private _securityGroupId?;
    get securityGroupId(): string;
    set securityGroupId(value: string);
    resetSecurityGroupId(): void;
    get securityGroupIdInput(): string | undefined;
    private _ssl?;
    get ssl(): boolean | cdktf.IResolvable;
    set ssl(value: boolean | cdktf.IResolvable);
    resetSsl(): void;
    get sslInput(): boolean | cdktf.IResolvable | undefined;
    get status(): string;
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    get subnetIdInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _volumeSize?;
    get volumeSize(): number;
    set volumeSize(value: number);
    get volumeSizeInput(): number | undefined;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    get vpcIdInput(): string | undefined;
    private _backupStrategy;
    get backupStrategy(): GeminiInstanceV3BackupStrategyOutputReference;
    putBackupStrategy(value: GeminiInstanceV3BackupStrategy): void;
    resetBackupStrategy(): void;
    get backupStrategyInput(): GeminiInstanceV3BackupStrategy | undefined;
    private _datastore;
    get datastore(): GeminiInstanceV3DatastoreOutputReference;
    putDatastore(value: GeminiInstanceV3Datastore): void;
    resetDatastore(): void;
    get datastoreInput(): GeminiInstanceV3Datastore | undefined;
    private _timeouts;
    get timeouts(): GeminiInstanceV3TimeoutsOutputReference;
    putTimeouts(value: GeminiInstanceV3Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | GeminiInstanceV3Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

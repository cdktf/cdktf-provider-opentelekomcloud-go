/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DmsInstanceV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2#access_user DmsInstanceV2#access_user}
    */
    readonly accessUser?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2#available_zones DmsInstanceV2#available_zones}
    */
    readonly availableZones: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2#description DmsInstanceV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2#disk_encrypted_enable DmsInstanceV2#disk_encrypted_enable}
    */
    readonly diskEncryptedEnable?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2#disk_encrypted_key DmsInstanceV2#disk_encrypted_key}
    */
    readonly diskEncryptedKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2#enable_publicip DmsInstanceV2#enable_publicip}
    */
    readonly enablePublicip?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2#engine DmsInstanceV2#engine}
    */
    readonly engine: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2#engine_version DmsInstanceV2#engine_version}
    */
    readonly engineVersion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2#id DmsInstanceV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2#maintain_begin DmsInstanceV2#maintain_begin}
    */
    readonly maintainBegin?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2#maintain_end DmsInstanceV2#maintain_end}
    */
    readonly maintainEnd?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2#name DmsInstanceV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2#partition_num DmsInstanceV2#partition_num}
    */
    readonly partitionNum?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2#password DmsInstanceV2#password}
    */
    readonly password?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2#product_id DmsInstanceV2#product_id}
    */
    readonly productId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2#public_bandwidth DmsInstanceV2#public_bandwidth}
    */
    readonly publicBandwidth?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2#publicip_id DmsInstanceV2#publicip_id}
    */
    readonly publicipId?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2#retention_policy DmsInstanceV2#retention_policy}
    */
    readonly retentionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2#security_group_id DmsInstanceV2#security_group_id}
    */
    readonly securityGroupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2#specification DmsInstanceV2#specification}
    */
    readonly specification?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2#storage_space DmsInstanceV2#storage_space}
    */
    readonly storageSpace: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2#storage_spec_code DmsInstanceV2#storage_spec_code}
    */
    readonly storageSpecCode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2#subnet_id DmsInstanceV2#subnet_id}
    */
    readonly subnetId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2#tags DmsInstanceV2#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2#vpc_id DmsInstanceV2#vpc_id}
    */
    readonly vpcId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2#timeouts DmsInstanceV2#timeouts}
    */
    readonly timeouts?: DmsInstanceV2Timeouts;
}
export interface DmsInstanceV2Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2#create DmsInstanceV2#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2#delete DmsInstanceV2#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2#update DmsInstanceV2#update}
    */
    readonly update?: string;
}
export declare function dmsInstanceV2TimeoutsToTerraform(struct?: DmsInstanceV2Timeouts | cdktf.IResolvable): any;
export declare function dmsInstanceV2TimeoutsToHclTerraform(struct?: DmsInstanceV2Timeouts | cdktf.IResolvable): any;
export declare class DmsInstanceV2TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DmsInstanceV2Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DmsInstanceV2Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2 opentelekomcloud_dms_instance_v2}
*/
export declare class DmsInstanceV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_dms_instance_v2";
    /**
    * Generates CDKTF code for importing a DmsInstanceV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DmsInstanceV2 to import
    * @param importFromId The id of the existing DmsInstanceV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DmsInstanceV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_instance_v2 opentelekomcloud_dms_instance_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DmsInstanceV2Config
    */
    constructor(scope: Construct, id: string, config: DmsInstanceV2Config);
    private _accessUser?;
    get accessUser(): string;
    set accessUser(value: string);
    resetAccessUser(): void;
    get accessUserInput(): string | undefined;
    private _availableZones?;
    get availableZones(): string[];
    set availableZones(value: string[]);
    get availableZonesInput(): string[] | undefined;
    get connectAddress(): string;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _diskEncryptedEnable?;
    get diskEncryptedEnable(): boolean | cdktf.IResolvable;
    set diskEncryptedEnable(value: boolean | cdktf.IResolvable);
    resetDiskEncryptedEnable(): void;
    get diskEncryptedEnableInput(): boolean | cdktf.IResolvable | undefined;
    private _diskEncryptedKey?;
    get diskEncryptedKey(): string;
    set diskEncryptedKey(value: string);
    resetDiskEncryptedKey(): void;
    get diskEncryptedKeyInput(): string | undefined;
    private _enablePublicip?;
    get enablePublicip(): boolean | cdktf.IResolvable;
    set enablePublicip(value: boolean | cdktf.IResolvable);
    resetEnablePublicip(): void;
    get enablePublicipInput(): boolean | cdktf.IResolvable | undefined;
    private _engine?;
    get engine(): string;
    set engine(value: string);
    get engineInput(): string | undefined;
    private _engineVersion?;
    get engineVersion(): string;
    set engineVersion(value: string);
    get engineVersionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maintainBegin?;
    get maintainBegin(): string;
    set maintainBegin(value: string);
    resetMaintainBegin(): void;
    get maintainBeginInput(): string | undefined;
    private _maintainEnd?;
    get maintainEnd(): string;
    set maintainEnd(value: string);
    resetMaintainEnd(): void;
    get maintainEndInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get nodeNum(): number;
    private _partitionNum?;
    get partitionNum(): number;
    set partitionNum(value: number);
    resetPartitionNum(): void;
    get partitionNumInput(): number | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    get port(): number;
    private _productId?;
    get productId(): string;
    set productId(value: string);
    get productIdInput(): string | undefined;
    get publicAccessEnabled(): string;
    private _publicBandwidth?;
    get publicBandwidth(): number;
    set publicBandwidth(value: number);
    resetPublicBandwidth(): void;
    get publicBandwidthInput(): number | undefined;
    get publicConnectAddress(): string[];
    private _publicipId?;
    get publicipId(): string[];
    set publicipId(value: string[]);
    resetPublicipId(): void;
    get publicipIdInput(): string[] | undefined;
    get resourceSpecCode(): string;
    private _retentionPolicy?;
    get retentionPolicy(): string;
    set retentionPolicy(value: string);
    resetRetentionPolicy(): void;
    get retentionPolicyInput(): string | undefined;
    private _securityGroupId?;
    get securityGroupId(): string;
    set securityGroupId(value: string);
    get securityGroupIdInput(): string | undefined;
    get securityGroupName(): string;
    private _specification?;
    get specification(): string;
    set specification(value: string);
    resetSpecification(): void;
    get specificationInput(): string | undefined;
    get sslEnable(): cdktf.IResolvable;
    get status(): string;
    get storageResourceId(): string;
    private _storageSpace?;
    get storageSpace(): number;
    set storageSpace(value: number);
    get storageSpaceInput(): number | undefined;
    private _storageSpecCode?;
    get storageSpecCode(): string;
    set storageSpecCode(value: string);
    get storageSpecCodeInput(): string | undefined;
    get subnetCidr(): string;
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    get subnetIdInput(): string | undefined;
    get subnetName(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get totalStorageSpace(): number;
    get type(): string;
    get usedStorageSpace(): number;
    get userId(): string;
    get userName(): string;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    get vpcIdInput(): string | undefined;
    get vpcName(): string;
    private _timeouts;
    get timeouts(): DmsInstanceV2TimeoutsOutputReference;
    putTimeouts(value: DmsInstanceV2Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DmsInstanceV2Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

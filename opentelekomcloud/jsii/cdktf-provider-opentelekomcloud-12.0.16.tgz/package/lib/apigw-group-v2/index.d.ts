/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ApigwGroupV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_group_v2#description ApigwGroupV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_group_v2#id ApigwGroupV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_group_v2#instance_id ApigwGroupV2#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_group_v2#name ApigwGroupV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_group_v2#region ApigwGroupV2#region}
    */
    readonly region?: string;
    /**
    * environment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_group_v2#environment ApigwGroupV2#environment}
    */
    readonly environment?: ApigwGroupV2Environment[] | cdktf.IResolvable;
}
export interface ApigwGroupV2EnvironmentVariable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_group_v2#name ApigwGroupV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_group_v2#value ApigwGroupV2#value}
    */
    readonly value: string;
}
export declare function apigwGroupV2EnvironmentVariableToTerraform(struct?: ApigwGroupV2EnvironmentVariable | cdktf.IResolvable): any;
export declare function apigwGroupV2EnvironmentVariableToHclTerraform(struct?: ApigwGroupV2EnvironmentVariable | cdktf.IResolvable): any;
export declare class ApigwGroupV2EnvironmentVariableOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigwGroupV2EnvironmentVariable | cdktf.IResolvable | undefined;
    set internalValue(value: ApigwGroupV2EnvironmentVariable | cdktf.IResolvable | undefined);
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ApigwGroupV2EnvironmentVariableList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ApigwGroupV2EnvironmentVariable[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigwGroupV2EnvironmentVariableOutputReference;
}
export interface ApigwGroupV2Environment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_group_v2#environment_id ApigwGroupV2#environment_id}
    */
    readonly environmentId: string;
    /**
    * variable block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_group_v2#variable ApigwGroupV2#variable}
    */
    readonly variable: ApigwGroupV2EnvironmentVariable[] | cdktf.IResolvable;
}
export declare function apigwGroupV2EnvironmentToTerraform(struct?: ApigwGroupV2Environment | cdktf.IResolvable): any;
export declare function apigwGroupV2EnvironmentToHclTerraform(struct?: ApigwGroupV2Environment | cdktf.IResolvable): any;
export declare class ApigwGroupV2EnvironmentOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigwGroupV2Environment | cdktf.IResolvable | undefined;
    set internalValue(value: ApigwGroupV2Environment | cdktf.IResolvable | undefined);
    private _environmentId?;
    get environmentId(): string;
    set environmentId(value: string);
    get environmentIdInput(): string | undefined;
    private _variable;
    get variable(): ApigwGroupV2EnvironmentVariableList;
    putVariable(value: ApigwGroupV2EnvironmentVariable[] | cdktf.IResolvable): void;
    get variableInput(): cdktf.IResolvable | ApigwGroupV2EnvironmentVariable[] | undefined;
}
export declare class ApigwGroupV2EnvironmentList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ApigwGroupV2Environment[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigwGroupV2EnvironmentOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_group_v2 opentelekomcloud_apigw_group_v2}
*/
export declare class ApigwGroupV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_apigw_group_v2";
    /**
    * Generates CDKTF code for importing a ApigwGroupV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigwGroupV2 to import
    * @param importFromId The id of the existing ApigwGroupV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_group_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigwGroupV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_group_v2 opentelekomcloud_apigw_group_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigwGroupV2Config
    */
    constructor(scope: Construct, id: string, config: ApigwGroupV2Config);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get registrationTime(): string;
    get updatedAt(): string;
    private _environment;
    get environment(): ApigwGroupV2EnvironmentList;
    putEnvironment(value: ApigwGroupV2Environment[] | cdktf.IResolvable): void;
    resetEnvironment(): void;
    get environmentInput(): cdktf.IResolvable | ApigwGroupV2Environment[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

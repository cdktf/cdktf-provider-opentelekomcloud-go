/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface RdsReadReplicaV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_read_replica_v3#availability_zone RdsReadReplicaV3#availability_zone}
    */
    readonly availabilityZone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_read_replica_v3#flavor_ref RdsReadReplicaV3#flavor_ref}
    */
    readonly flavorRef: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_read_replica_v3#id RdsReadReplicaV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_read_replica_v3#name RdsReadReplicaV3#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_read_replica_v3#public_ips RdsReadReplicaV3#public_ips}
    */
    readonly publicIps?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_read_replica_v3#region RdsReadReplicaV3#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_read_replica_v3#replica_of_id RdsReadReplicaV3#replica_of_id}
    */
    readonly replicaOfId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_read_replica_v3#ssl_enable RdsReadReplicaV3#ssl_enable}
    */
    readonly sslEnable?: boolean | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_read_replica_v3#timeouts RdsReadReplicaV3#timeouts}
    */
    readonly timeouts?: RdsReadReplicaV3Timeouts;
    /**
    * volume block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_read_replica_v3#volume RdsReadReplicaV3#volume}
    */
    readonly volume: RdsReadReplicaV3Volume;
}
export interface RdsReadReplicaV3Db {
}
export declare function rdsReadReplicaV3DbToTerraform(struct?: RdsReadReplicaV3Db): any;
export declare function rdsReadReplicaV3DbToHclTerraform(struct?: RdsReadReplicaV3Db): any;
export declare class RdsReadReplicaV3DbOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RdsReadReplicaV3Db | undefined;
    set internalValue(value: RdsReadReplicaV3Db | undefined);
    get port(): number;
    get type(): string;
    get userName(): string;
    get version(): string;
}
export declare class RdsReadReplicaV3DbList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RdsReadReplicaV3DbOutputReference;
}
export interface RdsReadReplicaV3Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_read_replica_v3#create RdsReadReplicaV3#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_read_replica_v3#update RdsReadReplicaV3#update}
    */
    readonly update?: string;
}
export declare function rdsReadReplicaV3TimeoutsToTerraform(struct?: RdsReadReplicaV3Timeouts | cdktf.IResolvable): any;
export declare function rdsReadReplicaV3TimeoutsToHclTerraform(struct?: RdsReadReplicaV3Timeouts | cdktf.IResolvable): any;
export declare class RdsReadReplicaV3TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RdsReadReplicaV3Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: RdsReadReplicaV3Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface RdsReadReplicaV3Volume {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_read_replica_v3#disk_encryption_id RdsReadReplicaV3#disk_encryption_id}
    */
    readonly diskEncryptionId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_read_replica_v3#type RdsReadReplicaV3#type}
    */
    readonly type: string;
}
export declare function rdsReadReplicaV3VolumeToTerraform(struct?: RdsReadReplicaV3VolumeOutputReference | RdsReadReplicaV3Volume): any;
export declare function rdsReadReplicaV3VolumeToHclTerraform(struct?: RdsReadReplicaV3VolumeOutputReference | RdsReadReplicaV3Volume): any;
export declare class RdsReadReplicaV3VolumeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RdsReadReplicaV3Volume | undefined;
    set internalValue(value: RdsReadReplicaV3Volume | undefined);
    private _diskEncryptionId?;
    get diskEncryptionId(): string;
    set diskEncryptionId(value: string);
    resetDiskEncryptionId(): void;
    get diskEncryptionIdInput(): string | undefined;
    get size(): number;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_read_replica_v3 opentelekomcloud_rds_read_replica_v3}
*/
export declare class RdsReadReplicaV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_rds_read_replica_v3";
    /**
    * Generates CDKTF code for importing a RdsReadReplicaV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RdsReadReplicaV3 to import
    * @param importFromId The id of the existing RdsReadReplicaV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_read_replica_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RdsReadReplicaV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_read_replica_v3 opentelekomcloud_rds_read_replica_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RdsReadReplicaV3Config
    */
    constructor(scope: Construct, id: string, config: RdsReadReplicaV3Config);
    private _availabilityZone?;
    get availabilityZone(): string;
    set availabilityZone(value: string);
    resetAvailabilityZone(): void;
    get availabilityZoneInput(): string | undefined;
    private _db;
    get db(): RdsReadReplicaV3DbList;
    private _flavorRef?;
    get flavorRef(): string;
    set flavorRef(value: string);
    get flavorRefInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get privateIps(): string[];
    private _publicIps?;
    get publicIps(): string[];
    set publicIps(value: string[]);
    resetPublicIps(): void;
    get publicIpsInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _replicaOfId?;
    get replicaOfId(): string;
    set replicaOfId(value: string);
    get replicaOfIdInput(): string | undefined;
    get securityGroupId(): string;
    private _sslEnable?;
    get sslEnable(): boolean | cdktf.IResolvable;
    set sslEnable(value: boolean | cdktf.IResolvable);
    resetSslEnable(): void;
    get sslEnableInput(): boolean | cdktf.IResolvable | undefined;
    get subnetId(): string;
    get vpcId(): string;
    private _timeouts;
    get timeouts(): RdsReadReplicaV3TimeoutsOutputReference;
    putTimeouts(value: RdsReadReplicaV3Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | RdsReadReplicaV3Timeouts | undefined;
    private _volume;
    get volume(): RdsReadReplicaV3VolumeOutputReference;
    putVolume(value: RdsReadReplicaV3Volume): void;
    get volumeInput(): RdsReadReplicaV3Volume | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface HssHostGroupV5Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/hss_host_group_v5#host_ids HssHostGroupV5#host_ids}
    */
    readonly hostIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/hss_host_group_v5#id HssHostGroupV5#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/hss_host_group_v5#name HssHostGroupV5#name}
    */
    readonly name: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/hss_host_group_v5#timeouts HssHostGroupV5#timeouts}
    */
    readonly timeouts?: HssHostGroupV5Timeouts;
}
export interface HssHostGroupV5Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/hss_host_group_v5#create HssHostGroupV5#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/hss_host_group_v5#update HssHostGroupV5#update}
    */
    readonly update?: string;
}
export declare function hssHostGroupV5TimeoutsToTerraform(struct?: HssHostGroupV5Timeouts | cdktf.IResolvable): any;
export declare function hssHostGroupV5TimeoutsToHclTerraform(struct?: HssHostGroupV5Timeouts | cdktf.IResolvable): any;
export declare class HssHostGroupV5TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): HssHostGroupV5Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: HssHostGroupV5Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/hss_host_group_v5 opentelekomcloud_hss_host_group_v5}
*/
export declare class HssHostGroupV5 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_hss_host_group_v5";
    /**
    * Generates CDKTF code for importing a HssHostGroupV5 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the HssHostGroupV5 to import
    * @param importFromId The id of the existing HssHostGroupV5 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/hss_host_group_v5#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the HssHostGroupV5 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/hss_host_group_v5 opentelekomcloud_hss_host_group_v5} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options HssHostGroupV5Config
    */
    constructor(scope: Construct, id: string, config: HssHostGroupV5Config);
    private _hostIds?;
    get hostIds(): string[];
    set hostIds(value: string[]);
    resetHostIds(): void;
    get hostIdsInput(): string[] | undefined;
    get hostNum(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get region(): string;
    get riskHostNum(): number;
    get unprotectHostIds(): string[];
    get unprotectHostNum(): number;
    private _timeouts;
    get timeouts(): HssHostGroupV5TimeoutsOutputReference;
    putTimeouts(value: HssHostGroupV5Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | HssHostGroupV5Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

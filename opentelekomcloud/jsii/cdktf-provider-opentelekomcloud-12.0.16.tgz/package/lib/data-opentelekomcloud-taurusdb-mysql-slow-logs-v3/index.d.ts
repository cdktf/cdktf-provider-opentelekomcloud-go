/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudTaurusdbMysqlSlowLogsV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_slow_logs_v3#end_date DataOpentelekomcloudTaurusdbMysqlSlowLogsV3#end_date}
    */
    readonly endDate: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_slow_logs_v3#id DataOpentelekomcloudTaurusdbMysqlSlowLogsV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_slow_logs_v3#instance_id DataOpentelekomcloudTaurusdbMysqlSlowLogsV3#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_slow_logs_v3#node_id DataOpentelekomcloudTaurusdbMysqlSlowLogsV3#node_id}
    */
    readonly nodeId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_slow_logs_v3#start_date DataOpentelekomcloudTaurusdbMysqlSlowLogsV3#start_date}
    */
    readonly startDate: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_slow_logs_v3#type DataOpentelekomcloudTaurusdbMysqlSlowLogsV3#type}
    */
    readonly type?: string;
}
export interface DataOpentelekomcloudTaurusdbMysqlSlowLogsV3SlowLogListStruct {
}
export declare function dataOpentelekomcloudTaurusdbMysqlSlowLogsV3SlowLogListStructToTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlSlowLogsV3SlowLogListStruct): any;
export declare function dataOpentelekomcloudTaurusdbMysqlSlowLogsV3SlowLogListStructToHclTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlSlowLogsV3SlowLogListStruct): any;
export declare class DataOpentelekomcloudTaurusdbMysqlSlowLogsV3SlowLogListStructOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudTaurusdbMysqlSlowLogsV3SlowLogListStruct | undefined;
    set internalValue(value: DataOpentelekomcloudTaurusdbMysqlSlowLogsV3SlowLogListStruct | undefined);
    get clientIp(): string;
    get count(): string;
    get database(): string;
    get lockTime(): string;
    get nodeId(): string;
    get querySample(): string;
    get rowsExamined(): string;
    get rowsSent(): string;
    get startTime(): string;
    get time(): string;
    get type(): string;
    get users(): string;
}
export declare class DataOpentelekomcloudTaurusdbMysqlSlowLogsV3SlowLogListStructList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudTaurusdbMysqlSlowLogsV3SlowLogListStructOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_slow_logs_v3 opentelekomcloud_taurusdb_mysql_slow_logs_v3}
*/
export declare class DataOpentelekomcloudTaurusdbMysqlSlowLogsV3 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_taurusdb_mysql_slow_logs_v3";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudTaurusdbMysqlSlowLogsV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudTaurusdbMysqlSlowLogsV3 to import
    * @param importFromId The id of the existing DataOpentelekomcloudTaurusdbMysqlSlowLogsV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_slow_logs_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudTaurusdbMysqlSlowLogsV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_slow_logs_v3 opentelekomcloud_taurusdb_mysql_slow_logs_v3} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudTaurusdbMysqlSlowLogsV3Config
    */
    constructor(scope: Construct, id: string, config: DataOpentelekomcloudTaurusdbMysqlSlowLogsV3Config);
    private _endDate?;
    get endDate(): string;
    set endDate(value: string);
    get endDateInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _nodeId?;
    get nodeId(): string;
    set nodeId(value: string);
    get nodeIdInput(): string | undefined;
    get region(): string;
    private _slowLogList;
    get slowLogList(): DataOpentelekomcloudTaurusdbMysqlSlowLogsV3SlowLogListStructList;
    private _startDate?;
    get startDate(): string;
    set startDate(value: string);
    get startDateInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface LbListenerV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_listener_v2#admin_state_up LbListenerV2#admin_state_up}
    */
    readonly adminStateUp?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_listener_v2#client_ca_tls_container_ref LbListenerV2#client_ca_tls_container_ref}
    */
    readonly clientCaTlsContainerRef?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_listener_v2#default_pool_id LbListenerV2#default_pool_id}
    */
    readonly defaultPoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_listener_v2#default_tls_container_ref LbListenerV2#default_tls_container_ref}
    */
    readonly defaultTlsContainerRef?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_listener_v2#description LbListenerV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_listener_v2#http2_enable LbListenerV2#http2_enable}
    */
    readonly http2Enable?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_listener_v2#id LbListenerV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_listener_v2#loadbalancer_id LbListenerV2#loadbalancer_id}
    */
    readonly loadbalancerId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_listener_v2#name LbListenerV2#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_listener_v2#protocol LbListenerV2#protocol}
    */
    readonly protocol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_listener_v2#protocol_port LbListenerV2#protocol_port}
    */
    readonly protocolPort: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_listener_v2#region LbListenerV2#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_listener_v2#sni_container_refs LbListenerV2#sni_container_refs}
    */
    readonly sniContainerRefs?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_listener_v2#tags LbListenerV2#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_listener_v2#tenant_id LbListenerV2#tenant_id}
    */
    readonly tenantId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_listener_v2#tls_ciphers_policy LbListenerV2#tls_ciphers_policy}
    */
    readonly tlsCiphersPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_listener_v2#transparent_client_ip_enable LbListenerV2#transparent_client_ip_enable}
    */
    readonly transparentClientIpEnable?: boolean | cdktf.IResolvable;
    /**
    * ip_group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_listener_v2#ip_group LbListenerV2#ip_group}
    */
    readonly ipGroup?: LbListenerV2IpGroup;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_listener_v2#timeouts LbListenerV2#timeouts}
    */
    readonly timeouts?: LbListenerV2Timeouts;
}
export interface LbListenerV2IpGroup {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_listener_v2#enable LbListenerV2#enable}
    */
    readonly enable?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_listener_v2#id LbListenerV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_listener_v2#type LbListenerV2#type}
    */
    readonly type?: string;
}
export declare function lbListenerV2IpGroupToTerraform(struct?: LbListenerV2IpGroupOutputReference | LbListenerV2IpGroup): any;
export declare function lbListenerV2IpGroupToHclTerraform(struct?: LbListenerV2IpGroupOutputReference | LbListenerV2IpGroup): any;
export declare class LbListenerV2IpGroupOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LbListenerV2IpGroup | undefined;
    set internalValue(value: LbListenerV2IpGroup | undefined);
    private _enable?;
    get enable(): boolean | cdktf.IResolvable;
    set enable(value: boolean | cdktf.IResolvable);
    resetEnable(): void;
    get enableInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface LbListenerV2Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_listener_v2#create LbListenerV2#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_listener_v2#delete LbListenerV2#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_listener_v2#update LbListenerV2#update}
    */
    readonly update?: string;
}
export declare function lbListenerV2TimeoutsToTerraform(struct?: LbListenerV2Timeouts | cdktf.IResolvable): any;
export declare function lbListenerV2TimeoutsToHclTerraform(struct?: LbListenerV2Timeouts | cdktf.IResolvable): any;
export declare class LbListenerV2TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LbListenerV2Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: LbListenerV2Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_listener_v2 opentelekomcloud_lb_listener_v2}
*/
export declare class LbListenerV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_lb_listener_v2";
    /**
    * Generates CDKTF code for importing a LbListenerV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LbListenerV2 to import
    * @param importFromId The id of the existing LbListenerV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_listener_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LbListenerV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_listener_v2 opentelekomcloud_lb_listener_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LbListenerV2Config
    */
    constructor(scope: Construct, id: string, config: LbListenerV2Config);
    private _adminStateUp?;
    get adminStateUp(): boolean | cdktf.IResolvable;
    set adminStateUp(value: boolean | cdktf.IResolvable);
    resetAdminStateUp(): void;
    get adminStateUpInput(): boolean | cdktf.IResolvable | undefined;
    private _clientCaTlsContainerRef?;
    get clientCaTlsContainerRef(): string;
    set clientCaTlsContainerRef(value: string);
    resetClientCaTlsContainerRef(): void;
    get clientCaTlsContainerRefInput(): string | undefined;
    private _defaultPoolId?;
    get defaultPoolId(): string;
    set defaultPoolId(value: string);
    resetDefaultPoolId(): void;
    get defaultPoolIdInput(): string | undefined;
    private _defaultTlsContainerRef?;
    get defaultTlsContainerRef(): string;
    set defaultTlsContainerRef(value: string);
    resetDefaultTlsContainerRef(): void;
    get defaultTlsContainerRefInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _http2Enable?;
    get http2Enable(): boolean | cdktf.IResolvable;
    set http2Enable(value: boolean | cdktf.IResolvable);
    resetHttp2Enable(): void;
    get http2EnableInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _loadbalancerId?;
    get loadbalancerId(): string;
    set loadbalancerId(value: string);
    get loadbalancerIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    get protocolInput(): string | undefined;
    private _protocolPort?;
    get protocolPort(): number;
    set protocolPort(value: number);
    get protocolPortInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _sniContainerRefs?;
    get sniContainerRefs(): string[];
    set sniContainerRefs(value: string[]);
    resetSniContainerRefs(): void;
    get sniContainerRefsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tenantId?;
    get tenantId(): string;
    set tenantId(value: string);
    resetTenantId(): void;
    get tenantIdInput(): string | undefined;
    private _tlsCiphersPolicy?;
    get tlsCiphersPolicy(): string;
    set tlsCiphersPolicy(value: string);
    resetTlsCiphersPolicy(): void;
    get tlsCiphersPolicyInput(): string | undefined;
    private _transparentClientIpEnable?;
    get transparentClientIpEnable(): boolean | cdktf.IResolvable;
    set transparentClientIpEnable(value: boolean | cdktf.IResolvable);
    resetTransparentClientIpEnable(): void;
    get transparentClientIpEnableInput(): boolean | cdktf.IResolvable | undefined;
    private _ipGroup;
    get ipGroup(): LbListenerV2IpGroupOutputReference;
    putIpGroup(value: LbListenerV2IpGroup): void;
    resetIpGroup(): void;
    get ipGroupInput(): LbListenerV2IpGroup | undefined;
    private _timeouts;
    get timeouts(): LbListenerV2TimeoutsOutputReference;
    putTimeouts(value: LbListenerV2Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | LbListenerV2Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

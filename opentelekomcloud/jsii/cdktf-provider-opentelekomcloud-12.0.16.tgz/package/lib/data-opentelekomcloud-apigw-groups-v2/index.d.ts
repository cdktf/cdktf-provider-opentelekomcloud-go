/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudApigwGroupsV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/apigw_groups_v2#group_id DataOpentelekomcloudApigwGroupsV2#group_id}
    */
    readonly groupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/apigw_groups_v2#id DataOpentelekomcloudApigwGroupsV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/apigw_groups_v2#instance_id DataOpentelekomcloudApigwGroupsV2#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/apigw_groups_v2#name DataOpentelekomcloudApigwGroupsV2#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/apigw_groups_v2#region DataOpentelekomcloudApigwGroupsV2#region}
    */
    readonly region?: string;
}
export interface DataOpentelekomcloudApigwGroupsV2GroupsEnvironmentVariable {
}
export declare function dataOpentelekomcloudApigwGroupsV2GroupsEnvironmentVariableToTerraform(struct?: DataOpentelekomcloudApigwGroupsV2GroupsEnvironmentVariable): any;
export declare function dataOpentelekomcloudApigwGroupsV2GroupsEnvironmentVariableToHclTerraform(struct?: DataOpentelekomcloudApigwGroupsV2GroupsEnvironmentVariable): any;
export declare class DataOpentelekomcloudApigwGroupsV2GroupsEnvironmentVariableOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudApigwGroupsV2GroupsEnvironmentVariable | undefined;
    set internalValue(value: DataOpentelekomcloudApigwGroupsV2GroupsEnvironmentVariable | undefined);
    get id(): string;
    get name(): string;
    get value(): string;
}
export declare class DataOpentelekomcloudApigwGroupsV2GroupsEnvironmentVariableList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudApigwGroupsV2GroupsEnvironmentVariableOutputReference;
}
export interface DataOpentelekomcloudApigwGroupsV2GroupsEnvironment {
}
export declare function dataOpentelekomcloudApigwGroupsV2GroupsEnvironmentToTerraform(struct?: DataOpentelekomcloudApigwGroupsV2GroupsEnvironment): any;
export declare function dataOpentelekomcloudApigwGroupsV2GroupsEnvironmentToHclTerraform(struct?: DataOpentelekomcloudApigwGroupsV2GroupsEnvironment): any;
export declare class DataOpentelekomcloudApigwGroupsV2GroupsEnvironmentOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudApigwGroupsV2GroupsEnvironment | undefined;
    set internalValue(value: DataOpentelekomcloudApigwGroupsV2GroupsEnvironment | undefined);
    get environmentId(): string;
    private _variable;
    get variable(): DataOpentelekomcloudApigwGroupsV2GroupsEnvironmentVariableList;
}
export declare class DataOpentelekomcloudApigwGroupsV2GroupsEnvironmentList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudApigwGroupsV2GroupsEnvironmentOutputReference;
}
export interface DataOpentelekomcloudApigwGroupsV2GroupsUrlDomains {
}
export declare function dataOpentelekomcloudApigwGroupsV2GroupsUrlDomainsToTerraform(struct?: DataOpentelekomcloudApigwGroupsV2GroupsUrlDomains): any;
export declare function dataOpentelekomcloudApigwGroupsV2GroupsUrlDomainsToHclTerraform(struct?: DataOpentelekomcloudApigwGroupsV2GroupsUrlDomains): any;
export declare class DataOpentelekomcloudApigwGroupsV2GroupsUrlDomainsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudApigwGroupsV2GroupsUrlDomains | undefined;
    set internalValue(value: DataOpentelekomcloudApigwGroupsV2GroupsUrlDomains | undefined);
    get cnameStatus(): number;
    get id(): string;
    get isHasTrustedRootCa(): cdktf.IResolvable;
    get minSslVersion(): string;
    get name(): string;
    get sslId(): string;
    get sslName(): string;
    get verifiedClientCertificateEnabled(): cdktf.IResolvable;
}
export declare class DataOpentelekomcloudApigwGroupsV2GroupsUrlDomainsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudApigwGroupsV2GroupsUrlDomainsOutputReference;
}
export interface DataOpentelekomcloudApigwGroupsV2Groups {
}
export declare function dataOpentelekomcloudApigwGroupsV2GroupsToTerraform(struct?: DataOpentelekomcloudApigwGroupsV2Groups): any;
export declare function dataOpentelekomcloudApigwGroupsV2GroupsToHclTerraform(struct?: DataOpentelekomcloudApigwGroupsV2Groups): any;
export declare class DataOpentelekomcloudApigwGroupsV2GroupsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudApigwGroupsV2Groups | undefined;
    set internalValue(value: DataOpentelekomcloudApigwGroupsV2Groups | undefined);
    get createdAt(): string;
    get description(): string;
    private _environment;
    get environment(): DataOpentelekomcloudApigwGroupsV2GroupsEnvironmentList;
    get id(): string;
    get isDefault(): number;
    get name(): string;
    get onSellStatus(): number;
    get slDomain(): string;
    get slDomains(): string[];
    get status(): number;
    get updatedAt(): string;
    private _urlDomains;
    get urlDomains(): DataOpentelekomcloudApigwGroupsV2GroupsUrlDomainsList;
}
export declare class DataOpentelekomcloudApigwGroupsV2GroupsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudApigwGroupsV2GroupsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/apigw_groups_v2 opentelekomcloud_apigw_groups_v2}
*/
export declare class DataOpentelekomcloudApigwGroupsV2 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_apigw_groups_v2";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudApigwGroupsV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudApigwGroupsV2 to import
    * @param importFromId The id of the existing DataOpentelekomcloudApigwGroupsV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/apigw_groups_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudApigwGroupsV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/apigw_groups_v2 opentelekomcloud_apigw_groups_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudApigwGroupsV2Config
    */
    constructor(scope: Construct, id: string, config: DataOpentelekomcloudApigwGroupsV2Config);
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    resetGroupId(): void;
    get groupIdInput(): string | undefined;
    private _groups;
    get groups(): DataOpentelekomcloudApigwGroupsV2GroupsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface LtsTransferV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_transfer_v2#id LtsTransferV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_transfer_v2#log_group_id LtsTransferV2#log_group_id}
    */
    readonly logGroupId: string;
    /**
    * log_streams block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_transfer_v2#log_streams LtsTransferV2#log_streams}
    */
    readonly logStreams: LtsTransferV2LogStreams[] | cdktf.IResolvable;
    /**
    * log_transfer_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_transfer_v2#log_transfer_info LtsTransferV2#log_transfer_info}
    */
    readonly logTransferInfo: LtsTransferV2LogTransferInfo;
}
export interface LtsTransferV2LogStreams {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_transfer_v2#log_stream_id LtsTransferV2#log_stream_id}
    */
    readonly logStreamId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_transfer_v2#log_stream_name LtsTransferV2#log_stream_name}
    */
    readonly logStreamName?: string;
}
export declare function ltsTransferV2LogStreamsToTerraform(struct?: LtsTransferV2LogStreams | cdktf.IResolvable): any;
export declare function ltsTransferV2LogStreamsToHclTerraform(struct?: LtsTransferV2LogStreams | cdktf.IResolvable): any;
export declare class LtsTransferV2LogStreamsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LtsTransferV2LogStreams | cdktf.IResolvable | undefined;
    set internalValue(value: LtsTransferV2LogStreams | cdktf.IResolvable | undefined);
    private _logStreamId?;
    get logStreamId(): string;
    set logStreamId(value: string);
    get logStreamIdInput(): string | undefined;
    private _logStreamName?;
    get logStreamName(): string;
    set logStreamName(value: string);
    resetLogStreamName(): void;
    get logStreamNameInput(): string | undefined;
}
export declare class LtsTransferV2LogStreamsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: LtsTransferV2LogStreams[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LtsTransferV2LogStreamsOutputReference;
}
export interface LtsTransferV2LogTransferInfoLogAgencyTransfer {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_transfer_v2#agency_domain_id LtsTransferV2#agency_domain_id}
    */
    readonly agencyDomainId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_transfer_v2#agency_domain_name LtsTransferV2#agency_domain_name}
    */
    readonly agencyDomainName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_transfer_v2#agency_name LtsTransferV2#agency_name}
    */
    readonly agencyName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_transfer_v2#agency_project_id LtsTransferV2#agency_project_id}
    */
    readonly agencyProjectId: string;
}
export declare function ltsTransferV2LogTransferInfoLogAgencyTransferToTerraform(struct?: LtsTransferV2LogTransferInfoLogAgencyTransferOutputReference | LtsTransferV2LogTransferInfoLogAgencyTransfer): any;
export declare function ltsTransferV2LogTransferInfoLogAgencyTransferToHclTerraform(struct?: LtsTransferV2LogTransferInfoLogAgencyTransferOutputReference | LtsTransferV2LogTransferInfoLogAgencyTransfer): any;
export declare class LtsTransferV2LogTransferInfoLogAgencyTransferOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LtsTransferV2LogTransferInfoLogAgencyTransfer | undefined;
    set internalValue(value: LtsTransferV2LogTransferInfoLogAgencyTransfer | undefined);
    private _agencyDomainId?;
    get agencyDomainId(): string;
    set agencyDomainId(value: string);
    get agencyDomainIdInput(): string | undefined;
    private _agencyDomainName?;
    get agencyDomainName(): string;
    set agencyDomainName(value: string);
    get agencyDomainNameInput(): string | undefined;
    private _agencyName?;
    get agencyName(): string;
    set agencyName(value: string);
    get agencyNameInput(): string | undefined;
    private _agencyProjectId?;
    get agencyProjectId(): string;
    set agencyProjectId(value: string);
    get agencyProjectIdInput(): string | undefined;
}
export interface LtsTransferV2LogTransferInfoLogTransferDetail {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_transfer_v2#obs_bucket_name LtsTransferV2#obs_bucket_name}
    */
    readonly obsBucketName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_transfer_v2#obs_dir_prefix_name LtsTransferV2#obs_dir_prefix_name}
    */
    readonly obsDirPrefixName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_transfer_v2#obs_encrypted_enable LtsTransferV2#obs_encrypted_enable}
    */
    readonly obsEncryptedEnable?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_transfer_v2#obs_encrypted_id LtsTransferV2#obs_encrypted_id}
    */
    readonly obsEncryptedId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_transfer_v2#obs_eps_id LtsTransferV2#obs_eps_id}
    */
    readonly obsEpsId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_transfer_v2#obs_period LtsTransferV2#obs_period}
    */
    readonly obsPeriod?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_transfer_v2#obs_period_unit LtsTransferV2#obs_period_unit}
    */
    readonly obsPeriodUnit?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_transfer_v2#obs_prefix_name LtsTransferV2#obs_prefix_name}
    */
    readonly obsPrefixName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_transfer_v2#obs_time_zone LtsTransferV2#obs_time_zone}
    */
    readonly obsTimeZone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_transfer_v2#obs_time_zone_id LtsTransferV2#obs_time_zone_id}
    */
    readonly obsTimeZoneId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_transfer_v2#obs_transfer_path LtsTransferV2#obs_transfer_path}
    */
    readonly obsTransferPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_transfer_v2#tags LtsTransferV2#tags}
    */
    readonly tags?: string[];
}
export declare function ltsTransferV2LogTransferInfoLogTransferDetailToTerraform(struct?: LtsTransferV2LogTransferInfoLogTransferDetailOutputReference | LtsTransferV2LogTransferInfoLogTransferDetail): any;
export declare function ltsTransferV2LogTransferInfoLogTransferDetailToHclTerraform(struct?: LtsTransferV2LogTransferInfoLogTransferDetailOutputReference | LtsTransferV2LogTransferInfoLogTransferDetail): any;
export declare class LtsTransferV2LogTransferInfoLogTransferDetailOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LtsTransferV2LogTransferInfoLogTransferDetail | undefined;
    set internalValue(value: LtsTransferV2LogTransferInfoLogTransferDetail | undefined);
    private _obsBucketName?;
    get obsBucketName(): string;
    set obsBucketName(value: string);
    resetObsBucketName(): void;
    get obsBucketNameInput(): string | undefined;
    private _obsDirPrefixName?;
    get obsDirPrefixName(): string;
    set obsDirPrefixName(value: string);
    resetObsDirPrefixName(): void;
    get obsDirPrefixNameInput(): string | undefined;
    private _obsEncryptedEnable?;
    get obsEncryptedEnable(): boolean | cdktf.IResolvable;
    set obsEncryptedEnable(value: boolean | cdktf.IResolvable);
    resetObsEncryptedEnable(): void;
    get obsEncryptedEnableInput(): boolean | cdktf.IResolvable | undefined;
    private _obsEncryptedId?;
    get obsEncryptedId(): string;
    set obsEncryptedId(value: string);
    resetObsEncryptedId(): void;
    get obsEncryptedIdInput(): string | undefined;
    private _obsEpsId?;
    get obsEpsId(): string;
    set obsEpsId(value: string);
    resetObsEpsId(): void;
    get obsEpsIdInput(): string | undefined;
    private _obsPeriod?;
    get obsPeriod(): number;
    set obsPeriod(value: number);
    resetObsPeriod(): void;
    get obsPeriodInput(): number | undefined;
    private _obsPeriodUnit?;
    get obsPeriodUnit(): string;
    set obsPeriodUnit(value: string);
    resetObsPeriodUnit(): void;
    get obsPeriodUnitInput(): string | undefined;
    private _obsPrefixName?;
    get obsPrefixName(): string;
    set obsPrefixName(value: string);
    resetObsPrefixName(): void;
    get obsPrefixNameInput(): string | undefined;
    private _obsTimeZone?;
    get obsTimeZone(): string;
    set obsTimeZone(value: string);
    resetObsTimeZone(): void;
    get obsTimeZoneInput(): string | undefined;
    private _obsTimeZoneId?;
    get obsTimeZoneId(): string;
    set obsTimeZoneId(value: string);
    resetObsTimeZoneId(): void;
    get obsTimeZoneIdInput(): string | undefined;
    private _obsTransferPath?;
    get obsTransferPath(): string;
    set obsTransferPath(value: string);
    resetObsTransferPath(): void;
    get obsTransferPathInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
}
export interface LtsTransferV2LogTransferInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_transfer_v2#log_storage_format LtsTransferV2#log_storage_format}
    */
    readonly logStorageFormat: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_transfer_v2#log_transfer_mode LtsTransferV2#log_transfer_mode}
    */
    readonly logTransferMode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_transfer_v2#log_transfer_status LtsTransferV2#log_transfer_status}
    */
    readonly logTransferStatus: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_transfer_v2#log_transfer_type LtsTransferV2#log_transfer_type}
    */
    readonly logTransferType: string;
    /**
    * log_agency_transfer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_transfer_v2#log_agency_transfer LtsTransferV2#log_agency_transfer}
    */
    readonly logAgencyTransfer?: LtsTransferV2LogTransferInfoLogAgencyTransfer;
    /**
    * log_transfer_detail block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_transfer_v2#log_transfer_detail LtsTransferV2#log_transfer_detail}
    */
    readonly logTransferDetail: LtsTransferV2LogTransferInfoLogTransferDetail;
}
export declare function ltsTransferV2LogTransferInfoToTerraform(struct?: LtsTransferV2LogTransferInfoOutputReference | LtsTransferV2LogTransferInfo): any;
export declare function ltsTransferV2LogTransferInfoToHclTerraform(struct?: LtsTransferV2LogTransferInfoOutputReference | LtsTransferV2LogTransferInfo): any;
export declare class LtsTransferV2LogTransferInfoOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LtsTransferV2LogTransferInfo | undefined;
    set internalValue(value: LtsTransferV2LogTransferInfo | undefined);
    get logCreatedAt(): string;
    private _logStorageFormat?;
    get logStorageFormat(): string;
    set logStorageFormat(value: string);
    get logStorageFormatInput(): string | undefined;
    private _logTransferMode?;
    get logTransferMode(): string;
    set logTransferMode(value: string);
    get logTransferModeInput(): string | undefined;
    private _logTransferStatus?;
    get logTransferStatus(): string;
    set logTransferStatus(value: string);
    get logTransferStatusInput(): string | undefined;
    private _logTransferType?;
    get logTransferType(): string;
    set logTransferType(value: string);
    get logTransferTypeInput(): string | undefined;
    private _logAgencyTransfer;
    get logAgencyTransfer(): LtsTransferV2LogTransferInfoLogAgencyTransferOutputReference;
    putLogAgencyTransfer(value: LtsTransferV2LogTransferInfoLogAgencyTransfer): void;
    resetLogAgencyTransfer(): void;
    get logAgencyTransferInput(): LtsTransferV2LogTransferInfoLogAgencyTransfer | undefined;
    private _logTransferDetail;
    get logTransferDetail(): LtsTransferV2LogTransferInfoLogTransferDetailOutputReference;
    putLogTransferDetail(value: LtsTransferV2LogTransferInfoLogTransferDetail): void;
    get logTransferDetailInput(): LtsTransferV2LogTransferInfoLogTransferDetail | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_transfer_v2 opentelekomcloud_lts_transfer_v2}
*/
export declare class LtsTransferV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_lts_transfer_v2";
    /**
    * Generates CDKTF code for importing a LtsTransferV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LtsTransferV2 to import
    * @param importFromId The id of the existing LtsTransferV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_transfer_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LtsTransferV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_transfer_v2 opentelekomcloud_lts_transfer_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LtsTransferV2Config
    */
    constructor(scope: Construct, id: string, config: LtsTransferV2Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _logGroupId?;
    get logGroupId(): string;
    set logGroupId(value: string);
    get logGroupIdInput(): string | undefined;
    get logGroupName(): string;
    get region(): string;
    private _logStreams;
    get logStreams(): LtsTransferV2LogStreamsList;
    putLogStreams(value: LtsTransferV2LogStreams[] | cdktf.IResolvable): void;
    get logStreamsInput(): cdktf.IResolvable | LtsTransferV2LogStreams[] | undefined;
    private _logTransferInfo;
    get logTransferInfo(): LtsTransferV2LogTransferInfoOutputReference;
    putLogTransferInfo(value: LtsTransferV2LogTransferInfo): void;
    get logTransferInfoInput(): LtsTransferV2LogTransferInfo | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

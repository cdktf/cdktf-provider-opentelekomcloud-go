/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DdsLtsLogV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dds_lts_log_v3#id DdsLtsLogV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dds_lts_log_v3#instance_id DdsLtsLogV3#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dds_lts_log_v3#log_type DdsLtsLogV3#log_type}
    */
    readonly logType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dds_lts_log_v3#lts_group_id DdsLtsLogV3#lts_group_id}
    */
    readonly ltsGroupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dds_lts_log_v3#lts_stream_id DdsLtsLogV3#lts_stream_id}
    */
    readonly ltsStreamId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dds_lts_log_v3#timeouts DdsLtsLogV3#timeouts}
    */
    readonly timeouts?: DdsLtsLogV3Timeouts;
}
export interface DdsLtsLogV3Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dds_lts_log_v3#create DdsLtsLogV3#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dds_lts_log_v3#delete DdsLtsLogV3#delete}
    */
    readonly delete?: string;
}
export declare function ddsLtsLogV3TimeoutsToTerraform(struct?: DdsLtsLogV3Timeouts | cdktf.IResolvable): any;
export declare function ddsLtsLogV3TimeoutsToHclTerraform(struct?: DdsLtsLogV3Timeouts | cdktf.IResolvable): any;
export declare class DdsLtsLogV3TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DdsLtsLogV3Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DdsLtsLogV3Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dds_lts_log_v3 opentelekomcloud_dds_lts_log_v3}
*/
export declare class DdsLtsLogV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_dds_lts_log_v3";
    /**
    * Generates CDKTF code for importing a DdsLtsLogV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DdsLtsLogV3 to import
    * @param importFromId The id of the existing DdsLtsLogV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dds_lts_log_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DdsLtsLogV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dds_lts_log_v3 opentelekomcloud_dds_lts_log_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DdsLtsLogV3Config
    */
    constructor(scope: Construct, id: string, config: DdsLtsLogV3Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _logType?;
    get logType(): string;
    set logType(value: string);
    get logTypeInput(): string | undefined;
    private _ltsGroupId?;
    get ltsGroupId(): string;
    set ltsGroupId(value: string);
    get ltsGroupIdInput(): string | undefined;
    private _ltsStreamId?;
    get ltsStreamId(): string;
    set ltsStreamId(value: string);
    get ltsStreamIdInput(): string | undefined;
    get region(): string;
    private _timeouts;
    get timeouts(): DdsLtsLogV3TimeoutsOutputReference;
    putTimeouts(value: DdsLtsLogV3Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DdsLtsLogV3Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

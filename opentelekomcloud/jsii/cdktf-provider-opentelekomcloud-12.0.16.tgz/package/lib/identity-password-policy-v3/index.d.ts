/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface IdentityPasswordPolicyV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_password_policy_v3#id IdentityPasswordPolicyV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_password_policy_v3#maximum_consecutive_identical_chars IdentityPasswordPolicyV3#maximum_consecutive_identical_chars}
    */
    readonly maximumConsecutiveIdenticalChars?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_password_policy_v3#minimum_password_age IdentityPasswordPolicyV3#minimum_password_age}
    */
    readonly minimumPasswordAge?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_password_policy_v3#minimum_password_length IdentityPasswordPolicyV3#minimum_password_length}
    */
    readonly minimumPasswordLength?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_password_policy_v3#number_of_recent_passwords_disallowed IdentityPasswordPolicyV3#number_of_recent_passwords_disallowed}
    */
    readonly numberOfRecentPasswordsDisallowed?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_password_policy_v3#password_char_combination IdentityPasswordPolicyV3#password_char_combination}
    */
    readonly passwordCharCombination?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_password_policy_v3#password_not_username_or_invert IdentityPasswordPolicyV3#password_not_username_or_invert}
    */
    readonly passwordNotUsernameOrInvert?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_password_policy_v3#password_validity_period IdentityPasswordPolicyV3#password_validity_period}
    */
    readonly passwordValidityPeriod?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_password_policy_v3 opentelekomcloud_identity_password_policy_v3}
*/
export declare class IdentityPasswordPolicyV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_identity_password_policy_v3";
    /**
    * Generates CDKTF code for importing a IdentityPasswordPolicyV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IdentityPasswordPolicyV3 to import
    * @param importFromId The id of the existing IdentityPasswordPolicyV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_password_policy_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IdentityPasswordPolicyV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_password_policy_v3 opentelekomcloud_identity_password_policy_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IdentityPasswordPolicyV3Config = {}
    */
    constructor(scope: Construct, id: string, config?: IdentityPasswordPolicyV3Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maximumConsecutiveIdenticalChars?;
    get maximumConsecutiveIdenticalChars(): number;
    set maximumConsecutiveIdenticalChars(value: number);
    resetMaximumConsecutiveIdenticalChars(): void;
    get maximumConsecutiveIdenticalCharsInput(): number | undefined;
    get maximumPasswordLength(): number;
    private _minimumPasswordAge?;
    get minimumPasswordAge(): number;
    set minimumPasswordAge(value: number);
    resetMinimumPasswordAge(): void;
    get minimumPasswordAgeInput(): number | undefined;
    private _minimumPasswordLength?;
    get minimumPasswordLength(): number;
    set minimumPasswordLength(value: number);
    resetMinimumPasswordLength(): void;
    get minimumPasswordLengthInput(): number | undefined;
    private _numberOfRecentPasswordsDisallowed?;
    get numberOfRecentPasswordsDisallowed(): number;
    set numberOfRecentPasswordsDisallowed(value: number);
    resetNumberOfRecentPasswordsDisallowed(): void;
    get numberOfRecentPasswordsDisallowedInput(): number | undefined;
    private _passwordCharCombination?;
    get passwordCharCombination(): number;
    set passwordCharCombination(value: number);
    resetPasswordCharCombination(): void;
    get passwordCharCombinationInput(): number | undefined;
    private _passwordNotUsernameOrInvert?;
    get passwordNotUsernameOrInvert(): boolean | cdktf.IResolvable;
    set passwordNotUsernameOrInvert(value: boolean | cdktf.IResolvable);
    resetPasswordNotUsernameOrInvert(): void;
    get passwordNotUsernameOrInvertInput(): boolean | cdktf.IResolvable | undefined;
    get passwordRequirements(): string;
    private _passwordValidityPeriod?;
    get passwordValidityPeriod(): number;
    set passwordValidityPeriod(value: number);
    resetPasswordValidityPeriod(): void;
    get passwordValidityPeriodInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

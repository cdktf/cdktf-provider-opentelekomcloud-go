/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface FgsTriggerV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_trigger_v2#event_data FgsTriggerV2#event_data}
    */
    readonly eventData: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_trigger_v2#function_urn FgsTriggerV2#function_urn}
    */
    readonly functionUrn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_trigger_v2#id FgsTriggerV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_trigger_v2#status FgsTriggerV2#status}
    */
    readonly status?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_trigger_v2#type FgsTriggerV2#type}
    */
    readonly type: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_trigger_v2#timeouts FgsTriggerV2#timeouts}
    */
    readonly timeouts?: FgsTriggerV2Timeouts;
}
export interface FgsTriggerV2Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_trigger_v2#delete FgsTriggerV2#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_trigger_v2#update FgsTriggerV2#update}
    */
    readonly update?: string;
}
export declare function fgsTriggerV2TimeoutsToTerraform(struct?: FgsTriggerV2Timeouts | cdktf.IResolvable): any;
export declare function fgsTriggerV2TimeoutsToHclTerraform(struct?: FgsTriggerV2Timeouts | cdktf.IResolvable): any;
export declare class FgsTriggerV2TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FgsTriggerV2Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: FgsTriggerV2Timeouts | cdktf.IResolvable | undefined);
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_trigger_v2 opentelekomcloud_fgs_trigger_v2}
*/
export declare class FgsTriggerV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_fgs_trigger_v2";
    /**
    * Generates CDKTF code for importing a FgsTriggerV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the FgsTriggerV2 to import
    * @param importFromId The id of the existing FgsTriggerV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_trigger_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the FgsTriggerV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_trigger_v2 opentelekomcloud_fgs_trigger_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options FgsTriggerV2Config
    */
    constructor(scope: Construct, id: string, config: FgsTriggerV2Config);
    get createdAt(): string;
    private _eventData?;
    get eventData(): string;
    set eventData(value: string);
    get eventDataInput(): string | undefined;
    private _functionUrn?;
    get functionUrn(): string;
    set functionUrn(value: string);
    get functionUrnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get region(): string;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    get updatedAt(): string;
    private _timeouts;
    get timeouts(): FgsTriggerV2TimeoutsOutputReference;
    putTimeouts(value: FgsTriggerV2Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | FgsTriggerV2Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

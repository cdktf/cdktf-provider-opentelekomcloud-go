/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AsConfigurationV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_configuration_v1#id AsConfigurationV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_configuration_v1#region AsConfigurationV1#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_configuration_v1#scaling_configuration_name AsConfigurationV1#scaling_configuration_name}
    */
    readonly scalingConfigurationName: string;
    /**
    * instance_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_configuration_v1#instance_config AsConfigurationV1#instance_config}
    */
    readonly instanceConfig: AsConfigurationV1InstanceConfig;
}
export interface AsConfigurationV1InstanceConfigDisk {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_configuration_v1#disk_type AsConfigurationV1#disk_type}
    */
    readonly diskType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_configuration_v1#kms_id AsConfigurationV1#kms_id}
    */
    readonly kmsId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_configuration_v1#size AsConfigurationV1#size}
    */
    readonly size: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_configuration_v1#volume_type AsConfigurationV1#volume_type}
    */
    readonly volumeType: string;
}
export declare function asConfigurationV1InstanceConfigDiskToTerraform(struct?: AsConfigurationV1InstanceConfigDisk | cdktf.IResolvable): any;
export declare function asConfigurationV1InstanceConfigDiskToHclTerraform(struct?: AsConfigurationV1InstanceConfigDisk | cdktf.IResolvable): any;
export declare class AsConfigurationV1InstanceConfigDiskOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AsConfigurationV1InstanceConfigDisk | cdktf.IResolvable | undefined;
    set internalValue(value: AsConfigurationV1InstanceConfigDisk | cdktf.IResolvable | undefined);
    private _diskType?;
    get diskType(): string;
    set diskType(value: string);
    get diskTypeInput(): string | undefined;
    private _kmsId?;
    get kmsId(): string;
    set kmsId(value: string);
    resetKmsId(): void;
    get kmsIdInput(): string | undefined;
    private _size?;
    get size(): number;
    set size(value: number);
    get sizeInput(): number | undefined;
    private _volumeType?;
    get volumeType(): string;
    set volumeType(value: string);
    get volumeTypeInput(): string | undefined;
}
export declare class AsConfigurationV1InstanceConfigDiskList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AsConfigurationV1InstanceConfigDisk[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AsConfigurationV1InstanceConfigDiskOutputReference;
}
export interface AsConfigurationV1InstanceConfigPersonality {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_configuration_v1#content AsConfigurationV1#content}
    */
    readonly content: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_configuration_v1#path AsConfigurationV1#path}
    */
    readonly path: string;
}
export declare function asConfigurationV1InstanceConfigPersonalityToTerraform(struct?: AsConfigurationV1InstanceConfigPersonality | cdktf.IResolvable): any;
export declare function asConfigurationV1InstanceConfigPersonalityToHclTerraform(struct?: AsConfigurationV1InstanceConfigPersonality | cdktf.IResolvable): any;
export declare class AsConfigurationV1InstanceConfigPersonalityOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AsConfigurationV1InstanceConfigPersonality | cdktf.IResolvable | undefined;
    set internalValue(value: AsConfigurationV1InstanceConfigPersonality | cdktf.IResolvable | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    get contentInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
}
export declare class AsConfigurationV1InstanceConfigPersonalityList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AsConfigurationV1InstanceConfigPersonality[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AsConfigurationV1InstanceConfigPersonalityOutputReference;
}
export interface AsConfigurationV1InstanceConfigPublicIpEipBandwidth {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_configuration_v1#charging_mode AsConfigurationV1#charging_mode}
    */
    readonly chargingMode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_configuration_v1#share_type AsConfigurationV1#share_type}
    */
    readonly shareType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_configuration_v1#size AsConfigurationV1#size}
    */
    readonly size: number;
}
export declare function asConfigurationV1InstanceConfigPublicIpEipBandwidthToTerraform(struct?: AsConfigurationV1InstanceConfigPublicIpEipBandwidthOutputReference | AsConfigurationV1InstanceConfigPublicIpEipBandwidth): any;
export declare function asConfigurationV1InstanceConfigPublicIpEipBandwidthToHclTerraform(struct?: AsConfigurationV1InstanceConfigPublicIpEipBandwidthOutputReference | AsConfigurationV1InstanceConfigPublicIpEipBandwidth): any;
export declare class AsConfigurationV1InstanceConfigPublicIpEipBandwidthOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AsConfigurationV1InstanceConfigPublicIpEipBandwidth | undefined;
    set internalValue(value: AsConfigurationV1InstanceConfigPublicIpEipBandwidth | undefined);
    private _chargingMode?;
    get chargingMode(): string;
    set chargingMode(value: string);
    get chargingModeInput(): string | undefined;
    private _shareType?;
    get shareType(): string;
    set shareType(value: string);
    get shareTypeInput(): string | undefined;
    private _size?;
    get size(): number;
    set size(value: number);
    get sizeInput(): number | undefined;
}
export interface AsConfigurationV1InstanceConfigPublicIpEip {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_configuration_v1#ip_type AsConfigurationV1#ip_type}
    */
    readonly ipType: string;
    /**
    * bandwidth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_configuration_v1#bandwidth AsConfigurationV1#bandwidth}
    */
    readonly bandwidth: AsConfigurationV1InstanceConfigPublicIpEipBandwidth;
}
export declare function asConfigurationV1InstanceConfigPublicIpEipToTerraform(struct?: AsConfigurationV1InstanceConfigPublicIpEipOutputReference | AsConfigurationV1InstanceConfigPublicIpEip): any;
export declare function asConfigurationV1InstanceConfigPublicIpEipToHclTerraform(struct?: AsConfigurationV1InstanceConfigPublicIpEipOutputReference | AsConfigurationV1InstanceConfigPublicIpEip): any;
export declare class AsConfigurationV1InstanceConfigPublicIpEipOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AsConfigurationV1InstanceConfigPublicIpEip | undefined;
    set internalValue(value: AsConfigurationV1InstanceConfigPublicIpEip | undefined);
    private _ipType?;
    get ipType(): string;
    set ipType(value: string);
    get ipTypeInput(): string | undefined;
    private _bandwidth;
    get bandwidth(): AsConfigurationV1InstanceConfigPublicIpEipBandwidthOutputReference;
    putBandwidth(value: AsConfigurationV1InstanceConfigPublicIpEipBandwidth): void;
    get bandwidthInput(): AsConfigurationV1InstanceConfigPublicIpEipBandwidth | undefined;
}
export interface AsConfigurationV1InstanceConfigPublicIp {
    /**
    * eip block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_configuration_v1#eip AsConfigurationV1#eip}
    */
    readonly eip: AsConfigurationV1InstanceConfigPublicIpEip;
}
export declare function asConfigurationV1InstanceConfigPublicIpToTerraform(struct?: AsConfigurationV1InstanceConfigPublicIpOutputReference | AsConfigurationV1InstanceConfigPublicIp): any;
export declare function asConfigurationV1InstanceConfigPublicIpToHclTerraform(struct?: AsConfigurationV1InstanceConfigPublicIpOutputReference | AsConfigurationV1InstanceConfigPublicIp): any;
export declare class AsConfigurationV1InstanceConfigPublicIpOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AsConfigurationV1InstanceConfigPublicIp | undefined;
    set internalValue(value: AsConfigurationV1InstanceConfigPublicIp | undefined);
    private _eip;
    get eip(): AsConfigurationV1InstanceConfigPublicIpEipOutputReference;
    putEip(value: AsConfigurationV1InstanceConfigPublicIpEip): void;
    get eipInput(): AsConfigurationV1InstanceConfigPublicIpEip | undefined;
}
export interface AsConfigurationV1InstanceConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_configuration_v1#flavor AsConfigurationV1#flavor}
    */
    readonly flavor?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_configuration_v1#image AsConfigurationV1#image}
    */
    readonly image?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_configuration_v1#instance_id AsConfigurationV1#instance_id}
    */
    readonly instanceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_configuration_v1#key_name AsConfigurationV1#key_name}
    */
    readonly keyName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_configuration_v1#metadata AsConfigurationV1#metadata}
    */
    readonly metadata?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_configuration_v1#security_groups AsConfigurationV1#security_groups}
    */
    readonly securityGroups?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_configuration_v1#user_data AsConfigurationV1#user_data}
    */
    readonly userData?: string;
    /**
    * disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_configuration_v1#disk AsConfigurationV1#disk}
    */
    readonly disk?: AsConfigurationV1InstanceConfigDisk[] | cdktf.IResolvable;
    /**
    * personality block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_configuration_v1#personality AsConfigurationV1#personality}
    */
    readonly personality?: AsConfigurationV1InstanceConfigPersonality[] | cdktf.IResolvable;
    /**
    * public_ip block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_configuration_v1#public_ip AsConfigurationV1#public_ip}
    */
    readonly publicIp?: AsConfigurationV1InstanceConfigPublicIp;
}
export declare function asConfigurationV1InstanceConfigToTerraform(struct?: AsConfigurationV1InstanceConfigOutputReference | AsConfigurationV1InstanceConfig): any;
export declare function asConfigurationV1InstanceConfigToHclTerraform(struct?: AsConfigurationV1InstanceConfigOutputReference | AsConfigurationV1InstanceConfig): any;
export declare class AsConfigurationV1InstanceConfigOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AsConfigurationV1InstanceConfig | undefined;
    set internalValue(value: AsConfigurationV1InstanceConfig | undefined);
    private _flavor?;
    get flavor(): string;
    set flavor(value: string);
    resetFlavor(): void;
    get flavorInput(): string | undefined;
    private _image?;
    get image(): string;
    set image(value: string);
    resetImage(): void;
    get imageInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    resetInstanceId(): void;
    get instanceIdInput(): string | undefined;
    private _keyName?;
    get keyName(): string;
    set keyName(value: string);
    get keyNameInput(): string | undefined;
    private _metadata?;
    get metadata(): {
        [key: string]: string;
    };
    set metadata(value: {
        [key: string]: string;
    });
    resetMetadata(): void;
    get metadataInput(): {
        [key: string]: string;
    } | undefined;
    private _securityGroups?;
    get securityGroups(): string[];
    set securityGroups(value: string[]);
    resetSecurityGroups(): void;
    get securityGroupsInput(): string[] | undefined;
    private _userData?;
    get userData(): string;
    set userData(value: string);
    resetUserData(): void;
    get userDataInput(): string | undefined;
    private _disk;
    get disk(): AsConfigurationV1InstanceConfigDiskList;
    putDisk(value: AsConfigurationV1InstanceConfigDisk[] | cdktf.IResolvable): void;
    resetDisk(): void;
    get diskInput(): cdktf.IResolvable | AsConfigurationV1InstanceConfigDisk[] | undefined;
    private _personality;
    get personality(): AsConfigurationV1InstanceConfigPersonalityList;
    putPersonality(value: AsConfigurationV1InstanceConfigPersonality[] | cdktf.IResolvable): void;
    resetPersonality(): void;
    get personalityInput(): cdktf.IResolvable | AsConfigurationV1InstanceConfigPersonality[] | undefined;
    private _publicIp;
    get publicIp(): AsConfigurationV1InstanceConfigPublicIpOutputReference;
    putPublicIp(value: AsConfigurationV1InstanceConfigPublicIp): void;
    resetPublicIp(): void;
    get publicIpInput(): AsConfigurationV1InstanceConfigPublicIp | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_configuration_v1 opentelekomcloud_as_configuration_v1}
*/
export declare class AsConfigurationV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_as_configuration_v1";
    /**
    * Generates CDKTF code for importing a AsConfigurationV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AsConfigurationV1 to import
    * @param importFromId The id of the existing AsConfigurationV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_configuration_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AsConfigurationV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/as_configuration_v1 opentelekomcloud_as_configuration_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AsConfigurationV1Config
    */
    constructor(scope: Construct, id: string, config: AsConfigurationV1Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _scalingConfigurationName?;
    get scalingConfigurationName(): string;
    set scalingConfigurationName(value: string);
    get scalingConfigurationNameInput(): string | undefined;
    private _instanceConfig;
    get instanceConfig(): AsConfigurationV1InstanceConfigOutputReference;
    putInstanceConfig(value: AsConfigurationV1InstanceConfig): void;
    get instanceConfigInput(): AsConfigurationV1InstanceConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

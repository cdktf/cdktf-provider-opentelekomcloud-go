/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface NetworkingNetworkV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_network_v2#admin_state_up NetworkingNetworkV2#admin_state_up}
    */
    readonly adminStateUp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_network_v2#id NetworkingNetworkV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_network_v2#name NetworkingNetworkV2#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_network_v2#region NetworkingNetworkV2#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_network_v2#shared NetworkingNetworkV2#shared}
    */
    readonly shared?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_network_v2#tenant_id NetworkingNetworkV2#tenant_id}
    */
    readonly tenantId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_network_v2#value_specs NetworkingNetworkV2#value_specs}
    */
    readonly valueSpecs?: {
        [key: string]: string;
    };
    /**
    * segments block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_network_v2#segments NetworkingNetworkV2#segments}
    */
    readonly segments?: NetworkingNetworkV2Segments[] | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_network_v2#timeouts NetworkingNetworkV2#timeouts}
    */
    readonly timeouts?: NetworkingNetworkV2Timeouts;
}
export interface NetworkingNetworkV2Segments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_network_v2#network_type NetworkingNetworkV2#network_type}
    */
    readonly networkType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_network_v2#physical_network NetworkingNetworkV2#physical_network}
    */
    readonly physicalNetwork?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_network_v2#segmentation_id NetworkingNetworkV2#segmentation_id}
    */
    readonly segmentationId?: number;
}
export declare function networkingNetworkV2SegmentsToTerraform(struct?: NetworkingNetworkV2Segments | cdktf.IResolvable): any;
export declare function networkingNetworkV2SegmentsToHclTerraform(struct?: NetworkingNetworkV2Segments | cdktf.IResolvable): any;
export declare class NetworkingNetworkV2SegmentsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NetworkingNetworkV2Segments | cdktf.IResolvable | undefined;
    set internalValue(value: NetworkingNetworkV2Segments | cdktf.IResolvable | undefined);
    private _networkType?;
    get networkType(): string;
    set networkType(value: string);
    resetNetworkType(): void;
    get networkTypeInput(): string | undefined;
    private _physicalNetwork?;
    get physicalNetwork(): string;
    set physicalNetwork(value: string);
    resetPhysicalNetwork(): void;
    get physicalNetworkInput(): string | undefined;
    private _segmentationId?;
    get segmentationId(): number;
    set segmentationId(value: number);
    resetSegmentationId(): void;
    get segmentationIdInput(): number | undefined;
}
export declare class NetworkingNetworkV2SegmentsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: NetworkingNetworkV2Segments[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NetworkingNetworkV2SegmentsOutputReference;
}
export interface NetworkingNetworkV2Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_network_v2#create NetworkingNetworkV2#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_network_v2#delete NetworkingNetworkV2#delete}
    */
    readonly delete?: string;
}
export declare function networkingNetworkV2TimeoutsToTerraform(struct?: NetworkingNetworkV2Timeouts | cdktf.IResolvable): any;
export declare function networkingNetworkV2TimeoutsToHclTerraform(struct?: NetworkingNetworkV2Timeouts | cdktf.IResolvable): any;
export declare class NetworkingNetworkV2TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NetworkingNetworkV2Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: NetworkingNetworkV2Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_network_v2 opentelekomcloud_networking_network_v2}
*/
export declare class NetworkingNetworkV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_networking_network_v2";
    /**
    * Generates CDKTF code for importing a NetworkingNetworkV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the NetworkingNetworkV2 to import
    * @param importFromId The id of the existing NetworkingNetworkV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_network_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the NetworkingNetworkV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_network_v2 opentelekomcloud_networking_network_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NetworkingNetworkV2Config = {}
    */
    constructor(scope: Construct, id: string, config?: NetworkingNetworkV2Config);
    private _adminStateUp?;
    get adminStateUp(): string;
    set adminStateUp(value: string);
    resetAdminStateUp(): void;
    get adminStateUpInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _shared?;
    get shared(): string;
    set shared(value: string);
    resetShared(): void;
    get sharedInput(): string | undefined;
    private _tenantId?;
    get tenantId(): string;
    set tenantId(value: string);
    resetTenantId(): void;
    get tenantIdInput(): string | undefined;
    private _valueSpecs?;
    get valueSpecs(): {
        [key: string]: string;
    };
    set valueSpecs(value: {
        [key: string]: string;
    });
    resetValueSpecs(): void;
    get valueSpecsInput(): {
        [key: string]: string;
    } | undefined;
    private _segments;
    get segments(): NetworkingNetworkV2SegmentsList;
    putSegments(value: NetworkingNetworkV2Segments[] | cdktf.IResolvable): void;
    resetSegments(): void;
    get segmentsInput(): cdktf.IResolvable | NetworkingNetworkV2Segments[] | undefined;
    private _timeouts;
    get timeouts(): NetworkingNetworkV2TimeoutsOutputReference;
    putTimeouts(value: NetworkingNetworkV2Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | NetworkingNetworkV2Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface HssHostProtectionV5Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/hss_host_protection_v5#charging_mode HssHostProtectionV5#charging_mode}
    */
    readonly chargingMode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/hss_host_protection_v5#host_id HssHostProtectionV5#host_id}
    */
    readonly hostId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/hss_host_protection_v5#id HssHostProtectionV5#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/hss_host_protection_v5#is_wait_host_available HssHostProtectionV5#is_wait_host_available}
    */
    readonly isWaitHostAvailable?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/hss_host_protection_v5#resource_id HssHostProtectionV5#resource_id}
    */
    readonly resourceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/hss_host_protection_v5#version HssHostProtectionV5#version}
    */
    readonly version: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/hss_host_protection_v5#timeouts HssHostProtectionV5#timeouts}
    */
    readonly timeouts?: HssHostProtectionV5Timeouts;
}
export interface HssHostProtectionV5Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/hss_host_protection_v5#create HssHostProtectionV5#create}
    */
    readonly create?: string;
}
export declare function hssHostProtectionV5TimeoutsToTerraform(struct?: HssHostProtectionV5Timeouts | cdktf.IResolvable): any;
export declare function hssHostProtectionV5TimeoutsToHclTerraform(struct?: HssHostProtectionV5Timeouts | cdktf.IResolvable): any;
export declare class HssHostProtectionV5TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): HssHostProtectionV5Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: HssHostProtectionV5Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/hss_host_protection_v5 opentelekomcloud_hss_host_protection_v5}
*/
export declare class HssHostProtectionV5 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_hss_host_protection_v5";
    /**
    * Generates CDKTF code for importing a HssHostProtectionV5 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the HssHostProtectionV5 to import
    * @param importFromId The id of the existing HssHostProtectionV5 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/hss_host_protection_v5#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the HssHostProtectionV5 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/hss_host_protection_v5 opentelekomcloud_hss_host_protection_v5} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options HssHostProtectionV5Config
    */
    constructor(scope: Construct, id: string, config: HssHostProtectionV5Config);
    get agentId(): string;
    get agentStatus(): string;
    get assetValue(): string;
    private _chargingMode?;
    get chargingMode(): string;
    set chargingMode(value: string);
    get chargingModeInput(): string | undefined;
    get detectResult(): string;
    private _hostId?;
    get hostId(): string;
    set hostId(value: string);
    get hostIdInput(): string | undefined;
    get hostName(): string;
    get hostStatus(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isWaitHostAvailable?;
    get isWaitHostAvailable(): boolean | cdktf.IResolvable;
    set isWaitHostAvailable(value: boolean | cdktf.IResolvable);
    resetIsWaitHostAvailable(): void;
    get isWaitHostAvailableInput(): boolean | cdktf.IResolvable | undefined;
    get osType(): string;
    get privateIp(): string;
    get region(): string;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    resetResourceId(): void;
    get resourceIdInput(): string | undefined;
    get status(): string;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
    private _timeouts;
    get timeouts(): HssHostProtectionV5TimeoutsOutputReference;
    putTimeouts(value: HssHostProtectionV5Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | HssHostProtectionV5Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

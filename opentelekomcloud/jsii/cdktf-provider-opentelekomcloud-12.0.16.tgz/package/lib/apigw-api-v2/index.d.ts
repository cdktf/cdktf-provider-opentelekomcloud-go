/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ApigwApiV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#authorizer_id ApigwApiV2#authorizer_id}
    */
    readonly authorizerId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#body_description ApigwApiV2#body_description}
    */
    readonly bodyDescription?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#cors ApigwApiV2#cors}
    */
    readonly cors?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#description ApigwApiV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#failure_response ApigwApiV2#failure_response}
    */
    readonly failureResponse?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#gateway_id ApigwApiV2#gateway_id}
    */
    readonly gatewayId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#group_id ApigwApiV2#group_id}
    */
    readonly groupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#id ApigwApiV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#match_mode ApigwApiV2#match_mode}
    */
    readonly matchMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#name ApigwApiV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#region ApigwApiV2#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#request_method ApigwApiV2#request_method}
    */
    readonly requestMethod: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#request_protocol ApigwApiV2#request_protocol}
    */
    readonly requestProtocol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#request_uri ApigwApiV2#request_uri}
    */
    readonly requestUri: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#response_id ApigwApiV2#response_id}
    */
    readonly responseId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#security_authentication_enabled ApigwApiV2#security_authentication_enabled}
    */
    readonly securityAuthenticationEnabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#security_authentication_type ApigwApiV2#security_authentication_type}
    */
    readonly securityAuthenticationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#success_response ApigwApiV2#success_response}
    */
    readonly successResponse?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#tags ApigwApiV2#tags}
    */
    readonly tags?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#type ApigwApiV2#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#version ApigwApiV2#version}
    */
    readonly version?: string;
    /**
    * backend_params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#backend_params ApigwApiV2#backend_params}
    */
    readonly backendParams?: ApigwApiV2BackendParams[] | cdktf.IResolvable;
    /**
    * func_graph block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#func_graph ApigwApiV2#func_graph}
    */
    readonly funcGraph?: ApigwApiV2FuncGraph;
    /**
    * func_graph_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#func_graph_policy ApigwApiV2#func_graph_policy}
    */
    readonly funcGraphPolicy?: ApigwApiV2FuncGraphPolicy[] | cdktf.IResolvable;
    /**
    * http block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#http ApigwApiV2#http}
    */
    readonly http?: ApigwApiV2Http;
    /**
    * http_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#http_policy ApigwApiV2#http_policy}
    */
    readonly httpPolicy?: ApigwApiV2HttpPolicy[] | cdktf.IResolvable;
    /**
    * mock block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#mock ApigwApiV2#mock}
    */
    readonly mock?: ApigwApiV2Mock;
    /**
    * mock_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#mock_policy ApigwApiV2#mock_policy}
    */
    readonly mockPolicy?: ApigwApiV2MockPolicy[] | cdktf.IResolvable;
    /**
    * request_params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#request_params ApigwApiV2#request_params}
    */
    readonly requestParams?: ApigwApiV2RequestParams[] | cdktf.IResolvable;
}
export interface ApigwApiV2BackendParams {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#description ApigwApiV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#location ApigwApiV2#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#name ApigwApiV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#system_param_type ApigwApiV2#system_param_type}
    */
    readonly systemParamType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#type ApigwApiV2#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#value ApigwApiV2#value}
    */
    readonly value: string;
}
export declare function apigwApiV2BackendParamsToTerraform(struct?: ApigwApiV2BackendParams | cdktf.IResolvable): any;
export declare function apigwApiV2BackendParamsToHclTerraform(struct?: ApigwApiV2BackendParams | cdktf.IResolvable): any;
export declare class ApigwApiV2BackendParamsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigwApiV2BackendParams | cdktf.IResolvable | undefined;
    set internalValue(value: ApigwApiV2BackendParams | cdktf.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _systemParamType?;
    get systemParamType(): string;
    set systemParamType(value: string);
    resetSystemParamType(): void;
    get systemParamTypeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ApigwApiV2BackendParamsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ApigwApiV2BackendParams[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigwApiV2BackendParamsOutputReference;
}
export interface ApigwApiV2FuncGraph {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#authorizer_id ApigwApiV2#authorizer_id}
    */
    readonly authorizerId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#description ApigwApiV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#function_urn ApigwApiV2#function_urn}
    */
    readonly functionUrn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#invocation_type ApigwApiV2#invocation_type}
    */
    readonly invocationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#network_type ApigwApiV2#network_type}
    */
    readonly networkType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#timeout ApigwApiV2#timeout}
    */
    readonly timeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#version ApigwApiV2#version}
    */
    readonly version?: string;
}
export declare function apigwApiV2FuncGraphToTerraform(struct?: ApigwApiV2FuncGraphOutputReference | ApigwApiV2FuncGraph): any;
export declare function apigwApiV2FuncGraphToHclTerraform(struct?: ApigwApiV2FuncGraphOutputReference | ApigwApiV2FuncGraph): any;
export declare class ApigwApiV2FuncGraphOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigwApiV2FuncGraph | undefined;
    set internalValue(value: ApigwApiV2FuncGraph | undefined);
    private _authorizerId?;
    get authorizerId(): string;
    set authorizerId(value: string);
    resetAuthorizerId(): void;
    get authorizerIdInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _functionUrn?;
    get functionUrn(): string;
    set functionUrn(value: string);
    get functionUrnInput(): string | undefined;
    private _invocationType?;
    get invocationType(): string;
    set invocationType(value: string);
    resetInvocationType(): void;
    get invocationTypeInput(): string | undefined;
    private _networkType?;
    get networkType(): string;
    set networkType(value: string);
    resetNetworkType(): void;
    get networkTypeInput(): string | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    resetTimeout(): void;
    get timeoutInput(): number | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export interface ApigwApiV2FuncGraphPolicyBackendParams {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#description ApigwApiV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#location ApigwApiV2#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#name ApigwApiV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#system_param_type ApigwApiV2#system_param_type}
    */
    readonly systemParamType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#type ApigwApiV2#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#value ApigwApiV2#value}
    */
    readonly value: string;
}
export declare function apigwApiV2FuncGraphPolicyBackendParamsToTerraform(struct?: ApigwApiV2FuncGraphPolicyBackendParams | cdktf.IResolvable): any;
export declare function apigwApiV2FuncGraphPolicyBackendParamsToHclTerraform(struct?: ApigwApiV2FuncGraphPolicyBackendParams | cdktf.IResolvable): any;
export declare class ApigwApiV2FuncGraphPolicyBackendParamsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigwApiV2FuncGraphPolicyBackendParams | cdktf.IResolvable | undefined;
    set internalValue(value: ApigwApiV2FuncGraphPolicyBackendParams | cdktf.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _systemParamType?;
    get systemParamType(): string;
    set systemParamType(value: string);
    resetSystemParamType(): void;
    get systemParamTypeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ApigwApiV2FuncGraphPolicyBackendParamsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ApigwApiV2FuncGraphPolicyBackendParams[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigwApiV2FuncGraphPolicyBackendParamsOutputReference;
}
export interface ApigwApiV2FuncGraphPolicyConditions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#origin ApigwApiV2#origin}
    */
    readonly origin?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#param_name ApigwApiV2#param_name}
    */
    readonly paramName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#type ApigwApiV2#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#value ApigwApiV2#value}
    */
    readonly value: string;
}
export declare function apigwApiV2FuncGraphPolicyConditionsToTerraform(struct?: ApigwApiV2FuncGraphPolicyConditions | cdktf.IResolvable): any;
export declare function apigwApiV2FuncGraphPolicyConditionsToHclTerraform(struct?: ApigwApiV2FuncGraphPolicyConditions | cdktf.IResolvable): any;
export declare class ApigwApiV2FuncGraphPolicyConditionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigwApiV2FuncGraphPolicyConditions | cdktf.IResolvable | undefined;
    set internalValue(value: ApigwApiV2FuncGraphPolicyConditions | cdktf.IResolvable | undefined);
    private _origin?;
    get origin(): string;
    set origin(value: string);
    resetOrigin(): void;
    get originInput(): string | undefined;
    private _paramName?;
    get paramName(): string;
    set paramName(value: string);
    resetParamName(): void;
    get paramNameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ApigwApiV2FuncGraphPolicyConditionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ApigwApiV2FuncGraphPolicyConditions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigwApiV2FuncGraphPolicyConditionsOutputReference;
}
export interface ApigwApiV2FuncGraphPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#authorizer_id ApigwApiV2#authorizer_id}
    */
    readonly authorizerId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#effective_mode ApigwApiV2#effective_mode}
    */
    readonly effectiveMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#function_urn ApigwApiV2#function_urn}
    */
    readonly functionUrn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#invocation_type ApigwApiV2#invocation_type}
    */
    readonly invocationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#name ApigwApiV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#network_type ApigwApiV2#network_type}
    */
    readonly networkType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#timeout ApigwApiV2#timeout}
    */
    readonly timeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#version ApigwApiV2#version}
    */
    readonly version?: string;
    /**
    * backend_params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#backend_params ApigwApiV2#backend_params}
    */
    readonly backendParams?: ApigwApiV2FuncGraphPolicyBackendParams[] | cdktf.IResolvable;
    /**
    * conditions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#conditions ApigwApiV2#conditions}
    */
    readonly conditions: ApigwApiV2FuncGraphPolicyConditions[] | cdktf.IResolvable;
}
export declare function apigwApiV2FuncGraphPolicyToTerraform(struct?: ApigwApiV2FuncGraphPolicy | cdktf.IResolvable): any;
export declare function apigwApiV2FuncGraphPolicyToHclTerraform(struct?: ApigwApiV2FuncGraphPolicy | cdktf.IResolvable): any;
export declare class ApigwApiV2FuncGraphPolicyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigwApiV2FuncGraphPolicy | cdktf.IResolvable | undefined;
    set internalValue(value: ApigwApiV2FuncGraphPolicy | cdktf.IResolvable | undefined);
    private _authorizerId?;
    get authorizerId(): string;
    set authorizerId(value: string);
    resetAuthorizerId(): void;
    get authorizerIdInput(): string | undefined;
    private _effectiveMode?;
    get effectiveMode(): string;
    set effectiveMode(value: string);
    resetEffectiveMode(): void;
    get effectiveModeInput(): string | undefined;
    private _functionUrn?;
    get functionUrn(): string;
    set functionUrn(value: string);
    get functionUrnInput(): string | undefined;
    private _invocationType?;
    get invocationType(): string;
    set invocationType(value: string);
    resetInvocationType(): void;
    get invocationTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _networkType?;
    get networkType(): string;
    set networkType(value: string);
    resetNetworkType(): void;
    get networkTypeInput(): string | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    resetTimeout(): void;
    get timeoutInput(): number | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
    private _backendParams;
    get backendParams(): ApigwApiV2FuncGraphPolicyBackendParamsList;
    putBackendParams(value: ApigwApiV2FuncGraphPolicyBackendParams[] | cdktf.IResolvable): void;
    resetBackendParams(): void;
    get backendParamsInput(): cdktf.IResolvable | ApigwApiV2FuncGraphPolicyBackendParams[] | undefined;
    private _conditions;
    get conditions(): ApigwApiV2FuncGraphPolicyConditionsList;
    putConditions(value: ApigwApiV2FuncGraphPolicyConditions[] | cdktf.IResolvable): void;
    get conditionsInput(): cdktf.IResolvable | ApigwApiV2FuncGraphPolicyConditions[] | undefined;
}
export declare class ApigwApiV2FuncGraphPolicyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ApigwApiV2FuncGraphPolicy[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigwApiV2FuncGraphPolicyOutputReference;
}
export interface ApigwApiV2Http {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#authorizer_id ApigwApiV2#authorizer_id}
    */
    readonly authorizerId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#description ApigwApiV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#request_method ApigwApiV2#request_method}
    */
    readonly requestMethod: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#request_protocol ApigwApiV2#request_protocol}
    */
    readonly requestProtocol?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#request_uri ApigwApiV2#request_uri}
    */
    readonly requestUri: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#retry_count ApigwApiV2#retry_count}
    */
    readonly retryCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#ssl_enable ApigwApiV2#ssl_enable}
    */
    readonly sslEnable?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#timeout ApigwApiV2#timeout}
    */
    readonly timeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#url_domain ApigwApiV2#url_domain}
    */
    readonly urlDomain?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#version ApigwApiV2#version}
    */
    readonly version?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#vpc_channel_id ApigwApiV2#vpc_channel_id}
    */
    readonly vpcChannelId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#vpc_channel_proxy_host ApigwApiV2#vpc_channel_proxy_host}
    */
    readonly vpcChannelProxyHost?: string;
}
export declare function apigwApiV2HttpToTerraform(struct?: ApigwApiV2HttpOutputReference | ApigwApiV2Http): any;
export declare function apigwApiV2HttpToHclTerraform(struct?: ApigwApiV2HttpOutputReference | ApigwApiV2Http): any;
export declare class ApigwApiV2HttpOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigwApiV2Http | undefined;
    set internalValue(value: ApigwApiV2Http | undefined);
    private _authorizerId?;
    get authorizerId(): string;
    set authorizerId(value: string);
    resetAuthorizerId(): void;
    get authorizerIdInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _requestMethod?;
    get requestMethod(): string;
    set requestMethod(value: string);
    get requestMethodInput(): string | undefined;
    private _requestProtocol?;
    get requestProtocol(): string;
    set requestProtocol(value: string);
    resetRequestProtocol(): void;
    get requestProtocolInput(): string | undefined;
    private _requestUri?;
    get requestUri(): string;
    set requestUri(value: string);
    get requestUriInput(): string | undefined;
    private _retryCount?;
    get retryCount(): number;
    set retryCount(value: number);
    resetRetryCount(): void;
    get retryCountInput(): number | undefined;
    private _sslEnable?;
    get sslEnable(): boolean | cdktf.IResolvable;
    set sslEnable(value: boolean | cdktf.IResolvable);
    resetSslEnable(): void;
    get sslEnableInput(): boolean | cdktf.IResolvable | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    resetTimeout(): void;
    get timeoutInput(): number | undefined;
    private _urlDomain?;
    get urlDomain(): string;
    set urlDomain(value: string);
    resetUrlDomain(): void;
    get urlDomainInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
    private _vpcChannelId?;
    get vpcChannelId(): string;
    set vpcChannelId(value: string);
    resetVpcChannelId(): void;
    get vpcChannelIdInput(): string | undefined;
    private _vpcChannelProxyHost?;
    get vpcChannelProxyHost(): string;
    set vpcChannelProxyHost(value: string);
    resetVpcChannelProxyHost(): void;
    get vpcChannelProxyHostInput(): string | undefined;
}
export interface ApigwApiV2HttpPolicyBackendParams {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#description ApigwApiV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#location ApigwApiV2#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#name ApigwApiV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#system_param_type ApigwApiV2#system_param_type}
    */
    readonly systemParamType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#type ApigwApiV2#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#value ApigwApiV2#value}
    */
    readonly value: string;
}
export declare function apigwApiV2HttpPolicyBackendParamsToTerraform(struct?: ApigwApiV2HttpPolicyBackendParams | cdktf.IResolvable): any;
export declare function apigwApiV2HttpPolicyBackendParamsToHclTerraform(struct?: ApigwApiV2HttpPolicyBackendParams | cdktf.IResolvable): any;
export declare class ApigwApiV2HttpPolicyBackendParamsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigwApiV2HttpPolicyBackendParams | cdktf.IResolvable | undefined;
    set internalValue(value: ApigwApiV2HttpPolicyBackendParams | cdktf.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _systemParamType?;
    get systemParamType(): string;
    set systemParamType(value: string);
    resetSystemParamType(): void;
    get systemParamTypeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ApigwApiV2HttpPolicyBackendParamsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ApigwApiV2HttpPolicyBackendParams[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigwApiV2HttpPolicyBackendParamsOutputReference;
}
export interface ApigwApiV2HttpPolicyConditions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#origin ApigwApiV2#origin}
    */
    readonly origin?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#param_name ApigwApiV2#param_name}
    */
    readonly paramName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#type ApigwApiV2#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#value ApigwApiV2#value}
    */
    readonly value: string;
}
export declare function apigwApiV2HttpPolicyConditionsToTerraform(struct?: ApigwApiV2HttpPolicyConditions | cdktf.IResolvable): any;
export declare function apigwApiV2HttpPolicyConditionsToHclTerraform(struct?: ApigwApiV2HttpPolicyConditions | cdktf.IResolvable): any;
export declare class ApigwApiV2HttpPolicyConditionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigwApiV2HttpPolicyConditions | cdktf.IResolvable | undefined;
    set internalValue(value: ApigwApiV2HttpPolicyConditions | cdktf.IResolvable | undefined);
    private _origin?;
    get origin(): string;
    set origin(value: string);
    resetOrigin(): void;
    get originInput(): string | undefined;
    private _paramName?;
    get paramName(): string;
    set paramName(value: string);
    resetParamName(): void;
    get paramNameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ApigwApiV2HttpPolicyConditionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ApigwApiV2HttpPolicyConditions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigwApiV2HttpPolicyConditionsOutputReference;
}
export interface ApigwApiV2HttpPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#authorizer_id ApigwApiV2#authorizer_id}
    */
    readonly authorizerId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#effective_mode ApigwApiV2#effective_mode}
    */
    readonly effectiveMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#name ApigwApiV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#request_method ApigwApiV2#request_method}
    */
    readonly requestMethod: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#request_protocol ApigwApiV2#request_protocol}
    */
    readonly requestProtocol?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#request_uri ApigwApiV2#request_uri}
    */
    readonly requestUri: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#retry_count ApigwApiV2#retry_count}
    */
    readonly retryCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#timeout ApigwApiV2#timeout}
    */
    readonly timeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#url_domain ApigwApiV2#url_domain}
    */
    readonly urlDomain?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#vpc_channel_id ApigwApiV2#vpc_channel_id}
    */
    readonly vpcChannelId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#vpc_channel_proxy_host ApigwApiV2#vpc_channel_proxy_host}
    */
    readonly vpcChannelProxyHost?: string;
    /**
    * backend_params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#backend_params ApigwApiV2#backend_params}
    */
    readonly backendParams?: ApigwApiV2HttpPolicyBackendParams[] | cdktf.IResolvable;
    /**
    * conditions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#conditions ApigwApiV2#conditions}
    */
    readonly conditions: ApigwApiV2HttpPolicyConditions[] | cdktf.IResolvable;
}
export declare function apigwApiV2HttpPolicyToTerraform(struct?: ApigwApiV2HttpPolicy | cdktf.IResolvable): any;
export declare function apigwApiV2HttpPolicyToHclTerraform(struct?: ApigwApiV2HttpPolicy | cdktf.IResolvable): any;
export declare class ApigwApiV2HttpPolicyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigwApiV2HttpPolicy | cdktf.IResolvable | undefined;
    set internalValue(value: ApigwApiV2HttpPolicy | cdktf.IResolvable | undefined);
    private _authorizerId?;
    get authorizerId(): string;
    set authorizerId(value: string);
    resetAuthorizerId(): void;
    get authorizerIdInput(): string | undefined;
    private _effectiveMode?;
    get effectiveMode(): string;
    set effectiveMode(value: string);
    resetEffectiveMode(): void;
    get effectiveModeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _requestMethod?;
    get requestMethod(): string;
    set requestMethod(value: string);
    get requestMethodInput(): string | undefined;
    private _requestProtocol?;
    get requestProtocol(): string;
    set requestProtocol(value: string);
    resetRequestProtocol(): void;
    get requestProtocolInput(): string | undefined;
    private _requestUri?;
    get requestUri(): string;
    set requestUri(value: string);
    get requestUriInput(): string | undefined;
    private _retryCount?;
    get retryCount(): number;
    set retryCount(value: number);
    resetRetryCount(): void;
    get retryCountInput(): number | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    resetTimeout(): void;
    get timeoutInput(): number | undefined;
    private _urlDomain?;
    get urlDomain(): string;
    set urlDomain(value: string);
    resetUrlDomain(): void;
    get urlDomainInput(): string | undefined;
    private _vpcChannelId?;
    get vpcChannelId(): string;
    set vpcChannelId(value: string);
    resetVpcChannelId(): void;
    get vpcChannelIdInput(): string | undefined;
    private _vpcChannelProxyHost?;
    get vpcChannelProxyHost(): string;
    set vpcChannelProxyHost(value: string);
    resetVpcChannelProxyHost(): void;
    get vpcChannelProxyHostInput(): string | undefined;
    private _backendParams;
    get backendParams(): ApigwApiV2HttpPolicyBackendParamsList;
    putBackendParams(value: ApigwApiV2HttpPolicyBackendParams[] | cdktf.IResolvable): void;
    resetBackendParams(): void;
    get backendParamsInput(): cdktf.IResolvable | ApigwApiV2HttpPolicyBackendParams[] | undefined;
    private _conditions;
    get conditions(): ApigwApiV2HttpPolicyConditionsList;
    putConditions(value: ApigwApiV2HttpPolicyConditions[] | cdktf.IResolvable): void;
    get conditionsInput(): cdktf.IResolvable | ApigwApiV2HttpPolicyConditions[] | undefined;
}
export declare class ApigwApiV2HttpPolicyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ApigwApiV2HttpPolicy[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigwApiV2HttpPolicyOutputReference;
}
export interface ApigwApiV2Mock {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#authorizer_id ApigwApiV2#authorizer_id}
    */
    readonly authorizerId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#description ApigwApiV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#response ApigwApiV2#response}
    */
    readonly response?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#version ApigwApiV2#version}
    */
    readonly version?: string;
}
export declare function apigwApiV2MockToTerraform(struct?: ApigwApiV2MockOutputReference | ApigwApiV2Mock): any;
export declare function apigwApiV2MockToHclTerraform(struct?: ApigwApiV2MockOutputReference | ApigwApiV2Mock): any;
export declare class ApigwApiV2MockOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigwApiV2Mock | undefined;
    set internalValue(value: ApigwApiV2Mock | undefined);
    private _authorizerId?;
    get authorizerId(): string;
    set authorizerId(value: string);
    resetAuthorizerId(): void;
    get authorizerIdInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _response?;
    get response(): string;
    set response(value: string);
    resetResponse(): void;
    get responseInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export interface ApigwApiV2MockPolicyBackendParams {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#description ApigwApiV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#location ApigwApiV2#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#name ApigwApiV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#system_param_type ApigwApiV2#system_param_type}
    */
    readonly systemParamType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#type ApigwApiV2#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#value ApigwApiV2#value}
    */
    readonly value: string;
}
export declare function apigwApiV2MockPolicyBackendParamsToTerraform(struct?: ApigwApiV2MockPolicyBackendParams | cdktf.IResolvable): any;
export declare function apigwApiV2MockPolicyBackendParamsToHclTerraform(struct?: ApigwApiV2MockPolicyBackendParams | cdktf.IResolvable): any;
export declare class ApigwApiV2MockPolicyBackendParamsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigwApiV2MockPolicyBackendParams | cdktf.IResolvable | undefined;
    set internalValue(value: ApigwApiV2MockPolicyBackendParams | cdktf.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _systemParamType?;
    get systemParamType(): string;
    set systemParamType(value: string);
    resetSystemParamType(): void;
    get systemParamTypeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ApigwApiV2MockPolicyBackendParamsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ApigwApiV2MockPolicyBackendParams[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigwApiV2MockPolicyBackendParamsOutputReference;
}
export interface ApigwApiV2MockPolicyConditions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#origin ApigwApiV2#origin}
    */
    readonly origin?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#param_name ApigwApiV2#param_name}
    */
    readonly paramName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#type ApigwApiV2#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#value ApigwApiV2#value}
    */
    readonly value: string;
}
export declare function apigwApiV2MockPolicyConditionsToTerraform(struct?: ApigwApiV2MockPolicyConditions | cdktf.IResolvable): any;
export declare function apigwApiV2MockPolicyConditionsToHclTerraform(struct?: ApigwApiV2MockPolicyConditions | cdktf.IResolvable): any;
export declare class ApigwApiV2MockPolicyConditionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigwApiV2MockPolicyConditions | cdktf.IResolvable | undefined;
    set internalValue(value: ApigwApiV2MockPolicyConditions | cdktf.IResolvable | undefined);
    private _origin?;
    get origin(): string;
    set origin(value: string);
    resetOrigin(): void;
    get originInput(): string | undefined;
    private _paramName?;
    get paramName(): string;
    set paramName(value: string);
    resetParamName(): void;
    get paramNameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ApigwApiV2MockPolicyConditionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ApigwApiV2MockPolicyConditions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigwApiV2MockPolicyConditionsOutputReference;
}
export interface ApigwApiV2MockPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#authorizer_id ApigwApiV2#authorizer_id}
    */
    readonly authorizerId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#effective_mode ApigwApiV2#effective_mode}
    */
    readonly effectiveMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#name ApigwApiV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#response ApigwApiV2#response}
    */
    readonly response?: string;
    /**
    * backend_params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#backend_params ApigwApiV2#backend_params}
    */
    readonly backendParams?: ApigwApiV2MockPolicyBackendParams[] | cdktf.IResolvable;
    /**
    * conditions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#conditions ApigwApiV2#conditions}
    */
    readonly conditions: ApigwApiV2MockPolicyConditions[] | cdktf.IResolvable;
}
export declare function apigwApiV2MockPolicyToTerraform(struct?: ApigwApiV2MockPolicy | cdktf.IResolvable): any;
export declare function apigwApiV2MockPolicyToHclTerraform(struct?: ApigwApiV2MockPolicy | cdktf.IResolvable): any;
export declare class ApigwApiV2MockPolicyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigwApiV2MockPolicy | cdktf.IResolvable | undefined;
    set internalValue(value: ApigwApiV2MockPolicy | cdktf.IResolvable | undefined);
    private _authorizerId?;
    get authorizerId(): string;
    set authorizerId(value: string);
    resetAuthorizerId(): void;
    get authorizerIdInput(): string | undefined;
    private _effectiveMode?;
    get effectiveMode(): string;
    set effectiveMode(value: string);
    resetEffectiveMode(): void;
    get effectiveModeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _response?;
    get response(): string;
    set response(value: string);
    resetResponse(): void;
    get responseInput(): string | undefined;
    private _backendParams;
    get backendParams(): ApigwApiV2MockPolicyBackendParamsList;
    putBackendParams(value: ApigwApiV2MockPolicyBackendParams[] | cdktf.IResolvable): void;
    resetBackendParams(): void;
    get backendParamsInput(): cdktf.IResolvable | ApigwApiV2MockPolicyBackendParams[] | undefined;
    private _conditions;
    get conditions(): ApigwApiV2MockPolicyConditionsList;
    putConditions(value: ApigwApiV2MockPolicyConditions[] | cdktf.IResolvable): void;
    get conditionsInput(): cdktf.IResolvable | ApigwApiV2MockPolicyConditions[] | undefined;
}
export declare class ApigwApiV2MockPolicyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ApigwApiV2MockPolicy[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigwApiV2MockPolicyOutputReference;
}
export interface ApigwApiV2RequestParams {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#default ApigwApiV2#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#description ApigwApiV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#enumeration ApigwApiV2#enumeration}
    */
    readonly enumeration?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#location ApigwApiV2#location}
    */
    readonly location?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#maximum ApigwApiV2#maximum}
    */
    readonly maximum?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#minimum ApigwApiV2#minimum}
    */
    readonly minimum?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#name ApigwApiV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#passthrough ApigwApiV2#passthrough}
    */
    readonly passthrough?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#required ApigwApiV2#required}
    */
    readonly required?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#sample ApigwApiV2#sample}
    */
    readonly sample?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#type ApigwApiV2#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#validity_check ApigwApiV2#validity_check}
    */
    readonly validityCheck?: boolean | cdktf.IResolvable;
}
export declare function apigwApiV2RequestParamsToTerraform(struct?: ApigwApiV2RequestParams | cdktf.IResolvable): any;
export declare function apigwApiV2RequestParamsToHclTerraform(struct?: ApigwApiV2RequestParams | cdktf.IResolvable): any;
export declare class ApigwApiV2RequestParamsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigwApiV2RequestParams | cdktf.IResolvable | undefined;
    set internalValue(value: ApigwApiV2RequestParams | cdktf.IResolvable | undefined);
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enumeration?;
    get enumeration(): string;
    set enumeration(value: string);
    resetEnumeration(): void;
    get enumerationInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _maximum?;
    get maximum(): number;
    set maximum(value: number);
    resetMaximum(): void;
    get maximumInput(): number | undefined;
    private _minimum?;
    get minimum(): number;
    set minimum(value: number);
    resetMinimum(): void;
    get minimumInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _passthrough?;
    get passthrough(): boolean | cdktf.IResolvable;
    set passthrough(value: boolean | cdktf.IResolvable);
    resetPassthrough(): void;
    get passthroughInput(): boolean | cdktf.IResolvable | undefined;
    private _required?;
    get required(): boolean | cdktf.IResolvable;
    set required(value: boolean | cdktf.IResolvable);
    resetRequired(): void;
    get requiredInput(): boolean | cdktf.IResolvable | undefined;
    private _sample?;
    get sample(): string;
    set sample(value: string);
    resetSample(): void;
    get sampleInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _validityCheck?;
    get validityCheck(): boolean | cdktf.IResolvable;
    set validityCheck(value: boolean | cdktf.IResolvable);
    resetValidityCheck(): void;
    get validityCheckInput(): boolean | cdktf.IResolvable | undefined;
}
export declare class ApigwApiV2RequestParamsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ApigwApiV2RequestParams[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigwApiV2RequestParamsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2 opentelekomcloud_apigw_api_v2}
*/
export declare class ApigwApiV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_apigw_api_v2";
    /**
    * Generates CDKTF code for importing a ApigwApiV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigwApiV2 to import
    * @param importFromId The id of the existing ApigwApiV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigwApiV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_api_v2 opentelekomcloud_apigw_api_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigwApiV2Config
    */
    constructor(scope: Construct, id: string, config: ApigwApiV2Config);
    private _authorizerId?;
    get authorizerId(): string;
    set authorizerId(value: string);
    resetAuthorizerId(): void;
    get authorizerIdInput(): string | undefined;
    private _bodyDescription?;
    get bodyDescription(): string;
    set bodyDescription(value: string);
    resetBodyDescription(): void;
    get bodyDescriptionInput(): string | undefined;
    private _cors?;
    get cors(): boolean | cdktf.IResolvable;
    set cors(value: boolean | cdktf.IResolvable);
    resetCors(): void;
    get corsInput(): boolean | cdktf.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _failureResponse?;
    get failureResponse(): string;
    set failureResponse(value: string);
    resetFailureResponse(): void;
    get failureResponseInput(): string | undefined;
    private _gatewayId?;
    get gatewayId(): string;
    set gatewayId(value: string);
    get gatewayIdInput(): string | undefined;
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    get groupIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _matchMode?;
    get matchMode(): string;
    set matchMode(value: string);
    resetMatchMode(): void;
    get matchModeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get registeredAt(): string;
    private _requestMethod?;
    get requestMethod(): string;
    set requestMethod(value: string);
    get requestMethodInput(): string | undefined;
    private _requestProtocol?;
    get requestProtocol(): string;
    set requestProtocol(value: string);
    get requestProtocolInput(): string | undefined;
    private _requestUri?;
    get requestUri(): string;
    set requestUri(value: string);
    get requestUriInput(): string | undefined;
    private _responseId?;
    get responseId(): string;
    set responseId(value: string);
    resetResponseId(): void;
    get responseIdInput(): string | undefined;
    private _securityAuthenticationEnabled?;
    get securityAuthenticationEnabled(): boolean | cdktf.IResolvable;
    set securityAuthenticationEnabled(value: boolean | cdktf.IResolvable);
    resetSecurityAuthenticationEnabled(): void;
    get securityAuthenticationEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _securityAuthenticationType?;
    get securityAuthenticationType(): string;
    set securityAuthenticationType(value: string);
    resetSecurityAuthenticationType(): void;
    get securityAuthenticationTypeInput(): string | undefined;
    private _successResponse?;
    get successResponse(): string;
    set successResponse(value: string);
    resetSuccessResponse(): void;
    get successResponseInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    get updatedAt(): string;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
    private _backendParams;
    get backendParams(): ApigwApiV2BackendParamsList;
    putBackendParams(value: ApigwApiV2BackendParams[] | cdktf.IResolvable): void;
    resetBackendParams(): void;
    get backendParamsInput(): cdktf.IResolvable | ApigwApiV2BackendParams[] | undefined;
    private _funcGraph;
    get funcGraph(): ApigwApiV2FuncGraphOutputReference;
    putFuncGraph(value: ApigwApiV2FuncGraph): void;
    resetFuncGraph(): void;
    get funcGraphInput(): ApigwApiV2FuncGraph | undefined;
    private _funcGraphPolicy;
    get funcGraphPolicy(): ApigwApiV2FuncGraphPolicyList;
    putFuncGraphPolicy(value: ApigwApiV2FuncGraphPolicy[] | cdktf.IResolvable): void;
    resetFuncGraphPolicy(): void;
    get funcGraphPolicyInput(): cdktf.IResolvable | ApigwApiV2FuncGraphPolicy[] | undefined;
    private _http;
    get http(): ApigwApiV2HttpOutputReference;
    putHttp(value: ApigwApiV2Http): void;
    resetHttp(): void;
    get httpInput(): ApigwApiV2Http | undefined;
    private _httpPolicy;
    get httpPolicy(): ApigwApiV2HttpPolicyList;
    putHttpPolicy(value: ApigwApiV2HttpPolicy[] | cdktf.IResolvable): void;
    resetHttpPolicy(): void;
    get httpPolicyInput(): cdktf.IResolvable | ApigwApiV2HttpPolicy[] | undefined;
    private _mock;
    get mock(): ApigwApiV2MockOutputReference;
    putMock(value: ApigwApiV2Mock): void;
    resetMock(): void;
    get mockInput(): ApigwApiV2Mock | undefined;
    private _mockPolicy;
    get mockPolicy(): ApigwApiV2MockPolicyList;
    putMockPolicy(value: ApigwApiV2MockPolicy[] | cdktf.IResolvable): void;
    resetMockPolicy(): void;
    get mockPolicyInput(): cdktf.IResolvable | ApigwApiV2MockPolicy[] | undefined;
    private _requestParams;
    get requestParams(): ApigwApiV2RequestParamsList;
    putRequestParams(value: ApigwApiV2RequestParams[] | cdktf.IResolvable): void;
    resetRequestParams(): void;
    get requestParamsInput(): cdktf.IResolvable | ApigwApiV2RequestParams[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

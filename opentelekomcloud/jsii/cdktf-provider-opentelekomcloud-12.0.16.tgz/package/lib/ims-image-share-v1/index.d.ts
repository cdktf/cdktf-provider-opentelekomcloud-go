/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ImsImageShareV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ims_image_share_v1#id ImsImageShareV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ims_image_share_v1#source_image_id ImsImageShareV1#source_image_id}
    */
    readonly sourceImageId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ims_image_share_v1#target_project_ids ImsImageShareV1#target_project_ids}
    */
    readonly targetProjectIds: string[];
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ims_image_share_v1#timeouts ImsImageShareV1#timeouts}
    */
    readonly timeouts?: ImsImageShareV1Timeouts;
}
export interface ImsImageShareV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ims_image_share_v1#create ImsImageShareV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ims_image_share_v1#delete ImsImageShareV1#delete}
    */
    readonly delete?: string;
}
export declare function imsImageShareV1TimeoutsToTerraform(struct?: ImsImageShareV1Timeouts | cdktf.IResolvable): any;
export declare function imsImageShareV1TimeoutsToHclTerraform(struct?: ImsImageShareV1Timeouts | cdktf.IResolvable): any;
export declare class ImsImageShareV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ImsImageShareV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: ImsImageShareV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ims_image_share_v1 opentelekomcloud_ims_image_share_v1}
*/
export declare class ImsImageShareV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_ims_image_share_v1";
    /**
    * Generates CDKTF code for importing a ImsImageShareV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ImsImageShareV1 to import
    * @param importFromId The id of the existing ImsImageShareV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ims_image_share_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ImsImageShareV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ims_image_share_v1 opentelekomcloud_ims_image_share_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ImsImageShareV1Config
    */
    constructor(scope: Construct, id: string, config: ImsImageShareV1Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get region(): string;
    private _sourceImageId?;
    get sourceImageId(): string;
    set sourceImageId(value: string);
    get sourceImageIdInput(): string | undefined;
    private _targetProjectIds?;
    get targetProjectIds(): string[];
    set targetProjectIds(value: string[]);
    get targetProjectIdsInput(): string[] | undefined;
    private _timeouts;
    get timeouts(): ImsImageShareV1TimeoutsOutputReference;
    putTimeouts(value: ImsImageShareV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | ImsImageShareV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

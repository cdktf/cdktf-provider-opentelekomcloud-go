/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudTaurusdbMysqlInstanceV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_instance_v3#id DataOpentelekomcloudTaurusdbMysqlInstanceV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_instance_v3#name DataOpentelekomcloudTaurusdbMysqlInstanceV3#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_instance_v3#region DataOpentelekomcloudTaurusdbMysqlInstanceV3#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_instance_v3#subnet_id DataOpentelekomcloudTaurusdbMysqlInstanceV3#subnet_id}
    */
    readonly subnetId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_instance_v3#vpc_id DataOpentelekomcloudTaurusdbMysqlInstanceV3#vpc_id}
    */
    readonly vpcId?: string;
}
export interface DataOpentelekomcloudTaurusdbMysqlInstanceV3BackupStrategy {
}
export declare function dataOpentelekomcloudTaurusdbMysqlInstanceV3BackupStrategyToTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlInstanceV3BackupStrategy): any;
export declare function dataOpentelekomcloudTaurusdbMysqlInstanceV3BackupStrategyToHclTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlInstanceV3BackupStrategy): any;
export declare class DataOpentelekomcloudTaurusdbMysqlInstanceV3BackupStrategyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudTaurusdbMysqlInstanceV3BackupStrategy | undefined;
    set internalValue(value: DataOpentelekomcloudTaurusdbMysqlInstanceV3BackupStrategy | undefined);
    get keepDays(): number;
    get startTime(): string;
}
export declare class DataOpentelekomcloudTaurusdbMysqlInstanceV3BackupStrategyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudTaurusdbMysqlInstanceV3BackupStrategyOutputReference;
}
export interface DataOpentelekomcloudTaurusdbMysqlInstanceV3Datastore {
}
export declare function dataOpentelekomcloudTaurusdbMysqlInstanceV3DatastoreToTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlInstanceV3Datastore): any;
export declare function dataOpentelekomcloudTaurusdbMysqlInstanceV3DatastoreToHclTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlInstanceV3Datastore): any;
export declare class DataOpentelekomcloudTaurusdbMysqlInstanceV3DatastoreOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudTaurusdbMysqlInstanceV3Datastore | undefined;
    set internalValue(value: DataOpentelekomcloudTaurusdbMysqlInstanceV3Datastore | undefined);
    get engine(): string;
    get version(): string;
}
export declare class DataOpentelekomcloudTaurusdbMysqlInstanceV3DatastoreList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudTaurusdbMysqlInstanceV3DatastoreOutputReference;
}
export interface DataOpentelekomcloudTaurusdbMysqlInstanceV3Nodes {
}
export declare function dataOpentelekomcloudTaurusdbMysqlInstanceV3NodesToTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlInstanceV3Nodes): any;
export declare function dataOpentelekomcloudTaurusdbMysqlInstanceV3NodesToHclTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlInstanceV3Nodes): any;
export declare class DataOpentelekomcloudTaurusdbMysqlInstanceV3NodesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudTaurusdbMysqlInstanceV3Nodes | undefined;
    set internalValue(value: DataOpentelekomcloudTaurusdbMysqlInstanceV3Nodes | undefined);
    get availabilityZone(): string;
    get id(): string;
    get name(): string;
    get privateReadIp(): string;
    get status(): string;
    get type(): string;
}
export declare class DataOpentelekomcloudTaurusdbMysqlInstanceV3NodesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudTaurusdbMysqlInstanceV3NodesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_instance_v3 opentelekomcloud_taurusdb_mysql_instance_v3}
*/
export declare class DataOpentelekomcloudTaurusdbMysqlInstanceV3 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_taurusdb_mysql_instance_v3";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudTaurusdbMysqlInstanceV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudTaurusdbMysqlInstanceV3 to import
    * @param importFromId The id of the existing DataOpentelekomcloudTaurusdbMysqlInstanceV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_instance_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudTaurusdbMysqlInstanceV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_instance_v3 opentelekomcloud_taurusdb_mysql_instance_v3} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudTaurusdbMysqlInstanceV3Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudTaurusdbMysqlInstanceV3Config);
    get availabilityZoneMode(): string;
    private _backupStrategy;
    get backupStrategy(): DataOpentelekomcloudTaurusdbMysqlInstanceV3BackupStrategyList;
    get configurationId(): string;
    private _datastore;
    get datastore(): DataOpentelekomcloudTaurusdbMysqlInstanceV3DatastoreList;
    get dbUserName(): string;
    get flavor(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get masterAvailabilityZone(): string;
    get mode(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _nodes;
    get nodes(): DataOpentelekomcloudTaurusdbMysqlInstanceV3NodesList;
    get port(): number;
    get privateWriteIp(): string;
    get readReplicas(): number;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get securityGroupId(): string;
    get status(): string;
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    resetSubnetId(): void;
    get subnetIdInput(): string | undefined;
    get timeZone(): string;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    resetVpcId(): void;
    get vpcIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

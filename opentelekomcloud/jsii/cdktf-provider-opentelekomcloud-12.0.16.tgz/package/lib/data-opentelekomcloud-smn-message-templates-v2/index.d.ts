/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudSmnMessageTemplatesV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/smn_message_templates_v2#id DataOpentelekomcloudSmnMessageTemplatesV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/smn_message_templates_v2#name DataOpentelekomcloudSmnMessageTemplatesV2#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/smn_message_templates_v2#protocol DataOpentelekomcloudSmnMessageTemplatesV2#protocol}
    */
    readonly protocol?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/smn_message_templates_v2#template_id DataOpentelekomcloudSmnMessageTemplatesV2#template_id}
    */
    readonly templateId?: string;
}
export interface DataOpentelekomcloudSmnMessageTemplatesV2Templates {
}
export declare function dataOpentelekomcloudSmnMessageTemplatesV2TemplatesToTerraform(struct?: DataOpentelekomcloudSmnMessageTemplatesV2Templates): any;
export declare function dataOpentelekomcloudSmnMessageTemplatesV2TemplatesToHclTerraform(struct?: DataOpentelekomcloudSmnMessageTemplatesV2Templates): any;
export declare class DataOpentelekomcloudSmnMessageTemplatesV2TemplatesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudSmnMessageTemplatesV2Templates | undefined;
    set internalValue(value: DataOpentelekomcloudSmnMessageTemplatesV2Templates | undefined);
    get createdAt(): string;
    get id(): string;
    get name(): string;
    get protocol(): string;
    get tagNames(): string[];
    get updatedAt(): string;
}
export declare class DataOpentelekomcloudSmnMessageTemplatesV2TemplatesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudSmnMessageTemplatesV2TemplatesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/smn_message_templates_v2 opentelekomcloud_smn_message_templates_v2}
*/
export declare class DataOpentelekomcloudSmnMessageTemplatesV2 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_smn_message_templates_v2";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudSmnMessageTemplatesV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudSmnMessageTemplatesV2 to import
    * @param importFromId The id of the existing DataOpentelekomcloudSmnMessageTemplatesV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/smn_message_templates_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudSmnMessageTemplatesV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/smn_message_templates_v2 opentelekomcloud_smn_message_templates_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudSmnMessageTemplatesV2Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudSmnMessageTemplatesV2Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    resetProtocol(): void;
    get protocolInput(): string | undefined;
    private _templateId?;
    get templateId(): string;
    set templateId(value: string);
    resetTemplateId(): void;
    get templateIdInput(): string | undefined;
    private _templates;
    get templates(): DataOpentelekomcloudSmnMessageTemplatesV2TemplatesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

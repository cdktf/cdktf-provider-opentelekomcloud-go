/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface RmsPolicyAssignmentEvaluateV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_policy_assignment_evaluate_v1#id RmsPolicyAssignmentEvaluateV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_policy_assignment_evaluate_v1#policy_assignment_id RmsPolicyAssignmentEvaluateV1#policy_assignment_id}
    */
    readonly policyAssignmentId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_policy_assignment_evaluate_v1 opentelekomcloud_rms_policy_assignment_evaluate_v1}
*/
export declare class RmsPolicyAssignmentEvaluateV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_rms_policy_assignment_evaluate_v1";
    /**
    * Generates CDKTF code for importing a RmsPolicyAssignmentEvaluateV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RmsPolicyAssignmentEvaluateV1 to import
    * @param importFromId The id of the existing RmsPolicyAssignmentEvaluateV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_policy_assignment_evaluate_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RmsPolicyAssignmentEvaluateV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_policy_assignment_evaluate_v1 opentelekomcloud_rms_policy_assignment_evaluate_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RmsPolicyAssignmentEvaluateV1Config
    */
    constructor(scope: Construct, id: string, config: RmsPolicyAssignmentEvaluateV1Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _policyAssignmentId?;
    get policyAssignmentId(): string;
    set policyAssignmentId(value: string);
    get policyAssignmentIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface WafDedicatedAlarmMaskingRuleV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_alarm_masking_rule_v1#description WafDedicatedAlarmMaskingRuleV1#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_alarm_masking_rule_v1#domains WafDedicatedAlarmMaskingRuleV1#domains}
    */
    readonly domains: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_alarm_masking_rule_v1#id WafDedicatedAlarmMaskingRuleV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_alarm_masking_rule_v1#policy_id WafDedicatedAlarmMaskingRuleV1#policy_id}
    */
    readonly policyId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_alarm_masking_rule_v1#rule WafDedicatedAlarmMaskingRuleV1#rule}
    */
    readonly rule: string;
    /**
    * advanced_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_alarm_masking_rule_v1#advanced_settings WafDedicatedAlarmMaskingRuleV1#advanced_settings}
    */
    readonly advancedSettings?: WafDedicatedAlarmMaskingRuleV1AdvancedSettings;
    /**
    * conditions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_alarm_masking_rule_v1#conditions WafDedicatedAlarmMaskingRuleV1#conditions}
    */
    readonly conditions: WafDedicatedAlarmMaskingRuleV1Conditions[] | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_alarm_masking_rule_v1#timeouts WafDedicatedAlarmMaskingRuleV1#timeouts}
    */
    readonly timeouts?: WafDedicatedAlarmMaskingRuleV1Timeouts;
}
export interface WafDedicatedAlarmMaskingRuleV1AdvancedSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_alarm_masking_rule_v1#contents WafDedicatedAlarmMaskingRuleV1#contents}
    */
    readonly contents?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_alarm_masking_rule_v1#index WafDedicatedAlarmMaskingRuleV1#index}
    */
    readonly index?: string;
}
export declare function wafDedicatedAlarmMaskingRuleV1AdvancedSettingsToTerraform(struct?: WafDedicatedAlarmMaskingRuleV1AdvancedSettingsOutputReference | WafDedicatedAlarmMaskingRuleV1AdvancedSettings): any;
export declare function wafDedicatedAlarmMaskingRuleV1AdvancedSettingsToHclTerraform(struct?: WafDedicatedAlarmMaskingRuleV1AdvancedSettingsOutputReference | WafDedicatedAlarmMaskingRuleV1AdvancedSettings): any;
export declare class WafDedicatedAlarmMaskingRuleV1AdvancedSettingsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WafDedicatedAlarmMaskingRuleV1AdvancedSettings | undefined;
    set internalValue(value: WafDedicatedAlarmMaskingRuleV1AdvancedSettings | undefined);
    private _contents?;
    get contents(): string[];
    set contents(value: string[]);
    resetContents(): void;
    get contentsInput(): string[] | undefined;
    private _index?;
    get index(): string;
    set index(value: string);
    resetIndex(): void;
    get indexInput(): string | undefined;
}
export interface WafDedicatedAlarmMaskingRuleV1Conditions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_alarm_masking_rule_v1#category WafDedicatedAlarmMaskingRuleV1#category}
    */
    readonly category: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_alarm_masking_rule_v1#contents WafDedicatedAlarmMaskingRuleV1#contents}
    */
    readonly contents?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_alarm_masking_rule_v1#index WafDedicatedAlarmMaskingRuleV1#index}
    */
    readonly index?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_alarm_masking_rule_v1#logic_operation WafDedicatedAlarmMaskingRuleV1#logic_operation}
    */
    readonly logicOperation: string;
}
export declare function wafDedicatedAlarmMaskingRuleV1ConditionsToTerraform(struct?: WafDedicatedAlarmMaskingRuleV1Conditions | cdktf.IResolvable): any;
export declare function wafDedicatedAlarmMaskingRuleV1ConditionsToHclTerraform(struct?: WafDedicatedAlarmMaskingRuleV1Conditions | cdktf.IResolvable): any;
export declare class WafDedicatedAlarmMaskingRuleV1ConditionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WafDedicatedAlarmMaskingRuleV1Conditions | cdktf.IResolvable | undefined;
    set internalValue(value: WafDedicatedAlarmMaskingRuleV1Conditions | cdktf.IResolvable | undefined);
    private _category?;
    get category(): string;
    set category(value: string);
    get categoryInput(): string | undefined;
    private _contents?;
    get contents(): string[];
    set contents(value: string[]);
    resetContents(): void;
    get contentsInput(): string[] | undefined;
    private _index?;
    get index(): string;
    set index(value: string);
    resetIndex(): void;
    get indexInput(): string | undefined;
    private _logicOperation?;
    get logicOperation(): string;
    set logicOperation(value: string);
    get logicOperationInput(): string | undefined;
}
export declare class WafDedicatedAlarmMaskingRuleV1ConditionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WafDedicatedAlarmMaskingRuleV1Conditions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WafDedicatedAlarmMaskingRuleV1ConditionsOutputReference;
}
export interface WafDedicatedAlarmMaskingRuleV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_alarm_masking_rule_v1#create WafDedicatedAlarmMaskingRuleV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_alarm_masking_rule_v1#delete WafDedicatedAlarmMaskingRuleV1#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_alarm_masking_rule_v1#update WafDedicatedAlarmMaskingRuleV1#update}
    */
    readonly update?: string;
}
export declare function wafDedicatedAlarmMaskingRuleV1TimeoutsToTerraform(struct?: WafDedicatedAlarmMaskingRuleV1Timeouts | cdktf.IResolvable): any;
export declare function wafDedicatedAlarmMaskingRuleV1TimeoutsToHclTerraform(struct?: WafDedicatedAlarmMaskingRuleV1Timeouts | cdktf.IResolvable): any;
export declare class WafDedicatedAlarmMaskingRuleV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WafDedicatedAlarmMaskingRuleV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: WafDedicatedAlarmMaskingRuleV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_alarm_masking_rule_v1 opentelekomcloud_waf_dedicated_alarm_masking_rule_v1}
*/
export declare class WafDedicatedAlarmMaskingRuleV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_waf_dedicated_alarm_masking_rule_v1";
    /**
    * Generates CDKTF code for importing a WafDedicatedAlarmMaskingRuleV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WafDedicatedAlarmMaskingRuleV1 to import
    * @param importFromId The id of the existing WafDedicatedAlarmMaskingRuleV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_alarm_masking_rule_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WafDedicatedAlarmMaskingRuleV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_alarm_masking_rule_v1 opentelekomcloud_waf_dedicated_alarm_masking_rule_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WafDedicatedAlarmMaskingRuleV1Config
    */
    constructor(scope: Construct, id: string, config: WafDedicatedAlarmMaskingRuleV1Config);
    get createdAt(): number;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _domains?;
    get domains(): string[];
    set domains(value: string[]);
    get domainsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    get policyIdInput(): string | undefined;
    private _rule?;
    get rule(): string;
    set rule(value: string);
    get ruleInput(): string | undefined;
    get status(): number;
    private _advancedSettings;
    get advancedSettings(): WafDedicatedAlarmMaskingRuleV1AdvancedSettingsOutputReference;
    putAdvancedSettings(value: WafDedicatedAlarmMaskingRuleV1AdvancedSettings): void;
    resetAdvancedSettings(): void;
    get advancedSettingsInput(): WafDedicatedAlarmMaskingRuleV1AdvancedSettings | undefined;
    private _conditions;
    get conditions(): WafDedicatedAlarmMaskingRuleV1ConditionsList;
    putConditions(value: WafDedicatedAlarmMaskingRuleV1Conditions[] | cdktf.IResolvable): void;
    get conditionsInput(): cdktf.IResolvable | WafDedicatedAlarmMaskingRuleV1Conditions[] | undefined;
    private _timeouts;
    get timeouts(): WafDedicatedAlarmMaskingRuleV1TimeoutsOutputReference;
    putTimeouts(value: WafDedicatedAlarmMaskingRuleV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | WafDedicatedAlarmMaskingRuleV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

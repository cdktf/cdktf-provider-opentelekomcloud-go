/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface VpcepServiceV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpcep_service_v1#approval_enabled VpcepServiceV1#approval_enabled}
    */
    readonly approvalEnabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpcep_service_v1#description VpcepServiceV1#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpcep_service_v1#id VpcepServiceV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpcep_service_v1#name VpcepServiceV1#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpcep_service_v1#pool_id VpcepServiceV1#pool_id}
    */
    readonly poolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpcep_service_v1#port_id VpcepServiceV1#port_id}
    */
    readonly portId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpcep_service_v1#server_type VpcepServiceV1#server_type}
    */
    readonly serverType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpcep_service_v1#service_type VpcepServiceV1#service_type}
    */
    readonly serviceType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpcep_service_v1#tags VpcepServiceV1#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpcep_service_v1#tcp_proxy VpcepServiceV1#tcp_proxy}
    */
    readonly tcpProxy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpcep_service_v1#vip_port_id VpcepServiceV1#vip_port_id}
    */
    readonly vipPortId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpcep_service_v1#vpc_id VpcepServiceV1#vpc_id}
    */
    readonly vpcId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpcep_service_v1#whitelist VpcepServiceV1#whitelist}
    */
    readonly whitelist?: string[];
    /**
    * port block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpcep_service_v1#port VpcepServiceV1#port}
    */
    readonly port: VpcepServiceV1Port[] | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpcep_service_v1#timeouts VpcepServiceV1#timeouts}
    */
    readonly timeouts?: VpcepServiceV1Timeouts;
}
export interface VpcepServiceV1Connections {
}
export declare function vpcepServiceV1ConnectionsToTerraform(struct?: VpcepServiceV1Connections): any;
export declare function vpcepServiceV1ConnectionsToHclTerraform(struct?: VpcepServiceV1Connections): any;
export declare class VpcepServiceV1ConnectionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): VpcepServiceV1Connections | undefined;
    set internalValue(value: VpcepServiceV1Connections | undefined);
    get createdAt(): string;
    get description(): string;
    get domainId(): string;
    get endpointId(): string;
    get packetId(): number;
    get status(): string;
    get updatedAt(): string;
}
export declare class VpcepServiceV1ConnectionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): VpcepServiceV1ConnectionsOutputReference;
}
export interface VpcepServiceV1Port {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpcep_service_v1#client_port VpcepServiceV1#client_port}
    */
    readonly clientPort: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpcep_service_v1#protocol VpcepServiceV1#protocol}
    */
    readonly protocol?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpcep_service_v1#server_port VpcepServiceV1#server_port}
    */
    readonly serverPort: number;
}
export declare function vpcepServiceV1PortToTerraform(struct?: VpcepServiceV1Port | cdktf.IResolvable): any;
export declare function vpcepServiceV1PortToHclTerraform(struct?: VpcepServiceV1Port | cdktf.IResolvable): any;
export declare class VpcepServiceV1PortOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): VpcepServiceV1Port | cdktf.IResolvable | undefined;
    set internalValue(value: VpcepServiceV1Port | cdktf.IResolvable | undefined);
    private _clientPort?;
    get clientPort(): number;
    set clientPort(value: number);
    get clientPortInput(): number | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    resetProtocol(): void;
    get protocolInput(): string | undefined;
    private _serverPort?;
    get serverPort(): number;
    set serverPort(value: number);
    get serverPortInput(): number | undefined;
}
export declare class VpcepServiceV1PortList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: VpcepServiceV1Port[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): VpcepServiceV1PortOutputReference;
}
export interface VpcepServiceV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpcep_service_v1#default VpcepServiceV1#default}
    */
    readonly default?: string;
}
export declare function vpcepServiceV1TimeoutsToTerraform(struct?: VpcepServiceV1Timeouts | cdktf.IResolvable): any;
export declare function vpcepServiceV1TimeoutsToHclTerraform(struct?: VpcepServiceV1Timeouts | cdktf.IResolvable): any;
export declare class VpcepServiceV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VpcepServiceV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: VpcepServiceV1Timeouts | cdktf.IResolvable | undefined);
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpcep_service_v1 opentelekomcloud_vpcep_service_v1}
*/
export declare class VpcepServiceV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_vpcep_service_v1";
    /**
    * Generates CDKTF code for importing a VpcepServiceV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VpcepServiceV1 to import
    * @param importFromId The id of the existing VpcepServiceV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpcep_service_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VpcepServiceV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpcep_service_v1 opentelekomcloud_vpcep_service_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VpcepServiceV1Config
    */
    constructor(scope: Construct, id: string, config: VpcepServiceV1Config);
    private _approvalEnabled?;
    get approvalEnabled(): boolean | cdktf.IResolvable;
    set approvalEnabled(value: boolean | cdktf.IResolvable);
    resetApprovalEnabled(): void;
    get approvalEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _connections;
    get connections(): VpcepServiceV1ConnectionsList;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _poolId?;
    get poolId(): string;
    set poolId(value: string);
    resetPoolId(): void;
    get poolIdInput(): string | undefined;
    private _portId?;
    get portId(): string;
    set portId(value: string);
    get portIdInput(): string | undefined;
    private _serverType?;
    get serverType(): string;
    set serverType(value: string);
    get serverTypeInput(): string | undefined;
    private _serviceType?;
    get serviceType(): string;
    set serviceType(value: string);
    resetServiceType(): void;
    get serviceTypeInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tcpProxy?;
    get tcpProxy(): string;
    set tcpProxy(value: string);
    resetTcpProxy(): void;
    get tcpProxyInput(): string | undefined;
    private _vipPortId?;
    get vipPortId(): string;
    set vipPortId(value: string);
    resetVipPortId(): void;
    get vipPortIdInput(): string | undefined;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    get vpcIdInput(): string | undefined;
    private _whitelist?;
    get whitelist(): string[];
    set whitelist(value: string[]);
    resetWhitelist(): void;
    get whitelistInput(): string[] | undefined;
    private _port;
    get port(): VpcepServiceV1PortList;
    putPort(value: VpcepServiceV1Port[] | cdktf.IResolvable): void;
    get portInput(): cdktf.IResolvable | VpcepServiceV1Port[] | undefined;
    private _timeouts;
    get timeouts(): VpcepServiceV1TimeoutsOutputReference;
    putTimeouts(value: VpcepServiceV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | VpcepServiceV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

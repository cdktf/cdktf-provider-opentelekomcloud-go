/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudErRouteTablesV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/er_route_tables_v3#id DataOpentelekomcloudErRouteTablesV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/er_route_tables_v3#instance_id DataOpentelekomcloudErRouteTablesV3#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/er_route_tables_v3#name DataOpentelekomcloudErRouteTablesV3#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/er_route_tables_v3#route_table_id DataOpentelekomcloudErRouteTablesV3#route_table_id}
    */
    readonly routeTableId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/er_route_tables_v3#tags DataOpentelekomcloudErRouteTablesV3#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
export interface DataOpentelekomcloudErRouteTablesV3RouteTablesAssociations {
}
export declare function dataOpentelekomcloudErRouteTablesV3RouteTablesAssociationsToTerraform(struct?: DataOpentelekomcloudErRouteTablesV3RouteTablesAssociations): any;
export declare function dataOpentelekomcloudErRouteTablesV3RouteTablesAssociationsToHclTerraform(struct?: DataOpentelekomcloudErRouteTablesV3RouteTablesAssociations): any;
export declare class DataOpentelekomcloudErRouteTablesV3RouteTablesAssociationsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudErRouteTablesV3RouteTablesAssociations | undefined;
    set internalValue(value: DataOpentelekomcloudErRouteTablesV3RouteTablesAssociations | undefined);
    get attachmentId(): string;
    get attachmentType(): string;
    get id(): string;
}
export declare class DataOpentelekomcloudErRouteTablesV3RouteTablesAssociationsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudErRouteTablesV3RouteTablesAssociationsOutputReference;
}
export interface DataOpentelekomcloudErRouteTablesV3RouteTablesPropagations {
}
export declare function dataOpentelekomcloudErRouteTablesV3RouteTablesPropagationsToTerraform(struct?: DataOpentelekomcloudErRouteTablesV3RouteTablesPropagations): any;
export declare function dataOpentelekomcloudErRouteTablesV3RouteTablesPropagationsToHclTerraform(struct?: DataOpentelekomcloudErRouteTablesV3RouteTablesPropagations): any;
export declare class DataOpentelekomcloudErRouteTablesV3RouteTablesPropagationsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudErRouteTablesV3RouteTablesPropagations | undefined;
    set internalValue(value: DataOpentelekomcloudErRouteTablesV3RouteTablesPropagations | undefined);
    get attachmentId(): string;
    get attachmentType(): string;
    get id(): string;
}
export declare class DataOpentelekomcloudErRouteTablesV3RouteTablesPropagationsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudErRouteTablesV3RouteTablesPropagationsOutputReference;
}
export interface DataOpentelekomcloudErRouteTablesV3RouteTablesRoutesAttachments {
}
export declare function dataOpentelekomcloudErRouteTablesV3RouteTablesRoutesAttachmentsToTerraform(struct?: DataOpentelekomcloudErRouteTablesV3RouteTablesRoutesAttachments): any;
export declare function dataOpentelekomcloudErRouteTablesV3RouteTablesRoutesAttachmentsToHclTerraform(struct?: DataOpentelekomcloudErRouteTablesV3RouteTablesRoutesAttachments): any;
export declare class DataOpentelekomcloudErRouteTablesV3RouteTablesRoutesAttachmentsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudErRouteTablesV3RouteTablesRoutesAttachments | undefined;
    set internalValue(value: DataOpentelekomcloudErRouteTablesV3RouteTablesRoutesAttachments | undefined);
    get attachmentId(): string;
    get attachmentType(): string;
    get resourceId(): string;
}
export declare class DataOpentelekomcloudErRouteTablesV3RouteTablesRoutesAttachmentsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudErRouteTablesV3RouteTablesRoutesAttachmentsOutputReference;
}
export interface DataOpentelekomcloudErRouteTablesV3RouteTablesRoutes {
}
export declare function dataOpentelekomcloudErRouteTablesV3RouteTablesRoutesToTerraform(struct?: DataOpentelekomcloudErRouteTablesV3RouteTablesRoutes): any;
export declare function dataOpentelekomcloudErRouteTablesV3RouteTablesRoutesToHclTerraform(struct?: DataOpentelekomcloudErRouteTablesV3RouteTablesRoutes): any;
export declare class DataOpentelekomcloudErRouteTablesV3RouteTablesRoutesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudErRouteTablesV3RouteTablesRoutes | undefined;
    set internalValue(value: DataOpentelekomcloudErRouteTablesV3RouteTablesRoutes | undefined);
    private _attachments;
    get attachments(): DataOpentelekomcloudErRouteTablesV3RouteTablesRoutesAttachmentsList;
    get destination(): string;
    get id(): string;
    get isBlackhole(): cdktf.IResolvable;
}
export declare class DataOpentelekomcloudErRouteTablesV3RouteTablesRoutesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudErRouteTablesV3RouteTablesRoutesOutputReference;
}
export interface DataOpentelekomcloudErRouteTablesV3RouteTables {
}
export declare function dataOpentelekomcloudErRouteTablesV3RouteTablesToTerraform(struct?: DataOpentelekomcloudErRouteTablesV3RouteTables): any;
export declare function dataOpentelekomcloudErRouteTablesV3RouteTablesToHclTerraform(struct?: DataOpentelekomcloudErRouteTablesV3RouteTables): any;
export declare class DataOpentelekomcloudErRouteTablesV3RouteTablesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudErRouteTablesV3RouteTables | undefined;
    set internalValue(value: DataOpentelekomcloudErRouteTablesV3RouteTables | undefined);
    private _associations;
    get associations(): DataOpentelekomcloudErRouteTablesV3RouteTablesAssociationsList;
    get createdAt(): string;
    get description(): string;
    get id(): string;
    get name(): string;
    private _propagations;
    get propagations(): DataOpentelekomcloudErRouteTablesV3RouteTablesPropagationsList;
    private _routes;
    get routes(): DataOpentelekomcloudErRouteTablesV3RouteTablesRoutesList;
    private _tags;
    get tags(): cdktf.StringMap;
    get updatedAt(): string;
}
export declare class DataOpentelekomcloudErRouteTablesV3RouteTablesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudErRouteTablesV3RouteTablesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/er_route_tables_v3 opentelekomcloud_er_route_tables_v3}
*/
export declare class DataOpentelekomcloudErRouteTablesV3 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_er_route_tables_v3";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudErRouteTablesV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudErRouteTablesV3 to import
    * @param importFromId The id of the existing DataOpentelekomcloudErRouteTablesV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/er_route_tables_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudErRouteTablesV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/er_route_tables_v3 opentelekomcloud_er_route_tables_v3} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudErRouteTablesV3Config
    */
    constructor(scope: Construct, id: string, config: DataOpentelekomcloudErRouteTablesV3Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _routeTableId?;
    get routeTableId(): string;
    set routeTableId(value: string);
    resetRouteTableId(): void;
    get routeTableIdInput(): string | undefined;
    private _routeTables;
    get routeTables(): DataOpentelekomcloudErRouteTablesV3RouteTablesList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

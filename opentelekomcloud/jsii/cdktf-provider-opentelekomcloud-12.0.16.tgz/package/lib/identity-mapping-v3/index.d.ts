/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface IdentityMappingV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_mapping_v3#id IdentityMappingV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_mapping_v3#mapping_id IdentityMappingV3#mapping_id}
    */
    readonly mappingId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_mapping_v3#rules IdentityMappingV3#rules}
    */
    readonly rules: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_mapping_v3 opentelekomcloud_identity_mapping_v3}
*/
export declare class IdentityMappingV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_identity_mapping_v3";
    /**
    * Generates CDKTF code for importing a IdentityMappingV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IdentityMappingV3 to import
    * @param importFromId The id of the existing IdentityMappingV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_mapping_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IdentityMappingV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_mapping_v3 opentelekomcloud_identity_mapping_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IdentityMappingV3Config
    */
    constructor(scope: Construct, id: string, config: IdentityMappingV3Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _links;
    get links(): cdktf.StringMap;
    private _mappingId?;
    get mappingId(): string;
    set mappingId(value: string);
    get mappingIdInput(): string | undefined;
    private _rules?;
    get rules(): string;
    set rules(value: string);
    get rulesInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

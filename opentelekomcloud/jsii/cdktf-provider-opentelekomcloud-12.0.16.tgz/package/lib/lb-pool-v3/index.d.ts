/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface LbPoolV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_pool_v3#description LbPoolV3#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_pool_v3#id LbPoolV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_pool_v3#lb_algorithm LbPoolV3#lb_algorithm}
    */
    readonly lbAlgorithm: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_pool_v3#listener_id LbPoolV3#listener_id}
    */
    readonly listenerId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_pool_v3#loadbalancer_id LbPoolV3#loadbalancer_id}
    */
    readonly loadbalancerId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_pool_v3#member_deletion_protection LbPoolV3#member_deletion_protection}
    */
    readonly memberDeletionProtection?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_pool_v3#name LbPoolV3#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_pool_v3#project_id LbPoolV3#project_id}
    */
    readonly projectId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_pool_v3#protocol LbPoolV3#protocol}
    */
    readonly protocol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_pool_v3#type LbPoolV3#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_pool_v3#vpc_id LbPoolV3#vpc_id}
    */
    readonly vpcId?: string;
    /**
    * session_persistence block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_pool_v3#session_persistence LbPoolV3#session_persistence}
    */
    readonly sessionPersistence?: LbPoolV3SessionPersistence;
}
export interface LbPoolV3SessionPersistence {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_pool_v3#cookie_name LbPoolV3#cookie_name}
    */
    readonly cookieName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_pool_v3#persistence_timeout LbPoolV3#persistence_timeout}
    */
    readonly persistenceTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_pool_v3#type LbPoolV3#type}
    */
    readonly type: string;
}
export declare function lbPoolV3SessionPersistenceToTerraform(struct?: LbPoolV3SessionPersistenceOutputReference | LbPoolV3SessionPersistence): any;
export declare function lbPoolV3SessionPersistenceToHclTerraform(struct?: LbPoolV3SessionPersistenceOutputReference | LbPoolV3SessionPersistence): any;
export declare class LbPoolV3SessionPersistenceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LbPoolV3SessionPersistence | undefined;
    set internalValue(value: LbPoolV3SessionPersistence | undefined);
    private _cookieName?;
    get cookieName(): string;
    set cookieName(value: string);
    resetCookieName(): void;
    get cookieNameInput(): string | undefined;
    private _persistenceTimeout?;
    get persistenceTimeout(): number;
    set persistenceTimeout(value: number);
    resetPersistenceTimeout(): void;
    get persistenceTimeoutInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_pool_v3 opentelekomcloud_lb_pool_v3}
*/
export declare class LbPoolV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_lb_pool_v3";
    /**
    * Generates CDKTF code for importing a LbPoolV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LbPoolV3 to import
    * @param importFromId The id of the existing LbPoolV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_pool_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LbPoolV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_pool_v3 opentelekomcloud_lb_pool_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LbPoolV3Config
    */
    constructor(scope: Construct, id: string, config: LbPoolV3Config);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ipVersion(): string;
    private _lbAlgorithm?;
    get lbAlgorithm(): string;
    set lbAlgorithm(value: string);
    get lbAlgorithmInput(): string | undefined;
    private _listenerId?;
    get listenerId(): string;
    set listenerId(value: string);
    resetListenerId(): void;
    get listenerIdInput(): string | undefined;
    private _loadbalancerId?;
    get loadbalancerId(): string;
    set loadbalancerId(value: string);
    resetLoadbalancerId(): void;
    get loadbalancerIdInput(): string | undefined;
    private _memberDeletionProtection?;
    get memberDeletionProtection(): boolean | cdktf.IResolvable;
    set memberDeletionProtection(value: boolean | cdktf.IResolvable);
    resetMemberDeletionProtection(): void;
    get memberDeletionProtectionInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    get protocolInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    resetVpcId(): void;
    get vpcIdInput(): string | undefined;
    private _sessionPersistence;
    get sessionPersistence(): LbPoolV3SessionPersistenceOutputReference;
    putSessionPersistence(value: LbPoolV3SessionPersistence): void;
    resetSessionPersistence(): void;
    get sessionPersistenceInput(): LbPoolV3SessionPersistence | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DmsReassignPartitionsV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_reassign_partitions_v2#execute_at DmsReassignPartitionsV2#execute_at}
    */
    readonly executeAt?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_reassign_partitions_v2#id DmsReassignPartitionsV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_reassign_partitions_v2#instance_id DmsReassignPartitionsV2#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_reassign_partitions_v2#is_schedule DmsReassignPartitionsV2#is_schedule}
    */
    readonly isSchedule?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_reassign_partitions_v2#throttle DmsReassignPartitionsV2#throttle}
    */
    readonly throttle?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_reassign_partitions_v2#time_estimate DmsReassignPartitionsV2#time_estimate}
    */
    readonly timeEstimate?: boolean | cdktf.IResolvable;
    /**
    * reassignments block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_reassign_partitions_v2#reassignments DmsReassignPartitionsV2#reassignments}
    */
    readonly reassignments: DmsReassignPartitionsV2Reassignments[] | cdktf.IResolvable;
}
export interface DmsReassignPartitionsV2ReassignmentsAssignments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_reassign_partitions_v2#partition DmsReassignPartitionsV2#partition}
    */
    readonly partition?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_reassign_partitions_v2#partition_brokers DmsReassignPartitionsV2#partition_brokers}
    */
    readonly partitionBrokers?: number[];
}
export declare function dmsReassignPartitionsV2ReassignmentsAssignmentsToTerraform(struct?: DmsReassignPartitionsV2ReassignmentsAssignments | cdktf.IResolvable): any;
export declare function dmsReassignPartitionsV2ReassignmentsAssignmentsToHclTerraform(struct?: DmsReassignPartitionsV2ReassignmentsAssignments | cdktf.IResolvable): any;
export declare class DmsReassignPartitionsV2ReassignmentsAssignmentsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DmsReassignPartitionsV2ReassignmentsAssignments | cdktf.IResolvable | undefined;
    set internalValue(value: DmsReassignPartitionsV2ReassignmentsAssignments | cdktf.IResolvable | undefined);
    private _partition?;
    get partition(): number;
    set partition(value: number);
    resetPartition(): void;
    get partitionInput(): number | undefined;
    private _partitionBrokers?;
    get partitionBrokers(): number[];
    set partitionBrokers(value: number[]);
    resetPartitionBrokers(): void;
    get partitionBrokersInput(): number[] | undefined;
}
export declare class DmsReassignPartitionsV2ReassignmentsAssignmentsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DmsReassignPartitionsV2ReassignmentsAssignments[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DmsReassignPartitionsV2ReassignmentsAssignmentsOutputReference;
}
export interface DmsReassignPartitionsV2Reassignments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_reassign_partitions_v2#brokers DmsReassignPartitionsV2#brokers}
    */
    readonly brokers?: number[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_reassign_partitions_v2#replication_factor DmsReassignPartitionsV2#replication_factor}
    */
    readonly replicationFactor?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_reassign_partitions_v2#topic DmsReassignPartitionsV2#topic}
    */
    readonly topic: string;
    /**
    * assignments block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_reassign_partitions_v2#assignments DmsReassignPartitionsV2#assignments}
    */
    readonly assignments?: DmsReassignPartitionsV2ReassignmentsAssignments[] | cdktf.IResolvable;
}
export declare function dmsReassignPartitionsV2ReassignmentsToTerraform(struct?: DmsReassignPartitionsV2Reassignments | cdktf.IResolvable): any;
export declare function dmsReassignPartitionsV2ReassignmentsToHclTerraform(struct?: DmsReassignPartitionsV2Reassignments | cdktf.IResolvable): any;
export declare class DmsReassignPartitionsV2ReassignmentsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DmsReassignPartitionsV2Reassignments | cdktf.IResolvable | undefined;
    set internalValue(value: DmsReassignPartitionsV2Reassignments | cdktf.IResolvable | undefined);
    private _brokers?;
    get brokers(): number[];
    set brokers(value: number[]);
    resetBrokers(): void;
    get brokersInput(): number[] | undefined;
    private _replicationFactor?;
    get replicationFactor(): number;
    set replicationFactor(value: number);
    resetReplicationFactor(): void;
    get replicationFactorInput(): number | undefined;
    private _topic?;
    get topic(): string;
    set topic(value: string);
    get topicInput(): string | undefined;
    private _assignments;
    get assignments(): DmsReassignPartitionsV2ReassignmentsAssignmentsList;
    putAssignments(value: DmsReassignPartitionsV2ReassignmentsAssignments[] | cdktf.IResolvable): void;
    resetAssignments(): void;
    get assignmentsInput(): cdktf.IResolvable | DmsReassignPartitionsV2ReassignmentsAssignments[] | undefined;
}
export declare class DmsReassignPartitionsV2ReassignmentsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DmsReassignPartitionsV2Reassignments[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DmsReassignPartitionsV2ReassignmentsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_reassign_partitions_v2 opentelekomcloud_dms_reassign_partitions_v2}
*/
export declare class DmsReassignPartitionsV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_dms_reassign_partitions_v2";
    /**
    * Generates CDKTF code for importing a DmsReassignPartitionsV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DmsReassignPartitionsV2 to import
    * @param importFromId The id of the existing DmsReassignPartitionsV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_reassign_partitions_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DmsReassignPartitionsV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_reassign_partitions_v2 opentelekomcloud_dms_reassign_partitions_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DmsReassignPartitionsV2Config
    */
    constructor(scope: Construct, id: string, config: DmsReassignPartitionsV2Config);
    private _executeAt?;
    get executeAt(): number;
    set executeAt(value: number);
    resetExecuteAt(): void;
    get executeAtInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _isSchedule?;
    get isSchedule(): boolean | cdktf.IResolvable;
    set isSchedule(value: boolean | cdktf.IResolvable);
    resetIsSchedule(): void;
    get isScheduleInput(): boolean | cdktf.IResolvable | undefined;
    get reassignmentTime(): number;
    get region(): string;
    private _throttle?;
    get throttle(): number;
    set throttle(value: number);
    resetThrottle(): void;
    get throttleInput(): number | undefined;
    private _timeEstimate?;
    get timeEstimate(): boolean | cdktf.IResolvable;
    set timeEstimate(value: boolean | cdktf.IResolvable);
    resetTimeEstimate(): void;
    get timeEstimateInput(): boolean | cdktf.IResolvable | undefined;
    private _reassignments;
    get reassignments(): DmsReassignPartitionsV2ReassignmentsList;
    putReassignments(value: DmsReassignPartitionsV2Reassignments[] | cdktf.IResolvable): void;
    get reassignmentsInput(): cdktf.IResolvable | DmsReassignPartitionsV2Reassignments[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface WafDedicatedCcRuleV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_cc_rule_v1#description WafDedicatedCcRuleV1#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_cc_rule_v1#id WafDedicatedCcRuleV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_cc_rule_v1#limit_num WafDedicatedCcRuleV1#limit_num}
    */
    readonly limitNum: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_cc_rule_v1#limit_period WafDedicatedCcRuleV1#limit_period}
    */
    readonly limitPeriod: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_cc_rule_v1#lock_time WafDedicatedCcRuleV1#lock_time}
    */
    readonly lockTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_cc_rule_v1#mode WafDedicatedCcRuleV1#mode}
    */
    readonly mode: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_cc_rule_v1#policy_id WafDedicatedCcRuleV1#policy_id}
    */
    readonly policyId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_cc_rule_v1#tag_category WafDedicatedCcRuleV1#tag_category}
    */
    readonly tagCategory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_cc_rule_v1#tag_contents WafDedicatedCcRuleV1#tag_contents}
    */
    readonly tagContents?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_cc_rule_v1#tag_index WafDedicatedCcRuleV1#tag_index}
    */
    readonly tagIndex?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_cc_rule_v1#tag_type WafDedicatedCcRuleV1#tag_type}
    */
    readonly tagType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_cc_rule_v1#unlock_num WafDedicatedCcRuleV1#unlock_num}
    */
    readonly unlockNum?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_cc_rule_v1#url WafDedicatedCcRuleV1#url}
    */
    readonly url: string;
    /**
    * action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_cc_rule_v1#action WafDedicatedCcRuleV1#action}
    */
    readonly action: WafDedicatedCcRuleV1Action[] | cdktf.IResolvable;
    /**
    * conditions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_cc_rule_v1#conditions WafDedicatedCcRuleV1#conditions}
    */
    readonly conditions?: WafDedicatedCcRuleV1Conditions[] | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_cc_rule_v1#timeouts WafDedicatedCcRuleV1#timeouts}
    */
    readonly timeouts?: WafDedicatedCcRuleV1Timeouts;
}
export interface WafDedicatedCcRuleV1Action {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_cc_rule_v1#category WafDedicatedCcRuleV1#category}
    */
    readonly category: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_cc_rule_v1#content WafDedicatedCcRuleV1#content}
    */
    readonly content?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_cc_rule_v1#content_type WafDedicatedCcRuleV1#content_type}
    */
    readonly contentType?: string;
}
export declare function wafDedicatedCcRuleV1ActionToTerraform(struct?: WafDedicatedCcRuleV1Action | cdktf.IResolvable): any;
export declare function wafDedicatedCcRuleV1ActionToHclTerraform(struct?: WafDedicatedCcRuleV1Action | cdktf.IResolvable): any;
export declare class WafDedicatedCcRuleV1ActionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WafDedicatedCcRuleV1Action | cdktf.IResolvable | undefined;
    set internalValue(value: WafDedicatedCcRuleV1Action | cdktf.IResolvable | undefined);
    private _category?;
    get category(): string;
    set category(value: string);
    get categoryInput(): string | undefined;
    private _content?;
    get content(): string;
    set content(value: string);
    resetContent(): void;
    get contentInput(): string | undefined;
    private _contentType?;
    get contentType(): string;
    set contentType(value: string);
    resetContentType(): void;
    get contentTypeInput(): string | undefined;
}
export declare class WafDedicatedCcRuleV1ActionList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WafDedicatedCcRuleV1Action[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WafDedicatedCcRuleV1ActionOutputReference;
}
export interface WafDedicatedCcRuleV1Conditions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_cc_rule_v1#category WafDedicatedCcRuleV1#category}
    */
    readonly category: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_cc_rule_v1#contents WafDedicatedCcRuleV1#contents}
    */
    readonly contents?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_cc_rule_v1#index WafDedicatedCcRuleV1#index}
    */
    readonly index?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_cc_rule_v1#logic_operation WafDedicatedCcRuleV1#logic_operation}
    */
    readonly logicOperation: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_cc_rule_v1#value_list_id WafDedicatedCcRuleV1#value_list_id}
    */
    readonly valueListId?: string;
}
export declare function wafDedicatedCcRuleV1ConditionsToTerraform(struct?: WafDedicatedCcRuleV1Conditions | cdktf.IResolvable): any;
export declare function wafDedicatedCcRuleV1ConditionsToHclTerraform(struct?: WafDedicatedCcRuleV1Conditions | cdktf.IResolvable): any;
export declare class WafDedicatedCcRuleV1ConditionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WafDedicatedCcRuleV1Conditions | cdktf.IResolvable | undefined;
    set internalValue(value: WafDedicatedCcRuleV1Conditions | cdktf.IResolvable | undefined);
    private _category?;
    get category(): string;
    set category(value: string);
    get categoryInput(): string | undefined;
    private _contents?;
    get contents(): string[];
    set contents(value: string[]);
    resetContents(): void;
    get contentsInput(): string[] | undefined;
    private _index?;
    get index(): string;
    set index(value: string);
    resetIndex(): void;
    get indexInput(): string | undefined;
    private _logicOperation?;
    get logicOperation(): string;
    set logicOperation(value: string);
    get logicOperationInput(): string | undefined;
    private _valueListId?;
    get valueListId(): string;
    set valueListId(value: string);
    resetValueListId(): void;
    get valueListIdInput(): string | undefined;
}
export declare class WafDedicatedCcRuleV1ConditionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WafDedicatedCcRuleV1Conditions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WafDedicatedCcRuleV1ConditionsOutputReference;
}
export interface WafDedicatedCcRuleV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_cc_rule_v1#create WafDedicatedCcRuleV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_cc_rule_v1#delete WafDedicatedCcRuleV1#delete}
    */
    readonly delete?: string;
}
export declare function wafDedicatedCcRuleV1TimeoutsToTerraform(struct?: WafDedicatedCcRuleV1Timeouts | cdktf.IResolvable): any;
export declare function wafDedicatedCcRuleV1TimeoutsToHclTerraform(struct?: WafDedicatedCcRuleV1Timeouts | cdktf.IResolvable): any;
export declare class WafDedicatedCcRuleV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WafDedicatedCcRuleV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: WafDedicatedCcRuleV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_cc_rule_v1 opentelekomcloud_waf_dedicated_cc_rule_v1}
*/
export declare class WafDedicatedCcRuleV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_waf_dedicated_cc_rule_v1";
    /**
    * Generates CDKTF code for importing a WafDedicatedCcRuleV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WafDedicatedCcRuleV1 to import
    * @param importFromId The id of the existing WafDedicatedCcRuleV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_cc_rule_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WafDedicatedCcRuleV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_cc_rule_v1 opentelekomcloud_waf_dedicated_cc_rule_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WafDedicatedCcRuleV1Config
    */
    constructor(scope: Construct, id: string, config: WafDedicatedCcRuleV1Config);
    get createdAt(): number;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _limitNum?;
    get limitNum(): number;
    set limitNum(value: number);
    get limitNumInput(): number | undefined;
    private _limitPeriod?;
    get limitPeriod(): number;
    set limitPeriod(value: number);
    get limitPeriodInput(): number | undefined;
    private _lockTime?;
    get lockTime(): number;
    set lockTime(value: number);
    resetLockTime(): void;
    get lockTimeInput(): number | undefined;
    private _mode?;
    get mode(): number;
    set mode(value: number);
    get modeInput(): number | undefined;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    get policyIdInput(): string | undefined;
    get status(): number;
    private _tagCategory?;
    get tagCategory(): string;
    set tagCategory(value: string);
    resetTagCategory(): void;
    get tagCategoryInput(): string | undefined;
    private _tagContents?;
    get tagContents(): string[];
    set tagContents(value: string[]);
    resetTagContents(): void;
    get tagContentsInput(): string[] | undefined;
    private _tagIndex?;
    get tagIndex(): string;
    set tagIndex(value: string);
    resetTagIndex(): void;
    get tagIndexInput(): string | undefined;
    private _tagType?;
    get tagType(): string;
    set tagType(value: string);
    get tagTypeInput(): string | undefined;
    private _unlockNum?;
    get unlockNum(): number;
    set unlockNum(value: number);
    resetUnlockNum(): void;
    get unlockNumInput(): number | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _action;
    get action(): WafDedicatedCcRuleV1ActionList;
    putAction(value: WafDedicatedCcRuleV1Action[] | cdktf.IResolvable): void;
    get actionInput(): cdktf.IResolvable | WafDedicatedCcRuleV1Action[] | undefined;
    private _conditions;
    get conditions(): WafDedicatedCcRuleV1ConditionsList;
    putConditions(value: WafDedicatedCcRuleV1Conditions[] | cdktf.IResolvable): void;
    resetConditions(): void;
    get conditionsInput(): cdktf.IResolvable | WafDedicatedCcRuleV1Conditions[] | undefined;
    private _timeouts;
    get timeouts(): WafDedicatedCcRuleV1TimeoutsOutputReference;
    putTimeouts(value: WafDedicatedCcRuleV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | WafDedicatedCcRuleV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

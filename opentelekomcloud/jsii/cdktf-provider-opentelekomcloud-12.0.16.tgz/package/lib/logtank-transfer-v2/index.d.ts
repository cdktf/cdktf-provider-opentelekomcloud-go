/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface LogtankTransferV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/logtank_transfer_v2#dir_prefix_name LogtankTransferV2#dir_prefix_name}
    */
    readonly dirPrefixName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/logtank_transfer_v2#id LogtankTransferV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/logtank_transfer_v2#log_group_id LogtankTransferV2#log_group_id}
    */
    readonly logGroupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/logtank_transfer_v2#log_stream_ids LogtankTransferV2#log_stream_ids}
    */
    readonly logStreamIds: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/logtank_transfer_v2#obs_bucket_name LogtankTransferV2#obs_bucket_name}
    */
    readonly obsBucketName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/logtank_transfer_v2#period LogtankTransferV2#period}
    */
    readonly period: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/logtank_transfer_v2#period_unit LogtankTransferV2#period_unit}
    */
    readonly periodUnit: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/logtank_transfer_v2#prefix_name LogtankTransferV2#prefix_name}
    */
    readonly prefixName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/logtank_transfer_v2#storage_format LogtankTransferV2#storage_format}
    */
    readonly storageFormat: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/logtank_transfer_v2#switch_on LogtankTransferV2#switch_on}
    */
    readonly switchOn?: boolean | cdktf.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/logtank_transfer_v2 opentelekomcloud_logtank_transfer_v2}
*/
export declare class LogtankTransferV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_logtank_transfer_v2";
    /**
    * Generates CDKTF code for importing a LogtankTransferV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LogtankTransferV2 to import
    * @param importFromId The id of the existing LogtankTransferV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/logtank_transfer_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LogtankTransferV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/logtank_transfer_v2 opentelekomcloud_logtank_transfer_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LogtankTransferV2Config
    */
    constructor(scope: Construct, id: string, config: LogtankTransferV2Config);
    get createTime(): number;
    private _dirPrefixName?;
    get dirPrefixName(): string;
    set dirPrefixName(value: string);
    resetDirPrefixName(): void;
    get dirPrefixNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _logGroupId?;
    get logGroupId(): string;
    set logGroupId(value: string);
    get logGroupIdInput(): string | undefined;
    get logGroupName(): string;
    private _logStreamIds?;
    get logStreamIds(): string[];
    set logStreamIds(value: string[]);
    get logStreamIdsInput(): string[] | undefined;
    get logTransferMode(): string;
    get logTransferType(): string;
    private _obsBucketName?;
    get obsBucketName(): string;
    set obsBucketName(value: string);
    get obsBucketNameInput(): string | undefined;
    get obsEncryptionEnable(): cdktf.IResolvable;
    get obsEncryptionId(): string;
    private _period?;
    get period(): number;
    set period(value: number);
    get periodInput(): number | undefined;
    private _periodUnit?;
    get periodUnit(): string;
    set periodUnit(value: string);
    get periodUnitInput(): string | undefined;
    private _prefixName?;
    get prefixName(): string;
    set prefixName(value: string);
    resetPrefixName(): void;
    get prefixNameInput(): string | undefined;
    get status(): string;
    private _storageFormat?;
    get storageFormat(): string;
    set storageFormat(value: string);
    get storageFormatInput(): string | undefined;
    private _switchOn?;
    get switchOn(): boolean | cdktf.IResolvable;
    set switchOn(value: boolean | cdktf.IResolvable);
    resetSwitchOn(): void;
    get switchOnInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

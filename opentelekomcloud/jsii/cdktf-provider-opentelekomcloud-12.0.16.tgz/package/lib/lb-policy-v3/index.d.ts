/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface LbPolicyV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3#action LbPolicyV3#action}
    */
    readonly action: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3#description LbPolicyV3#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3#id LbPolicyV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3#listener_id LbPolicyV3#listener_id}
    */
    readonly listenerId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3#name LbPolicyV3#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3#position LbPolicyV3#position}
    */
    readonly position?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3#priority LbPolicyV3#priority}
    */
    readonly priority?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3#project_id LbPolicyV3#project_id}
    */
    readonly projectId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3#redirect_listener_id LbPolicyV3#redirect_listener_id}
    */
    readonly redirectListenerId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3#redirect_pool_id LbPolicyV3#redirect_pool_id}
    */
    readonly redirectPoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3#redirect_url LbPolicyV3#redirect_url}
    */
    readonly redirectUrl?: string;
    /**
    * fixed_response_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3#fixed_response_config LbPolicyV3#fixed_response_config}
    */
    readonly fixedResponseConfig?: LbPolicyV3FixedResponseConfig;
    /**
    * redirect_pools_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3#redirect_pools_config LbPolicyV3#redirect_pools_config}
    */
    readonly redirectPoolsConfig?: LbPolicyV3RedirectPoolsConfig[] | cdktf.IResolvable;
    /**
    * redirect_url_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3#redirect_url_config LbPolicyV3#redirect_url_config}
    */
    readonly redirectUrlConfig?: LbPolicyV3RedirectUrlConfig;
    /**
    * rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3#rules LbPolicyV3#rules}
    */
    readonly rules?: LbPolicyV3Rules[] | cdktf.IResolvable;
}
export interface LbPolicyV3FixedResponseConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3#content_type LbPolicyV3#content_type}
    */
    readonly contentType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3#message_body LbPolicyV3#message_body}
    */
    readonly messageBody?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3#status_code LbPolicyV3#status_code}
    */
    readonly statusCode: string;
}
export declare function lbPolicyV3FixedResponseConfigToTerraform(struct?: LbPolicyV3FixedResponseConfigOutputReference | LbPolicyV3FixedResponseConfig): any;
export declare function lbPolicyV3FixedResponseConfigToHclTerraform(struct?: LbPolicyV3FixedResponseConfigOutputReference | LbPolicyV3FixedResponseConfig): any;
export declare class LbPolicyV3FixedResponseConfigOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LbPolicyV3FixedResponseConfig | undefined;
    set internalValue(value: LbPolicyV3FixedResponseConfig | undefined);
    private _contentType?;
    get contentType(): string;
    set contentType(value: string);
    resetContentType(): void;
    get contentTypeInput(): string | undefined;
    private _messageBody?;
    get messageBody(): string;
    set messageBody(value: string);
    resetMessageBody(): void;
    get messageBodyInput(): string | undefined;
    private _statusCode?;
    get statusCode(): string;
    set statusCode(value: string);
    get statusCodeInput(): string | undefined;
}
export interface LbPolicyV3RedirectPoolsConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3#pool_id LbPolicyV3#pool_id}
    */
    readonly poolId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3#weight LbPolicyV3#weight}
    */
    readonly weight: number;
}
export declare function lbPolicyV3RedirectPoolsConfigToTerraform(struct?: LbPolicyV3RedirectPoolsConfig | cdktf.IResolvable): any;
export declare function lbPolicyV3RedirectPoolsConfigToHclTerraform(struct?: LbPolicyV3RedirectPoolsConfig | cdktf.IResolvable): any;
export declare class LbPolicyV3RedirectPoolsConfigOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LbPolicyV3RedirectPoolsConfig | cdktf.IResolvable | undefined;
    set internalValue(value: LbPolicyV3RedirectPoolsConfig | cdktf.IResolvable | undefined);
    private _poolId?;
    get poolId(): string;
    set poolId(value: string);
    get poolIdInput(): string | undefined;
    private _weight?;
    get weight(): number;
    set weight(value: number);
    get weightInput(): number | undefined;
}
export declare class LbPolicyV3RedirectPoolsConfigList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: LbPolicyV3RedirectPoolsConfig[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LbPolicyV3RedirectPoolsConfigOutputReference;
}
export interface LbPolicyV3RedirectUrlConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3#host LbPolicyV3#host}
    */
    readonly host?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3#path LbPolicyV3#path}
    */
    readonly path?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3#port LbPolicyV3#port}
    */
    readonly port?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3#protocol LbPolicyV3#protocol}
    */
    readonly protocol?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3#query LbPolicyV3#query}
    */
    readonly query?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3#status_code LbPolicyV3#status_code}
    */
    readonly statusCode: string;
}
export declare function lbPolicyV3RedirectUrlConfigToTerraform(struct?: LbPolicyV3RedirectUrlConfigOutputReference | LbPolicyV3RedirectUrlConfig): any;
export declare function lbPolicyV3RedirectUrlConfigToHclTerraform(struct?: LbPolicyV3RedirectUrlConfigOutputReference | LbPolicyV3RedirectUrlConfig): any;
export declare class LbPolicyV3RedirectUrlConfigOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LbPolicyV3RedirectUrlConfig | undefined;
    set internalValue(value: LbPolicyV3RedirectUrlConfig | undefined);
    private _host?;
    get host(): string;
    set host(value: string);
    resetHost(): void;
    get hostInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _port?;
    get port(): string;
    set port(value: string);
    resetPort(): void;
    get portInput(): string | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    resetProtocol(): void;
    get protocolInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    resetQuery(): void;
    get queryInput(): string | undefined;
    private _statusCode?;
    get statusCode(): string;
    set statusCode(value: string);
    get statusCodeInput(): string | undefined;
}
export interface LbPolicyV3Rules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3#compare_type LbPolicyV3#compare_type}
    */
    readonly compareType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3#type LbPolicyV3#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3#value LbPolicyV3#value}
    */
    readonly value: string;
}
export declare function lbPolicyV3RulesToTerraform(struct?: LbPolicyV3Rules | cdktf.IResolvable): any;
export declare function lbPolicyV3RulesToHclTerraform(struct?: LbPolicyV3Rules | cdktf.IResolvable): any;
export declare class LbPolicyV3RulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LbPolicyV3Rules | cdktf.IResolvable | undefined;
    set internalValue(value: LbPolicyV3Rules | cdktf.IResolvable | undefined);
    private _compareType?;
    get compareType(): string;
    set compareType(value: string);
    get compareTypeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class LbPolicyV3RulesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: LbPolicyV3Rules[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LbPolicyV3RulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3 opentelekomcloud_lb_policy_v3}
*/
export declare class LbPolicyV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_lb_policy_v3";
    /**
    * Generates CDKTF code for importing a LbPolicyV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LbPolicyV3 to import
    * @param importFromId The id of the existing LbPolicyV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LbPolicyV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_policy_v3 opentelekomcloud_lb_policy_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LbPolicyV3Config
    */
    constructor(scope: Construct, id: string, config: LbPolicyV3Config);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _listenerId?;
    get listenerId(): string;
    set listenerId(value: string);
    get listenerIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _position?;
    get position(): number;
    set position(value: number);
    resetPosition(): void;
    get positionInput(): number | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    resetPriority(): void;
    get priorityInput(): number | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _redirectListenerId?;
    get redirectListenerId(): string;
    set redirectListenerId(value: string);
    resetRedirectListenerId(): void;
    get redirectListenerIdInput(): string | undefined;
    private _redirectPoolId?;
    get redirectPoolId(): string;
    set redirectPoolId(value: string);
    resetRedirectPoolId(): void;
    get redirectPoolIdInput(): string | undefined;
    private _redirectUrl?;
    get redirectUrl(): string;
    set redirectUrl(value: string);
    resetRedirectUrl(): void;
    get redirectUrlInput(): string | undefined;
    get status(): string;
    private _fixedResponseConfig;
    get fixedResponseConfig(): LbPolicyV3FixedResponseConfigOutputReference;
    putFixedResponseConfig(value: LbPolicyV3FixedResponseConfig): void;
    resetFixedResponseConfig(): void;
    get fixedResponseConfigInput(): LbPolicyV3FixedResponseConfig | undefined;
    private _redirectPoolsConfig;
    get redirectPoolsConfig(): LbPolicyV3RedirectPoolsConfigList;
    putRedirectPoolsConfig(value: LbPolicyV3RedirectPoolsConfig[] | cdktf.IResolvable): void;
    resetRedirectPoolsConfig(): void;
    get redirectPoolsConfigInput(): cdktf.IResolvable | LbPolicyV3RedirectPoolsConfig[] | undefined;
    private _redirectUrlConfig;
    get redirectUrlConfig(): LbPolicyV3RedirectUrlConfigOutputReference;
    putRedirectUrlConfig(value: LbPolicyV3RedirectUrlConfig): void;
    resetRedirectUrlConfig(): void;
    get redirectUrlConfigInput(): LbPolicyV3RedirectUrlConfig | undefined;
    private _rules;
    get rules(): LbPolicyV3RulesList;
    putRules(value: LbPolicyV3Rules[] | cdktf.IResolvable): void;
    resetRules(): void;
    get rulesInput(): cdktf.IResolvable | LbPolicyV3Rules[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AsmServiceMeshV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/asm_service_mesh_v1#id AsmServiceMeshV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/asm_service_mesh_v1#ipv6_enable AsmServiceMeshV1#ipv6_enable}
    */
    readonly ipv6Enable?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/asm_service_mesh_v1#name AsmServiceMeshV1#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/asm_service_mesh_v1#type AsmServiceMeshV1#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/asm_service_mesh_v1#version AsmServiceMeshV1#version}
    */
    readonly version: string;
    /**
    * clusters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/asm_service_mesh_v1#clusters AsmServiceMeshV1#clusters}
    */
    readonly clusters: AsmServiceMeshV1Clusters[] | cdktf.IResolvable;
    /**
    * proxy_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/asm_service_mesh_v1#proxy_config AsmServiceMeshV1#proxy_config}
    */
    readonly proxyConfig?: AsmServiceMeshV1ProxyConfig;
    /**
    * telemetry_config_tracing block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/asm_service_mesh_v1#telemetry_config_tracing AsmServiceMeshV1#telemetry_config_tracing}
    */
    readonly telemetryConfigTracing?: AsmServiceMeshV1TelemetryConfigTracing;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/asm_service_mesh_v1#timeouts AsmServiceMeshV1#timeouts}
    */
    readonly timeouts?: AsmServiceMeshV1Timeouts;
}
export interface AsmServiceMeshV1Clusters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/asm_service_mesh_v1#cluster_id AsmServiceMeshV1#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/asm_service_mesh_v1#injection_namespaces AsmServiceMeshV1#injection_namespaces}
    */
    readonly injectionNamespaces?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/asm_service_mesh_v1#installation_nodes AsmServiceMeshV1#installation_nodes}
    */
    readonly installationNodes: string[];
}
export declare function asmServiceMeshV1ClustersToTerraform(struct?: AsmServiceMeshV1Clusters | cdktf.IResolvable): any;
export declare function asmServiceMeshV1ClustersToHclTerraform(struct?: AsmServiceMeshV1Clusters | cdktf.IResolvable): any;
export declare class AsmServiceMeshV1ClustersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AsmServiceMeshV1Clusters | cdktf.IResolvable | undefined;
    set internalValue(value: AsmServiceMeshV1Clusters | cdktf.IResolvable | undefined);
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _injectionNamespaces?;
    get injectionNamespaces(): string[];
    set injectionNamespaces(value: string[]);
    resetInjectionNamespaces(): void;
    get injectionNamespacesInput(): string[] | undefined;
    private _installationNodes?;
    get installationNodes(): string[];
    set installationNodes(value: string[]);
    get installationNodesInput(): string[] | undefined;
}
export declare class AsmServiceMeshV1ClustersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AsmServiceMeshV1Clusters[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AsmServiceMeshV1ClustersOutputReference;
}
export interface AsmServiceMeshV1ProxyConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/asm_service_mesh_v1#exclude_inbound_ports AsmServiceMeshV1#exclude_inbound_ports}
    */
    readonly excludeInboundPorts?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/asm_service_mesh_v1#exclude_ip_ranges AsmServiceMeshV1#exclude_ip_ranges}
    */
    readonly excludeIpRanges?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/asm_service_mesh_v1#exclude_outbound_ports AsmServiceMeshV1#exclude_outbound_ports}
    */
    readonly excludeOutboundPorts?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/asm_service_mesh_v1#include_inbound_ports AsmServiceMeshV1#include_inbound_ports}
    */
    readonly includeInboundPorts?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/asm_service_mesh_v1#include_ip_ranges AsmServiceMeshV1#include_ip_ranges}
    */
    readonly includeIpRanges?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/asm_service_mesh_v1#include_outbound_ports AsmServiceMeshV1#include_outbound_ports}
    */
    readonly includeOutboundPorts?: string;
}
export declare function asmServiceMeshV1ProxyConfigToTerraform(struct?: AsmServiceMeshV1ProxyConfigOutputReference | AsmServiceMeshV1ProxyConfig): any;
export declare function asmServiceMeshV1ProxyConfigToHclTerraform(struct?: AsmServiceMeshV1ProxyConfigOutputReference | AsmServiceMeshV1ProxyConfig): any;
export declare class AsmServiceMeshV1ProxyConfigOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AsmServiceMeshV1ProxyConfig | undefined;
    set internalValue(value: AsmServiceMeshV1ProxyConfig | undefined);
    private _excludeInboundPorts?;
    get excludeInboundPorts(): string;
    set excludeInboundPorts(value: string);
    resetExcludeInboundPorts(): void;
    get excludeInboundPortsInput(): string | undefined;
    private _excludeIpRanges?;
    get excludeIpRanges(): string;
    set excludeIpRanges(value: string);
    resetExcludeIpRanges(): void;
    get excludeIpRangesInput(): string | undefined;
    private _excludeOutboundPorts?;
    get excludeOutboundPorts(): string;
    set excludeOutboundPorts(value: string);
    resetExcludeOutboundPorts(): void;
    get excludeOutboundPortsInput(): string | undefined;
    private _includeInboundPorts?;
    get includeInboundPorts(): string;
    set includeInboundPorts(value: string);
    resetIncludeInboundPorts(): void;
    get includeInboundPortsInput(): string | undefined;
    private _includeIpRanges?;
    get includeIpRanges(): string;
    set includeIpRanges(value: string);
    resetIncludeIpRanges(): void;
    get includeIpRangesInput(): string | undefined;
    private _includeOutboundPorts?;
    get includeOutboundPorts(): string;
    set includeOutboundPorts(value: string);
    resetIncludeOutboundPorts(): void;
    get includeOutboundPortsInput(): string | undefined;
}
export interface AsmServiceMeshV1TelemetryConfigTracingExtensionProviders {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/asm_service_mesh_v1#name AsmServiceMeshV1#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/asm_service_mesh_v1#zipkin_service_addr AsmServiceMeshV1#zipkin_service_addr}
    */
    readonly zipkinServiceAddr?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/asm_service_mesh_v1#zipkin_service_port AsmServiceMeshV1#zipkin_service_port}
    */
    readonly zipkinServicePort?: number;
}
export declare function asmServiceMeshV1TelemetryConfigTracingExtensionProvidersToTerraform(struct?: AsmServiceMeshV1TelemetryConfigTracingExtensionProviders | cdktf.IResolvable): any;
export declare function asmServiceMeshV1TelemetryConfigTracingExtensionProvidersToHclTerraform(struct?: AsmServiceMeshV1TelemetryConfigTracingExtensionProviders | cdktf.IResolvable): any;
export declare class AsmServiceMeshV1TelemetryConfigTracingExtensionProvidersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AsmServiceMeshV1TelemetryConfigTracingExtensionProviders | cdktf.IResolvable | undefined;
    set internalValue(value: AsmServiceMeshV1TelemetryConfigTracingExtensionProviders | cdktf.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _zipkinServiceAddr?;
    get zipkinServiceAddr(): string;
    set zipkinServiceAddr(value: string);
    resetZipkinServiceAddr(): void;
    get zipkinServiceAddrInput(): string | undefined;
    private _zipkinServicePort?;
    get zipkinServicePort(): number;
    set zipkinServicePort(value: number);
    resetZipkinServicePort(): void;
    get zipkinServicePortInput(): number | undefined;
}
export declare class AsmServiceMeshV1TelemetryConfigTracingExtensionProvidersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AsmServiceMeshV1TelemetryConfigTracingExtensionProviders[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AsmServiceMeshV1TelemetryConfigTracingExtensionProvidersOutputReference;
}
export interface AsmServiceMeshV1TelemetryConfigTracing {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/asm_service_mesh_v1#default_providers AsmServiceMeshV1#default_providers}
    */
    readonly defaultProviders?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/asm_service_mesh_v1#random_sampling_percentage AsmServiceMeshV1#random_sampling_percentage}
    */
    readonly randomSamplingPercentage?: number;
    /**
    * extension_providers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/asm_service_mesh_v1#extension_providers AsmServiceMeshV1#extension_providers}
    */
    readonly extensionProviders?: AsmServiceMeshV1TelemetryConfigTracingExtensionProviders[] | cdktf.IResolvable;
}
export declare function asmServiceMeshV1TelemetryConfigTracingToTerraform(struct?: AsmServiceMeshV1TelemetryConfigTracingOutputReference | AsmServiceMeshV1TelemetryConfigTracing): any;
export declare function asmServiceMeshV1TelemetryConfigTracingToHclTerraform(struct?: AsmServiceMeshV1TelemetryConfigTracingOutputReference | AsmServiceMeshV1TelemetryConfigTracing): any;
export declare class AsmServiceMeshV1TelemetryConfigTracingOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AsmServiceMeshV1TelemetryConfigTracing | undefined;
    set internalValue(value: AsmServiceMeshV1TelemetryConfigTracing | undefined);
    private _defaultProviders?;
    get defaultProviders(): string[];
    set defaultProviders(value: string[]);
    resetDefaultProviders(): void;
    get defaultProvidersInput(): string[] | undefined;
    private _randomSamplingPercentage?;
    get randomSamplingPercentage(): number;
    set randomSamplingPercentage(value: number);
    resetRandomSamplingPercentage(): void;
    get randomSamplingPercentageInput(): number | undefined;
    private _extensionProviders;
    get extensionProviders(): AsmServiceMeshV1TelemetryConfigTracingExtensionProvidersList;
    putExtensionProviders(value: AsmServiceMeshV1TelemetryConfigTracingExtensionProviders[] | cdktf.IResolvable): void;
    resetExtensionProviders(): void;
    get extensionProvidersInput(): cdktf.IResolvable | AsmServiceMeshV1TelemetryConfigTracingExtensionProviders[] | undefined;
}
export interface AsmServiceMeshV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/asm_service_mesh_v1#create AsmServiceMeshV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/asm_service_mesh_v1#delete AsmServiceMeshV1#delete}
    */
    readonly delete?: string;
}
export declare function asmServiceMeshV1TimeoutsToTerraform(struct?: AsmServiceMeshV1Timeouts | cdktf.IResolvable): any;
export declare function asmServiceMeshV1TimeoutsToHclTerraform(struct?: AsmServiceMeshV1Timeouts | cdktf.IResolvable): any;
export declare class AsmServiceMeshV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AsmServiceMeshV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: AsmServiceMeshV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/asm_service_mesh_v1 opentelekomcloud_asm_service_mesh_v1}
*/
export declare class AsmServiceMeshV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_asm_service_mesh_v1";
    /**
    * Generates CDKTF code for importing a AsmServiceMeshV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AsmServiceMeshV1 to import
    * @param importFromId The id of the existing AsmServiceMeshV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/asm_service_mesh_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AsmServiceMeshV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/asm_service_mesh_v1 opentelekomcloud_asm_service_mesh_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AsmServiceMeshV1Config
    */
    constructor(scope: Construct, id: string, config: AsmServiceMeshV1Config);
    get clusterIds(): string[];
    get creationTimestamp(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipv6Enable?;
    get ipv6Enable(): boolean | cdktf.IResolvable;
    set ipv6Enable(value: boolean | cdktf.IResolvable);
    resetIpv6Enable(): void;
    get ipv6EnableInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get status(): string;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
    private _clusters;
    get clusters(): AsmServiceMeshV1ClustersList;
    putClusters(value: AsmServiceMeshV1Clusters[] | cdktf.IResolvable): void;
    get clustersInput(): cdktf.IResolvable | AsmServiceMeshV1Clusters[] | undefined;
    private _proxyConfig;
    get proxyConfig(): AsmServiceMeshV1ProxyConfigOutputReference;
    putProxyConfig(value: AsmServiceMeshV1ProxyConfig): void;
    resetProxyConfig(): void;
    get proxyConfigInput(): AsmServiceMeshV1ProxyConfig | undefined;
    private _telemetryConfigTracing;
    get telemetryConfigTracing(): AsmServiceMeshV1TelemetryConfigTracingOutputReference;
    putTelemetryConfigTracing(value: AsmServiceMeshV1TelemetryConfigTracing): void;
    resetTelemetryConfigTracing(): void;
    get telemetryConfigTracingInput(): AsmServiceMeshV1TelemetryConfigTracing | undefined;
    private _timeouts;
    get timeouts(): AsmServiceMeshV1TimeoutsOutputReference;
    putTimeouts(value: AsmServiceMeshV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | AsmServiceMeshV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DcVirtualInterfaceV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v2#asn DcVirtualInterfaceV2#asn}
    */
    readonly asn?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v2#bandwidth DcVirtualInterfaceV2#bandwidth}
    */
    readonly bandwidth: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v2#bgp_md5 DcVirtualInterfaceV2#bgp_md5}
    */
    readonly bgpMd5?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v2#description DcVirtualInterfaceV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v2#direct_connect_id DcVirtualInterfaceV2#direct_connect_id}
    */
    readonly directConnectId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v2#enable_bfd DcVirtualInterfaceV2#enable_bfd}
    */
    readonly enableBfd?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v2#enable_nqa DcVirtualInterfaceV2#enable_nqa}
    */
    readonly enableNqa?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v2#id DcVirtualInterfaceV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v2#lag_id DcVirtualInterfaceV2#lag_id}
    */
    readonly lagId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v2#local_gateway_v4_ip DcVirtualInterfaceV2#local_gateway_v4_ip}
    */
    readonly localGatewayV4Ip?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v2#name DcVirtualInterfaceV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v2#project_id DcVirtualInterfaceV2#project_id}
    */
    readonly projectId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v2#remote_gateway_v4_ip DcVirtualInterfaceV2#remote_gateway_v4_ip}
    */
    readonly remoteGatewayV4Ip?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v2#route_mode DcVirtualInterfaceV2#route_mode}
    */
    readonly routeMode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v2#service_type DcVirtualInterfaceV2#service_type}
    */
    readonly serviceType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v2#type DcVirtualInterfaceV2#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v2#virtual_gateway_id DcVirtualInterfaceV2#virtual_gateway_id}
    */
    readonly virtualGatewayId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v2#vlan DcVirtualInterfaceV2#vlan}
    */
    readonly vlan: number;
    /**
    * remote_ep_group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v2#remote_ep_group DcVirtualInterfaceV2#remote_ep_group}
    */
    readonly remoteEpGroup: DcVirtualInterfaceV2RemoteEpGroup;
}
export interface DcVirtualInterfaceV2RemoteEpGroup {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v2#description DcVirtualInterfaceV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v2#endpoints DcVirtualInterfaceV2#endpoints}
    */
    readonly endpoints: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v2#name DcVirtualInterfaceV2#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v2#project_id DcVirtualInterfaceV2#project_id}
    */
    readonly projectId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v2#type DcVirtualInterfaceV2#type}
    */
    readonly type?: string;
}
export declare function dcVirtualInterfaceV2RemoteEpGroupToTerraform(struct?: DcVirtualInterfaceV2RemoteEpGroupOutputReference | DcVirtualInterfaceV2RemoteEpGroup): any;
export declare function dcVirtualInterfaceV2RemoteEpGroupToHclTerraform(struct?: DcVirtualInterfaceV2RemoteEpGroupOutputReference | DcVirtualInterfaceV2RemoteEpGroup): any;
export declare class DcVirtualInterfaceV2RemoteEpGroupOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DcVirtualInterfaceV2RemoteEpGroup | undefined;
    set internalValue(value: DcVirtualInterfaceV2RemoteEpGroup | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _endpoints?;
    get endpoints(): string[];
    set endpoints(value: string[]);
    get endpointsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v2 opentelekomcloud_dc_virtual_interface_v2}
*/
export declare class DcVirtualInterfaceV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_dc_virtual_interface_v2";
    /**
    * Generates CDKTF code for importing a DcVirtualInterfaceV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DcVirtualInterfaceV2 to import
    * @param importFromId The id of the existing DcVirtualInterfaceV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DcVirtualInterfaceV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_interface_v2 opentelekomcloud_dc_virtual_interface_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DcVirtualInterfaceV2Config
    */
    constructor(scope: Construct, id: string, config: DcVirtualInterfaceV2Config);
    private _asn?;
    get asn(): number;
    set asn(value: number);
    resetAsn(): void;
    get asnInput(): number | undefined;
    private _bandwidth?;
    get bandwidth(): number;
    set bandwidth(value: number);
    get bandwidthInput(): number | undefined;
    private _bgpMd5?;
    get bgpMd5(): string;
    set bgpMd5(value: string);
    resetBgpMd5(): void;
    get bgpMd5Input(): string | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _directConnectId?;
    get directConnectId(): string;
    set directConnectId(value: string);
    get directConnectIdInput(): string | undefined;
    private _enableBfd?;
    get enableBfd(): boolean | cdktf.IResolvable;
    set enableBfd(value: boolean | cdktf.IResolvable);
    resetEnableBfd(): void;
    get enableBfdInput(): boolean | cdktf.IResolvable | undefined;
    private _enableNqa?;
    get enableNqa(): boolean | cdktf.IResolvable;
    set enableNqa(value: boolean | cdktf.IResolvable);
    resetEnableNqa(): void;
    get enableNqaInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _lagId?;
    get lagId(): string;
    set lagId(value: string);
    resetLagId(): void;
    get lagIdInput(): string | undefined;
    private _localGatewayV4Ip?;
    get localGatewayV4Ip(): string;
    set localGatewayV4Ip(value: string);
    resetLocalGatewayV4Ip(): void;
    get localGatewayV4IpInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get remoteEpGroupId(): string;
    private _remoteGatewayV4Ip?;
    get remoteGatewayV4Ip(): string;
    set remoteGatewayV4Ip(value: string);
    resetRemoteGatewayV4Ip(): void;
    get remoteGatewayV4IpInput(): string | undefined;
    private _routeMode?;
    get routeMode(): string;
    set routeMode(value: string);
    get routeModeInput(): string | undefined;
    private _serviceType?;
    get serviceType(): string;
    set serviceType(value: string);
    get serviceTypeInput(): string | undefined;
    get status(): string;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _virtualGatewayId?;
    get virtualGatewayId(): string;
    set virtualGatewayId(value: string);
    get virtualGatewayIdInput(): string | undefined;
    private _vlan?;
    get vlan(): number;
    set vlan(value: number);
    get vlanInput(): number | undefined;
    private _remoteEpGroup;
    get remoteEpGroup(): DcVirtualInterfaceV2RemoteEpGroupOutputReference;
    putRemoteEpGroup(value: DcVirtualInterfaceV2RemoteEpGroup): void;
    get remoteEpGroupInput(): DcVirtualInterfaceV2RemoteEpGroup | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

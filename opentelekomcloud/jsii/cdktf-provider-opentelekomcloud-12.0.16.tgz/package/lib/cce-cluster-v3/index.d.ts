/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CceClusterV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#annotations CceClusterV3#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#api_access_trustlist CceClusterV3#api_access_trustlist}
    */
    readonly apiAccessTrustlist?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#authenticating_proxy_ca CceClusterV3#authenticating_proxy_ca}
    */
    readonly authenticatingProxyCa?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#authentication_mode CceClusterV3#authentication_mode}
    */
    readonly authenticationMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#billing_mode CceClusterV3#billing_mode}
    */
    readonly billingMode?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#cluster_type CceClusterV3#cluster_type}
    */
    readonly clusterType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#cluster_version CceClusterV3#cluster_version}
    */
    readonly clusterVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#container_network_cidr CceClusterV3#container_network_cidr}
    */
    readonly containerNetworkCidr?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#container_network_type CceClusterV3#container_network_type}
    */
    readonly containerNetworkType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#custom_san CceClusterV3#custom_san}
    */
    readonly customSan?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#delete_all_network CceClusterV3#delete_all_network}
    */
    readonly deleteAllNetwork?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#delete_all_storage CceClusterV3#delete_all_storage}
    */
    readonly deleteAllStorage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#delete_efs CceClusterV3#delete_efs}
    */
    readonly deleteEfs?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#delete_eni CceClusterV3#delete_eni}
    */
    readonly deleteEni?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#delete_evs CceClusterV3#delete_evs}
    */
    readonly deleteEvs?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#delete_net CceClusterV3#delete_net}
    */
    readonly deleteNet?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#delete_obs CceClusterV3#delete_obs}
    */
    readonly deleteObs?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#delete_sfs CceClusterV3#delete_sfs}
    */
    readonly deleteSfs?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#description CceClusterV3#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#eip CceClusterV3#eip}
    */
    readonly eip?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#enable_volume_encryption CceClusterV3#enable_volume_encryption}
    */
    readonly enableVolumeEncryption?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#eni_subnet_cidr CceClusterV3#eni_subnet_cidr}
    */
    readonly eniSubnetCidr?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#eni_subnet_id CceClusterV3#eni_subnet_id}
    */
    readonly eniSubnetId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#extend_param CceClusterV3#extend_param}
    */
    readonly extendParam?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#flavor_id CceClusterV3#flavor_id}
    */
    readonly flavorId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#highway_subnet_id CceClusterV3#highway_subnet_id}
    */
    readonly highwaySubnetId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#id CceClusterV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#ignore_addons CceClusterV3#ignore_addons}
    */
    readonly ignoreAddons?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#ignore_certificate_clusters_data CceClusterV3#ignore_certificate_clusters_data}
    */
    readonly ignoreCertificateClustersData?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#ignore_certificate_users_data CceClusterV3#ignore_certificate_users_data}
    */
    readonly ignoreCertificateUsersData?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#ipv6_enable CceClusterV3#ipv6_enable}
    */
    readonly ipv6Enable?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#kube_proxy_mode CceClusterV3#kube_proxy_mode}
    */
    readonly kubeProxyMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#kubernetes_svc_ip_range CceClusterV3#kubernetes_svc_ip_range}
    */
    readonly kubernetesSvcIpRange?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#labels CceClusterV3#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#multi_az CceClusterV3#multi_az}
    */
    readonly multiAz?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#name CceClusterV3#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#no_addons CceClusterV3#no_addons}
    */
    readonly noAddons?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#region CceClusterV3#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#security_group_id CceClusterV3#security_group_id}
    */
    readonly securityGroupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#subnet_id CceClusterV3#subnet_id}
    */
    readonly subnetId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#support_istio CceClusterV3#support_istio}
    */
    readonly supportIstio?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#timezone CceClusterV3#timezone}
    */
    readonly timezone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#vpc_id CceClusterV3#vpc_id}
    */
    readonly vpcId: string;
    /**
    * authenticating_proxy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#authenticating_proxy CceClusterV3#authenticating_proxy}
    */
    readonly authenticatingProxy?: CceClusterV3AuthenticatingProxy;
    /**
    * component_configurations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#component_configurations CceClusterV3#component_configurations}
    */
    readonly componentConfigurations?: CceClusterV3ComponentConfigurations[] | cdktf.IResolvable;
    /**
    * masters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#masters CceClusterV3#masters}
    */
    readonly masters?: CceClusterV3Masters[] | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#timeouts CceClusterV3#timeouts}
    */
    readonly timeouts?: CceClusterV3Timeouts;
}
export interface CceClusterV3CertificateClusters {
}
export declare function cceClusterV3CertificateClustersToTerraform(struct?: CceClusterV3CertificateClusters): any;
export declare function cceClusterV3CertificateClustersToHclTerraform(struct?: CceClusterV3CertificateClusters): any;
export declare class CceClusterV3CertificateClustersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CceClusterV3CertificateClusters | undefined;
    set internalValue(value: CceClusterV3CertificateClusters | undefined);
    get certificateAuthorityData(): string;
    get name(): string;
    get server(): string;
}
export declare class CceClusterV3CertificateClustersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CceClusterV3CertificateClustersOutputReference;
}
export interface CceClusterV3CertificateUsers {
}
export declare function cceClusterV3CertificateUsersToTerraform(struct?: CceClusterV3CertificateUsers): any;
export declare function cceClusterV3CertificateUsersToHclTerraform(struct?: CceClusterV3CertificateUsers): any;
export declare class CceClusterV3CertificateUsersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CceClusterV3CertificateUsers | undefined;
    set internalValue(value: CceClusterV3CertificateUsers | undefined);
    get clientCertificateData(): string;
    get clientKeyData(): string;
    get name(): string;
}
export declare class CceClusterV3CertificateUsersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CceClusterV3CertificateUsersOutputReference;
}
export interface CceClusterV3AuthenticatingProxy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#ca CceClusterV3#ca}
    */
    readonly ca: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#cert CceClusterV3#cert}
    */
    readonly cert: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#private_key CceClusterV3#private_key}
    */
    readonly privateKey: string;
}
export declare function cceClusterV3AuthenticatingProxyToTerraform(struct?: CceClusterV3AuthenticatingProxyOutputReference | CceClusterV3AuthenticatingProxy): any;
export declare function cceClusterV3AuthenticatingProxyToHclTerraform(struct?: CceClusterV3AuthenticatingProxyOutputReference | CceClusterV3AuthenticatingProxy): any;
export declare class CceClusterV3AuthenticatingProxyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CceClusterV3AuthenticatingProxy | undefined;
    set internalValue(value: CceClusterV3AuthenticatingProxy | undefined);
    private _ca?;
    get ca(): string;
    set ca(value: string);
    get caInput(): string | undefined;
    private _cert?;
    get cert(): string;
    set cert(value: string);
    get certInput(): string | undefined;
    private _privateKey?;
    get privateKey(): string;
    set privateKey(value: string);
    get privateKeyInput(): string | undefined;
}
export interface CceClusterV3ComponentConfigurationsConfigurations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#name CceClusterV3#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#value CceClusterV3#value}
    */
    readonly value: string;
}
export declare function cceClusterV3ComponentConfigurationsConfigurationsToTerraform(struct?: CceClusterV3ComponentConfigurationsConfigurations | cdktf.IResolvable): any;
export declare function cceClusterV3ComponentConfigurationsConfigurationsToHclTerraform(struct?: CceClusterV3ComponentConfigurationsConfigurations | cdktf.IResolvable): any;
export declare class CceClusterV3ComponentConfigurationsConfigurationsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CceClusterV3ComponentConfigurationsConfigurations | cdktf.IResolvable | undefined;
    set internalValue(value: CceClusterV3ComponentConfigurationsConfigurations | cdktf.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class CceClusterV3ComponentConfigurationsConfigurationsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: CceClusterV3ComponentConfigurationsConfigurations[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CceClusterV3ComponentConfigurationsConfigurationsOutputReference;
}
export interface CceClusterV3ComponentConfigurations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#name CceClusterV3#name}
    */
    readonly name: string;
    /**
    * configurations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#configurations CceClusterV3#configurations}
    */
    readonly configurations?: CceClusterV3ComponentConfigurationsConfigurations[] | cdktf.IResolvable;
}
export declare function cceClusterV3ComponentConfigurationsToTerraform(struct?: CceClusterV3ComponentConfigurations | cdktf.IResolvable): any;
export declare function cceClusterV3ComponentConfigurationsToHclTerraform(struct?: CceClusterV3ComponentConfigurations | cdktf.IResolvable): any;
export declare class CceClusterV3ComponentConfigurationsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CceClusterV3ComponentConfigurations | cdktf.IResolvable | undefined;
    set internalValue(value: CceClusterV3ComponentConfigurations | cdktf.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _configurations;
    get configurations(): CceClusterV3ComponentConfigurationsConfigurationsList;
    putConfigurations(value: CceClusterV3ComponentConfigurationsConfigurations[] | cdktf.IResolvable): void;
    resetConfigurations(): void;
    get configurationsInput(): cdktf.IResolvable | CceClusterV3ComponentConfigurationsConfigurations[] | undefined;
}
export declare class CceClusterV3ComponentConfigurationsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: CceClusterV3ComponentConfigurations[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CceClusterV3ComponentConfigurationsOutputReference;
}
export interface CceClusterV3Masters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#availability_zone CceClusterV3#availability_zone}
    */
    readonly availabilityZone?: string;
}
export declare function cceClusterV3MastersToTerraform(struct?: CceClusterV3Masters | cdktf.IResolvable): any;
export declare function cceClusterV3MastersToHclTerraform(struct?: CceClusterV3Masters | cdktf.IResolvable): any;
export declare class CceClusterV3MastersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CceClusterV3Masters | cdktf.IResolvable | undefined;
    set internalValue(value: CceClusterV3Masters | cdktf.IResolvable | undefined);
    private _availabilityZone?;
    get availabilityZone(): string;
    set availabilityZone(value: string);
    resetAvailabilityZone(): void;
    get availabilityZoneInput(): string | undefined;
}
export declare class CceClusterV3MastersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: CceClusterV3Masters[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CceClusterV3MastersOutputReference;
}
export interface CceClusterV3Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#create CceClusterV3#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#delete CceClusterV3#delete}
    */
    readonly delete?: string;
}
export declare function cceClusterV3TimeoutsToTerraform(struct?: CceClusterV3Timeouts | cdktf.IResolvable): any;
export declare function cceClusterV3TimeoutsToHclTerraform(struct?: CceClusterV3Timeouts | cdktf.IResolvable): any;
export declare class CceClusterV3TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CceClusterV3Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: CceClusterV3Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3 opentelekomcloud_cce_cluster_v3}
*/
export declare class CceClusterV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_cce_cluster_v3";
    /**
    * Generates CDKTF code for importing a CceClusterV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CceClusterV3 to import
    * @param importFromId The id of the existing CceClusterV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CceClusterV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_cluster_v3 opentelekomcloud_cce_cluster_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CceClusterV3Config
    */
    constructor(scope: Construct, id: string, config: CceClusterV3Config);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _apiAccessTrustlist?;
    get apiAccessTrustlist(): string[];
    set apiAccessTrustlist(value: string[]);
    resetApiAccessTrustlist(): void;
    get apiAccessTrustlistInput(): string[] | undefined;
    private _authenticatingProxyCa?;
    get authenticatingProxyCa(): string;
    set authenticatingProxyCa(value: string);
    resetAuthenticatingProxyCa(): void;
    get authenticatingProxyCaInput(): string | undefined;
    private _authenticationMode?;
    get authenticationMode(): string;
    set authenticationMode(value: string);
    resetAuthenticationMode(): void;
    get authenticationModeInput(): string | undefined;
    private _billingMode?;
    get billingMode(): number;
    set billingMode(value: number);
    resetBillingMode(): void;
    get billingModeInput(): number | undefined;
    private _certificateClusters;
    get certificateClusters(): CceClusterV3CertificateClustersList;
    private _certificateUsers;
    get certificateUsers(): CceClusterV3CertificateUsersList;
    private _clusterType?;
    get clusterType(): string;
    set clusterType(value: string);
    get clusterTypeInput(): string | undefined;
    private _clusterVersion?;
    get clusterVersion(): string;
    set clusterVersion(value: string);
    resetClusterVersion(): void;
    get clusterVersionInput(): string | undefined;
    private _containerNetworkCidr?;
    get containerNetworkCidr(): string;
    set containerNetworkCidr(value: string);
    resetContainerNetworkCidr(): void;
    get containerNetworkCidrInput(): string | undefined;
    private _containerNetworkType?;
    get containerNetworkType(): string;
    set containerNetworkType(value: string);
    get containerNetworkTypeInput(): string | undefined;
    private _customSan?;
    get customSan(): string[];
    set customSan(value: string[]);
    resetCustomSan(): void;
    get customSanInput(): string[] | undefined;
    private _deleteAllNetwork?;
    get deleteAllNetwork(): string;
    set deleteAllNetwork(value: string);
    resetDeleteAllNetwork(): void;
    get deleteAllNetworkInput(): string | undefined;
    private _deleteAllStorage?;
    get deleteAllStorage(): string;
    set deleteAllStorage(value: string);
    resetDeleteAllStorage(): void;
    get deleteAllStorageInput(): string | undefined;
    private _deleteEfs?;
    get deleteEfs(): string;
    set deleteEfs(value: string);
    resetDeleteEfs(): void;
    get deleteEfsInput(): string | undefined;
    private _deleteEni?;
    get deleteEni(): string;
    set deleteEni(value: string);
    resetDeleteEni(): void;
    get deleteEniInput(): string | undefined;
    private _deleteEvs?;
    get deleteEvs(): string;
    set deleteEvs(value: string);
    resetDeleteEvs(): void;
    get deleteEvsInput(): string | undefined;
    private _deleteNet?;
    get deleteNet(): string;
    set deleteNet(value: string);
    resetDeleteNet(): void;
    get deleteNetInput(): string | undefined;
    private _deleteObs?;
    get deleteObs(): string;
    set deleteObs(value: string);
    resetDeleteObs(): void;
    get deleteObsInput(): string | undefined;
    private _deleteSfs?;
    get deleteSfs(): string;
    set deleteSfs(value: string);
    resetDeleteSfs(): void;
    get deleteSfsInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _eip?;
    get eip(): string;
    set eip(value: string);
    resetEip(): void;
    get eipInput(): string | undefined;
    private _enableVolumeEncryption?;
    get enableVolumeEncryption(): boolean | cdktf.IResolvable;
    set enableVolumeEncryption(value: boolean | cdktf.IResolvable);
    resetEnableVolumeEncryption(): void;
    get enableVolumeEncryptionInput(): boolean | cdktf.IResolvable | undefined;
    private _eniSubnetCidr?;
    get eniSubnetCidr(): string;
    set eniSubnetCidr(value: string);
    resetEniSubnetCidr(): void;
    get eniSubnetCidrInput(): string | undefined;
    private _eniSubnetId?;
    get eniSubnetId(): string;
    set eniSubnetId(value: string);
    resetEniSubnetId(): void;
    get eniSubnetIdInput(): string | undefined;
    private _extendParam?;
    get extendParam(): {
        [key: string]: string;
    };
    set extendParam(value: {
        [key: string]: string;
    });
    resetExtendParam(): void;
    get extendParamInput(): {
        [key: string]: string;
    } | undefined;
    get external(): string;
    get externalOtc(): string;
    private _flavorId?;
    get flavorId(): string;
    set flavorId(value: string);
    get flavorIdInput(): string | undefined;
    private _highwaySubnetId?;
    get highwaySubnetId(): string;
    set highwaySubnetId(value: string);
    resetHighwaySubnetId(): void;
    get highwaySubnetIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ignoreAddons?;
    get ignoreAddons(): boolean | cdktf.IResolvable;
    set ignoreAddons(value: boolean | cdktf.IResolvable);
    resetIgnoreAddons(): void;
    get ignoreAddonsInput(): boolean | cdktf.IResolvable | undefined;
    private _ignoreCertificateClustersData?;
    get ignoreCertificateClustersData(): boolean | cdktf.IResolvable;
    set ignoreCertificateClustersData(value: boolean | cdktf.IResolvable);
    resetIgnoreCertificateClustersData(): void;
    get ignoreCertificateClustersDataInput(): boolean | cdktf.IResolvable | undefined;
    private _ignoreCertificateUsersData?;
    get ignoreCertificateUsersData(): boolean | cdktf.IResolvable;
    set ignoreCertificateUsersData(value: boolean | cdktf.IResolvable);
    resetIgnoreCertificateUsersData(): void;
    get ignoreCertificateUsersDataInput(): boolean | cdktf.IResolvable | undefined;
    get installedAddons(): string[];
    get internal(): string;
    private _ipv6Enable?;
    get ipv6Enable(): boolean | cdktf.IResolvable;
    set ipv6Enable(value: boolean | cdktf.IResolvable);
    resetIpv6Enable(): void;
    get ipv6EnableInput(): boolean | cdktf.IResolvable | undefined;
    private _kubeProxyMode?;
    get kubeProxyMode(): string;
    set kubeProxyMode(value: string);
    resetKubeProxyMode(): void;
    get kubeProxyModeInput(): string | undefined;
    private _kubernetesSvcIpRange?;
    get kubernetesSvcIpRange(): string;
    set kubernetesSvcIpRange(value: string);
    resetKubernetesSvcIpRange(): void;
    get kubernetesSvcIpRangeInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _multiAz?;
    get multiAz(): boolean | cdktf.IResolvable;
    set multiAz(value: boolean | cdktf.IResolvable);
    resetMultiAz(): void;
    get multiAzInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _noAddons?;
    get noAddons(): boolean | cdktf.IResolvable;
    set noAddons(value: boolean | cdktf.IResolvable);
    resetNoAddons(): void;
    get noAddonsInput(): boolean | cdktf.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get securityGroupControl(): string;
    private _securityGroupId?;
    get securityGroupId(): string;
    set securityGroupId(value: string);
    resetSecurityGroupId(): void;
    get securityGroupIdInput(): string | undefined;
    get securityGroupNode(): string;
    get status(): string;
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    get subnetIdInput(): string | undefined;
    private _supportIstio?;
    get supportIstio(): boolean | cdktf.IResolvable;
    set supportIstio(value: boolean | cdktf.IResolvable);
    resetSupportIstio(): void;
    get supportIstioInput(): boolean | cdktf.IResolvable | undefined;
    private _timezone?;
    get timezone(): string;
    set timezone(value: string);
    resetTimezone(): void;
    get timezoneInput(): string | undefined;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    get vpcIdInput(): string | undefined;
    private _authenticatingProxy;
    get authenticatingProxy(): CceClusterV3AuthenticatingProxyOutputReference;
    putAuthenticatingProxy(value: CceClusterV3AuthenticatingProxy): void;
    resetAuthenticatingProxy(): void;
    get authenticatingProxyInput(): CceClusterV3AuthenticatingProxy | undefined;
    private _componentConfigurations;
    get componentConfigurations(): CceClusterV3ComponentConfigurationsList;
    putComponentConfigurations(value: CceClusterV3ComponentConfigurations[] | cdktf.IResolvable): void;
    resetComponentConfigurations(): void;
    get componentConfigurationsInput(): cdktf.IResolvable | CceClusterV3ComponentConfigurations[] | undefined;
    private _masters;
    get masters(): CceClusterV3MastersList;
    putMasters(value: CceClusterV3Masters[] | cdktf.IResolvable): void;
    resetMasters(): void;
    get mastersInput(): cdktf.IResolvable | CceClusterV3Masters[] | undefined;
    private _timeouts;
    get timeouts(): CceClusterV3TimeoutsOutputReference;
    putTimeouts(value: CceClusterV3Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | CceClusterV3Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

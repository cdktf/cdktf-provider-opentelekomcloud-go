/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface TaurusdbMysqlInstanceV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3#availability_zone_mode TaurusdbMysqlInstanceV3#availability_zone_mode}
    */
    readonly availabilityZoneMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3#configuration_id TaurusdbMysqlInstanceV3#configuration_id}
    */
    readonly configurationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3#dedicated_resource_id TaurusdbMysqlInstanceV3#dedicated_resource_id}
    */
    readonly dedicatedResourceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3#enterprise_project_id TaurusdbMysqlInstanceV3#enterprise_project_id}
    */
    readonly enterpriseProjectId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3#flavor TaurusdbMysqlInstanceV3#flavor}
    */
    readonly flavor: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3#id TaurusdbMysqlInstanceV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3#master_availability_zone TaurusdbMysqlInstanceV3#master_availability_zone}
    */
    readonly masterAvailabilityZone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3#name TaurusdbMysqlInstanceV3#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3#password TaurusdbMysqlInstanceV3#password}
    */
    readonly password: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3#port TaurusdbMysqlInstanceV3#port}
    */
    readonly port?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3#read_replicas TaurusdbMysqlInstanceV3#read_replicas}
    */
    readonly readReplicas?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3#seconds_level_monitoring_enabled TaurusdbMysqlInstanceV3#seconds_level_monitoring_enabled}
    */
    readonly secondsLevelMonitoringEnabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3#seconds_level_monitoring_period TaurusdbMysqlInstanceV3#seconds_level_monitoring_period}
    */
    readonly secondsLevelMonitoringPeriod?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3#security_group_id TaurusdbMysqlInstanceV3#security_group_id}
    */
    readonly securityGroupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3#subnet_id TaurusdbMysqlInstanceV3#subnet_id}
    */
    readonly subnetId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3#table_name_case_sensitivity TaurusdbMysqlInstanceV3#table_name_case_sensitivity}
    */
    readonly tableNameCaseSensitivity?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3#time_zone TaurusdbMysqlInstanceV3#time_zone}
    */
    readonly timeZone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3#volume_size TaurusdbMysqlInstanceV3#volume_size}
    */
    readonly volumeSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3#vpc_id TaurusdbMysqlInstanceV3#vpc_id}
    */
    readonly vpcId: string;
    /**
    * backup_strategy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3#backup_strategy TaurusdbMysqlInstanceV3#backup_strategy}
    */
    readonly backupStrategy?: TaurusdbMysqlInstanceV3BackupStrategy;
    /**
    * datastore block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3#datastore TaurusdbMysqlInstanceV3#datastore}
    */
    readonly datastore?: TaurusdbMysqlInstanceV3Datastore;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3#timeouts TaurusdbMysqlInstanceV3#timeouts}
    */
    readonly timeouts?: TaurusdbMysqlInstanceV3Timeouts;
}
export interface TaurusdbMysqlInstanceV3Nodes {
}
export declare function taurusdbMysqlInstanceV3NodesToTerraform(struct?: TaurusdbMysqlInstanceV3Nodes): any;
export declare function taurusdbMysqlInstanceV3NodesToHclTerraform(struct?: TaurusdbMysqlInstanceV3Nodes): any;
export declare class TaurusdbMysqlInstanceV3NodesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): TaurusdbMysqlInstanceV3Nodes | undefined;
    set internalValue(value: TaurusdbMysqlInstanceV3Nodes | undefined);
    get availabilityZone(): string;
    get id(): string;
    get name(): string;
    get privateReadIp(): string;
    get status(): string;
    get type(): string;
}
export declare class TaurusdbMysqlInstanceV3NodesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): TaurusdbMysqlInstanceV3NodesOutputReference;
}
export interface TaurusdbMysqlInstanceV3BackupStrategy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3#keep_days TaurusdbMysqlInstanceV3#keep_days}
    */
    readonly keepDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3#start_time TaurusdbMysqlInstanceV3#start_time}
    */
    readonly startTime: string;
}
export declare function taurusdbMysqlInstanceV3BackupStrategyToTerraform(struct?: TaurusdbMysqlInstanceV3BackupStrategyOutputReference | TaurusdbMysqlInstanceV3BackupStrategy): any;
export declare function taurusdbMysqlInstanceV3BackupStrategyToHclTerraform(struct?: TaurusdbMysqlInstanceV3BackupStrategyOutputReference | TaurusdbMysqlInstanceV3BackupStrategy): any;
export declare class TaurusdbMysqlInstanceV3BackupStrategyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TaurusdbMysqlInstanceV3BackupStrategy | undefined;
    set internalValue(value: TaurusdbMysqlInstanceV3BackupStrategy | undefined);
    private _keepDays?;
    get keepDays(): number;
    set keepDays(value: number);
    resetKeepDays(): void;
    get keepDaysInput(): number | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    get startTimeInput(): string | undefined;
}
export interface TaurusdbMysqlInstanceV3Datastore {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3#engine TaurusdbMysqlInstanceV3#engine}
    */
    readonly engine: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3#version TaurusdbMysqlInstanceV3#version}
    */
    readonly version?: string;
}
export declare function taurusdbMysqlInstanceV3DatastoreToTerraform(struct?: TaurusdbMysqlInstanceV3DatastoreOutputReference | TaurusdbMysqlInstanceV3Datastore): any;
export declare function taurusdbMysqlInstanceV3DatastoreToHclTerraform(struct?: TaurusdbMysqlInstanceV3DatastoreOutputReference | TaurusdbMysqlInstanceV3Datastore): any;
export declare class TaurusdbMysqlInstanceV3DatastoreOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TaurusdbMysqlInstanceV3Datastore | undefined;
    set internalValue(value: TaurusdbMysqlInstanceV3Datastore | undefined);
    private _engine?;
    get engine(): string;
    set engine(value: string);
    get engineInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export interface TaurusdbMysqlInstanceV3Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3#create TaurusdbMysqlInstanceV3#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3#delete TaurusdbMysqlInstanceV3#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3#update TaurusdbMysqlInstanceV3#update}
    */
    readonly update?: string;
}
export declare function taurusdbMysqlInstanceV3TimeoutsToTerraform(struct?: TaurusdbMysqlInstanceV3Timeouts | cdktf.IResolvable): any;
export declare function taurusdbMysqlInstanceV3TimeoutsToHclTerraform(struct?: TaurusdbMysqlInstanceV3Timeouts | cdktf.IResolvable): any;
export declare class TaurusdbMysqlInstanceV3TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TaurusdbMysqlInstanceV3Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: TaurusdbMysqlInstanceV3Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3 opentelekomcloud_taurusdb_mysql_instance_v3}
*/
export declare class TaurusdbMysqlInstanceV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_taurusdb_mysql_instance_v3";
    /**
    * Generates CDKTF code for importing a TaurusdbMysqlInstanceV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TaurusdbMysqlInstanceV3 to import
    * @param importFromId The id of the existing TaurusdbMysqlInstanceV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TaurusdbMysqlInstanceV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_instance_v3 opentelekomcloud_taurusdb_mysql_instance_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TaurusdbMysqlInstanceV3Config
    */
    constructor(scope: Construct, id: string, config: TaurusdbMysqlInstanceV3Config);
    private _availabilityZoneMode?;
    get availabilityZoneMode(): string;
    set availabilityZoneMode(value: string);
    resetAvailabilityZoneMode(): void;
    get availabilityZoneModeInput(): string | undefined;
    private _configurationId?;
    get configurationId(): string;
    set configurationId(value: string);
    resetConfigurationId(): void;
    get configurationIdInput(): string | undefined;
    get createdAt(): string;
    get dbUserName(): string;
    private _dedicatedResourceId?;
    get dedicatedResourceId(): string;
    set dedicatedResourceId(value: string);
    resetDedicatedResourceId(): void;
    get dedicatedResourceIdInput(): string | undefined;
    private _enterpriseProjectId?;
    get enterpriseProjectId(): string;
    set enterpriseProjectId(value: string);
    resetEnterpriseProjectId(): void;
    get enterpriseProjectIdInput(): string | undefined;
    private _flavor?;
    get flavor(): string;
    set flavor(value: string);
    get flavorInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _masterAvailabilityZone?;
    get masterAvailabilityZone(): string;
    set masterAvailabilityZone(value: string);
    resetMasterAvailabilityZone(): void;
    get masterAvailabilityZoneInput(): string | undefined;
    get mode(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _nodes;
    get nodes(): TaurusdbMysqlInstanceV3NodesList;
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    get privateDnsName(): string;
    get privateWriteIp(): string;
    private _readReplicas?;
    get readReplicas(): number;
    set readReplicas(value: number);
    resetReadReplicas(): void;
    get readReplicasInput(): number | undefined;
    get region(): string;
    private _secondsLevelMonitoringEnabled?;
    get secondsLevelMonitoringEnabled(): boolean | cdktf.IResolvable;
    set secondsLevelMonitoringEnabled(value: boolean | cdktf.IResolvable);
    resetSecondsLevelMonitoringEnabled(): void;
    get secondsLevelMonitoringEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _secondsLevelMonitoringPeriod?;
    get secondsLevelMonitoringPeriod(): number;
    set secondsLevelMonitoringPeriod(value: number);
    resetSecondsLevelMonitoringPeriod(): void;
    get secondsLevelMonitoringPeriodInput(): number | undefined;
    private _securityGroupId?;
    get securityGroupId(): string;
    set securityGroupId(value: string);
    resetSecurityGroupId(): void;
    get securityGroupIdInput(): string | undefined;
    get status(): string;
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    get subnetIdInput(): string | undefined;
    private _tableNameCaseSensitivity?;
    get tableNameCaseSensitivity(): boolean | cdktf.IResolvable;
    set tableNameCaseSensitivity(value: boolean | cdktf.IResolvable);
    resetTableNameCaseSensitivity(): void;
    get tableNameCaseSensitivityInput(): boolean | cdktf.IResolvable | undefined;
    private _timeZone?;
    get timeZone(): string;
    set timeZone(value: string);
    resetTimeZone(): void;
    get timeZoneInput(): string | undefined;
    get updatedAt(): string;
    private _volumeSize?;
    get volumeSize(): number;
    set volumeSize(value: number);
    resetVolumeSize(): void;
    get volumeSizeInput(): number | undefined;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    get vpcIdInput(): string | undefined;
    private _backupStrategy;
    get backupStrategy(): TaurusdbMysqlInstanceV3BackupStrategyOutputReference;
    putBackupStrategy(value: TaurusdbMysqlInstanceV3BackupStrategy): void;
    resetBackupStrategy(): void;
    get backupStrategyInput(): TaurusdbMysqlInstanceV3BackupStrategy | undefined;
    private _datastore;
    get datastore(): TaurusdbMysqlInstanceV3DatastoreOutputReference;
    putDatastore(value: TaurusdbMysqlInstanceV3Datastore): void;
    resetDatastore(): void;
    get datastoreInput(): TaurusdbMysqlInstanceV3Datastore | undefined;
    private _timeouts;
    get timeouts(): TaurusdbMysqlInstanceV3TimeoutsOutputReference;
    putTimeouts(value: TaurusdbMysqlInstanceV3Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | TaurusdbMysqlInstanceV3Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

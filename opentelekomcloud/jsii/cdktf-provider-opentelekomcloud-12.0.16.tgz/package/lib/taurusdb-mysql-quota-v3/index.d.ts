/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface TaurusdbMysqlQuotaV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_quota_v3#enterprise_project_id TaurusdbMysqlQuotaV3#enterprise_project_id}
    */
    readonly enterpriseProjectId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_quota_v3#enterprise_project_name TaurusdbMysqlQuotaV3#enterprise_project_name}
    */
    readonly enterpriseProjectName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_quota_v3#id TaurusdbMysqlQuotaV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_quota_v3#instance_quota TaurusdbMysqlQuotaV3#instance_quota}
    */
    readonly instanceQuota?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_quota_v3#ram_quota TaurusdbMysqlQuotaV3#ram_quota}
    */
    readonly ramQuota?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_quota_v3#vcpus_quota TaurusdbMysqlQuotaV3#vcpus_quota}
    */
    readonly vcpusQuota?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_quota_v3 opentelekomcloud_taurusdb_mysql_quota_v3}
*/
export declare class TaurusdbMysqlQuotaV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_taurusdb_mysql_quota_v3";
    /**
    * Generates CDKTF code for importing a TaurusdbMysqlQuotaV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TaurusdbMysqlQuotaV3 to import
    * @param importFromId The id of the existing TaurusdbMysqlQuotaV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_quota_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TaurusdbMysqlQuotaV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_quota_v3 opentelekomcloud_taurusdb_mysql_quota_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TaurusdbMysqlQuotaV3Config
    */
    constructor(scope: Construct, id: string, config: TaurusdbMysqlQuotaV3Config);
    get availabilityInstanceQuota(): number;
    get availabilityRamQuota(): number;
    get availabilityVcpusQuota(): number;
    private _enterpriseProjectId?;
    get enterpriseProjectId(): string;
    set enterpriseProjectId(value: string);
    get enterpriseProjectIdInput(): string | undefined;
    private _enterpriseProjectName?;
    get enterpriseProjectName(): string;
    set enterpriseProjectName(value: string);
    get enterpriseProjectNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceQuota?;
    get instanceQuota(): number;
    set instanceQuota(value: number);
    resetInstanceQuota(): void;
    get instanceQuotaInput(): number | undefined;
    private _ramQuota?;
    get ramQuota(): number;
    set ramQuota(value: number);
    resetRamQuota(): void;
    get ramQuotaInput(): number | undefined;
    get region(): string;
    private _vcpusQuota?;
    get vcpusQuota(): number;
    set vcpusQuota(value: number);
    resetVcpusQuota(): void;
    get vcpusQuotaInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

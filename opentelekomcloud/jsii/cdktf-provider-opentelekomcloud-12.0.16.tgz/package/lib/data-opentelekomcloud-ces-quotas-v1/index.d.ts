/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudCesQuotasV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_quotas_v1#id DataOpentelekomcloudCesQuotasV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataOpentelekomcloudCesQuotasV1QuotasResources {
}
export declare function dataOpentelekomcloudCesQuotasV1QuotasResourcesToTerraform(struct?: DataOpentelekomcloudCesQuotasV1QuotasResources): any;
export declare function dataOpentelekomcloudCesQuotasV1QuotasResourcesToHclTerraform(struct?: DataOpentelekomcloudCesQuotasV1QuotasResources): any;
export declare class DataOpentelekomcloudCesQuotasV1QuotasResourcesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudCesQuotasV1QuotasResources | undefined;
    set internalValue(value: DataOpentelekomcloudCesQuotasV1QuotasResources | undefined);
    get quota(): number;
    get type(): string;
    get unit(): string;
    get used(): number;
}
export declare class DataOpentelekomcloudCesQuotasV1QuotasResourcesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudCesQuotasV1QuotasResourcesOutputReference;
}
export interface DataOpentelekomcloudCesQuotasV1Quotas {
}
export declare function dataOpentelekomcloudCesQuotasV1QuotasToTerraform(struct?: DataOpentelekomcloudCesQuotasV1Quotas): any;
export declare function dataOpentelekomcloudCesQuotasV1QuotasToHclTerraform(struct?: DataOpentelekomcloudCesQuotasV1Quotas): any;
export declare class DataOpentelekomcloudCesQuotasV1QuotasOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudCesQuotasV1Quotas | undefined;
    set internalValue(value: DataOpentelekomcloudCesQuotasV1Quotas | undefined);
    private _resources;
    get resources(): DataOpentelekomcloudCesQuotasV1QuotasResourcesList;
}
export declare class DataOpentelekomcloudCesQuotasV1QuotasList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudCesQuotasV1QuotasOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_quotas_v1 opentelekomcloud_ces_quotas_v1}
*/
export declare class DataOpentelekomcloudCesQuotasV1 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_ces_quotas_v1";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudCesQuotasV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudCesQuotasV1 to import
    * @param importFromId The id of the existing DataOpentelekomcloudCesQuotasV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_quotas_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudCesQuotasV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_quotas_v1 opentelekomcloud_ces_quotas_v1} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudCesQuotasV1Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudCesQuotasV1Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _quotas;
    get quotas(): DataOpentelekomcloudCesQuotasV1QuotasList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

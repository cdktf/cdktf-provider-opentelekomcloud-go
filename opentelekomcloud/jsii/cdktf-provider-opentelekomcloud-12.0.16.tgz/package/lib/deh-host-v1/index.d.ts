/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DehHostV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/deh_host_v1#auto_placement DehHostV1#auto_placement}
    */
    readonly autoPlacement?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/deh_host_v1#availability_zone DehHostV1#availability_zone}
    */
    readonly availabilityZone: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/deh_host_v1#available_memory DehHostV1#available_memory}
    */
    readonly availableMemory?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/deh_host_v1#available_vcpus DehHostV1#available_vcpus}
    */
    readonly availableVcpus?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/deh_host_v1#cores DehHostV1#cores}
    */
    readonly cores?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/deh_host_v1#host_type DehHostV1#host_type}
    */
    readonly hostType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/deh_host_v1#host_type_name DehHostV1#host_type_name}
    */
    readonly hostTypeName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/deh_host_v1#id DehHostV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/deh_host_v1#instance_total DehHostV1#instance_total}
    */
    readonly instanceTotal?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/deh_host_v1#instance_uuids DehHostV1#instance_uuids}
    */
    readonly instanceUuids?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/deh_host_v1#memory DehHostV1#memory}
    */
    readonly memory?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/deh_host_v1#name DehHostV1#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/deh_host_v1#region DehHostV1#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/deh_host_v1#sockets DehHostV1#sockets}
    */
    readonly sockets?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/deh_host_v1#status DehHostV1#status}
    */
    readonly status?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/deh_host_v1#tags DehHostV1#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/deh_host_v1#vcpus DehHostV1#vcpus}
    */
    readonly vcpus?: number;
    /**
    * available_instance_capacities block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/deh_host_v1#available_instance_capacities DehHostV1#available_instance_capacities}
    */
    readonly availableInstanceCapacities?: DehHostV1AvailableInstanceCapacities[] | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/deh_host_v1#timeouts DehHostV1#timeouts}
    */
    readonly timeouts?: DehHostV1Timeouts;
}
export interface DehHostV1AvailableInstanceCapacities {
}
export declare function dehHostV1AvailableInstanceCapacitiesToTerraform(struct?: DehHostV1AvailableInstanceCapacities | cdktf.IResolvable): any;
export declare function dehHostV1AvailableInstanceCapacitiesToHclTerraform(struct?: DehHostV1AvailableInstanceCapacities | cdktf.IResolvable): any;
export declare class DehHostV1AvailableInstanceCapacitiesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DehHostV1AvailableInstanceCapacities | cdktf.IResolvable | undefined;
    set internalValue(value: DehHostV1AvailableInstanceCapacities | cdktf.IResolvable | undefined);
    get flavor(): string;
}
export declare class DehHostV1AvailableInstanceCapacitiesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DehHostV1AvailableInstanceCapacities[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DehHostV1AvailableInstanceCapacitiesOutputReference;
}
export interface DehHostV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/deh_host_v1#create DehHostV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/deh_host_v1#delete DehHostV1#delete}
    */
    readonly delete?: string;
}
export declare function dehHostV1TimeoutsToTerraform(struct?: DehHostV1Timeouts | cdktf.IResolvable): any;
export declare function dehHostV1TimeoutsToHclTerraform(struct?: DehHostV1Timeouts | cdktf.IResolvable): any;
export declare class DehHostV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DehHostV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DehHostV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/deh_host_v1 opentelekomcloud_deh_host_v1}
*/
export declare class DehHostV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_deh_host_v1";
    /**
    * Generates CDKTF code for importing a DehHostV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DehHostV1 to import
    * @param importFromId The id of the existing DehHostV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/deh_host_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DehHostV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/deh_host_v1 opentelekomcloud_deh_host_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DehHostV1Config
    */
    constructor(scope: Construct, id: string, config: DehHostV1Config);
    private _autoPlacement?;
    get autoPlacement(): string;
    set autoPlacement(value: string);
    resetAutoPlacement(): void;
    get autoPlacementInput(): string | undefined;
    private _availabilityZone?;
    get availabilityZone(): string;
    set availabilityZone(value: string);
    get availabilityZoneInput(): string | undefined;
    private _availableMemory?;
    get availableMemory(): number;
    set availableMemory(value: number);
    resetAvailableMemory(): void;
    get availableMemoryInput(): number | undefined;
    private _availableVcpus?;
    get availableVcpus(): number;
    set availableVcpus(value: number);
    resetAvailableVcpus(): void;
    get availableVcpusInput(): number | undefined;
    private _cores?;
    get cores(): number;
    set cores(value: number);
    resetCores(): void;
    get coresInput(): number | undefined;
    private _hostType?;
    get hostType(): string;
    set hostType(value: string);
    get hostTypeInput(): string | undefined;
    private _hostTypeName?;
    get hostTypeName(): string;
    set hostTypeName(value: string);
    resetHostTypeName(): void;
    get hostTypeNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceTotal?;
    get instanceTotal(): number;
    set instanceTotal(value: number);
    resetInstanceTotal(): void;
    get instanceTotalInput(): number | undefined;
    private _instanceUuids?;
    get instanceUuids(): string[];
    set instanceUuids(value: string[]);
    resetInstanceUuids(): void;
    get instanceUuidsInput(): string[] | undefined;
    private _memory?;
    get memory(): number;
    set memory(value: number);
    resetMemory(): void;
    get memoryInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _sockets?;
    get sockets(): number;
    set sockets(value: number);
    resetSockets(): void;
    get socketsInput(): number | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _vcpus?;
    get vcpus(): number;
    set vcpus(value: number);
    resetVcpus(): void;
    get vcpusInput(): number | undefined;
    private _availableInstanceCapacities;
    get availableInstanceCapacities(): DehHostV1AvailableInstanceCapacitiesList;
    putAvailableInstanceCapacities(value: DehHostV1AvailableInstanceCapacities[] | cdktf.IResolvable): void;
    resetAvailableInstanceCapacities(): void;
    get availableInstanceCapacitiesInput(): cdktf.IResolvable | DehHostV1AvailableInstanceCapacities[] | undefined;
    private _timeouts;
    get timeouts(): DehHostV1TimeoutsOutputReference;
    putTimeouts(value: DehHostV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DehHostV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

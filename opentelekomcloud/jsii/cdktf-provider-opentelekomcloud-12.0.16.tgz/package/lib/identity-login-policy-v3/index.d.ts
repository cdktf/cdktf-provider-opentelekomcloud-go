/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface IdentityLoginPolicyV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_login_policy_v3#account_validity_period IdentityLoginPolicyV3#account_validity_period}
    */
    readonly accountValidityPeriod?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_login_policy_v3#custom_info_for_login IdentityLoginPolicyV3#custom_info_for_login}
    */
    readonly customInfoForLogin?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_login_policy_v3#id IdentityLoginPolicyV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_login_policy_v3#lockout_duration IdentityLoginPolicyV3#lockout_duration}
    */
    readonly lockoutDuration?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_login_policy_v3#login_failed_times IdentityLoginPolicyV3#login_failed_times}
    */
    readonly loginFailedTimes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_login_policy_v3#period_with_login_failures IdentityLoginPolicyV3#period_with_login_failures}
    */
    readonly periodWithLoginFailures?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_login_policy_v3#session_timeout IdentityLoginPolicyV3#session_timeout}
    */
    readonly sessionTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_login_policy_v3#show_recent_login_info IdentityLoginPolicyV3#show_recent_login_info}
    */
    readonly showRecentLoginInfo?: boolean | cdktf.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_login_policy_v3 opentelekomcloud_identity_login_policy_v3}
*/
export declare class IdentityLoginPolicyV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_identity_login_policy_v3";
    /**
    * Generates CDKTF code for importing a IdentityLoginPolicyV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IdentityLoginPolicyV3 to import
    * @param importFromId The id of the existing IdentityLoginPolicyV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_login_policy_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IdentityLoginPolicyV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_login_policy_v3 opentelekomcloud_identity_login_policy_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IdentityLoginPolicyV3Config = {}
    */
    constructor(scope: Construct, id: string, config?: IdentityLoginPolicyV3Config);
    private _accountValidityPeriod?;
    get accountValidityPeriod(): number;
    set accountValidityPeriod(value: number);
    resetAccountValidityPeriod(): void;
    get accountValidityPeriodInput(): number | undefined;
    private _customInfoForLogin?;
    get customInfoForLogin(): string;
    set customInfoForLogin(value: string);
    resetCustomInfoForLogin(): void;
    get customInfoForLoginInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _lockoutDuration?;
    get lockoutDuration(): number;
    set lockoutDuration(value: number);
    resetLockoutDuration(): void;
    get lockoutDurationInput(): number | undefined;
    private _loginFailedTimes?;
    get loginFailedTimes(): number;
    set loginFailedTimes(value: number);
    resetLoginFailedTimes(): void;
    get loginFailedTimesInput(): number | undefined;
    private _periodWithLoginFailures?;
    get periodWithLoginFailures(): number;
    set periodWithLoginFailures(value: number);
    resetPeriodWithLoginFailures(): void;
    get periodWithLoginFailuresInput(): number | undefined;
    private _sessionTimeout?;
    get sessionTimeout(): number;
    set sessionTimeout(value: number);
    resetSessionTimeout(): void;
    get sessionTimeoutInput(): number | undefined;
    private _showRecentLoginInfo?;
    get showRecentLoginInfo(): boolean | cdktf.IResolvable;
    set showRecentLoginInfo(value: boolean | cdktf.IResolvable);
    resetShowRecentLoginInfo(): void;
    get showRecentLoginInfoInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

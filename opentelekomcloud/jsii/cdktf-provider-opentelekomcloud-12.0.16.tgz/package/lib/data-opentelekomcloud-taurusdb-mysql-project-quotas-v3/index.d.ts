/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudTaurusdbMysqlProjectQuotasV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_project_quotas_v3#id DataOpentelekomcloudTaurusdbMysqlProjectQuotasV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_project_quotas_v3#type DataOpentelekomcloudTaurusdbMysqlProjectQuotasV3#type}
    */
    readonly type?: string;
}
export interface DataOpentelekomcloudTaurusdbMysqlProjectQuotasV3QuotasResources {
}
export declare function dataOpentelekomcloudTaurusdbMysqlProjectQuotasV3QuotasResourcesToTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlProjectQuotasV3QuotasResources): any;
export declare function dataOpentelekomcloudTaurusdbMysqlProjectQuotasV3QuotasResourcesToHclTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlProjectQuotasV3QuotasResources): any;
export declare class DataOpentelekomcloudTaurusdbMysqlProjectQuotasV3QuotasResourcesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudTaurusdbMysqlProjectQuotasV3QuotasResources | undefined;
    set internalValue(value: DataOpentelekomcloudTaurusdbMysqlProjectQuotasV3QuotasResources | undefined);
    get quota(): number;
    get type(): string;
    get used(): number;
}
export declare class DataOpentelekomcloudTaurusdbMysqlProjectQuotasV3QuotasResourcesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudTaurusdbMysqlProjectQuotasV3QuotasResourcesOutputReference;
}
export interface DataOpentelekomcloudTaurusdbMysqlProjectQuotasV3Quotas {
}
export declare function dataOpentelekomcloudTaurusdbMysqlProjectQuotasV3QuotasToTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlProjectQuotasV3Quotas): any;
export declare function dataOpentelekomcloudTaurusdbMysqlProjectQuotasV3QuotasToHclTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlProjectQuotasV3Quotas): any;
export declare class DataOpentelekomcloudTaurusdbMysqlProjectQuotasV3QuotasOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudTaurusdbMysqlProjectQuotasV3Quotas | undefined;
    set internalValue(value: DataOpentelekomcloudTaurusdbMysqlProjectQuotasV3Quotas | undefined);
    private _resources;
    get resources(): DataOpentelekomcloudTaurusdbMysqlProjectQuotasV3QuotasResourcesList;
}
export declare class DataOpentelekomcloudTaurusdbMysqlProjectQuotasV3QuotasList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudTaurusdbMysqlProjectQuotasV3QuotasOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_project_quotas_v3 opentelekomcloud_taurusdb_mysql_project_quotas_v3}
*/
export declare class DataOpentelekomcloudTaurusdbMysqlProjectQuotasV3 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_taurusdb_mysql_project_quotas_v3";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudTaurusdbMysqlProjectQuotasV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudTaurusdbMysqlProjectQuotasV3 to import
    * @param importFromId The id of the existing DataOpentelekomcloudTaurusdbMysqlProjectQuotasV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_project_quotas_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudTaurusdbMysqlProjectQuotasV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_project_quotas_v3 opentelekomcloud_taurusdb_mysql_project_quotas_v3} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudTaurusdbMysqlProjectQuotasV3Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudTaurusdbMysqlProjectQuotasV3Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _quotas;
    get quotas(): DataOpentelekomcloudTaurusdbMysqlProjectQuotasV3QuotasList;
    get region(): string;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

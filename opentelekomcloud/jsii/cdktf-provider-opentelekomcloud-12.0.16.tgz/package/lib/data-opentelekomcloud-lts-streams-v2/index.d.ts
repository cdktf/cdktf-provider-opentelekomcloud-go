/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudLtsStreamsV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/lts_streams_v2#id DataOpentelekomcloudLtsStreamsV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/lts_streams_v2#log_group_name DataOpentelekomcloudLtsStreamsV2#log_group_name}
    */
    readonly logGroupName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/lts_streams_v2#name DataOpentelekomcloudLtsStreamsV2#name}
    */
    readonly name?: string;
}
export interface DataOpentelekomcloudLtsStreamsV2Streams {
}
export declare function dataOpentelekomcloudLtsStreamsV2StreamsToTerraform(struct?: DataOpentelekomcloudLtsStreamsV2Streams): any;
export declare function dataOpentelekomcloudLtsStreamsV2StreamsToHclTerraform(struct?: DataOpentelekomcloudLtsStreamsV2Streams): any;
export declare class DataOpentelekomcloudLtsStreamsV2StreamsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudLtsStreamsV2Streams | undefined;
    set internalValue(value: DataOpentelekomcloudLtsStreamsV2Streams | undefined);
    get createdAt(): string;
    get enterpriseProjectId(): string;
    get id(): string;
    get name(): string;
    private _tags;
    get tags(): cdktf.StringMap;
    get ttlInDays(): number;
}
export declare class DataOpentelekomcloudLtsStreamsV2StreamsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudLtsStreamsV2StreamsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/lts_streams_v2 opentelekomcloud_lts_streams_v2}
*/
export declare class DataOpentelekomcloudLtsStreamsV2 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_lts_streams_v2";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudLtsStreamsV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudLtsStreamsV2 to import
    * @param importFromId The id of the existing DataOpentelekomcloudLtsStreamsV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/lts_streams_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudLtsStreamsV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/lts_streams_v2 opentelekomcloud_lts_streams_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudLtsStreamsV2Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudLtsStreamsV2Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _logGroupName?;
    get logGroupName(): string;
    set logGroupName(value: string);
    resetLogGroupName(): void;
    get logGroupNameInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get region(): string;
    private _streams;
    get streams(): DataOpentelekomcloudLtsStreamsV2StreamsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

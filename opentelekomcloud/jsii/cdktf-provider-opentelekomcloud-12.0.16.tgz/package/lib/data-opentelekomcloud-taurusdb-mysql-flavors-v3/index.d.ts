/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudTaurusdbMysqlFlavorsV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_flavors_v3#availability_zone_mode DataOpentelekomcloudTaurusdbMysqlFlavorsV3#availability_zone_mode}
    */
    readonly availabilityZoneMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_flavors_v3#engine DataOpentelekomcloudTaurusdbMysqlFlavorsV3#engine}
    */
    readonly engine?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_flavors_v3#id DataOpentelekomcloudTaurusdbMysqlFlavorsV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_flavors_v3#version DataOpentelekomcloudTaurusdbMysqlFlavorsV3#version}
    */
    readonly version?: string;
}
export interface DataOpentelekomcloudTaurusdbMysqlFlavorsV3Flavors {
}
export declare function dataOpentelekomcloudTaurusdbMysqlFlavorsV3FlavorsToTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlFlavorsV3Flavors): any;
export declare function dataOpentelekomcloudTaurusdbMysqlFlavorsV3FlavorsToHclTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlFlavorsV3Flavors): any;
export declare class DataOpentelekomcloudTaurusdbMysqlFlavorsV3FlavorsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudTaurusdbMysqlFlavorsV3Flavors | undefined;
    set internalValue(value: DataOpentelekomcloudTaurusdbMysqlFlavorsV3Flavors | undefined);
    private _azStatus;
    get azStatus(): cdktf.StringMap;
    get memory(): string;
    get mode(): string;
    get name(): string;
    get type(): string;
    get vcpus(): string;
    get version(): string;
}
export declare class DataOpentelekomcloudTaurusdbMysqlFlavorsV3FlavorsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudTaurusdbMysqlFlavorsV3FlavorsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_flavors_v3 opentelekomcloud_taurusdb_mysql_flavors_v3}
*/
export declare class DataOpentelekomcloudTaurusdbMysqlFlavorsV3 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_taurusdb_mysql_flavors_v3";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudTaurusdbMysqlFlavorsV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudTaurusdbMysqlFlavorsV3 to import
    * @param importFromId The id of the existing DataOpentelekomcloudTaurusdbMysqlFlavorsV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_flavors_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudTaurusdbMysqlFlavorsV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_flavors_v3 opentelekomcloud_taurusdb_mysql_flavors_v3} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudTaurusdbMysqlFlavorsV3Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudTaurusdbMysqlFlavorsV3Config);
    private _availabilityZoneMode?;
    get availabilityZoneMode(): string;
    set availabilityZoneMode(value: string);
    resetAvailabilityZoneMode(): void;
    get availabilityZoneModeInput(): string | undefined;
    private _engine?;
    get engine(): string;
    set engine(value: string);
    resetEngine(): void;
    get engineInput(): string | undefined;
    private _flavors;
    get flavors(): DataOpentelekomcloudTaurusdbMysqlFlavorsV3FlavorsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get region(): string;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

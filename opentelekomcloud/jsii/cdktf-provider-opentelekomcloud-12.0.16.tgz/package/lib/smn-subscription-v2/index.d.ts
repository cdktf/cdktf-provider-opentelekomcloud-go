/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface SmnSubscriptionV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/smn_subscription_v2#endpoint SmnSubscriptionV2#endpoint}
    */
    readonly endpoint: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/smn_subscription_v2#id SmnSubscriptionV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/smn_subscription_v2#project_name SmnSubscriptionV2#project_name}
    */
    readonly projectName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/smn_subscription_v2#protocol SmnSubscriptionV2#protocol}
    */
    readonly protocol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/smn_subscription_v2#remark SmnSubscriptionV2#remark}
    */
    readonly remark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/smn_subscription_v2#topic_urn SmnSubscriptionV2#topic_urn}
    */
    readonly topicUrn: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/smn_subscription_v2 opentelekomcloud_smn_subscription_v2}
*/
export declare class SmnSubscriptionV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_smn_subscription_v2";
    /**
    * Generates CDKTF code for importing a SmnSubscriptionV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SmnSubscriptionV2 to import
    * @param importFromId The id of the existing SmnSubscriptionV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/smn_subscription_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SmnSubscriptionV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/smn_subscription_v2 opentelekomcloud_smn_subscription_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SmnSubscriptionV2Config
    */
    constructor(scope: Construct, id: string, config: SmnSubscriptionV2Config);
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    get endpointInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get owner(): string;
    private _projectName?;
    get projectName(): string;
    set projectName(value: string);
    resetProjectName(): void;
    get projectNameInput(): string | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    get protocolInput(): string | undefined;
    private _remark?;
    get remark(): string;
    set remark(value: string);
    resetRemark(): void;
    get remarkInput(): string | undefined;
    get status(): number;
    get subscriptionUrn(): string;
    private _topicUrn?;
    get topicUrn(): string;
    set topicUrn(value: string);
    get topicUrnInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface RmsPolicyAssignmentV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_policy_assignment_v1#description RmsPolicyAssignmentV1#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_policy_assignment_v1#id RmsPolicyAssignmentV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_policy_assignment_v1#name RmsPolicyAssignmentV1#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_policy_assignment_v1#parameters RmsPolicyAssignmentV1#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_policy_assignment_v1#period RmsPolicyAssignmentV1#period}
    */
    readonly period?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_policy_assignment_v1#policy_definition_id RmsPolicyAssignmentV1#policy_definition_id}
    */
    readonly policyDefinitionId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_policy_assignment_v1#status RmsPolicyAssignmentV1#status}
    */
    readonly status?: string;
    /**
    * custom_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_policy_assignment_v1#custom_policy RmsPolicyAssignmentV1#custom_policy}
    */
    readonly customPolicy?: RmsPolicyAssignmentV1CustomPolicy;
    /**
    * policy_filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_policy_assignment_v1#policy_filter RmsPolicyAssignmentV1#policy_filter}
    */
    readonly policyFilter?: RmsPolicyAssignmentV1PolicyFilter;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_policy_assignment_v1#timeouts RmsPolicyAssignmentV1#timeouts}
    */
    readonly timeouts?: RmsPolicyAssignmentV1Timeouts;
}
export interface RmsPolicyAssignmentV1CustomPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_policy_assignment_v1#auth_type RmsPolicyAssignmentV1#auth_type}
    */
    readonly authType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_policy_assignment_v1#auth_value RmsPolicyAssignmentV1#auth_value}
    */
    readonly authValue?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_policy_assignment_v1#function_urn RmsPolicyAssignmentV1#function_urn}
    */
    readonly functionUrn: string;
}
export declare function rmsPolicyAssignmentV1CustomPolicyToTerraform(struct?: RmsPolicyAssignmentV1CustomPolicyOutputReference | RmsPolicyAssignmentV1CustomPolicy): any;
export declare function rmsPolicyAssignmentV1CustomPolicyToHclTerraform(struct?: RmsPolicyAssignmentV1CustomPolicyOutputReference | RmsPolicyAssignmentV1CustomPolicy): any;
export declare class RmsPolicyAssignmentV1CustomPolicyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RmsPolicyAssignmentV1CustomPolicy | undefined;
    set internalValue(value: RmsPolicyAssignmentV1CustomPolicy | undefined);
    private _authType?;
    get authType(): string;
    set authType(value: string);
    get authTypeInput(): string | undefined;
    private _authValue?;
    get authValue(): {
        [key: string]: string;
    };
    set authValue(value: {
        [key: string]: string;
    });
    resetAuthValue(): void;
    get authValueInput(): {
        [key: string]: string;
    } | undefined;
    private _functionUrn?;
    get functionUrn(): string;
    set functionUrn(value: string);
    get functionUrnInput(): string | undefined;
}
export interface RmsPolicyAssignmentV1PolicyFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_policy_assignment_v1#region RmsPolicyAssignmentV1#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_policy_assignment_v1#resource_id RmsPolicyAssignmentV1#resource_id}
    */
    readonly resourceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_policy_assignment_v1#resource_provider RmsPolicyAssignmentV1#resource_provider}
    */
    readonly resourceProvider?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_policy_assignment_v1#resource_type RmsPolicyAssignmentV1#resource_type}
    */
    readonly resourceType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_policy_assignment_v1#tag_key RmsPolicyAssignmentV1#tag_key}
    */
    readonly tagKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_policy_assignment_v1#tag_value RmsPolicyAssignmentV1#tag_value}
    */
    readonly tagValue?: string;
}
export declare function rmsPolicyAssignmentV1PolicyFilterToTerraform(struct?: RmsPolicyAssignmentV1PolicyFilterOutputReference | RmsPolicyAssignmentV1PolicyFilter): any;
export declare function rmsPolicyAssignmentV1PolicyFilterToHclTerraform(struct?: RmsPolicyAssignmentV1PolicyFilterOutputReference | RmsPolicyAssignmentV1PolicyFilter): any;
export declare class RmsPolicyAssignmentV1PolicyFilterOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RmsPolicyAssignmentV1PolicyFilter | undefined;
    set internalValue(value: RmsPolicyAssignmentV1PolicyFilter | undefined);
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    resetResourceId(): void;
    get resourceIdInput(): string | undefined;
    private _resourceProvider?;
    get resourceProvider(): string;
    set resourceProvider(value: string);
    resetResourceProvider(): void;
    get resourceProviderInput(): string | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    resetResourceType(): void;
    get resourceTypeInput(): string | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    resetTagKey(): void;
    get tagKeyInput(): string | undefined;
    private _tagValue?;
    get tagValue(): string;
    set tagValue(value: string);
    resetTagValue(): void;
    get tagValueInput(): string | undefined;
}
export interface RmsPolicyAssignmentV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_policy_assignment_v1#create RmsPolicyAssignmentV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_policy_assignment_v1#update RmsPolicyAssignmentV1#update}
    */
    readonly update?: string;
}
export declare function rmsPolicyAssignmentV1TimeoutsToTerraform(struct?: RmsPolicyAssignmentV1Timeouts | cdktf.IResolvable): any;
export declare function rmsPolicyAssignmentV1TimeoutsToHclTerraform(struct?: RmsPolicyAssignmentV1Timeouts | cdktf.IResolvable): any;
export declare class RmsPolicyAssignmentV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RmsPolicyAssignmentV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: RmsPolicyAssignmentV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_policy_assignment_v1 opentelekomcloud_rms_policy_assignment_v1}
*/
export declare class RmsPolicyAssignmentV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_rms_policy_assignment_v1";
    /**
    * Generates CDKTF code for importing a RmsPolicyAssignmentV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RmsPolicyAssignmentV1 to import
    * @param importFromId The id of the existing RmsPolicyAssignmentV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_policy_assignment_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RmsPolicyAssignmentV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_policy_assignment_v1 opentelekomcloud_rms_policy_assignment_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RmsPolicyAssignmentV1Config
    */
    constructor(scope: Construct, id: string, config: RmsPolicyAssignmentV1Config);
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _period?;
    get period(): string;
    set period(value: string);
    resetPeriod(): void;
    get periodInput(): string | undefined;
    private _policyDefinitionId?;
    get policyDefinitionId(): string;
    set policyDefinitionId(value: string);
    resetPolicyDefinitionId(): void;
    get policyDefinitionIdInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    get type(): string;
    get updatedAt(): string;
    private _customPolicy;
    get customPolicy(): RmsPolicyAssignmentV1CustomPolicyOutputReference;
    putCustomPolicy(value: RmsPolicyAssignmentV1CustomPolicy): void;
    resetCustomPolicy(): void;
    get customPolicyInput(): RmsPolicyAssignmentV1CustomPolicy | undefined;
    private _policyFilter;
    get policyFilter(): RmsPolicyAssignmentV1PolicyFilterOutputReference;
    putPolicyFilter(value: RmsPolicyAssignmentV1PolicyFilter): void;
    resetPolicyFilter(): void;
    get policyFilterInput(): RmsPolicyAssignmentV1PolicyFilter | undefined;
    private _timeouts;
    get timeouts(): RmsPolicyAssignmentV1TimeoutsOutputReference;
    putTimeouts(value: RmsPolicyAssignmentV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | RmsPolicyAssignmentV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

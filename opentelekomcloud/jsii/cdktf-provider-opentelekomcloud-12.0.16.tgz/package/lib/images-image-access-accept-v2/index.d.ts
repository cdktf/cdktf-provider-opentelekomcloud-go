/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ImagesImageAccessAcceptV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/images_image_access_accept_v2#id ImagesImageAccessAcceptV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/images_image_access_accept_v2#image_id ImagesImageAccessAcceptV2#image_id}
    */
    readonly imageId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/images_image_access_accept_v2#member_id ImagesImageAccessAcceptV2#member_id}
    */
    readonly memberId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/images_image_access_accept_v2#status ImagesImageAccessAcceptV2#status}
    */
    readonly status: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/images_image_access_accept_v2 opentelekomcloud_images_image_access_accept_v2}
*/
export declare class ImagesImageAccessAcceptV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_images_image_access_accept_v2";
    /**
    * Generates CDKTF code for importing a ImagesImageAccessAcceptV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ImagesImageAccessAcceptV2 to import
    * @param importFromId The id of the existing ImagesImageAccessAcceptV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/images_image_access_accept_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ImagesImageAccessAcceptV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/images_image_access_accept_v2 opentelekomcloud_images_image_access_accept_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ImagesImageAccessAcceptV2Config
    */
    constructor(scope: Construct, id: string, config: ImagesImageAccessAcceptV2Config);
    get createdAt(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _imageId?;
    get imageId(): string;
    set imageId(value: string);
    get imageIdInput(): string | undefined;
    private _memberId?;
    get memberId(): string;
    set memberId(value: string);
    get memberIdInput(): string | undefined;
    get schema(): string;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

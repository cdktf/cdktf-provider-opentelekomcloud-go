/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudCesMultipleMetricDataV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_multiple_metric_data_v1#filter DataOpentelekomcloudCesMultipleMetricDataV1#filter}
    */
    readonly filter: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_multiple_metric_data_v1#from DataOpentelekomcloudCesMultipleMetricDataV1#from}
    */
    readonly from: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_multiple_metric_data_v1#id DataOpentelekomcloudCesMultipleMetricDataV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_multiple_metric_data_v1#period DataOpentelekomcloudCesMultipleMetricDataV1#period}
    */
    readonly period: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_multiple_metric_data_v1#to DataOpentelekomcloudCesMultipleMetricDataV1#to}
    */
    readonly to: number;
    /**
    * metrics block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_multiple_metric_data_v1#metrics DataOpentelekomcloudCesMultipleMetricDataV1#metrics}
    */
    readonly metrics: DataOpentelekomcloudCesMultipleMetricDataV1Metrics[] | cdktf.IResolvable;
}
export interface DataOpentelekomcloudCesMultipleMetricDataV1MetricsDatapoints {
}
export declare function dataOpentelekomcloudCesMultipleMetricDataV1MetricsDatapointsToTerraform(struct?: DataOpentelekomcloudCesMultipleMetricDataV1MetricsDatapoints): any;
export declare function dataOpentelekomcloudCesMultipleMetricDataV1MetricsDatapointsToHclTerraform(struct?: DataOpentelekomcloudCesMultipleMetricDataV1MetricsDatapoints): any;
export declare class DataOpentelekomcloudCesMultipleMetricDataV1MetricsDatapointsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudCesMultipleMetricDataV1MetricsDatapoints | undefined;
    set internalValue(value: DataOpentelekomcloudCesMultipleMetricDataV1MetricsDatapoints | undefined);
    get average(): number;
    get max(): number;
    get min(): number;
    get sum(): number;
    get timestamp(): number;
    get variance(): number;
}
export declare class DataOpentelekomcloudCesMultipleMetricDataV1MetricsDatapointsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudCesMultipleMetricDataV1MetricsDatapointsOutputReference;
}
export interface DataOpentelekomcloudCesMultipleMetricDataV1MetricsDimensions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_multiple_metric_data_v1#name DataOpentelekomcloudCesMultipleMetricDataV1#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_multiple_metric_data_v1#value DataOpentelekomcloudCesMultipleMetricDataV1#value}
    */
    readonly value: string;
}
export declare function dataOpentelekomcloudCesMultipleMetricDataV1MetricsDimensionsToTerraform(struct?: DataOpentelekomcloudCesMultipleMetricDataV1MetricsDimensions | cdktf.IResolvable): any;
export declare function dataOpentelekomcloudCesMultipleMetricDataV1MetricsDimensionsToHclTerraform(struct?: DataOpentelekomcloudCesMultipleMetricDataV1MetricsDimensions | cdktf.IResolvable): any;
export declare class DataOpentelekomcloudCesMultipleMetricDataV1MetricsDimensionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudCesMultipleMetricDataV1MetricsDimensions | cdktf.IResolvable | undefined;
    set internalValue(value: DataOpentelekomcloudCesMultipleMetricDataV1MetricsDimensions | cdktf.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class DataOpentelekomcloudCesMultipleMetricDataV1MetricsDimensionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataOpentelekomcloudCesMultipleMetricDataV1MetricsDimensions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudCesMultipleMetricDataV1MetricsDimensionsOutputReference;
}
export interface DataOpentelekomcloudCesMultipleMetricDataV1Metrics {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_multiple_metric_data_v1#metric_name DataOpentelekomcloudCesMultipleMetricDataV1#metric_name}
    */
    readonly metricName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_multiple_metric_data_v1#namespace DataOpentelekomcloudCesMultipleMetricDataV1#namespace}
    */
    readonly namespace: string;
    /**
    * dimensions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_multiple_metric_data_v1#dimensions DataOpentelekomcloudCesMultipleMetricDataV1#dimensions}
    */
    readonly dimensions: DataOpentelekomcloudCesMultipleMetricDataV1MetricsDimensions[] | cdktf.IResolvable;
}
export declare function dataOpentelekomcloudCesMultipleMetricDataV1MetricsToTerraform(struct?: DataOpentelekomcloudCesMultipleMetricDataV1Metrics | cdktf.IResolvable): any;
export declare function dataOpentelekomcloudCesMultipleMetricDataV1MetricsToHclTerraform(struct?: DataOpentelekomcloudCesMultipleMetricDataV1Metrics | cdktf.IResolvable): any;
export declare class DataOpentelekomcloudCesMultipleMetricDataV1MetricsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudCesMultipleMetricDataV1Metrics | cdktf.IResolvable | undefined;
    set internalValue(value: DataOpentelekomcloudCesMultipleMetricDataV1Metrics | cdktf.IResolvable | undefined);
    private _datapoints;
    get datapoints(): DataOpentelekomcloudCesMultipleMetricDataV1MetricsDatapointsList;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    get metricNameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    get namespaceInput(): string | undefined;
    get unit(): string;
    private _dimensions;
    get dimensions(): DataOpentelekomcloudCesMultipleMetricDataV1MetricsDimensionsList;
    putDimensions(value: DataOpentelekomcloudCesMultipleMetricDataV1MetricsDimensions[] | cdktf.IResolvable): void;
    get dimensionsInput(): cdktf.IResolvable | DataOpentelekomcloudCesMultipleMetricDataV1MetricsDimensions[] | undefined;
}
export declare class DataOpentelekomcloudCesMultipleMetricDataV1MetricsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataOpentelekomcloudCesMultipleMetricDataV1Metrics[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudCesMultipleMetricDataV1MetricsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_multiple_metric_data_v1 opentelekomcloud_ces_multiple_metric_data_v1}
*/
export declare class DataOpentelekomcloudCesMultipleMetricDataV1 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_ces_multiple_metric_data_v1";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudCesMultipleMetricDataV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudCesMultipleMetricDataV1 to import
    * @param importFromId The id of the existing DataOpentelekomcloudCesMultipleMetricDataV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_multiple_metric_data_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudCesMultipleMetricDataV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ces_multiple_metric_data_v1 opentelekomcloud_ces_multiple_metric_data_v1} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudCesMultipleMetricDataV1Config
    */
    constructor(scope: Construct, id: string, config: DataOpentelekomcloudCesMultipleMetricDataV1Config);
    private _filter?;
    get filter(): string;
    set filter(value: string);
    get filterInput(): string | undefined;
    private _from?;
    get from(): number;
    set from(value: number);
    get fromInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _period?;
    get period(): string;
    set period(value: string);
    get periodInput(): string | undefined;
    private _to?;
    get to(): number;
    set to(value: number);
    get toInput(): number | undefined;
    private _metrics;
    get metrics(): DataOpentelekomcloudCesMultipleMetricDataV1MetricsList;
    putMetrics(value: DataOpentelekomcloudCesMultipleMetricDataV1Metrics[] | cdktf.IResolvable): void;
    get metricsInput(): cdktf.IResolvable | DataOpentelekomcloudCesMultipleMetricDataV1Metrics[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

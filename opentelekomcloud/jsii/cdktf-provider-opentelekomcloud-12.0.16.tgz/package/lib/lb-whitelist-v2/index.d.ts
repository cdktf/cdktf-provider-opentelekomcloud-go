/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface LbWhitelistV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_whitelist_v2#enable_whitelist LbWhitelistV2#enable_whitelist}
    */
    readonly enableWhitelist?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_whitelist_v2#id LbWhitelistV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_whitelist_v2#listener_id LbWhitelistV2#listener_id}
    */
    readonly listenerId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_whitelist_v2#tenant_id LbWhitelistV2#tenant_id}
    */
    readonly tenantId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_whitelist_v2#whitelist LbWhitelistV2#whitelist}
    */
    readonly whitelist?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_whitelist_v2 opentelekomcloud_lb_whitelist_v2}
*/
export declare class LbWhitelistV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_lb_whitelist_v2";
    /**
    * Generates CDKTF code for importing a LbWhitelistV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LbWhitelistV2 to import
    * @param importFromId The id of the existing LbWhitelistV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_whitelist_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LbWhitelistV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lb_whitelist_v2 opentelekomcloud_lb_whitelist_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LbWhitelistV2Config
    */
    constructor(scope: Construct, id: string, config: LbWhitelistV2Config);
    private _enableWhitelist?;
    get enableWhitelist(): boolean | cdktf.IResolvable;
    set enableWhitelist(value: boolean | cdktf.IResolvable);
    resetEnableWhitelist(): void;
    get enableWhitelistInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _listenerId?;
    get listenerId(): string;
    set listenerId(value: string);
    get listenerIdInput(): string | undefined;
    private _tenantId?;
    get tenantId(): string;
    set tenantId(value: string);
    resetTenantId(): void;
    get tenantIdInput(): string | undefined;
    private _whitelist?;
    get whitelist(): string;
    set whitelist(value: string);
    resetWhitelist(): void;
    get whitelistInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

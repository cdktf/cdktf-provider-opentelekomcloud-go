/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudComputeInstancesV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/compute_instances_v2#availability_zone DataOpentelekomcloudComputeInstancesV2#availability_zone}
    */
    readonly availabilityZone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/compute_instances_v2#flavor_id DataOpentelekomcloudComputeInstancesV2#flavor_id}
    */
    readonly flavorId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/compute_instances_v2#flavor_name DataOpentelekomcloudComputeInstancesV2#flavor_name}
    */
    readonly flavorName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/compute_instances_v2#id DataOpentelekomcloudComputeInstancesV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/compute_instances_v2#image_id DataOpentelekomcloudComputeInstancesV2#image_id}
    */
    readonly imageId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/compute_instances_v2#instance_id DataOpentelekomcloudComputeInstancesV2#instance_id}
    */
    readonly instanceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/compute_instances_v2#key_pair DataOpentelekomcloudComputeInstancesV2#key_pair}
    */
    readonly keyPair?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/compute_instances_v2#limit DataOpentelekomcloudComputeInstancesV2#limit}
    */
    readonly limit?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/compute_instances_v2#name DataOpentelekomcloudComputeInstancesV2#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/compute_instances_v2#project_id DataOpentelekomcloudComputeInstancesV2#project_id}
    */
    readonly projectId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/compute_instances_v2#status DataOpentelekomcloudComputeInstancesV2#status}
    */
    readonly status?: string;
}
export interface DataOpentelekomcloudComputeInstancesV2InstancesNetwork {
}
export declare function dataOpentelekomcloudComputeInstancesV2InstancesNetworkToTerraform(struct?: DataOpentelekomcloudComputeInstancesV2InstancesNetwork): any;
export declare function dataOpentelekomcloudComputeInstancesV2InstancesNetworkToHclTerraform(struct?: DataOpentelekomcloudComputeInstancesV2InstancesNetwork): any;
export declare class DataOpentelekomcloudComputeInstancesV2InstancesNetworkOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudComputeInstancesV2InstancesNetwork | undefined;
    set internalValue(value: DataOpentelekomcloudComputeInstancesV2InstancesNetwork | undefined);
    get fixedIpV4(): string;
    get fixedIpV6(): string;
    get mac(): string;
    get name(): string;
    get port(): string;
    get uuid(): string;
}
export declare class DataOpentelekomcloudComputeInstancesV2InstancesNetworkList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudComputeInstancesV2InstancesNetworkOutputReference;
}
export interface DataOpentelekomcloudComputeInstancesV2Instances {
}
export declare function dataOpentelekomcloudComputeInstancesV2InstancesToTerraform(struct?: DataOpentelekomcloudComputeInstancesV2Instances): any;
export declare function dataOpentelekomcloudComputeInstancesV2InstancesToHclTerraform(struct?: DataOpentelekomcloudComputeInstancesV2Instances): any;
export declare class DataOpentelekomcloudComputeInstancesV2InstancesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudComputeInstancesV2Instances | undefined;
    set internalValue(value: DataOpentelekomcloudComputeInstancesV2Instances | undefined);
    get availabilityZone(): string;
    get description(): string;
    get flavorId(): string;
    get id(): string;
    get imageId(): string;
    get imageName(): string;
    get keyPair(): string;
    get name(): string;
    private _network;
    get network(): DataOpentelekomcloudComputeInstancesV2InstancesNetworkList;
    get projectId(): string;
    get publicIp(): string;
    get securityGroupsIds(): string[];
    get status(): string;
    get systemDiskId(): string;
    private _tags;
    get tags(): cdktf.StringMap;
    get userData(): string;
}
export declare class DataOpentelekomcloudComputeInstancesV2InstancesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudComputeInstancesV2InstancesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/compute_instances_v2 opentelekomcloud_compute_instances_v2}
*/
export declare class DataOpentelekomcloudComputeInstancesV2 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_compute_instances_v2";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudComputeInstancesV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudComputeInstancesV2 to import
    * @param importFromId The id of the existing DataOpentelekomcloudComputeInstancesV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/compute_instances_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudComputeInstancesV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/compute_instances_v2 opentelekomcloud_compute_instances_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudComputeInstancesV2Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudComputeInstancesV2Config);
    private _availabilityZone?;
    get availabilityZone(): string;
    set availabilityZone(value: string);
    resetAvailabilityZone(): void;
    get availabilityZoneInput(): string | undefined;
    private _flavorId?;
    get flavorId(): string;
    set flavorId(value: string);
    resetFlavorId(): void;
    get flavorIdInput(): string | undefined;
    private _flavorName?;
    get flavorName(): string;
    set flavorName(value: string);
    resetFlavorName(): void;
    get flavorNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _imageId?;
    get imageId(): string;
    set imageId(value: string);
    resetImageId(): void;
    get imageIdInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    resetInstanceId(): void;
    get instanceIdInput(): string | undefined;
    private _instances;
    get instances(): DataOpentelekomcloudComputeInstancesV2InstancesList;
    private _keyPair?;
    get keyPair(): string;
    set keyPair(value: string);
    resetKeyPair(): void;
    get keyPairInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

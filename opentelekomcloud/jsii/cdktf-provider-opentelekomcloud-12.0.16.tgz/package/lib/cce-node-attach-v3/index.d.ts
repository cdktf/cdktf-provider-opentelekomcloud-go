/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CceNodeAttachV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#cluster_id CceNodeAttachV3#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#docker_base_size CceNodeAttachV3#docker_base_size}
    */
    readonly dockerBaseSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#id CceNodeAttachV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#k8s_tags CceNodeAttachV3#k8s_tags}
    */
    readonly k8STags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#key_pair CceNodeAttachV3#key_pair}
    */
    readonly keyPair?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#lvm_config CceNodeAttachV3#lvm_config}
    */
    readonly lvmConfig?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#max_pods CceNodeAttachV3#max_pods}
    */
    readonly maxPods?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#name CceNodeAttachV3#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#os CceNodeAttachV3#os}
    */
    readonly os: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#password CceNodeAttachV3#password}
    */
    readonly password?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#postinstall CceNodeAttachV3#postinstall}
    */
    readonly postinstall?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#preinstall CceNodeAttachV3#preinstall}
    */
    readonly preinstall?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#private_key CceNodeAttachV3#private_key}
    */
    readonly privateKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#runtime CceNodeAttachV3#runtime}
    */
    readonly runtime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#server_id CceNodeAttachV3#server_id}
    */
    readonly serverId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#system_disk_kms_key_id CceNodeAttachV3#system_disk_kms_key_id}
    */
    readonly systemDiskKmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#tags CceNodeAttachV3#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * storage block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#storage CceNodeAttachV3#storage}
    */
    readonly storage?: CceNodeAttachV3Storage;
    /**
    * taints block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#taints CceNodeAttachV3#taints}
    */
    readonly taints?: CceNodeAttachV3Taints[] | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#timeouts CceNodeAttachV3#timeouts}
    */
    readonly timeouts?: CceNodeAttachV3Timeouts;
}
export interface CceNodeAttachV3DataVolumes {
}
export declare function cceNodeAttachV3DataVolumesToTerraform(struct?: CceNodeAttachV3DataVolumes): any;
export declare function cceNodeAttachV3DataVolumesToHclTerraform(struct?: CceNodeAttachV3DataVolumes): any;
export declare class CceNodeAttachV3DataVolumesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CceNodeAttachV3DataVolumes | undefined;
    set internalValue(value: CceNodeAttachV3DataVolumes | undefined);
    get dssPoolId(): string;
    get extendParam(): string;
    private _extendParams;
    get extendParams(): cdktf.StringMap;
    get hwPassthrough(): cdktf.IResolvable;
    get kmsId(): string;
    get size(): number;
    get volumetype(): string;
}
export declare class CceNodeAttachV3DataVolumesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CceNodeAttachV3DataVolumesOutputReference;
}
export interface CceNodeAttachV3RootVolume {
}
export declare function cceNodeAttachV3RootVolumeToTerraform(struct?: CceNodeAttachV3RootVolume): any;
export declare function cceNodeAttachV3RootVolumeToHclTerraform(struct?: CceNodeAttachV3RootVolume): any;
export declare class CceNodeAttachV3RootVolumeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CceNodeAttachV3RootVolume | undefined;
    set internalValue(value: CceNodeAttachV3RootVolume | undefined);
    get extendParam(): string;
    private _extendParams;
    get extendParams(): cdktf.StringMap;
    get kmsId(): string;
    get size(): number;
    get volumetype(): string;
}
export declare class CceNodeAttachV3RootVolumeList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CceNodeAttachV3RootVolumeOutputReference;
}
export interface CceNodeAttachV3StorageGroupsVirtualSpaces {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#lvm_lv_type CceNodeAttachV3#lvm_lv_type}
    */
    readonly lvmLvType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#lvm_path CceNodeAttachV3#lvm_path}
    */
    readonly lvmPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#name CceNodeAttachV3#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#runtime_lv_type CceNodeAttachV3#runtime_lv_type}
    */
    readonly runtimeLvType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#size CceNodeAttachV3#size}
    */
    readonly size: string;
}
export declare function cceNodeAttachV3StorageGroupsVirtualSpacesToTerraform(struct?: CceNodeAttachV3StorageGroupsVirtualSpaces | cdktf.IResolvable): any;
export declare function cceNodeAttachV3StorageGroupsVirtualSpacesToHclTerraform(struct?: CceNodeAttachV3StorageGroupsVirtualSpaces | cdktf.IResolvable): any;
export declare class CceNodeAttachV3StorageGroupsVirtualSpacesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CceNodeAttachV3StorageGroupsVirtualSpaces | cdktf.IResolvable | undefined;
    set internalValue(value: CceNodeAttachV3StorageGroupsVirtualSpaces | cdktf.IResolvable | undefined);
    private _lvmLvType?;
    get lvmLvType(): string;
    set lvmLvType(value: string);
    resetLvmLvType(): void;
    get lvmLvTypeInput(): string | undefined;
    private _lvmPath?;
    get lvmPath(): string;
    set lvmPath(value: string);
    resetLvmPath(): void;
    get lvmPathInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _runtimeLvType?;
    get runtimeLvType(): string;
    set runtimeLvType(value: string);
    resetRuntimeLvType(): void;
    get runtimeLvTypeInput(): string | undefined;
    private _size?;
    get size(): string;
    set size(value: string);
    get sizeInput(): string | undefined;
}
export declare class CceNodeAttachV3StorageGroupsVirtualSpacesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: CceNodeAttachV3StorageGroupsVirtualSpaces[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CceNodeAttachV3StorageGroupsVirtualSpacesOutputReference;
}
export interface CceNodeAttachV3StorageGroups {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#cce_managed CceNodeAttachV3#cce_managed}
    */
    readonly cceManaged?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#name CceNodeAttachV3#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#selector_names CceNodeAttachV3#selector_names}
    */
    readonly selectorNames: string[];
    /**
    * virtual_spaces block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#virtual_spaces CceNodeAttachV3#virtual_spaces}
    */
    readonly virtualSpaces: CceNodeAttachV3StorageGroupsVirtualSpaces[] | cdktf.IResolvable;
}
export declare function cceNodeAttachV3StorageGroupsToTerraform(struct?: CceNodeAttachV3StorageGroups | cdktf.IResolvable): any;
export declare function cceNodeAttachV3StorageGroupsToHclTerraform(struct?: CceNodeAttachV3StorageGroups | cdktf.IResolvable): any;
export declare class CceNodeAttachV3StorageGroupsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CceNodeAttachV3StorageGroups | cdktf.IResolvable | undefined;
    set internalValue(value: CceNodeAttachV3StorageGroups | cdktf.IResolvable | undefined);
    private _cceManaged?;
    get cceManaged(): boolean | cdktf.IResolvable;
    set cceManaged(value: boolean | cdktf.IResolvable);
    resetCceManaged(): void;
    get cceManagedInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _selectorNames?;
    get selectorNames(): string[];
    set selectorNames(value: string[]);
    get selectorNamesInput(): string[] | undefined;
    private _virtualSpaces;
    get virtualSpaces(): CceNodeAttachV3StorageGroupsVirtualSpacesList;
    putVirtualSpaces(value: CceNodeAttachV3StorageGroupsVirtualSpaces[] | cdktf.IResolvable): void;
    get virtualSpacesInput(): cdktf.IResolvable | CceNodeAttachV3StorageGroupsVirtualSpaces[] | undefined;
}
export declare class CceNodeAttachV3StorageGroupsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: CceNodeAttachV3StorageGroups[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CceNodeAttachV3StorageGroupsOutputReference;
}
export interface CceNodeAttachV3StorageSelectors {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#match_label_count CceNodeAttachV3#match_label_count}
    */
    readonly matchLabelCount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#match_label_metadata_cmkid CceNodeAttachV3#match_label_metadata_cmkid}
    */
    readonly matchLabelMetadataCmkid?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#match_label_metadata_encrypted CceNodeAttachV3#match_label_metadata_encrypted}
    */
    readonly matchLabelMetadataEncrypted?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#match_label_size CceNodeAttachV3#match_label_size}
    */
    readonly matchLabelSize?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#match_label_volume_type CceNodeAttachV3#match_label_volume_type}
    */
    readonly matchLabelVolumeType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#name CceNodeAttachV3#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#type CceNodeAttachV3#type}
    */
    readonly type?: string;
}
export declare function cceNodeAttachV3StorageSelectorsToTerraform(struct?: CceNodeAttachV3StorageSelectors | cdktf.IResolvable): any;
export declare function cceNodeAttachV3StorageSelectorsToHclTerraform(struct?: CceNodeAttachV3StorageSelectors | cdktf.IResolvable): any;
export declare class CceNodeAttachV3StorageSelectorsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CceNodeAttachV3StorageSelectors | cdktf.IResolvable | undefined;
    set internalValue(value: CceNodeAttachV3StorageSelectors | cdktf.IResolvable | undefined);
    private _matchLabelCount?;
    get matchLabelCount(): string;
    set matchLabelCount(value: string);
    resetMatchLabelCount(): void;
    get matchLabelCountInput(): string | undefined;
    private _matchLabelMetadataCmkid?;
    get matchLabelMetadataCmkid(): string;
    set matchLabelMetadataCmkid(value: string);
    resetMatchLabelMetadataCmkid(): void;
    get matchLabelMetadataCmkidInput(): string | undefined;
    private _matchLabelMetadataEncrypted?;
    get matchLabelMetadataEncrypted(): string;
    set matchLabelMetadataEncrypted(value: string);
    resetMatchLabelMetadataEncrypted(): void;
    get matchLabelMetadataEncryptedInput(): string | undefined;
    private _matchLabelSize?;
    get matchLabelSize(): string;
    set matchLabelSize(value: string);
    resetMatchLabelSize(): void;
    get matchLabelSizeInput(): string | undefined;
    private _matchLabelVolumeType?;
    get matchLabelVolumeType(): string;
    set matchLabelVolumeType(value: string);
    resetMatchLabelVolumeType(): void;
    get matchLabelVolumeTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class CceNodeAttachV3StorageSelectorsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: CceNodeAttachV3StorageSelectors[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CceNodeAttachV3StorageSelectorsOutputReference;
}
export interface CceNodeAttachV3Storage {
    /**
    * groups block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#groups CceNodeAttachV3#groups}
    */
    readonly groups: CceNodeAttachV3StorageGroups[] | cdktf.IResolvable;
    /**
    * selectors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#selectors CceNodeAttachV3#selectors}
    */
    readonly selectors: CceNodeAttachV3StorageSelectors[] | cdktf.IResolvable;
}
export declare function cceNodeAttachV3StorageToTerraform(struct?: CceNodeAttachV3StorageOutputReference | CceNodeAttachV3Storage): any;
export declare function cceNodeAttachV3StorageToHclTerraform(struct?: CceNodeAttachV3StorageOutputReference | CceNodeAttachV3Storage): any;
export declare class CceNodeAttachV3StorageOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CceNodeAttachV3Storage | undefined;
    set internalValue(value: CceNodeAttachV3Storage | undefined);
    private _groups;
    get groups(): CceNodeAttachV3StorageGroupsList;
    putGroups(value: CceNodeAttachV3StorageGroups[] | cdktf.IResolvable): void;
    get groupsInput(): cdktf.IResolvable | CceNodeAttachV3StorageGroups[] | undefined;
    private _selectors;
    get selectors(): CceNodeAttachV3StorageSelectorsList;
    putSelectors(value: CceNodeAttachV3StorageSelectors[] | cdktf.IResolvable): void;
    get selectorsInput(): cdktf.IResolvable | CceNodeAttachV3StorageSelectors[] | undefined;
}
export interface CceNodeAttachV3Taints {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#effect CceNodeAttachV3#effect}
    */
    readonly effect: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#key CceNodeAttachV3#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#value CceNodeAttachV3#value}
    */
    readonly value: string;
}
export declare function cceNodeAttachV3TaintsToTerraform(struct?: CceNodeAttachV3Taints | cdktf.IResolvable): any;
export declare function cceNodeAttachV3TaintsToHclTerraform(struct?: CceNodeAttachV3Taints | cdktf.IResolvable): any;
export declare class CceNodeAttachV3TaintsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CceNodeAttachV3Taints | cdktf.IResolvable | undefined;
    set internalValue(value: CceNodeAttachV3Taints | cdktf.IResolvable | undefined);
    private _effect?;
    get effect(): string;
    set effect(value: string);
    get effectInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class CceNodeAttachV3TaintsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: CceNodeAttachV3Taints[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CceNodeAttachV3TaintsOutputReference;
}
export interface CceNodeAttachV3Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#create CceNodeAttachV3#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#delete CceNodeAttachV3#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#update CceNodeAttachV3#update}
    */
    readonly update?: string;
}
export declare function cceNodeAttachV3TimeoutsToTerraform(struct?: CceNodeAttachV3Timeouts | cdktf.IResolvable): any;
export declare function cceNodeAttachV3TimeoutsToHclTerraform(struct?: CceNodeAttachV3Timeouts | cdktf.IResolvable): any;
export declare class CceNodeAttachV3TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CceNodeAttachV3Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: CceNodeAttachV3Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3 opentelekomcloud_cce_node_attach_v3}
*/
export declare class CceNodeAttachV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_cce_node_attach_v3";
    /**
    * Generates CDKTF code for importing a CceNodeAttachV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CceNodeAttachV3 to import
    * @param importFromId The id of the existing CceNodeAttachV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CceNodeAttachV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_node_attach_v3 opentelekomcloud_cce_node_attach_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CceNodeAttachV3Config
    */
    constructor(scope: Construct, id: string, config: CceNodeAttachV3Config);
    get availabilityZone(): string;
    get billingMode(): number;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _dataVolumes;
    get dataVolumes(): CceNodeAttachV3DataVolumesList;
    private _dockerBaseSize?;
    get dockerBaseSize(): number;
    set dockerBaseSize(value: number);
    resetDockerBaseSize(): void;
    get dockerBaseSizeInput(): number | undefined;
    get flavorId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _k8STags?;
    get k8STags(): {
        [key: string]: string;
    };
    set k8STags(value: {
        [key: string]: string;
    });
    resetK8STags(): void;
    get k8STagsInput(): {
        [key: string]: string;
    } | undefined;
    private _keyPair?;
    get keyPair(): string;
    set keyPair(value: string);
    resetKeyPair(): void;
    get keyPairInput(): string | undefined;
    private _lvmConfig?;
    get lvmConfig(): string;
    set lvmConfig(value: string);
    resetLvmConfig(): void;
    get lvmConfigInput(): string | undefined;
    private _maxPods?;
    get maxPods(): number;
    set maxPods(value: number);
    resetMaxPods(): void;
    get maxPodsInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _os?;
    get os(): string;
    set os(value: string);
    get osInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _postinstall?;
    get postinstall(): string;
    set postinstall(value: string);
    resetPostinstall(): void;
    get postinstallInput(): string | undefined;
    private _preinstall?;
    get preinstall(): string;
    set preinstall(value: string);
    resetPreinstall(): void;
    get preinstallInput(): string | undefined;
    get privateIp(): string;
    private _privateKey?;
    get privateKey(): string;
    set privateKey(value: string);
    resetPrivateKey(): void;
    get privateKeyInput(): string | undefined;
    get publicIp(): string;
    get region(): string;
    private _rootVolume;
    get rootVolume(): CceNodeAttachV3RootVolumeList;
    private _runtime?;
    get runtime(): string;
    set runtime(value: string);
    resetRuntime(): void;
    get runtimeInput(): string | undefined;
    private _serverId?;
    get serverId(): string;
    set serverId(value: string);
    get serverIdInput(): string | undefined;
    get status(): string;
    get subnetId(): string;
    private _systemDiskKmsKeyId?;
    get systemDiskKmsKeyId(): string;
    set systemDiskKmsKeyId(value: string);
    resetSystemDiskKmsKeyId(): void;
    get systemDiskKmsKeyIdInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _storage;
    get storage(): CceNodeAttachV3StorageOutputReference;
    putStorage(value: CceNodeAttachV3Storage): void;
    resetStorage(): void;
    get storageInput(): CceNodeAttachV3Storage | undefined;
    private _taints;
    get taints(): CceNodeAttachV3TaintsList;
    putTaints(value: CceNodeAttachV3Taints[] | cdktf.IResolvable): void;
    resetTaints(): void;
    get taintsInput(): cdktf.IResolvable | CceNodeAttachV3Taints[] | undefined;
    private _timeouts;
    get timeouts(): CceNodeAttachV3TimeoutsOutputReference;
    putTimeouts(value: CceNodeAttachV3Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | CceNodeAttachV3Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

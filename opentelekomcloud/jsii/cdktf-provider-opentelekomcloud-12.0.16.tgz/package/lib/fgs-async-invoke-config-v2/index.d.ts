/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface FgsAsyncInvokeConfigV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_async_invoke_config_v2#function_urn FgsAsyncInvokeConfigV2#function_urn}
    */
    readonly functionUrn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_async_invoke_config_v2#id FgsAsyncInvokeConfigV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_async_invoke_config_v2#max_async_event_age_in_seconds FgsAsyncInvokeConfigV2#max_async_event_age_in_seconds}
    */
    readonly maxAsyncEventAgeInSeconds: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_async_invoke_config_v2#max_async_retry_attempts FgsAsyncInvokeConfigV2#max_async_retry_attempts}
    */
    readonly maxAsyncRetryAttempts: number;
    /**
    * on_failure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_async_invoke_config_v2#on_failure FgsAsyncInvokeConfigV2#on_failure}
    */
    readonly onFailure?: FgsAsyncInvokeConfigV2OnFailure;
    /**
    * on_success block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_async_invoke_config_v2#on_success FgsAsyncInvokeConfigV2#on_success}
    */
    readonly onSuccess?: FgsAsyncInvokeConfigV2OnSuccess;
}
export interface FgsAsyncInvokeConfigV2OnFailure {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_async_invoke_config_v2#destination FgsAsyncInvokeConfigV2#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_async_invoke_config_v2#param FgsAsyncInvokeConfigV2#param}
    */
    readonly param: string;
}
export declare function fgsAsyncInvokeConfigV2OnFailureToTerraform(struct?: FgsAsyncInvokeConfigV2OnFailureOutputReference | FgsAsyncInvokeConfigV2OnFailure): any;
export declare function fgsAsyncInvokeConfigV2OnFailureToHclTerraform(struct?: FgsAsyncInvokeConfigV2OnFailureOutputReference | FgsAsyncInvokeConfigV2OnFailure): any;
export declare class FgsAsyncInvokeConfigV2OnFailureOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FgsAsyncInvokeConfigV2OnFailure | undefined;
    set internalValue(value: FgsAsyncInvokeConfigV2OnFailure | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _param?;
    get param(): string;
    set param(value: string);
    get paramInput(): string | undefined;
}
export interface FgsAsyncInvokeConfigV2OnSuccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_async_invoke_config_v2#destination FgsAsyncInvokeConfigV2#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_async_invoke_config_v2#param FgsAsyncInvokeConfigV2#param}
    */
    readonly param: string;
}
export declare function fgsAsyncInvokeConfigV2OnSuccessToTerraform(struct?: FgsAsyncInvokeConfigV2OnSuccessOutputReference | FgsAsyncInvokeConfigV2OnSuccess): any;
export declare function fgsAsyncInvokeConfigV2OnSuccessToHclTerraform(struct?: FgsAsyncInvokeConfigV2OnSuccessOutputReference | FgsAsyncInvokeConfigV2OnSuccess): any;
export declare class FgsAsyncInvokeConfigV2OnSuccessOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FgsAsyncInvokeConfigV2OnSuccess | undefined;
    set internalValue(value: FgsAsyncInvokeConfigV2OnSuccess | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _param?;
    get param(): string;
    set param(value: string);
    get paramInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_async_invoke_config_v2 opentelekomcloud_fgs_async_invoke_config_v2}
*/
export declare class FgsAsyncInvokeConfigV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_fgs_async_invoke_config_v2";
    /**
    * Generates CDKTF code for importing a FgsAsyncInvokeConfigV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the FgsAsyncInvokeConfigV2 to import
    * @param importFromId The id of the existing FgsAsyncInvokeConfigV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_async_invoke_config_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the FgsAsyncInvokeConfigV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_async_invoke_config_v2 opentelekomcloud_fgs_async_invoke_config_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options FgsAsyncInvokeConfigV2Config
    */
    constructor(scope: Construct, id: string, config: FgsAsyncInvokeConfigV2Config);
    private _functionUrn?;
    get functionUrn(): string;
    set functionUrn(value: string);
    get functionUrnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maxAsyncEventAgeInSeconds?;
    get maxAsyncEventAgeInSeconds(): number;
    set maxAsyncEventAgeInSeconds(value: number);
    get maxAsyncEventAgeInSecondsInput(): number | undefined;
    private _maxAsyncRetryAttempts?;
    get maxAsyncRetryAttempts(): number;
    set maxAsyncRetryAttempts(value: number);
    get maxAsyncRetryAttemptsInput(): number | undefined;
    get region(): string;
    private _onFailure;
    get onFailure(): FgsAsyncInvokeConfigV2OnFailureOutputReference;
    putOnFailure(value: FgsAsyncInvokeConfigV2OnFailure): void;
    resetOnFailure(): void;
    get onFailureInput(): FgsAsyncInvokeConfigV2OnFailure | undefined;
    private _onSuccess;
    get onSuccess(): FgsAsyncInvokeConfigV2OnSuccessOutputReference;
    putOnSuccess(value: FgsAsyncInvokeConfigV2OnSuccess): void;
    resetOnSuccess(): void;
    get onSuccessInput(): FgsAsyncInvokeConfigV2OnSuccess | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

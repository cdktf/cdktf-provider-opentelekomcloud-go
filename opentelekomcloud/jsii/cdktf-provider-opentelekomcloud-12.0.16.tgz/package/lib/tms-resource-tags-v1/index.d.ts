/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface TmsResourceTagsV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/tms_resource_tags_v1#id TmsResourceTagsV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/tms_resource_tags_v1#project_id TmsResourceTagsV1#project_id}
    */
    readonly projectId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/tms_resource_tags_v1#tags TmsResourceTagsV1#tags}
    */
    readonly tags: {
        [key: string]: string;
    };
    /**
    * resources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/tms_resource_tags_v1#resources TmsResourceTagsV1#resources}
    */
    readonly resources: TmsResourceTagsV1Resources[] | cdktf.IResolvable;
}
export interface TmsResourceTagsV1Resources {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/tms_resource_tags_v1#resource_id TmsResourceTagsV1#resource_id}
    */
    readonly resourceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/tms_resource_tags_v1#resource_type TmsResourceTagsV1#resource_type}
    */
    readonly resourceType: string;
}
export declare function tmsResourceTagsV1ResourcesToTerraform(struct?: TmsResourceTagsV1Resources | cdktf.IResolvable): any;
export declare function tmsResourceTagsV1ResourcesToHclTerraform(struct?: TmsResourceTagsV1Resources | cdktf.IResolvable): any;
export declare class TmsResourceTagsV1ResourcesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): TmsResourceTagsV1Resources | cdktf.IResolvable | undefined;
    set internalValue(value: TmsResourceTagsV1Resources | cdktf.IResolvable | undefined);
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    get resourceIdInput(): string | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    get resourceTypeInput(): string | undefined;
}
export declare class TmsResourceTagsV1ResourcesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: TmsResourceTagsV1Resources[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): TmsResourceTagsV1ResourcesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/tms_resource_tags_v1 opentelekomcloud_tms_resource_tags_v1}
*/
export declare class TmsResourceTagsV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_tms_resource_tags_v1";
    /**
    * Generates CDKTF code for importing a TmsResourceTagsV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TmsResourceTagsV1 to import
    * @param importFromId The id of the existing TmsResourceTagsV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/tms_resource_tags_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TmsResourceTagsV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/tms_resource_tags_v1 opentelekomcloud_tms_resource_tags_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TmsResourceTagsV1Config
    */
    constructor(scope: Construct, id: string, config: TmsResourceTagsV1Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _resources;
    get resources(): TmsResourceTagsV1ResourcesList;
    putResources(value: TmsResourceTagsV1Resources[] | cdktf.IResolvable): void;
    get resourcesInput(): cdktf.IResolvable | TmsResourceTagsV1Resources[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

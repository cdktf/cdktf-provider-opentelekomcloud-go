/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface PrivateNatTransitIpV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_transit_ip_v3#enterprise_project_id PrivateNatTransitIpV3#enterprise_project_id}
    */
    readonly enterpriseProjectId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_transit_ip_v3#ip_address PrivateNatTransitIpV3#ip_address}
    */
    readonly ipAddress?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_transit_ip_v3#tags PrivateNatTransitIpV3#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_transit_ip_v3#virsubnet_id PrivateNatTransitIpV3#virsubnet_id}
    */
    readonly virsubnetId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_transit_ip_v3#timeouts PrivateNatTransitIpV3#timeouts}
    */
    readonly timeouts?: PrivateNatTransitIpV3Timeouts;
}
export interface PrivateNatTransitIpV3Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_transit_ip_v3#create PrivateNatTransitIpV3#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_transit_ip_v3#delete PrivateNatTransitIpV3#delete}
    */
    readonly delete?: string;
}
export declare function privateNatTransitIpV3TimeoutsToTerraform(struct?: PrivateNatTransitIpV3Timeouts | cdktf.IResolvable): any;
export declare function privateNatTransitIpV3TimeoutsToHclTerraform(struct?: PrivateNatTransitIpV3Timeouts | cdktf.IResolvable): any;
export declare class PrivateNatTransitIpV3TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PrivateNatTransitIpV3Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: PrivateNatTransitIpV3Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_transit_ip_v3 opentelekomcloud_private_nat_transit_ip_v3}
*/
export declare class PrivateNatTransitIpV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_private_nat_transit_ip_v3";
    /**
    * Generates CDKTF code for importing a PrivateNatTransitIpV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PrivateNatTransitIpV3 to import
    * @param importFromId The id of the existing PrivateNatTransitIpV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_transit_ip_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PrivateNatTransitIpV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/private_nat_transit_ip_v3 opentelekomcloud_private_nat_transit_ip_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PrivateNatTransitIpV3Config
    */
    constructor(scope: Construct, id: string, config: PrivateNatTransitIpV3Config);
    get createdAt(): string;
    private _enterpriseProjectId?;
    get enterpriseProjectId(): string;
    set enterpriseProjectId(value: string);
    resetEnterpriseProjectId(): void;
    get enterpriseProjectIdInput(): string | undefined;
    get gatewayId(): string;
    get id(): string;
    private _ipAddress?;
    get ipAddress(): string;
    set ipAddress(value: string);
    resetIpAddress(): void;
    get ipAddressInput(): string | undefined;
    get networkInterfaceId(): string;
    get projectId(): string;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get updatedAt(): string;
    private _virsubnetId?;
    get virsubnetId(): string;
    set virsubnetId(value: string);
    get virsubnetIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): PrivateNatTransitIpV3TimeoutsOutputReference;
    putTimeouts(value: PrivateNatTransitIpV3Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | PrivateNatTransitIpV3Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

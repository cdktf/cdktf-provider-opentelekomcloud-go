/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CtsTrackerV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_tracker_v1#bucket_name CtsTrackerV1#bucket_name}
    */
    readonly bucketName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_tracker_v1#file_prefix_name CtsTrackerV1#file_prefix_name}
    */
    readonly filePrefixName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_tracker_v1#id CtsTrackerV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_tracker_v1#is_lts_enabled CtsTrackerV1#is_lts_enabled}
    */
    readonly isLtsEnabled?: boolean | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_tracker_v1#timeouts CtsTrackerV1#timeouts}
    */
    readonly timeouts?: CtsTrackerV1Timeouts;
}
export interface CtsTrackerV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_tracker_v1#create CtsTrackerV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_tracker_v1#delete CtsTrackerV1#delete}
    */
    readonly delete?: string;
}
export declare function ctsTrackerV1TimeoutsToTerraform(struct?: CtsTrackerV1Timeouts | cdktf.IResolvable): any;
export declare function ctsTrackerV1TimeoutsToHclTerraform(struct?: CtsTrackerV1Timeouts | cdktf.IResolvable): any;
export declare class CtsTrackerV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CtsTrackerV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: CtsTrackerV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_tracker_v1 opentelekomcloud_cts_tracker_v1}
*/
export declare class CtsTrackerV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_cts_tracker_v1";
    /**
    * Generates CDKTF code for importing a CtsTrackerV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CtsTrackerV1 to import
    * @param importFromId The id of the existing CtsTrackerV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_tracker_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CtsTrackerV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_tracker_v1 opentelekomcloud_cts_tracker_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CtsTrackerV1Config
    */
    constructor(scope: Construct, id: string, config: CtsTrackerV1Config);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    get bucketNameInput(): string | undefined;
    private _filePrefixName?;
    get filePrefixName(): string;
    set filePrefixName(value: string);
    resetFilePrefixName(): void;
    get filePrefixNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isLtsEnabled?;
    get isLtsEnabled(): boolean | cdktf.IResolvable;
    set isLtsEnabled(value: boolean | cdktf.IResolvable);
    resetIsLtsEnabled(): void;
    get isLtsEnabledInput(): boolean | cdktf.IResolvable | undefined;
    get logGroupName(): string;
    get logTopicName(): string;
    get region(): string;
    get status(): string;
    get trackerName(): string;
    private _timeouts;
    get timeouts(): CtsTrackerV1TimeoutsOutputReference;
    putTimeouts(value: CtsTrackerV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | CtsTrackerV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DisDumpTaskV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_dump_task_v2#action DisDumpTaskV2#action}
    */
    readonly action?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_dump_task_v2#destination DisDumpTaskV2#destination}
    */
    readonly destination?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_dump_task_v2#id DisDumpTaskV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_dump_task_v2#stream_name DisDumpTaskV2#stream_name}
    */
    readonly streamName: string;
    /**
    * obs_destination_descriptor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_dump_task_v2#obs_destination_descriptor DisDumpTaskV2#obs_destination_descriptor}
    */
    readonly obsDestinationDescriptor?: DisDumpTaskV2ObsDestinationDescriptor[] | cdktf.IResolvable;
    /**
    * obs_processing_schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_dump_task_v2#obs_processing_schema DisDumpTaskV2#obs_processing_schema}
    */
    readonly obsProcessingSchema?: DisDumpTaskV2ObsProcessingSchema[] | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_dump_task_v2#timeouts DisDumpTaskV2#timeouts}
    */
    readonly timeouts?: DisDumpTaskV2Timeouts;
}
export interface DisDumpTaskV2Partitions {
}
export declare function disDumpTaskV2PartitionsToTerraform(struct?: DisDumpTaskV2Partitions): any;
export declare function disDumpTaskV2PartitionsToHclTerraform(struct?: DisDumpTaskV2Partitions): any;
export declare class DisDumpTaskV2PartitionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DisDumpTaskV2Partitions | undefined;
    set internalValue(value: DisDumpTaskV2Partitions | undefined);
    get hashRange(): string;
    get id(): string;
    get parentPartitions(): string;
    get sequenceNumberRange(): string;
    get status(): string;
}
export declare class DisDumpTaskV2PartitionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DisDumpTaskV2PartitionsOutputReference;
}
export interface DisDumpTaskV2ObsDestinationDescriptor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_dump_task_v2#agency_name DisDumpTaskV2#agency_name}
    */
    readonly agencyName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_dump_task_v2#consumer_strategy DisDumpTaskV2#consumer_strategy}
    */
    readonly consumerStrategy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_dump_task_v2#deliver_time_interval DisDumpTaskV2#deliver_time_interval}
    */
    readonly deliverTimeInterval: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_dump_task_v2#destination_file_type DisDumpTaskV2#destination_file_type}
    */
    readonly destinationFileType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_dump_task_v2#file_prefix DisDumpTaskV2#file_prefix}
    */
    readonly filePrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_dump_task_v2#obs_bucket_path DisDumpTaskV2#obs_bucket_path}
    */
    readonly obsBucketPath: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_dump_task_v2#partition_format DisDumpTaskV2#partition_format}
    */
    readonly partitionFormat?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_dump_task_v2#record_delimiter DisDumpTaskV2#record_delimiter}
    */
    readonly recordDelimiter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_dump_task_v2#task_name DisDumpTaskV2#task_name}
    */
    readonly taskName: string;
}
export declare function disDumpTaskV2ObsDestinationDescriptorToTerraform(struct?: DisDumpTaskV2ObsDestinationDescriptor | cdktf.IResolvable): any;
export declare function disDumpTaskV2ObsDestinationDescriptorToHclTerraform(struct?: DisDumpTaskV2ObsDestinationDescriptor | cdktf.IResolvable): any;
export declare class DisDumpTaskV2ObsDestinationDescriptorOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DisDumpTaskV2ObsDestinationDescriptor | cdktf.IResolvable | undefined;
    set internalValue(value: DisDumpTaskV2ObsDestinationDescriptor | cdktf.IResolvable | undefined);
    private _agencyName?;
    get agencyName(): string;
    set agencyName(value: string);
    get agencyNameInput(): string | undefined;
    private _consumerStrategy?;
    get consumerStrategy(): string;
    set consumerStrategy(value: string);
    resetConsumerStrategy(): void;
    get consumerStrategyInput(): string | undefined;
    private _deliverTimeInterval?;
    get deliverTimeInterval(): number;
    set deliverTimeInterval(value: number);
    get deliverTimeIntervalInput(): number | undefined;
    private _destinationFileType?;
    get destinationFileType(): string;
    set destinationFileType(value: string);
    resetDestinationFileType(): void;
    get destinationFileTypeInput(): string | undefined;
    private _filePrefix?;
    get filePrefix(): string;
    set filePrefix(value: string);
    resetFilePrefix(): void;
    get filePrefixInput(): string | undefined;
    private _obsBucketPath?;
    get obsBucketPath(): string;
    set obsBucketPath(value: string);
    get obsBucketPathInput(): string | undefined;
    private _partitionFormat?;
    get partitionFormat(): string;
    set partitionFormat(value: string);
    resetPartitionFormat(): void;
    get partitionFormatInput(): string | undefined;
    private _recordDelimiter?;
    get recordDelimiter(): string;
    set recordDelimiter(value: string);
    resetRecordDelimiter(): void;
    get recordDelimiterInput(): string | undefined;
    private _taskName?;
    get taskName(): string;
    set taskName(value: string);
    get taskNameInput(): string | undefined;
}
export declare class DisDumpTaskV2ObsDestinationDescriptorList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DisDumpTaskV2ObsDestinationDescriptor[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DisDumpTaskV2ObsDestinationDescriptorOutputReference;
}
export interface DisDumpTaskV2ObsProcessingSchema {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_dump_task_v2#timestamp_format DisDumpTaskV2#timestamp_format}
    */
    readonly timestampFormat?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_dump_task_v2#timestamp_name DisDumpTaskV2#timestamp_name}
    */
    readonly timestampName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_dump_task_v2#timestamp_type DisDumpTaskV2#timestamp_type}
    */
    readonly timestampType: string;
}
export declare function disDumpTaskV2ObsProcessingSchemaToTerraform(struct?: DisDumpTaskV2ObsProcessingSchema | cdktf.IResolvable): any;
export declare function disDumpTaskV2ObsProcessingSchemaToHclTerraform(struct?: DisDumpTaskV2ObsProcessingSchema | cdktf.IResolvable): any;
export declare class DisDumpTaskV2ObsProcessingSchemaOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DisDumpTaskV2ObsProcessingSchema | cdktf.IResolvable | undefined;
    set internalValue(value: DisDumpTaskV2ObsProcessingSchema | cdktf.IResolvable | undefined);
    private _timestampFormat?;
    get timestampFormat(): string;
    set timestampFormat(value: string);
    resetTimestampFormat(): void;
    get timestampFormatInput(): string | undefined;
    private _timestampName?;
    get timestampName(): string;
    set timestampName(value: string);
    get timestampNameInput(): string | undefined;
    private _timestampType?;
    get timestampType(): string;
    set timestampType(value: string);
    get timestampTypeInput(): string | undefined;
}
export declare class DisDumpTaskV2ObsProcessingSchemaList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DisDumpTaskV2ObsProcessingSchema[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DisDumpTaskV2ObsProcessingSchemaOutputReference;
}
export interface DisDumpTaskV2Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_dump_task_v2#update DisDumpTaskV2#update}
    */
    readonly update?: string;
}
export declare function disDumpTaskV2TimeoutsToTerraform(struct?: DisDumpTaskV2Timeouts | cdktf.IResolvable): any;
export declare function disDumpTaskV2TimeoutsToHclTerraform(struct?: DisDumpTaskV2Timeouts | cdktf.IResolvable): any;
export declare class DisDumpTaskV2TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DisDumpTaskV2Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DisDumpTaskV2Timeouts | cdktf.IResolvable | undefined);
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_dump_task_v2 opentelekomcloud_dis_dump_task_v2}
*/
export declare class DisDumpTaskV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_dis_dump_task_v2";
    /**
    * Generates CDKTF code for importing a DisDumpTaskV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DisDumpTaskV2 to import
    * @param importFromId The id of the existing DisDumpTaskV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_dump_task_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DisDumpTaskV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_dump_task_v2 opentelekomcloud_dis_dump_task_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DisDumpTaskV2Config
    */
    constructor(scope: Construct, id: string, config: DisDumpTaskV2Config);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    get createdAt(): number;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    resetDestination(): void;
    get destinationInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastTransferTimestamp(): number;
    get name(): string;
    private _partitions;
    get partitions(): DisDumpTaskV2PartitionsList;
    get status(): string;
    private _streamName?;
    get streamName(): string;
    set streamName(value: string);
    get streamNameInput(): string | undefined;
    get taskId(): string;
    private _obsDestinationDescriptor;
    get obsDestinationDescriptor(): DisDumpTaskV2ObsDestinationDescriptorList;
    putObsDestinationDescriptor(value: DisDumpTaskV2ObsDestinationDescriptor[] | cdktf.IResolvable): void;
    resetObsDestinationDescriptor(): void;
    get obsDestinationDescriptorInput(): cdktf.IResolvable | DisDumpTaskV2ObsDestinationDescriptor[] | undefined;
    private _obsProcessingSchema;
    get obsProcessingSchema(): DisDumpTaskV2ObsProcessingSchemaList;
    putObsProcessingSchema(value: DisDumpTaskV2ObsProcessingSchema[] | cdktf.IResolvable): void;
    resetObsProcessingSchema(): void;
    get obsProcessingSchemaInput(): cdktf.IResolvable | DisDumpTaskV2ObsProcessingSchema[] | undefined;
    private _timeouts;
    get timeouts(): DisDumpTaskV2TimeoutsOutputReference;
    putTimeouts(value: DisDumpTaskV2Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DisDumpTaskV2Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface RmsResourceRecorderV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_resource_recorder_v1#agency_name RmsResourceRecorderV1#agency_name}
    */
    readonly agencyName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_resource_recorder_v1#id RmsResourceRecorderV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * obs_channel block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_resource_recorder_v1#obs_channel RmsResourceRecorderV1#obs_channel}
    */
    readonly obsChannel?: RmsResourceRecorderV1ObsChannel;
    /**
    * selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_resource_recorder_v1#selector RmsResourceRecorderV1#selector}
    */
    readonly selector: RmsResourceRecorderV1Selector;
    /**
    * smn_channel block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_resource_recorder_v1#smn_channel RmsResourceRecorderV1#smn_channel}
    */
    readonly smnChannel?: RmsResourceRecorderV1SmnChannel;
}
export interface RmsResourceRecorderV1ObsChannel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_resource_recorder_v1#bucket RmsResourceRecorderV1#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_resource_recorder_v1#bucket_prefix RmsResourceRecorderV1#bucket_prefix}
    */
    readonly bucketPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_resource_recorder_v1#region RmsResourceRecorderV1#region}
    */
    readonly region: string;
}
export declare function rmsResourceRecorderV1ObsChannelToTerraform(struct?: RmsResourceRecorderV1ObsChannelOutputReference | RmsResourceRecorderV1ObsChannel): any;
export declare function rmsResourceRecorderV1ObsChannelToHclTerraform(struct?: RmsResourceRecorderV1ObsChannelOutputReference | RmsResourceRecorderV1ObsChannel): any;
export declare class RmsResourceRecorderV1ObsChannelOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RmsResourceRecorderV1ObsChannel | undefined;
    set internalValue(value: RmsResourceRecorderV1ObsChannel | undefined);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _bucketPrefix?;
    get bucketPrefix(): string;
    set bucketPrefix(value: string);
    resetBucketPrefix(): void;
    get bucketPrefixInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
}
export interface RmsResourceRecorderV1Selector {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_resource_recorder_v1#all_supported RmsResourceRecorderV1#all_supported}
    */
    readonly allSupported: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_resource_recorder_v1#resource_types RmsResourceRecorderV1#resource_types}
    */
    readonly resourceTypes?: string[];
}
export declare function rmsResourceRecorderV1SelectorToTerraform(struct?: RmsResourceRecorderV1SelectorOutputReference | RmsResourceRecorderV1Selector): any;
export declare function rmsResourceRecorderV1SelectorToHclTerraform(struct?: RmsResourceRecorderV1SelectorOutputReference | RmsResourceRecorderV1Selector): any;
export declare class RmsResourceRecorderV1SelectorOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RmsResourceRecorderV1Selector | undefined;
    set internalValue(value: RmsResourceRecorderV1Selector | undefined);
    private _allSupported?;
    get allSupported(): boolean | cdktf.IResolvable;
    set allSupported(value: boolean | cdktf.IResolvable);
    get allSupportedInput(): boolean | cdktf.IResolvable | undefined;
    private _resourceTypes?;
    get resourceTypes(): string[];
    set resourceTypes(value: string[]);
    resetResourceTypes(): void;
    get resourceTypesInput(): string[] | undefined;
}
export interface RmsResourceRecorderV1SmnChannel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_resource_recorder_v1#topic_urn RmsResourceRecorderV1#topic_urn}
    */
    readonly topicUrn: string;
}
export declare function rmsResourceRecorderV1SmnChannelToTerraform(struct?: RmsResourceRecorderV1SmnChannelOutputReference | RmsResourceRecorderV1SmnChannel): any;
export declare function rmsResourceRecorderV1SmnChannelToHclTerraform(struct?: RmsResourceRecorderV1SmnChannelOutputReference | RmsResourceRecorderV1SmnChannel): any;
export declare class RmsResourceRecorderV1SmnChannelOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RmsResourceRecorderV1SmnChannel | undefined;
    set internalValue(value: RmsResourceRecorderV1SmnChannel | undefined);
    get projectId(): string;
    get region(): string;
    private _topicUrn?;
    get topicUrn(): string;
    set topicUrn(value: string);
    get topicUrnInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_resource_recorder_v1 opentelekomcloud_rms_resource_recorder_v1}
*/
export declare class RmsResourceRecorderV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_rms_resource_recorder_v1";
    /**
    * Generates CDKTF code for importing a RmsResourceRecorderV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RmsResourceRecorderV1 to import
    * @param importFromId The id of the existing RmsResourceRecorderV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_resource_recorder_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RmsResourceRecorderV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rms_resource_recorder_v1 opentelekomcloud_rms_resource_recorder_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RmsResourceRecorderV1Config
    */
    constructor(scope: Construct, id: string, config: RmsResourceRecorderV1Config);
    private _agencyName?;
    get agencyName(): string;
    set agencyName(value: string);
    get agencyNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get retentionPeriod(): number;
    private _obsChannel;
    get obsChannel(): RmsResourceRecorderV1ObsChannelOutputReference;
    putObsChannel(value: RmsResourceRecorderV1ObsChannel): void;
    resetObsChannel(): void;
    get obsChannelInput(): RmsResourceRecorderV1ObsChannel | undefined;
    private _selector;
    get selector(): RmsResourceRecorderV1SelectorOutputReference;
    putSelector(value: RmsResourceRecorderV1Selector): void;
    get selectorInput(): RmsResourceRecorderV1Selector | undefined;
    private _smnChannel;
    get smnChannel(): RmsResourceRecorderV1SmnChannelOutputReference;
    putSmnChannel(value: RmsResourceRecorderV1SmnChannel): void;
    resetSmnChannel(): void;
    get smnChannelInput(): RmsResourceRecorderV1SmnChannel | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

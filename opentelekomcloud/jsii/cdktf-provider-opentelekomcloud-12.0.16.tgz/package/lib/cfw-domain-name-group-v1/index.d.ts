/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CfwDomainNameGroupV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_domain_name_group_v1#description CfwDomainNameGroupV1#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_domain_name_group_v1#domain_set_type CfwDomainNameGroupV1#domain_set_type}
    */
    readonly domainSetType?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_domain_name_group_v1#firewall_id CfwDomainNameGroupV1#firewall_id}
    */
    readonly firewallId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_domain_name_group_v1#name CfwDomainNameGroupV1#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_domain_name_group_v1#object_id CfwDomainNameGroupV1#object_id}
    */
    readonly objectId: string;
    /**
    * domain_names block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_domain_name_group_v1#domain_names CfwDomainNameGroupV1#domain_names}
    */
    readonly domainNames: CfwDomainNameGroupV1DomainNames[] | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_domain_name_group_v1#timeouts CfwDomainNameGroupV1#timeouts}
    */
    readonly timeouts?: CfwDomainNameGroupV1Timeouts;
}
export interface CfwDomainNameGroupV1Rules {
}
export declare function cfwDomainNameGroupV1RulesToTerraform(struct?: CfwDomainNameGroupV1Rules): any;
export declare function cfwDomainNameGroupV1RulesToHclTerraform(struct?: CfwDomainNameGroupV1Rules): any;
export declare class CfwDomainNameGroupV1RulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CfwDomainNameGroupV1Rules | undefined;
    set internalValue(value: CfwDomainNameGroupV1Rules | undefined);
    get id(): string;
    get name(): string;
}
export declare class CfwDomainNameGroupV1RulesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CfwDomainNameGroupV1RulesOutputReference;
}
export interface CfwDomainNameGroupV1DomainNames {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_domain_name_group_v1#description CfwDomainNameGroupV1#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_domain_name_group_v1#domain_name CfwDomainNameGroupV1#domain_name}
    */
    readonly domainName: string;
}
export declare function cfwDomainNameGroupV1DomainNamesToTerraform(struct?: CfwDomainNameGroupV1DomainNames | cdktf.IResolvable): any;
export declare function cfwDomainNameGroupV1DomainNamesToHclTerraform(struct?: CfwDomainNameGroupV1DomainNames | cdktf.IResolvable): any;
export declare class CfwDomainNameGroupV1DomainNamesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CfwDomainNameGroupV1DomainNames | cdktf.IResolvable | undefined;
    set internalValue(value: CfwDomainNameGroupV1DomainNames | cdktf.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get domainAddressId(): string;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
}
export declare class CfwDomainNameGroupV1DomainNamesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: CfwDomainNameGroupV1DomainNames[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CfwDomainNameGroupV1DomainNamesOutputReference;
}
export interface CfwDomainNameGroupV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_domain_name_group_v1#create CfwDomainNameGroupV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_domain_name_group_v1#delete CfwDomainNameGroupV1#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_domain_name_group_v1#update CfwDomainNameGroupV1#update}
    */
    readonly update?: string;
}
export declare function cfwDomainNameGroupV1TimeoutsToTerraform(struct?: CfwDomainNameGroupV1Timeouts | cdktf.IResolvable): any;
export declare function cfwDomainNameGroupV1TimeoutsToHclTerraform(struct?: CfwDomainNameGroupV1Timeouts | cdktf.IResolvable): any;
export declare class CfwDomainNameGroupV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CfwDomainNameGroupV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: CfwDomainNameGroupV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_domain_name_group_v1 opentelekomcloud_cfw_domain_name_group_v1}
*/
export declare class CfwDomainNameGroupV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_cfw_domain_name_group_v1";
    /**
    * Generates CDKTF code for importing a CfwDomainNameGroupV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CfwDomainNameGroupV1 to import
    * @param importFromId The id of the existing CfwDomainNameGroupV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_domain_name_group_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CfwDomainNameGroupV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_domain_name_group_v1 opentelekomcloud_cfw_domain_name_group_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CfwDomainNameGroupV1Config
    */
    constructor(scope: Construct, id: string, config: CfwDomainNameGroupV1Config);
    get configStatus(): number;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _domainSetType?;
    get domainSetType(): number;
    set domainSetType(value: number);
    resetDomainSetType(): void;
    get domainSetTypeInput(): number | undefined;
    private _firewallId?;
    get firewallId(): string;
    set firewallId(value: string);
    get firewallIdInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _objectId?;
    get objectId(): string;
    set objectId(value: string);
    get objectIdInput(): string | undefined;
    get refCount(): number;
    private _rules;
    get rules(): CfwDomainNameGroupV1RulesList;
    private _domainNames;
    get domainNames(): CfwDomainNameGroupV1DomainNamesList;
    putDomainNames(value: CfwDomainNameGroupV1DomainNames[] | cdktf.IResolvable): void;
    get domainNamesInput(): cdktf.IResolvable | CfwDomainNameGroupV1DomainNames[] | undefined;
    private _timeouts;
    get timeouts(): CfwDomainNameGroupV1TimeoutsOutputReference;
    putTimeouts(value: CfwDomainNameGroupV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | CfwDomainNameGroupV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

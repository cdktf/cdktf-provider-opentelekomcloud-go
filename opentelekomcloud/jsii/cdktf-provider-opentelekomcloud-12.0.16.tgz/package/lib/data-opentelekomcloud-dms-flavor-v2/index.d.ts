/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudDmsFlavorV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/dms_flavor_v2#arch_type DataOpentelekomcloudDmsFlavorV2#arch_type}
    */
    readonly archType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/dms_flavor_v2#availability_zones DataOpentelekomcloudDmsFlavorV2#availability_zones}
    */
    readonly availabilityZones?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/dms_flavor_v2#charging_mode DataOpentelekomcloudDmsFlavorV2#charging_mode}
    */
    readonly chargingMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/dms_flavor_v2#flavor_id DataOpentelekomcloudDmsFlavorV2#flavor_id}
    */
    readonly flavorId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/dms_flavor_v2#id DataOpentelekomcloudDmsFlavorV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/dms_flavor_v2#storage_spec_code DataOpentelekomcloudDmsFlavorV2#storage_spec_code}
    */
    readonly storageSpecCode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/dms_flavor_v2#type DataOpentelekomcloudDmsFlavorV2#type}
    */
    readonly type?: string;
}
export interface DataOpentelekomcloudDmsFlavorV2FlavorsIos {
}
export declare function dataOpentelekomcloudDmsFlavorV2FlavorsIosToTerraform(struct?: DataOpentelekomcloudDmsFlavorV2FlavorsIos): any;
export declare function dataOpentelekomcloudDmsFlavorV2FlavorsIosToHclTerraform(struct?: DataOpentelekomcloudDmsFlavorV2FlavorsIos): any;
export declare class DataOpentelekomcloudDmsFlavorV2FlavorsIosOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudDmsFlavorV2FlavorsIos | undefined;
    set internalValue(value: DataOpentelekomcloudDmsFlavorV2FlavorsIos | undefined);
    get availabilityZones(): string[];
    get storageSpecCode(): string;
    get type(): string;
    get unavailabilityZones(): string[];
}
export declare class DataOpentelekomcloudDmsFlavorV2FlavorsIosList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudDmsFlavorV2FlavorsIosOutputReference;
}
export interface DataOpentelekomcloudDmsFlavorV2FlavorsProperties {
}
export declare function dataOpentelekomcloudDmsFlavorV2FlavorsPropertiesToTerraform(struct?: DataOpentelekomcloudDmsFlavorV2FlavorsProperties): any;
export declare function dataOpentelekomcloudDmsFlavorV2FlavorsPropertiesToHclTerraform(struct?: DataOpentelekomcloudDmsFlavorV2FlavorsProperties): any;
export declare class DataOpentelekomcloudDmsFlavorV2FlavorsPropertiesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudDmsFlavorV2FlavorsProperties | undefined;
    set internalValue(value: DataOpentelekomcloudDmsFlavorV2FlavorsProperties | undefined);
    get flavorAlias(): string;
    get maxBandwidthPerBroker(): number;
    get maxBroker(): number;
    get maxConsumerPerBroker(): number;
    get maxPartitionPerBroker(): number;
    get maxStoragePerNode(): number;
    get maxTpsPerBroker(): number;
    get minBroker(): number;
    get minStoragePerNode(): number;
}
export declare class DataOpentelekomcloudDmsFlavorV2FlavorsPropertiesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudDmsFlavorV2FlavorsPropertiesOutputReference;
}
export interface DataOpentelekomcloudDmsFlavorV2FlavorsSupportFeaturesProperties {
}
export declare function dataOpentelekomcloudDmsFlavorV2FlavorsSupportFeaturesPropertiesToTerraform(struct?: DataOpentelekomcloudDmsFlavorV2FlavorsSupportFeaturesProperties): any;
export declare function dataOpentelekomcloudDmsFlavorV2FlavorsSupportFeaturesPropertiesToHclTerraform(struct?: DataOpentelekomcloudDmsFlavorV2FlavorsSupportFeaturesProperties): any;
export declare class DataOpentelekomcloudDmsFlavorV2FlavorsSupportFeaturesPropertiesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudDmsFlavorV2FlavorsSupportFeaturesProperties | undefined;
    set internalValue(value: DataOpentelekomcloudDmsFlavorV2FlavorsSupportFeaturesProperties | undefined);
    get maxNode(): number;
    get maxTask(): number;
    get minNode(): number;
    get minTask(): number;
}
export declare class DataOpentelekomcloudDmsFlavorV2FlavorsSupportFeaturesPropertiesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudDmsFlavorV2FlavorsSupportFeaturesPropertiesOutputReference;
}
export interface DataOpentelekomcloudDmsFlavorV2FlavorsSupportFeatures {
}
export declare function dataOpentelekomcloudDmsFlavorV2FlavorsSupportFeaturesToTerraform(struct?: DataOpentelekomcloudDmsFlavorV2FlavorsSupportFeatures): any;
export declare function dataOpentelekomcloudDmsFlavorV2FlavorsSupportFeaturesToHclTerraform(struct?: DataOpentelekomcloudDmsFlavorV2FlavorsSupportFeatures): any;
export declare class DataOpentelekomcloudDmsFlavorV2FlavorsSupportFeaturesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudDmsFlavorV2FlavorsSupportFeatures | undefined;
    set internalValue(value: DataOpentelekomcloudDmsFlavorV2FlavorsSupportFeatures | undefined);
    get name(): string;
    private _properties;
    get properties(): DataOpentelekomcloudDmsFlavorV2FlavorsSupportFeaturesPropertiesList;
}
export declare class DataOpentelekomcloudDmsFlavorV2FlavorsSupportFeaturesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudDmsFlavorV2FlavorsSupportFeaturesOutputReference;
}
export interface DataOpentelekomcloudDmsFlavorV2Flavors {
}
export declare function dataOpentelekomcloudDmsFlavorV2FlavorsToTerraform(struct?: DataOpentelekomcloudDmsFlavorV2Flavors): any;
export declare function dataOpentelekomcloudDmsFlavorV2FlavorsToHclTerraform(struct?: DataOpentelekomcloudDmsFlavorV2Flavors): any;
export declare class DataOpentelekomcloudDmsFlavorV2FlavorsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudDmsFlavorV2Flavors | undefined;
    set internalValue(value: DataOpentelekomcloudDmsFlavorV2Flavors | undefined);
    get archTypes(): string[];
    get chargingModes(): string[];
    get id(): string;
    private _ios;
    get ios(): DataOpentelekomcloudDmsFlavorV2FlavorsIosList;
    private _properties;
    get properties(): DataOpentelekomcloudDmsFlavorV2FlavorsPropertiesList;
    private _supportFeatures;
    get supportFeatures(): DataOpentelekomcloudDmsFlavorV2FlavorsSupportFeaturesList;
    get type(): string;
    get vmSpecification(): string;
}
export declare class DataOpentelekomcloudDmsFlavorV2FlavorsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudDmsFlavorV2FlavorsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/dms_flavor_v2 opentelekomcloud_dms_flavor_v2}
*/
export declare class DataOpentelekomcloudDmsFlavorV2 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_dms_flavor_v2";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudDmsFlavorV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudDmsFlavorV2 to import
    * @param importFromId The id of the existing DataOpentelekomcloudDmsFlavorV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/dms_flavor_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudDmsFlavorV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/dms_flavor_v2 opentelekomcloud_dms_flavor_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudDmsFlavorV2Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudDmsFlavorV2Config);
    private _archType?;
    get archType(): string;
    set archType(value: string);
    resetArchType(): void;
    get archTypeInput(): string | undefined;
    private _availabilityZones?;
    get availabilityZones(): string[];
    set availabilityZones(value: string[]);
    resetAvailabilityZones(): void;
    get availabilityZonesInput(): string[] | undefined;
    private _chargingMode?;
    get chargingMode(): string;
    set chargingMode(value: string);
    resetChargingMode(): void;
    get chargingModeInput(): string | undefined;
    private _flavorId?;
    get flavorId(): string;
    set flavorId(value: string);
    resetFlavorId(): void;
    get flavorIdInput(): string | undefined;
    private _flavors;
    get flavors(): DataOpentelekomcloudDmsFlavorV2FlavorsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get region(): string;
    private _storageSpecCode?;
    get storageSpecCode(): string;
    set storageSpecCode(value: string);
    resetStorageSpecCode(): void;
    get storageSpecCodeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    get versions(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

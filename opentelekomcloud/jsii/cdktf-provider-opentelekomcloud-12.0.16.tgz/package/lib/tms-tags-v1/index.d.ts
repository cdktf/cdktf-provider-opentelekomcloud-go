/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface TmsTagsV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/tms_tags_v1#id TmsTagsV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/tms_tags_v1#tags TmsTagsV1#tags}
    */
    readonly tags: TmsTagsV1Tags[] | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/tms_tags_v1#timeouts TmsTagsV1#timeouts}
    */
    readonly timeouts?: TmsTagsV1Timeouts;
}
export interface TmsTagsV1Tags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/tms_tags_v1#key TmsTagsV1#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/tms_tags_v1#value TmsTagsV1#value}
    */
    readonly value: string;
}
export declare function tmsTagsV1TagsToTerraform(struct?: TmsTagsV1Tags | cdktf.IResolvable): any;
export declare function tmsTagsV1TagsToHclTerraform(struct?: TmsTagsV1Tags | cdktf.IResolvable): any;
export declare class TmsTagsV1TagsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): TmsTagsV1Tags | cdktf.IResolvable | undefined;
    set internalValue(value: TmsTagsV1Tags | cdktf.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class TmsTagsV1TagsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: TmsTagsV1Tags[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): TmsTagsV1TagsOutputReference;
}
export interface TmsTagsV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/tms_tags_v1#create TmsTagsV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/tms_tags_v1#delete TmsTagsV1#delete}
    */
    readonly delete?: string;
}
export declare function tmsTagsV1TimeoutsToTerraform(struct?: TmsTagsV1Timeouts | cdktf.IResolvable): any;
export declare function tmsTagsV1TimeoutsToHclTerraform(struct?: TmsTagsV1Timeouts | cdktf.IResolvable): any;
export declare class TmsTagsV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TmsTagsV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: TmsTagsV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/tms_tags_v1 opentelekomcloud_tms_tags_v1}
*/
export declare class TmsTagsV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_tms_tags_v1";
    /**
    * Generates CDKTF code for importing a TmsTagsV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TmsTagsV1 to import
    * @param importFromId The id of the existing TmsTagsV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/tms_tags_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TmsTagsV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/tms_tags_v1 opentelekomcloud_tms_tags_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TmsTagsV1Config
    */
    constructor(scope: Construct, id: string, config: TmsTagsV1Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _tags;
    get tags(): TmsTagsV1TagsList;
    putTags(value: TmsTagsV1Tags[] | cdktf.IResolvable): void;
    get tagsInput(): cdktf.IResolvable | TmsTagsV1Tags[] | undefined;
    private _timeouts;
    get timeouts(): TmsTagsV1TimeoutsOutputReference;
    putTimeouts(value: TmsTagsV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | TmsTagsV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

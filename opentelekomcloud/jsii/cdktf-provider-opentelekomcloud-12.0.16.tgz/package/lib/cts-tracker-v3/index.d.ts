/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CtsTrackerV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_tracker_v3#bucket_name CtsTrackerV3#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_tracker_v3#compress_type CtsTrackerV3#compress_type}
    */
    readonly compressType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_tracker_v3#file_prefix_name CtsTrackerV3#file_prefix_name}
    */
    readonly filePrefixName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_tracker_v3#is_lts_enabled CtsTrackerV3#is_lts_enabled}
    */
    readonly isLtsEnabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_tracker_v3#is_obs_created CtsTrackerV3#is_obs_created}
    */
    readonly isObsCreated?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_tracker_v3#is_sort_by_service CtsTrackerV3#is_sort_by_service}
    */
    readonly isSortByService?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_tracker_v3#status CtsTrackerV3#status}
    */
    readonly status: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_tracker_v3#timeouts CtsTrackerV3#timeouts}
    */
    readonly timeouts?: CtsTrackerV3Timeouts;
}
export interface CtsTrackerV3Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_tracker_v3#create CtsTrackerV3#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_tracker_v3#delete CtsTrackerV3#delete}
    */
    readonly delete?: string;
}
export declare function ctsTrackerV3TimeoutsToTerraform(struct?: CtsTrackerV3Timeouts | cdktf.IResolvable): any;
export declare function ctsTrackerV3TimeoutsToHclTerraform(struct?: CtsTrackerV3Timeouts | cdktf.IResolvable): any;
export declare class CtsTrackerV3TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CtsTrackerV3Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: CtsTrackerV3Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_tracker_v3 opentelekomcloud_cts_tracker_v3}
*/
export declare class CtsTrackerV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_cts_tracker_v3";
    /**
    * Generates CDKTF code for importing a CtsTrackerV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CtsTrackerV3 to import
    * @param importFromId The id of the existing CtsTrackerV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_tracker_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CtsTrackerV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_tracker_v3 opentelekomcloud_cts_tracker_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CtsTrackerV3Config
    */
    constructor(scope: Construct, id: string, config: CtsTrackerV3Config);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _compressType?;
    get compressType(): string;
    set compressType(value: string);
    resetCompressType(): void;
    get compressTypeInput(): string | undefined;
    get detail(): string;
    get domainId(): string;
    private _filePrefixName?;
    get filePrefixName(): string;
    set filePrefixName(value: string);
    resetFilePrefixName(): void;
    get filePrefixNameInput(): string | undefined;
    get id(): string;
    private _isLtsEnabled?;
    get isLtsEnabled(): boolean | cdktf.IResolvable;
    set isLtsEnabled(value: boolean | cdktf.IResolvable);
    resetIsLtsEnabled(): void;
    get isLtsEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _isObsCreated?;
    get isObsCreated(): boolean | cdktf.IResolvable;
    set isObsCreated(value: boolean | cdktf.IResolvable);
    resetIsObsCreated(): void;
    get isObsCreatedInput(): boolean | cdktf.IResolvable | undefined;
    private _isSortByService?;
    get isSortByService(): boolean | cdktf.IResolvable;
    set isSortByService(value: boolean | cdktf.IResolvable);
    resetIsSortByService(): void;
    get isSortByServiceInput(): boolean | cdktf.IResolvable | undefined;
    get logGroupName(): string;
    get logTopicName(): string;
    get projectId(): string;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
    get trackerName(): string;
    get trackerType(): string;
    private _timeouts;
    get timeouts(): CtsTrackerV3TimeoutsOutputReference;
    putTimeouts(value: CtsTrackerV3Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | CtsTrackerV3Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

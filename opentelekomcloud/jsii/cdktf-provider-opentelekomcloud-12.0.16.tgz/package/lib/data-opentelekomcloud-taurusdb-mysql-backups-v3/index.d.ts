/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudTaurusdbMysqlBackupsV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_backups_v3#backup_id DataOpentelekomcloudTaurusdbMysqlBackupsV3#backup_id}
    */
    readonly backupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_backups_v3#backup_type DataOpentelekomcloudTaurusdbMysqlBackupsV3#backup_type}
    */
    readonly backupType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_backups_v3#begin_time DataOpentelekomcloudTaurusdbMysqlBackupsV3#begin_time}
    */
    readonly beginTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_backups_v3#end_time DataOpentelekomcloudTaurusdbMysqlBackupsV3#end_time}
    */
    readonly endTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_backups_v3#id DataOpentelekomcloudTaurusdbMysqlBackupsV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_backups_v3#instance_id DataOpentelekomcloudTaurusdbMysqlBackupsV3#instance_id}
    */
    readonly instanceId?: string;
}
export interface DataOpentelekomcloudTaurusdbMysqlBackupsV3BackupsDatastore {
}
export declare function dataOpentelekomcloudTaurusdbMysqlBackupsV3BackupsDatastoreToTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlBackupsV3BackupsDatastore): any;
export declare function dataOpentelekomcloudTaurusdbMysqlBackupsV3BackupsDatastoreToHclTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlBackupsV3BackupsDatastore): any;
export declare class DataOpentelekomcloudTaurusdbMysqlBackupsV3BackupsDatastoreOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudTaurusdbMysqlBackupsV3BackupsDatastore | undefined;
    set internalValue(value: DataOpentelekomcloudTaurusdbMysqlBackupsV3BackupsDatastore | undefined);
    get type(): string;
    get version(): string;
}
export declare class DataOpentelekomcloudTaurusdbMysqlBackupsV3BackupsDatastoreList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudTaurusdbMysqlBackupsV3BackupsDatastoreOutputReference;
}
export interface DataOpentelekomcloudTaurusdbMysqlBackupsV3Backups {
}
export declare function dataOpentelekomcloudTaurusdbMysqlBackupsV3BackupsToTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlBackupsV3Backups): any;
export declare function dataOpentelekomcloudTaurusdbMysqlBackupsV3BackupsToHclTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlBackupsV3Backups): any;
export declare class DataOpentelekomcloudTaurusdbMysqlBackupsV3BackupsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudTaurusdbMysqlBackupsV3Backups | undefined;
    set internalValue(value: DataOpentelekomcloudTaurusdbMysqlBackupsV3Backups | undefined);
    get beginTime(): string;
    private _datastore;
    get datastore(): DataOpentelekomcloudTaurusdbMysqlBackupsV3BackupsDatastoreList;
    get description(): string;
    get endTime(): string;
    get id(): string;
    get instanceId(): string;
    get name(): string;
    get size(): number;
    get status(): string;
    get takeUpTime(): number;
    get type(): string;
}
export declare class DataOpentelekomcloudTaurusdbMysqlBackupsV3BackupsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudTaurusdbMysqlBackupsV3BackupsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_backups_v3 opentelekomcloud_taurusdb_mysql_backups_v3}
*/
export declare class DataOpentelekomcloudTaurusdbMysqlBackupsV3 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_taurusdb_mysql_backups_v3";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudTaurusdbMysqlBackupsV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudTaurusdbMysqlBackupsV3 to import
    * @param importFromId The id of the existing DataOpentelekomcloudTaurusdbMysqlBackupsV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_backups_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudTaurusdbMysqlBackupsV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_backups_v3 opentelekomcloud_taurusdb_mysql_backups_v3} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudTaurusdbMysqlBackupsV3Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudTaurusdbMysqlBackupsV3Config);
    private _backupId?;
    get backupId(): string;
    set backupId(value: string);
    resetBackupId(): void;
    get backupIdInput(): string | undefined;
    private _backupType?;
    get backupType(): string;
    set backupType(value: string);
    resetBackupType(): void;
    get backupTypeInput(): string | undefined;
    private _backups;
    get backups(): DataOpentelekomcloudTaurusdbMysqlBackupsV3BackupsList;
    private _beginTime?;
    get beginTime(): string;
    set beginTime(value: string);
    resetBeginTime(): void;
    get beginTimeInput(): string | undefined;
    private _endTime?;
    get endTime(): string;
    set endTime(value: string);
    resetEndTime(): void;
    get endTimeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    resetInstanceId(): void;
    get instanceIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface LtsKeywordsAlarmRuleV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#alarm_action_rule_name LtsKeywordsAlarmRuleV2#alarm_action_rule_name}
    */
    readonly alarmActionRuleName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#description LtsKeywordsAlarmRuleV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#id LtsKeywordsAlarmRuleV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#name LtsKeywordsAlarmRuleV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#notification_frequency LtsKeywordsAlarmRuleV2#notification_frequency}
    */
    readonly notificationFrequency: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#recovery_policy LtsKeywordsAlarmRuleV2#recovery_policy}
    */
    readonly recoveryPolicy?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#send_notifications LtsKeywordsAlarmRuleV2#send_notifications}
    */
    readonly sendNotifications?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#send_recovery_notifications LtsKeywordsAlarmRuleV2#send_recovery_notifications}
    */
    readonly sendRecoveryNotifications?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#severity LtsKeywordsAlarmRuleV2#severity}
    */
    readonly severity: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#trigger_condition_count LtsKeywordsAlarmRuleV2#trigger_condition_count}
    */
    readonly triggerConditionCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#trigger_condition_frequency LtsKeywordsAlarmRuleV2#trigger_condition_frequency}
    */
    readonly triggerConditionFrequency?: number;
    /**
    * frequency block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#frequency LtsKeywordsAlarmRuleV2#frequency}
    */
    readonly frequency: LtsKeywordsAlarmRuleV2Frequency;
    /**
    * keywords_requests block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#keywords_requests LtsKeywordsAlarmRuleV2#keywords_requests}
    */
    readonly keywordsRequests: LtsKeywordsAlarmRuleV2KeywordsRequests[] | cdktf.IResolvable;
    /**
    * notification_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#notification_rule LtsKeywordsAlarmRuleV2#notification_rule}
    */
    readonly notificationRule?: LtsKeywordsAlarmRuleV2NotificationRule;
}
export interface LtsKeywordsAlarmRuleV2Frequency {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#cron_expression LtsKeywordsAlarmRuleV2#cron_expression}
    */
    readonly cronExpression?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#day_of_week LtsKeywordsAlarmRuleV2#day_of_week}
    */
    readonly dayOfWeek?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#fixed_rate LtsKeywordsAlarmRuleV2#fixed_rate}
    */
    readonly fixedRate?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#fixed_rate_unit LtsKeywordsAlarmRuleV2#fixed_rate_unit}
    */
    readonly fixedRateUnit?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#hour_of_day LtsKeywordsAlarmRuleV2#hour_of_day}
    */
    readonly hourOfDay?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#type LtsKeywordsAlarmRuleV2#type}
    */
    readonly type: string;
}
export declare function ltsKeywordsAlarmRuleV2FrequencyToTerraform(struct?: LtsKeywordsAlarmRuleV2FrequencyOutputReference | LtsKeywordsAlarmRuleV2Frequency): any;
export declare function ltsKeywordsAlarmRuleV2FrequencyToHclTerraform(struct?: LtsKeywordsAlarmRuleV2FrequencyOutputReference | LtsKeywordsAlarmRuleV2Frequency): any;
export declare class LtsKeywordsAlarmRuleV2FrequencyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LtsKeywordsAlarmRuleV2Frequency | undefined;
    set internalValue(value: LtsKeywordsAlarmRuleV2Frequency | undefined);
    private _cronExpression?;
    get cronExpression(): string;
    set cronExpression(value: string);
    resetCronExpression(): void;
    get cronExpressionInput(): string | undefined;
    private _dayOfWeek?;
    get dayOfWeek(): number;
    set dayOfWeek(value: number);
    resetDayOfWeek(): void;
    get dayOfWeekInput(): number | undefined;
    private _fixedRate?;
    get fixedRate(): number;
    set fixedRate(value: number);
    resetFixedRate(): void;
    get fixedRateInput(): number | undefined;
    private _fixedRateUnit?;
    get fixedRateUnit(): string;
    set fixedRateUnit(value: string);
    resetFixedRateUnit(): void;
    get fixedRateUnitInput(): string | undefined;
    private _hourOfDay?;
    get hourOfDay(): number;
    set hourOfDay(value: number);
    resetHourOfDay(): void;
    get hourOfDayInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface LtsKeywordsAlarmRuleV2KeywordsRequests {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#condition LtsKeywordsAlarmRuleV2#condition}
    */
    readonly condition: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#keyword LtsKeywordsAlarmRuleV2#keyword}
    */
    readonly keyword: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#log_group_id LtsKeywordsAlarmRuleV2#log_group_id}
    */
    readonly logGroupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#log_stream_id LtsKeywordsAlarmRuleV2#log_stream_id}
    */
    readonly logStreamId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#number LtsKeywordsAlarmRuleV2#number}
    */
    readonly number: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#search_time_range LtsKeywordsAlarmRuleV2#search_time_range}
    */
    readonly searchTimeRange: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#search_time_range_unit LtsKeywordsAlarmRuleV2#search_time_range_unit}
    */
    readonly searchTimeRangeUnit: string;
}
export declare function ltsKeywordsAlarmRuleV2KeywordsRequestsToTerraform(struct?: LtsKeywordsAlarmRuleV2KeywordsRequests | cdktf.IResolvable): any;
export declare function ltsKeywordsAlarmRuleV2KeywordsRequestsToHclTerraform(struct?: LtsKeywordsAlarmRuleV2KeywordsRequests | cdktf.IResolvable): any;
export declare class LtsKeywordsAlarmRuleV2KeywordsRequestsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LtsKeywordsAlarmRuleV2KeywordsRequests | cdktf.IResolvable | undefined;
    set internalValue(value: LtsKeywordsAlarmRuleV2KeywordsRequests | cdktf.IResolvable | undefined);
    private _condition?;
    get condition(): string;
    set condition(value: string);
    get conditionInput(): string | undefined;
    private _keyword?;
    get keyword(): string;
    set keyword(value: string);
    get keywordInput(): string | undefined;
    private _logGroupId?;
    get logGroupId(): string;
    set logGroupId(value: string);
    get logGroupIdInput(): string | undefined;
    private _logStreamId?;
    get logStreamId(): string;
    set logStreamId(value: string);
    get logStreamIdInput(): string | undefined;
    private _number?;
    get number(): number;
    set number(value: number);
    get numberInput(): number | undefined;
    private _searchTimeRange?;
    get searchTimeRange(): number;
    set searchTimeRange(value: number);
    get searchTimeRangeInput(): number | undefined;
    private _searchTimeRangeUnit?;
    get searchTimeRangeUnit(): string;
    set searchTimeRangeUnit(value: string);
    get searchTimeRangeUnitInput(): string | undefined;
}
export declare class LtsKeywordsAlarmRuleV2KeywordsRequestsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: LtsKeywordsAlarmRuleV2KeywordsRequests[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LtsKeywordsAlarmRuleV2KeywordsRequestsOutputReference;
}
export interface LtsKeywordsAlarmRuleV2NotificationRuleTopics {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#display_name LtsKeywordsAlarmRuleV2#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#name LtsKeywordsAlarmRuleV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#push_policy LtsKeywordsAlarmRuleV2#push_policy}
    */
    readonly pushPolicy?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#topic_urn LtsKeywordsAlarmRuleV2#topic_urn}
    */
    readonly topicUrn: string;
}
export declare function ltsKeywordsAlarmRuleV2NotificationRuleTopicsToTerraform(struct?: LtsKeywordsAlarmRuleV2NotificationRuleTopics | cdktf.IResolvable): any;
export declare function ltsKeywordsAlarmRuleV2NotificationRuleTopicsToHclTerraform(struct?: LtsKeywordsAlarmRuleV2NotificationRuleTopics | cdktf.IResolvable): any;
export declare class LtsKeywordsAlarmRuleV2NotificationRuleTopicsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LtsKeywordsAlarmRuleV2NotificationRuleTopics | cdktf.IResolvable | undefined;
    set internalValue(value: LtsKeywordsAlarmRuleV2NotificationRuleTopics | cdktf.IResolvable | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _pushPolicy?;
    get pushPolicy(): number;
    set pushPolicy(value: number);
    resetPushPolicy(): void;
    get pushPolicyInput(): number | undefined;
    private _topicUrn?;
    get topicUrn(): string;
    set topicUrn(value: string);
    get topicUrnInput(): string | undefined;
}
export declare class LtsKeywordsAlarmRuleV2NotificationRuleTopicsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: LtsKeywordsAlarmRuleV2NotificationRuleTopics[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LtsKeywordsAlarmRuleV2NotificationRuleTopicsOutputReference;
}
export interface LtsKeywordsAlarmRuleV2NotificationRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#language LtsKeywordsAlarmRuleV2#language}
    */
    readonly language?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#template_name LtsKeywordsAlarmRuleV2#template_name}
    */
    readonly templateName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#timezone LtsKeywordsAlarmRuleV2#timezone}
    */
    readonly timezone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#user_name LtsKeywordsAlarmRuleV2#user_name}
    */
    readonly userName: string;
    /**
    * topics block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#topics LtsKeywordsAlarmRuleV2#topics}
    */
    readonly topics: LtsKeywordsAlarmRuleV2NotificationRuleTopics[] | cdktf.IResolvable;
}
export declare function ltsKeywordsAlarmRuleV2NotificationRuleToTerraform(struct?: LtsKeywordsAlarmRuleV2NotificationRuleOutputReference | LtsKeywordsAlarmRuleV2NotificationRule): any;
export declare function ltsKeywordsAlarmRuleV2NotificationRuleToHclTerraform(struct?: LtsKeywordsAlarmRuleV2NotificationRuleOutputReference | LtsKeywordsAlarmRuleV2NotificationRule): any;
export declare class LtsKeywordsAlarmRuleV2NotificationRuleOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LtsKeywordsAlarmRuleV2NotificationRule | undefined;
    set internalValue(value: LtsKeywordsAlarmRuleV2NotificationRule | undefined);
    private _language?;
    get language(): string;
    set language(value: string);
    resetLanguage(): void;
    get languageInput(): string | undefined;
    private _templateName?;
    get templateName(): string;
    set templateName(value: string);
    resetTemplateName(): void;
    get templateNameInput(): string | undefined;
    private _timezone?;
    get timezone(): string;
    set timezone(value: string);
    resetTimezone(): void;
    get timezoneInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    get userNameInput(): string | undefined;
    private _topics;
    get topics(): LtsKeywordsAlarmRuleV2NotificationRuleTopicsList;
    putTopics(value: LtsKeywordsAlarmRuleV2NotificationRuleTopics[] | cdktf.IResolvable): void;
    get topicsInput(): cdktf.IResolvable | LtsKeywordsAlarmRuleV2NotificationRuleTopics[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2 opentelekomcloud_lts_keywords_alarm_rule_v2}
*/
export declare class LtsKeywordsAlarmRuleV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_lts_keywords_alarm_rule_v2";
    /**
    * Generates CDKTF code for importing a LtsKeywordsAlarmRuleV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LtsKeywordsAlarmRuleV2 to import
    * @param importFromId The id of the existing LtsKeywordsAlarmRuleV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LtsKeywordsAlarmRuleV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_keywords_alarm_rule_v2 opentelekomcloud_lts_keywords_alarm_rule_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LtsKeywordsAlarmRuleV2Config
    */
    constructor(scope: Construct, id: string, config: LtsKeywordsAlarmRuleV2Config);
    private _alarmActionRuleName?;
    get alarmActionRuleName(): string;
    set alarmActionRuleName(value: string);
    resetAlarmActionRuleName(): void;
    get alarmActionRuleNameInput(): string | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get domainId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _notificationFrequency?;
    get notificationFrequency(): number;
    set notificationFrequency(value: number);
    get notificationFrequencyInput(): number | undefined;
    private _recoveryPolicy?;
    get recoveryPolicy(): number;
    set recoveryPolicy(value: number);
    resetRecoveryPolicy(): void;
    get recoveryPolicyInput(): number | undefined;
    get region(): string;
    private _sendNotifications?;
    get sendNotifications(): boolean | cdktf.IResolvable;
    set sendNotifications(value: boolean | cdktf.IResolvable);
    resetSendNotifications(): void;
    get sendNotificationsInput(): boolean | cdktf.IResolvable | undefined;
    private _sendRecoveryNotifications?;
    get sendRecoveryNotifications(): boolean | cdktf.IResolvable;
    set sendRecoveryNotifications(value: boolean | cdktf.IResolvable);
    resetSendRecoveryNotifications(): void;
    get sendRecoveryNotificationsInput(): boolean | cdktf.IResolvable | undefined;
    private _severity?;
    get severity(): string;
    set severity(value: string);
    get severityInput(): string | undefined;
    get status(): string;
    private _triggerConditionCount?;
    get triggerConditionCount(): number;
    set triggerConditionCount(value: number);
    resetTriggerConditionCount(): void;
    get triggerConditionCountInput(): number | undefined;
    private _triggerConditionFrequency?;
    get triggerConditionFrequency(): number;
    set triggerConditionFrequency(value: number);
    resetTriggerConditionFrequency(): void;
    get triggerConditionFrequencyInput(): number | undefined;
    get updatedAt(): string;
    private _frequency;
    get frequency(): LtsKeywordsAlarmRuleV2FrequencyOutputReference;
    putFrequency(value: LtsKeywordsAlarmRuleV2Frequency): void;
    get frequencyInput(): LtsKeywordsAlarmRuleV2Frequency | undefined;
    private _keywordsRequests;
    get keywordsRequests(): LtsKeywordsAlarmRuleV2KeywordsRequestsList;
    putKeywordsRequests(value: LtsKeywordsAlarmRuleV2KeywordsRequests[] | cdktf.IResolvable): void;
    get keywordsRequestsInput(): cdktf.IResolvable | LtsKeywordsAlarmRuleV2KeywordsRequests[] | undefined;
    private _notificationRule;
    get notificationRule(): LtsKeywordsAlarmRuleV2NotificationRuleOutputReference;
    putNotificationRule(value: LtsKeywordsAlarmRuleV2NotificationRule): void;
    resetNotificationRule(): void;
    get notificationRuleInput(): LtsKeywordsAlarmRuleV2NotificationRule | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

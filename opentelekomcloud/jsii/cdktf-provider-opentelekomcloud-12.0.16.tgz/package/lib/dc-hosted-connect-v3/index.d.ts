/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DcHostedConnectV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_hosted_connect_v3#bandwidth DcHostedConnectV3#bandwidth}
    */
    readonly bandwidth: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_hosted_connect_v3#description DcHostedConnectV3#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_hosted_connect_v3#hosting_id DcHostedConnectV3#hosting_id}
    */
    readonly hostingId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_hosted_connect_v3#id DcHostedConnectV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_hosted_connect_v3#name DcHostedConnectV3#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_hosted_connect_v3#peer_location DcHostedConnectV3#peer_location}
    */
    readonly peerLocation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_hosted_connect_v3#resource_tenant_id DcHostedConnectV3#resource_tenant_id}
    */
    readonly resourceTenantId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_hosted_connect_v3#vlan DcHostedConnectV3#vlan}
    */
    readonly vlan: number;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_hosted_connect_v3#timeouts DcHostedConnectV3#timeouts}
    */
    readonly timeouts?: DcHostedConnectV3Timeouts;
}
export interface DcHostedConnectV3Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_hosted_connect_v3#create DcHostedConnectV3#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_hosted_connect_v3#delete DcHostedConnectV3#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_hosted_connect_v3#update DcHostedConnectV3#update}
    */
    readonly update?: string;
}
export declare function dcHostedConnectV3TimeoutsToTerraform(struct?: DcHostedConnectV3Timeouts | cdktf.IResolvable): any;
export declare function dcHostedConnectV3TimeoutsToHclTerraform(struct?: DcHostedConnectV3Timeouts | cdktf.IResolvable): any;
export declare class DcHostedConnectV3TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DcHostedConnectV3Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DcHostedConnectV3Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_hosted_connect_v3 opentelekomcloud_dc_hosted_connect_v3}
*/
export declare class DcHostedConnectV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_dc_hosted_connect_v3";
    /**
    * Generates CDKTF code for importing a DcHostedConnectV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DcHostedConnectV3 to import
    * @param importFromId The id of the existing DcHostedConnectV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_hosted_connect_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DcHostedConnectV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_hosted_connect_v3 opentelekomcloud_dc_hosted_connect_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DcHostedConnectV3Config
    */
    constructor(scope: Construct, id: string, config: DcHostedConnectV3Config);
    private _bandwidth?;
    get bandwidth(): number;
    set bandwidth(value: number);
    get bandwidthInput(): number | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _hostingId?;
    get hostingId(): string;
    set hostingId(value: string);
    get hostingIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _peerLocation?;
    get peerLocation(): string;
    set peerLocation(value: string);
    resetPeerLocation(): void;
    get peerLocationInput(): string | undefined;
    get region(): string;
    private _resourceTenantId?;
    get resourceTenantId(): string;
    set resourceTenantId(value: string);
    get resourceTenantIdInput(): string | undefined;
    get status(): string;
    private _vlan?;
    get vlan(): number;
    set vlan(value: number);
    get vlanInput(): number | undefined;
    private _timeouts;
    get timeouts(): DcHostedConnectV3TimeoutsOutputReference;
    putTimeouts(value: DcHostedConnectV3Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DcHostedConnectV3Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

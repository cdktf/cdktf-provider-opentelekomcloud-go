/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudIdentityRoleCustomV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/identity_role_custom_v3#display_name DataOpentelekomcloudIdentityRoleCustomV3#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/identity_role_custom_v3#id DataOpentelekomcloudIdentityRoleCustomV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/identity_role_custom_v3#type DataOpentelekomcloudIdentityRoleCustomV3#type}
    */
    readonly type?: string;
}
export interface DataOpentelekomcloudIdentityRoleCustomV3Statement {
}
export declare function dataOpentelekomcloudIdentityRoleCustomV3StatementToTerraform(struct?: DataOpentelekomcloudIdentityRoleCustomV3Statement): any;
export declare function dataOpentelekomcloudIdentityRoleCustomV3StatementToHclTerraform(struct?: DataOpentelekomcloudIdentityRoleCustomV3Statement): any;
export declare class DataOpentelekomcloudIdentityRoleCustomV3StatementOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudIdentityRoleCustomV3Statement | undefined;
    set internalValue(value: DataOpentelekomcloudIdentityRoleCustomV3Statement | undefined);
    get action(): string[];
    get condition(): string;
    get effect(): string;
    get resource(): string[];
}
export declare class DataOpentelekomcloudIdentityRoleCustomV3StatementList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudIdentityRoleCustomV3StatementOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/identity_role_custom_v3 opentelekomcloud_identity_role_custom_v3}
*/
export declare class DataOpentelekomcloudIdentityRoleCustomV3 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_identity_role_custom_v3";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudIdentityRoleCustomV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudIdentityRoleCustomV3 to import
    * @param importFromId The id of the existing DataOpentelekomcloudIdentityRoleCustomV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/identity_role_custom_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudIdentityRoleCustomV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/identity_role_custom_v3 opentelekomcloud_identity_role_custom_v3} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudIdentityRoleCustomV3Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudIdentityRoleCustomV3Config);
    get description(): string;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    get domainId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    private _statement;
    get statement(): DataOpentelekomcloudIdentityRoleCustomV3StatementList;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

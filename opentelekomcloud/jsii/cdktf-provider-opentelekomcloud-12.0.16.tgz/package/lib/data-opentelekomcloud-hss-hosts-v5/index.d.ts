/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudHssHostsV5Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_hosts_v5#agent_status DataOpentelekomcloudHssHostsV5#agent_status}
    */
    readonly agentStatus?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_hosts_v5#asset_value DataOpentelekomcloudHssHostsV5#asset_value}
    */
    readonly assetValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_hosts_v5#detect_result DataOpentelekomcloudHssHostsV5#detect_result}
    */
    readonly detectResult?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_hosts_v5#group_id DataOpentelekomcloudHssHostsV5#group_id}
    */
    readonly groupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_hosts_v5#host_id DataOpentelekomcloudHssHostsV5#host_id}
    */
    readonly hostId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_hosts_v5#id DataOpentelekomcloudHssHostsV5#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_hosts_v5#name DataOpentelekomcloudHssHostsV5#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_hosts_v5#os_type DataOpentelekomcloudHssHostsV5#os_type}
    */
    readonly osType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_hosts_v5#policy_group_id DataOpentelekomcloudHssHostsV5#policy_group_id}
    */
    readonly policyGroupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_hosts_v5#protect_charging_mode DataOpentelekomcloudHssHostsV5#protect_charging_mode}
    */
    readonly protectChargingMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_hosts_v5#protect_status DataOpentelekomcloudHssHostsV5#protect_status}
    */
    readonly protectStatus?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_hosts_v5#protect_version DataOpentelekomcloudHssHostsV5#protect_version}
    */
    readonly protectVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_hosts_v5#status DataOpentelekomcloudHssHostsV5#status}
    */
    readonly status?: string;
}
export interface DataOpentelekomcloudHssHostsV5Hosts {
}
export declare function dataOpentelekomcloudHssHostsV5HostsToTerraform(struct?: DataOpentelekomcloudHssHostsV5Hosts): any;
export declare function dataOpentelekomcloudHssHostsV5HostsToHclTerraform(struct?: DataOpentelekomcloudHssHostsV5Hosts): any;
export declare class DataOpentelekomcloudHssHostsV5HostsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudHssHostsV5Hosts | undefined;
    set internalValue(value: DataOpentelekomcloudHssHostsV5Hosts | undefined);
    get agentId(): string;
    get agentStatus(): string;
    get assetRiskNum(): number;
    get assetValue(): string;
    get baselineRiskNum(): number;
    get detectResult(): string;
    get groupId(): string;
    get id(): string;
    get intrusionRiskNum(): number;
    get name(): string;
    get osType(): string;
    get policyGroupId(): string;
    get privateIp(): string;
    get protectChargingMode(): string;
    get protectStatus(): string;
    get protectVersion(): string;
    get publicIp(): string;
    get resourceId(): string;
    get status(): string;
    get vulnerabilityRiskNum(): number;
}
export declare class DataOpentelekomcloudHssHostsV5HostsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudHssHostsV5HostsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_hosts_v5 opentelekomcloud_hss_hosts_v5}
*/
export declare class DataOpentelekomcloudHssHostsV5 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_hss_hosts_v5";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudHssHostsV5 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudHssHostsV5 to import
    * @param importFromId The id of the existing DataOpentelekomcloudHssHostsV5 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_hosts_v5#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudHssHostsV5 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_hosts_v5 opentelekomcloud_hss_hosts_v5} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudHssHostsV5Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudHssHostsV5Config);
    private _agentStatus?;
    get agentStatus(): string;
    set agentStatus(value: string);
    resetAgentStatus(): void;
    get agentStatusInput(): string | undefined;
    private _assetValue?;
    get assetValue(): string;
    set assetValue(value: string);
    resetAssetValue(): void;
    get assetValueInput(): string | undefined;
    private _detectResult?;
    get detectResult(): string;
    set detectResult(value: string);
    resetDetectResult(): void;
    get detectResultInput(): string | undefined;
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    resetGroupId(): void;
    get groupIdInput(): string | undefined;
    private _hostId?;
    get hostId(): string;
    set hostId(value: string);
    resetHostId(): void;
    get hostIdInput(): string | undefined;
    private _hosts;
    get hosts(): DataOpentelekomcloudHssHostsV5HostsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _osType?;
    get osType(): string;
    set osType(value: string);
    resetOsType(): void;
    get osTypeInput(): string | undefined;
    private _policyGroupId?;
    get policyGroupId(): string;
    set policyGroupId(value: string);
    resetPolicyGroupId(): void;
    get policyGroupIdInput(): string | undefined;
    private _protectChargingMode?;
    get protectChargingMode(): string;
    set protectChargingMode(value: string);
    resetProtectChargingMode(): void;
    get protectChargingModeInput(): string | undefined;
    private _protectStatus?;
    get protectStatus(): string;
    set protectStatus(value: string);
    resetProtectStatus(): void;
    get protectStatusInput(): string | undefined;
    private _protectVersion?;
    get protectVersion(): string;
    set protectVersion(value: string);
    resetProtectVersion(): void;
    get protectVersionInput(): string | undefined;
    get region(): string;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

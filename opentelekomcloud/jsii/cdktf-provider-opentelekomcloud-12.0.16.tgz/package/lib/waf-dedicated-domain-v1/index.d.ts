/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface WafDedicatedDomainV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_domain_v1#certificate_id WafDedicatedDomainV1#certificate_id}
    */
    readonly certificateId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_domain_v1#cipher WafDedicatedDomainV1#cipher}
    */
    readonly cipher?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_domain_v1#domain WafDedicatedDomainV1#domain}
    */
    readonly domain: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_domain_v1#id WafDedicatedDomainV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_domain_v1#keep_policy WafDedicatedDomainV1#keep_policy}
    */
    readonly keepPolicy?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_domain_v1#pci_3ds WafDedicatedDomainV1#pci_3ds}
    */
    readonly pci3Ds?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_domain_v1#pci_dss WafDedicatedDomainV1#pci_dss}
    */
    readonly pciDss?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_domain_v1#policy_id WafDedicatedDomainV1#policy_id}
    */
    readonly policyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_domain_v1#protect_status WafDedicatedDomainV1#protect_status}
    */
    readonly protectStatus?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_domain_v1#proxy WafDedicatedDomainV1#proxy}
    */
    readonly proxy?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_domain_v1#region WafDedicatedDomainV1#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_domain_v1#tls WafDedicatedDomainV1#tls}
    */
    readonly tls?: string;
    /**
    * server block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_domain_v1#server WafDedicatedDomainV1#server}
    */
    readonly server: WafDedicatedDomainV1Server[] | cdktf.IResolvable;
    /**
    * timeout_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_domain_v1#timeout_config WafDedicatedDomainV1#timeout_config}
    */
    readonly timeoutConfig?: WafDedicatedDomainV1TimeoutConfig;
}
export interface WafDedicatedDomainV1Server {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_domain_v1#address WafDedicatedDomainV1#address}
    */
    readonly address: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_domain_v1#client_protocol WafDedicatedDomainV1#client_protocol}
    */
    readonly clientProtocol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_domain_v1#port WafDedicatedDomainV1#port}
    */
    readonly port: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_domain_v1#server_protocol WafDedicatedDomainV1#server_protocol}
    */
    readonly serverProtocol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_domain_v1#type WafDedicatedDomainV1#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_domain_v1#vpc_id WafDedicatedDomainV1#vpc_id}
    */
    readonly vpcId: string;
}
export declare function wafDedicatedDomainV1ServerToTerraform(struct?: WafDedicatedDomainV1Server | cdktf.IResolvable): any;
export declare function wafDedicatedDomainV1ServerToHclTerraform(struct?: WafDedicatedDomainV1Server | cdktf.IResolvable): any;
export declare class WafDedicatedDomainV1ServerOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WafDedicatedDomainV1Server | cdktf.IResolvable | undefined;
    set internalValue(value: WafDedicatedDomainV1Server | cdktf.IResolvable | undefined);
    private _address?;
    get address(): string;
    set address(value: string);
    get addressInput(): string | undefined;
    private _clientProtocol?;
    get clientProtocol(): string;
    set clientProtocol(value: string);
    get clientProtocolInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
    private _serverProtocol?;
    get serverProtocol(): string;
    set serverProtocol(value: string);
    get serverProtocolInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    get vpcIdInput(): string | undefined;
}
export declare class WafDedicatedDomainV1ServerList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WafDedicatedDomainV1Server[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WafDedicatedDomainV1ServerOutputReference;
}
export interface WafDedicatedDomainV1TimeoutConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_domain_v1#connect_timeout WafDedicatedDomainV1#connect_timeout}
    */
    readonly connectTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_domain_v1#read_timeout WafDedicatedDomainV1#read_timeout}
    */
    readonly readTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_domain_v1#send_timeout WafDedicatedDomainV1#send_timeout}
    */
    readonly sendTimeout?: number;
}
export declare function wafDedicatedDomainV1TimeoutConfigToTerraform(struct?: WafDedicatedDomainV1TimeoutConfigOutputReference | WafDedicatedDomainV1TimeoutConfig): any;
export declare function wafDedicatedDomainV1TimeoutConfigToHclTerraform(struct?: WafDedicatedDomainV1TimeoutConfigOutputReference | WafDedicatedDomainV1TimeoutConfig): any;
export declare class WafDedicatedDomainV1TimeoutConfigOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WafDedicatedDomainV1TimeoutConfig | undefined;
    set internalValue(value: WafDedicatedDomainV1TimeoutConfig | undefined);
    private _connectTimeout?;
    get connectTimeout(): number;
    set connectTimeout(value: number);
    resetConnectTimeout(): void;
    get connectTimeoutInput(): number | undefined;
    private _readTimeout?;
    get readTimeout(): number;
    set readTimeout(value: number);
    resetReadTimeout(): void;
    get readTimeoutInput(): number | undefined;
    private _sendTimeout?;
    get sendTimeout(): number;
    set sendTimeout(value: number);
    resetSendTimeout(): void;
    get sendTimeoutInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_domain_v1 opentelekomcloud_waf_dedicated_domain_v1}
*/
export declare class WafDedicatedDomainV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_waf_dedicated_domain_v1";
    /**
    * Generates CDKTF code for importing a WafDedicatedDomainV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WafDedicatedDomainV1 to import
    * @param importFromId The id of the existing WafDedicatedDomainV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_domain_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WafDedicatedDomainV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_domain_v1 opentelekomcloud_waf_dedicated_domain_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WafDedicatedDomainV1Config
    */
    constructor(scope: Construct, id: string, config: WafDedicatedDomainV1Config);
    get accessStatus(): number;
    private _alarmPage;
    get alarmPage(): cdktf.StringMap;
    private _certificateId?;
    get certificateId(): string;
    set certificateId(value: string);
    resetCertificateId(): void;
    get certificateIdInput(): string | undefined;
    get certificateName(): string;
    private _cipher?;
    get cipher(): string;
    set cipher(value: string);
    resetCipher(): void;
    get cipherInput(): string | undefined;
    private _complianceCertification;
    get complianceCertification(): cdktf.BooleanMap;
    get createdAt(): number;
    private _domain?;
    get domain(): string;
    set domain(value: string);
    get domainInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _keepPolicy?;
    get keepPolicy(): boolean | cdktf.IResolvable;
    set keepPolicy(value: boolean | cdktf.IResolvable);
    resetKeepPolicy(): void;
    get keepPolicyInput(): boolean | cdktf.IResolvable | undefined;
    private _pci3Ds?;
    get pci3Ds(): boolean | cdktf.IResolvable;
    set pci3Ds(value: boolean | cdktf.IResolvable);
    resetPci3Ds(): void;
    get pci3DsInput(): boolean | cdktf.IResolvable | undefined;
    private _pciDss?;
    get pciDss(): boolean | cdktf.IResolvable;
    set pciDss(value: boolean | cdktf.IResolvable);
    resetPciDss(): void;
    get pciDssInput(): boolean | cdktf.IResolvable | undefined;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    resetPolicyId(): void;
    get policyIdInput(): string | undefined;
    private _protectStatus?;
    get protectStatus(): number;
    set protectStatus(value: number);
    resetProtectStatus(): void;
    get protectStatusInput(): number | undefined;
    get protocol(): string;
    private _proxy?;
    get proxy(): boolean | cdktf.IResolvable;
    set proxy(value: boolean | cdktf.IResolvable);
    resetProxy(): void;
    get proxyInput(): boolean | cdktf.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tls?;
    get tls(): string;
    set tls(value: string);
    resetTls(): void;
    get tlsInput(): string | undefined;
    private _trafficIdentifier;
    get trafficIdentifier(): cdktf.StringMap;
    private _server;
    get server(): WafDedicatedDomainV1ServerList;
    putServer(value: WafDedicatedDomainV1Server[] | cdktf.IResolvable): void;
    get serverInput(): cdktf.IResolvable | WafDedicatedDomainV1Server[] | undefined;
    private _timeoutConfig;
    get timeoutConfig(): WafDedicatedDomainV1TimeoutConfigOutputReference;
    putTimeoutConfig(value: WafDedicatedDomainV1TimeoutConfig): void;
    resetTimeoutConfig(): void;
    get timeoutConfigInput(): WafDedicatedDomainV1TimeoutConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

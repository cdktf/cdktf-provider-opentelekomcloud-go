/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudLbLoadbalancerV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/lb_loadbalancer_v3#id DataOpentelekomcloudLbLoadbalancerV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/lb_loadbalancer_v3#l4_flavor DataOpentelekomcloudLbLoadbalancerV3#l4_flavor}
    */
    readonly l4Flavor?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/lb_loadbalancer_v3#l7_flavor DataOpentelekomcloudLbLoadbalancerV3#l7_flavor}
    */
    readonly l7Flavor?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/lb_loadbalancer_v3#name DataOpentelekomcloudLbLoadbalancerV3#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/lb_loadbalancer_v3#router_id DataOpentelekomcloudLbLoadbalancerV3#router_id}
    */
    readonly routerId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/lb_loadbalancer_v3#subnet_id DataOpentelekomcloudLbLoadbalancerV3#subnet_id}
    */
    readonly subnetId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/lb_loadbalancer_v3#vip_address DataOpentelekomcloudLbLoadbalancerV3#vip_address}
    */
    readonly vipAddress?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/lb_loadbalancer_v3#vip_port_id DataOpentelekomcloudLbLoadbalancerV3#vip_port_id}
    */
    readonly vipPortId?: string;
}
export interface DataOpentelekomcloudLbLoadbalancerV3PublicIp {
}
export declare function dataOpentelekomcloudLbLoadbalancerV3PublicIpToTerraform(struct?: DataOpentelekomcloudLbLoadbalancerV3PublicIp): any;
export declare function dataOpentelekomcloudLbLoadbalancerV3PublicIpToHclTerraform(struct?: DataOpentelekomcloudLbLoadbalancerV3PublicIp): any;
export declare class DataOpentelekomcloudLbLoadbalancerV3PublicIpOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudLbLoadbalancerV3PublicIp | undefined;
    set internalValue(value: DataOpentelekomcloudLbLoadbalancerV3PublicIp | undefined);
    get address(): string;
    get bandwidthChargeMode(): string;
    get bandwidthName(): string;
    get bandwidthShareType(): string;
    get bandwidthSize(): number;
    get id(): string;
    get ipType(): string;
}
export declare class DataOpentelekomcloudLbLoadbalancerV3PublicIpList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudLbLoadbalancerV3PublicIpOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/lb_loadbalancer_v3 opentelekomcloud_lb_loadbalancer_v3}
*/
export declare class DataOpentelekomcloudLbLoadbalancerV3 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_lb_loadbalancer_v3";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudLbLoadbalancerV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudLbLoadbalancerV3 to import
    * @param importFromId The id of the existing DataOpentelekomcloudLbLoadbalancerV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/lb_loadbalancer_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudLbLoadbalancerV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/lb_loadbalancer_v3 opentelekomcloud_lb_loadbalancer_v3} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudLbLoadbalancerV3Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudLbLoadbalancerV3Config);
    get adminStateUp(): cdktf.IResolvable;
    get availabilityZones(): string[];
    get createdAt(): string;
    get deletionProtection(): cdktf.IResolvable;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ipTargetEnable(): cdktf.IResolvable;
    private _l4Flavor?;
    get l4Flavor(): string;
    set l4Flavor(value: string);
    resetL4Flavor(): void;
    get l4FlavorInput(): string | undefined;
    private _l7Flavor?;
    get l7Flavor(): string;
    set l7Flavor(value: string);
    resetL7Flavor(): void;
    get l7FlavorInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get networkIds(): string[];
    private _publicIp;
    get publicIp(): DataOpentelekomcloudLbLoadbalancerV3PublicIpList;
    private _routerId?;
    get routerId(): string;
    set routerId(value: string);
    resetRouterId(): void;
    get routerIdInput(): string | undefined;
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    resetSubnetId(): void;
    get subnetIdInput(): string | undefined;
    private _tags;
    get tags(): cdktf.StringMap;
    get updatedAt(): string;
    private _vipAddress?;
    get vipAddress(): string;
    set vipAddress(value: string);
    resetVipAddress(): void;
    get vipAddressInput(): string | undefined;
    private _vipPortId?;
    get vipPortId(): string;
    set vipPortId(value: string);
    resetVipPortId(): void;
    get vipPortIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

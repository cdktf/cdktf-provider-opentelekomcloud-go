/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudEnterpriseVpnConnectionV5Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/enterprise_vpn_connection_v5#id DataOpentelekomcloudEnterpriseVpnConnectionV5#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/enterprise_vpn_connection_v5#tags DataOpentelekomcloudEnterpriseVpnConnectionV5#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
export interface DataOpentelekomcloudEnterpriseVpnConnectionV5IkepolicyDpd {
}
export declare function dataOpentelekomcloudEnterpriseVpnConnectionV5IkepolicyDpdToTerraform(struct?: DataOpentelekomcloudEnterpriseVpnConnectionV5IkepolicyDpd): any;
export declare function dataOpentelekomcloudEnterpriseVpnConnectionV5IkepolicyDpdToHclTerraform(struct?: DataOpentelekomcloudEnterpriseVpnConnectionV5IkepolicyDpd): any;
export declare class DataOpentelekomcloudEnterpriseVpnConnectionV5IkepolicyDpdOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudEnterpriseVpnConnectionV5IkepolicyDpd | undefined;
    set internalValue(value: DataOpentelekomcloudEnterpriseVpnConnectionV5IkepolicyDpd | undefined);
    get interval(): number;
    get msg(): string;
    get timeout(): number;
}
export declare class DataOpentelekomcloudEnterpriseVpnConnectionV5IkepolicyDpdList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudEnterpriseVpnConnectionV5IkepolicyDpdOutputReference;
}
export interface DataOpentelekomcloudEnterpriseVpnConnectionV5Ikepolicy {
}
export declare function dataOpentelekomcloudEnterpriseVpnConnectionV5IkepolicyToTerraform(struct?: DataOpentelekomcloudEnterpriseVpnConnectionV5Ikepolicy): any;
export declare function dataOpentelekomcloudEnterpriseVpnConnectionV5IkepolicyToHclTerraform(struct?: DataOpentelekomcloudEnterpriseVpnConnectionV5Ikepolicy): any;
export declare class DataOpentelekomcloudEnterpriseVpnConnectionV5IkepolicyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudEnterpriseVpnConnectionV5Ikepolicy | undefined;
    set internalValue(value: DataOpentelekomcloudEnterpriseVpnConnectionV5Ikepolicy | undefined);
    get authenticationAlgorithm(): string;
    get authenticationMethod(): string;
    get dhGroup(): string;
    private _dpd;
    get dpd(): DataOpentelekomcloudEnterpriseVpnConnectionV5IkepolicyDpdList;
    get encryptionAlgorithm(): string;
    get ikeVersion(): string;
    get lifetimeSeconds(): number;
    get localId(): string;
    get localIdType(): string;
    get peerId(): string;
    get peerIdType(): string;
    get phaseOneNegotiationMode(): string;
}
export declare class DataOpentelekomcloudEnterpriseVpnConnectionV5IkepolicyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudEnterpriseVpnConnectionV5IkepolicyOutputReference;
}
export interface DataOpentelekomcloudEnterpriseVpnConnectionV5Ipsecpolicy {
}
export declare function dataOpentelekomcloudEnterpriseVpnConnectionV5IpsecpolicyToTerraform(struct?: DataOpentelekomcloudEnterpriseVpnConnectionV5Ipsecpolicy): any;
export declare function dataOpentelekomcloudEnterpriseVpnConnectionV5IpsecpolicyToHclTerraform(struct?: DataOpentelekomcloudEnterpriseVpnConnectionV5Ipsecpolicy): any;
export declare class DataOpentelekomcloudEnterpriseVpnConnectionV5IpsecpolicyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudEnterpriseVpnConnectionV5Ipsecpolicy | undefined;
    set internalValue(value: DataOpentelekomcloudEnterpriseVpnConnectionV5Ipsecpolicy | undefined);
    get authenticationAlgorithm(): string;
    get encapsulationMode(): string;
    get encryptionAlgorithm(): string;
    get lifetimeSeconds(): number;
    get pfs(): string;
    get transformProtocol(): string;
}
export declare class DataOpentelekomcloudEnterpriseVpnConnectionV5IpsecpolicyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudEnterpriseVpnConnectionV5IpsecpolicyOutputReference;
}
export interface DataOpentelekomcloudEnterpriseVpnConnectionV5PolicyRules {
}
export declare function dataOpentelekomcloudEnterpriseVpnConnectionV5PolicyRulesToTerraform(struct?: DataOpentelekomcloudEnterpriseVpnConnectionV5PolicyRules): any;
export declare function dataOpentelekomcloudEnterpriseVpnConnectionV5PolicyRulesToHclTerraform(struct?: DataOpentelekomcloudEnterpriseVpnConnectionV5PolicyRules): any;
export declare class DataOpentelekomcloudEnterpriseVpnConnectionV5PolicyRulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudEnterpriseVpnConnectionV5PolicyRules | undefined;
    set internalValue(value: DataOpentelekomcloudEnterpriseVpnConnectionV5PolicyRules | undefined);
    get destination(): string[];
    get ruleIndex(): number;
    get source(): string;
}
export declare class DataOpentelekomcloudEnterpriseVpnConnectionV5PolicyRulesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudEnterpriseVpnConnectionV5PolicyRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/enterprise_vpn_connection_v5 opentelekomcloud_enterprise_vpn_connection_v5}
*/
export declare class DataOpentelekomcloudEnterpriseVpnConnectionV5 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_enterprise_vpn_connection_v5";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudEnterpriseVpnConnectionV5 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudEnterpriseVpnConnectionV5 to import
    * @param importFromId The id of the existing DataOpentelekomcloudEnterpriseVpnConnectionV5 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/enterprise_vpn_connection_v5#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudEnterpriseVpnConnectionV5 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/enterprise_vpn_connection_v5 opentelekomcloud_enterprise_vpn_connection_v5} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudEnterpriseVpnConnectionV5Config
    */
    constructor(scope: Construct, id: string, config: DataOpentelekomcloudEnterpriseVpnConnectionV5Config);
    get createdAt(): string;
    get customerGatewayId(): string;
    get enableNqa(): cdktf.IResolvable;
    get gatewayId(): string;
    get gatewayIp(): string;
    get haRole(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _ikepolicy;
    get ikepolicy(): DataOpentelekomcloudEnterpriseVpnConnectionV5IkepolicyList;
    private _ipsecpolicy;
    get ipsecpolicy(): DataOpentelekomcloudEnterpriseVpnConnectionV5IpsecpolicyList;
    get name(): string;
    get peerSubnets(): string[];
    private _policyRules;
    get policyRules(): DataOpentelekomcloudEnterpriseVpnConnectionV5PolicyRulesList;
    get region(): string;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get tunnelLocalAddress(): string;
    get tunnelPeerAddress(): string;
    get updatedAt(): string;
    get vpnType(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

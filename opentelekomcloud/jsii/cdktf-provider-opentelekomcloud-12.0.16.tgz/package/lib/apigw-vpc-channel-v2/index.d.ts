/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ApigwVpcChannelV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#gateway_id ApigwVpcChannelV2#gateway_id}
    */
    readonly gatewayId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#id ApigwVpcChannelV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#lb_algorithm ApigwVpcChannelV2#lb_algorithm}
    */
    readonly lbAlgorithm: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#member_type ApigwVpcChannelV2#member_type}
    */
    readonly memberType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#name ApigwVpcChannelV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#port ApigwVpcChannelV2#port}
    */
    readonly port: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#type ApigwVpcChannelV2#type}
    */
    readonly type?: number;
    /**
    * health_check block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#health_check ApigwVpcChannelV2#health_check}
    */
    readonly healthCheck?: ApigwVpcChannelV2HealthCheck;
    /**
    * member block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#member ApigwVpcChannelV2#member}
    */
    readonly member?: ApigwVpcChannelV2Member[] | cdktf.IResolvable;
    /**
    * member_group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#member_group ApigwVpcChannelV2#member_group}
    */
    readonly memberGroup?: ApigwVpcChannelV2MemberGroup[] | cdktf.IResolvable;
    /**
    * microservice block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#microservice ApigwVpcChannelV2#microservice}
    */
    readonly microservice?: ApigwVpcChannelV2Microservice;
}
export interface ApigwVpcChannelV2HealthCheck {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#enable_client_ssl ApigwVpcChannelV2#enable_client_ssl}
    */
    readonly enableClientSsl?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#http_codes ApigwVpcChannelV2#http_codes}
    */
    readonly httpCodes?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#interval ApigwVpcChannelV2#interval}
    */
    readonly interval: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#method ApigwVpcChannelV2#method}
    */
    readonly method?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#path ApigwVpcChannelV2#path}
    */
    readonly path?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#port ApigwVpcChannelV2#port}
    */
    readonly port?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#protocol ApigwVpcChannelV2#protocol}
    */
    readonly protocol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#status ApigwVpcChannelV2#status}
    */
    readonly status?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#threshold_abnormal ApigwVpcChannelV2#threshold_abnormal}
    */
    readonly thresholdAbnormal: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#threshold_normal ApigwVpcChannelV2#threshold_normal}
    */
    readonly thresholdNormal: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#timeout ApigwVpcChannelV2#timeout}
    */
    readonly timeout: number;
}
export declare function apigwVpcChannelV2HealthCheckToTerraform(struct?: ApigwVpcChannelV2HealthCheckOutputReference | ApigwVpcChannelV2HealthCheck): any;
export declare function apigwVpcChannelV2HealthCheckToHclTerraform(struct?: ApigwVpcChannelV2HealthCheckOutputReference | ApigwVpcChannelV2HealthCheck): any;
export declare class ApigwVpcChannelV2HealthCheckOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigwVpcChannelV2HealthCheck | undefined;
    set internalValue(value: ApigwVpcChannelV2HealthCheck | undefined);
    private _enableClientSsl?;
    get enableClientSsl(): boolean | cdktf.IResolvable;
    set enableClientSsl(value: boolean | cdktf.IResolvable);
    resetEnableClientSsl(): void;
    get enableClientSslInput(): boolean | cdktf.IResolvable | undefined;
    private _httpCodes?;
    get httpCodes(): string;
    set httpCodes(value: string);
    resetHttpCodes(): void;
    get httpCodesInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    get intervalInput(): number | undefined;
    private _method?;
    get method(): string;
    set method(value: string);
    resetMethod(): void;
    get methodInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    get protocolInput(): string | undefined;
    private _status?;
    get status(): number;
    set status(value: number);
    resetStatus(): void;
    get statusInput(): number | undefined;
    private _thresholdAbnormal?;
    get thresholdAbnormal(): number;
    set thresholdAbnormal(value: number);
    get thresholdAbnormalInput(): number | undefined;
    private _thresholdNormal?;
    get thresholdNormal(): number;
    set thresholdNormal(value: number);
    get thresholdNormalInput(): number | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    get timeoutInput(): number | undefined;
}
export interface ApigwVpcChannelV2Member {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#group_name ApigwVpcChannelV2#group_name}
    */
    readonly groupName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#host ApigwVpcChannelV2#host}
    */
    readonly host?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#id ApigwVpcChannelV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#is_backup ApigwVpcChannelV2#is_backup}
    */
    readonly isBackup?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#name ApigwVpcChannelV2#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#port ApigwVpcChannelV2#port}
    */
    readonly port?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#status ApigwVpcChannelV2#status}
    */
    readonly status?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#weight ApigwVpcChannelV2#weight}
    */
    readonly weight?: number;
}
export declare function apigwVpcChannelV2MemberToTerraform(struct?: ApigwVpcChannelV2Member | cdktf.IResolvable): any;
export declare function apigwVpcChannelV2MemberToHclTerraform(struct?: ApigwVpcChannelV2Member | cdktf.IResolvable): any;
export declare class ApigwVpcChannelV2MemberOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigwVpcChannelV2Member | cdktf.IResolvable | undefined;
    set internalValue(value: ApigwVpcChannelV2Member | cdktf.IResolvable | undefined);
    private _groupName?;
    get groupName(): string;
    set groupName(value: string);
    resetGroupName(): void;
    get groupNameInput(): string | undefined;
    private _host?;
    get host(): string;
    set host(value: string);
    resetHost(): void;
    get hostInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isBackup?;
    get isBackup(): boolean | cdktf.IResolvable;
    set isBackup(value: boolean | cdktf.IResolvable);
    resetIsBackup(): void;
    get isBackupInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _status?;
    get status(): number;
    set status(value: number);
    resetStatus(): void;
    get statusInput(): number | undefined;
    private _weight?;
    get weight(): number;
    set weight(value: number);
    resetWeight(): void;
    get weightInput(): number | undefined;
}
export declare class ApigwVpcChannelV2MemberList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ApigwVpcChannelV2Member[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigwVpcChannelV2MemberOutputReference;
}
export interface ApigwVpcChannelV2MemberGroup {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#description ApigwVpcChannelV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#microservice_port ApigwVpcChannelV2#microservice_port}
    */
    readonly microservicePort?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#microservice_tags ApigwVpcChannelV2#microservice_tags}
    */
    readonly microserviceTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#microservice_version ApigwVpcChannelV2#microservice_version}
    */
    readonly microserviceVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#name ApigwVpcChannelV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#weight ApigwVpcChannelV2#weight}
    */
    readonly weight?: number;
}
export declare function apigwVpcChannelV2MemberGroupToTerraform(struct?: ApigwVpcChannelV2MemberGroup | cdktf.IResolvable): any;
export declare function apigwVpcChannelV2MemberGroupToHclTerraform(struct?: ApigwVpcChannelV2MemberGroup | cdktf.IResolvable): any;
export declare class ApigwVpcChannelV2MemberGroupOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigwVpcChannelV2MemberGroup | cdktf.IResolvable | undefined;
    set internalValue(value: ApigwVpcChannelV2MemberGroup | cdktf.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _microservicePort?;
    get microservicePort(): number;
    set microservicePort(value: number);
    resetMicroservicePort(): void;
    get microservicePortInput(): number | undefined;
    private _microserviceTags?;
    get microserviceTags(): {
        [key: string]: string;
    };
    set microserviceTags(value: {
        [key: string]: string;
    });
    resetMicroserviceTags(): void;
    get microserviceTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _microserviceVersion?;
    get microserviceVersion(): string;
    set microserviceVersion(value: string);
    resetMicroserviceVersion(): void;
    get microserviceVersionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _weight?;
    get weight(): number;
    set weight(value: number);
    resetWeight(): void;
    get weightInput(): number | undefined;
}
export declare class ApigwVpcChannelV2MemberGroupList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ApigwVpcChannelV2MemberGroup[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigwVpcChannelV2MemberGroupOutputReference;
}
export interface ApigwVpcChannelV2MicroserviceCceConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#cluster_id ApigwVpcChannelV2#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#label_key ApigwVpcChannelV2#label_key}
    */
    readonly labelKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#label_value ApigwVpcChannelV2#label_value}
    */
    readonly labelValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#namespace ApigwVpcChannelV2#namespace}
    */
    readonly namespace: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#workload_name ApigwVpcChannelV2#workload_name}
    */
    readonly workloadName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#workload_type ApigwVpcChannelV2#workload_type}
    */
    readonly workloadType: string;
}
export declare function apigwVpcChannelV2MicroserviceCceConfigToTerraform(struct?: ApigwVpcChannelV2MicroserviceCceConfigOutputReference | ApigwVpcChannelV2MicroserviceCceConfig): any;
export declare function apigwVpcChannelV2MicroserviceCceConfigToHclTerraform(struct?: ApigwVpcChannelV2MicroserviceCceConfigOutputReference | ApigwVpcChannelV2MicroserviceCceConfig): any;
export declare class ApigwVpcChannelV2MicroserviceCceConfigOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigwVpcChannelV2MicroserviceCceConfig | undefined;
    set internalValue(value: ApigwVpcChannelV2MicroserviceCceConfig | undefined);
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _labelKey?;
    get labelKey(): string;
    set labelKey(value: string);
    resetLabelKey(): void;
    get labelKeyInput(): string | undefined;
    private _labelValue?;
    get labelValue(): string;
    set labelValue(value: string);
    resetLabelValue(): void;
    get labelValueInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    get namespaceInput(): string | undefined;
    private _workloadName?;
    get workloadName(): string;
    set workloadName(value: string);
    resetWorkloadName(): void;
    get workloadNameInput(): string | undefined;
    private _workloadType?;
    get workloadType(): string;
    set workloadType(value: string);
    get workloadTypeInput(): string | undefined;
}
export interface ApigwVpcChannelV2MicroserviceCseConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#engine_id ApigwVpcChannelV2#engine_id}
    */
    readonly engineId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#service_id ApigwVpcChannelV2#service_id}
    */
    readonly serviceId: string;
}
export declare function apigwVpcChannelV2MicroserviceCseConfigToTerraform(struct?: ApigwVpcChannelV2MicroserviceCseConfigOutputReference | ApigwVpcChannelV2MicroserviceCseConfig): any;
export declare function apigwVpcChannelV2MicroserviceCseConfigToHclTerraform(struct?: ApigwVpcChannelV2MicroserviceCseConfigOutputReference | ApigwVpcChannelV2MicroserviceCseConfig): any;
export declare class ApigwVpcChannelV2MicroserviceCseConfigOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigwVpcChannelV2MicroserviceCseConfig | undefined;
    set internalValue(value: ApigwVpcChannelV2MicroserviceCseConfig | undefined);
    private _engineId?;
    get engineId(): string;
    set engineId(value: string);
    get engineIdInput(): string | undefined;
    private _serviceId?;
    get serviceId(): string;
    set serviceId(value: string);
    get serviceIdInput(): string | undefined;
}
export interface ApigwVpcChannelV2Microservice {
    /**
    * cce_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#cce_config ApigwVpcChannelV2#cce_config}
    */
    readonly cceConfig?: ApigwVpcChannelV2MicroserviceCceConfig;
    /**
    * cse_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#cse_config ApigwVpcChannelV2#cse_config}
    */
    readonly cseConfig?: ApigwVpcChannelV2MicroserviceCseConfig;
}
export declare function apigwVpcChannelV2MicroserviceToTerraform(struct?: ApigwVpcChannelV2MicroserviceOutputReference | ApigwVpcChannelV2Microservice): any;
export declare function apigwVpcChannelV2MicroserviceToHclTerraform(struct?: ApigwVpcChannelV2MicroserviceOutputReference | ApigwVpcChannelV2Microservice): any;
export declare class ApigwVpcChannelV2MicroserviceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigwVpcChannelV2Microservice | undefined;
    set internalValue(value: ApigwVpcChannelV2Microservice | undefined);
    private _cceConfig;
    get cceConfig(): ApigwVpcChannelV2MicroserviceCceConfigOutputReference;
    putCceConfig(value: ApigwVpcChannelV2MicroserviceCceConfig): void;
    resetCceConfig(): void;
    get cceConfigInput(): ApigwVpcChannelV2MicroserviceCceConfig | undefined;
    private _cseConfig;
    get cseConfig(): ApigwVpcChannelV2MicroserviceCseConfigOutputReference;
    putCseConfig(value: ApigwVpcChannelV2MicroserviceCseConfig): void;
    resetCseConfig(): void;
    get cseConfigInput(): ApigwVpcChannelV2MicroserviceCseConfig | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2 opentelekomcloud_apigw_vpc_channel_v2}
*/
export declare class ApigwVpcChannelV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_apigw_vpc_channel_v2";
    /**
    * Generates CDKTF code for importing a ApigwVpcChannelV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigwVpcChannelV2 to import
    * @param importFromId The id of the existing ApigwVpcChannelV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigwVpcChannelV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_vpc_channel_v2 opentelekomcloud_apigw_vpc_channel_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigwVpcChannelV2Config
    */
    constructor(scope: Construct, id: string, config: ApigwVpcChannelV2Config);
    get createdAt(): string;
    private _gatewayId?;
    get gatewayId(): string;
    set gatewayId(value: string);
    get gatewayIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _lbAlgorithm?;
    get lbAlgorithm(): number;
    set lbAlgorithm(value: number);
    get lbAlgorithmInput(): number | undefined;
    private _memberType?;
    get memberType(): string;
    set memberType(value: string);
    resetMemberType(): void;
    get memberTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
    get region(): string;
    get status(): number;
    private _type?;
    get type(): number;
    set type(value: number);
    resetType(): void;
    get typeInput(): number | undefined;
    private _healthCheck;
    get healthCheck(): ApigwVpcChannelV2HealthCheckOutputReference;
    putHealthCheck(value: ApigwVpcChannelV2HealthCheck): void;
    resetHealthCheck(): void;
    get healthCheckInput(): ApigwVpcChannelV2HealthCheck | undefined;
    private _member;
    get member(): ApigwVpcChannelV2MemberList;
    putMember(value: ApigwVpcChannelV2Member[] | cdktf.IResolvable): void;
    resetMember(): void;
    get memberInput(): cdktf.IResolvable | ApigwVpcChannelV2Member[] | undefined;
    private _memberGroup;
    get memberGroup(): ApigwVpcChannelV2MemberGroupList;
    putMemberGroup(value: ApigwVpcChannelV2MemberGroup[] | cdktf.IResolvable): void;
    resetMemberGroup(): void;
    get memberGroupInput(): cdktf.IResolvable | ApigwVpcChannelV2MemberGroup[] | undefined;
    private _microservice;
    get microservice(): ApigwVpcChannelV2MicroserviceOutputReference;
    putMicroservice(value: ApigwVpcChannelV2Microservice): void;
    resetMicroservice(): void;
    get microserviceInput(): ApigwVpcChannelV2Microservice | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DisAppV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_app_v2#name DisAppV2#name}
    */
    readonly name: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_app_v2#timeouts DisAppV2#timeouts}
    */
    readonly timeouts?: DisAppV2Timeouts;
}
export interface DisAppV2PartitionConsumingStates {
}
export declare function disAppV2PartitionConsumingStatesToTerraform(struct?: DisAppV2PartitionConsumingStates): any;
export declare function disAppV2PartitionConsumingStatesToHclTerraform(struct?: DisAppV2PartitionConsumingStates): any;
export declare class DisAppV2PartitionConsumingStatesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DisAppV2PartitionConsumingStates | undefined;
    set internalValue(value: DisAppV2PartitionConsumingStates | undefined);
    get checkpointType(): string;
    get earliestOffset(): number;
    get id(): string;
    get latestOffset(): number;
    get sequenceNumber(): string;
    get status(): string;
}
export declare class DisAppV2PartitionConsumingStatesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DisAppV2PartitionConsumingStatesOutputReference;
}
export interface DisAppV2Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_app_v2#update DisAppV2#update}
    */
    readonly update?: string;
}
export declare function disAppV2TimeoutsToTerraform(struct?: DisAppV2Timeouts | cdktf.IResolvable): any;
export declare function disAppV2TimeoutsToHclTerraform(struct?: DisAppV2Timeouts | cdktf.IResolvable): any;
export declare class DisAppV2TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DisAppV2Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DisAppV2Timeouts | cdktf.IResolvable | undefined);
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_app_v2 opentelekomcloud_dis_app_v2}
*/
export declare class DisAppV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_dis_app_v2";
    /**
    * Generates CDKTF code for importing a DisAppV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DisAppV2 to import
    * @param importFromId The id of the existing DisAppV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_app_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DisAppV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_app_v2 opentelekomcloud_dis_app_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DisAppV2Config
    */
    constructor(scope: Construct, id: string, config: DisAppV2Config);
    get commitCheckpointStreamNames(): string[];
    get created(): number;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _partitionConsumingStates;
    get partitionConsumingStates(): DisAppV2PartitionConsumingStatesList;
    private _timeouts;
    get timeouts(): DisAppV2TimeoutsOutputReference;
    putTimeouts(value: DisAppV2Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DisAppV2Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CssConfigurationV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Whether to auto-create index.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_configuration_v1#auto_create_index CssConfigurationV1#auto_create_index}
    */
    readonly autoCreateIndex?: string;
    /**
    * The CSS cluster ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_configuration_v1#cluster_id CssConfigurationV1#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Whether to return the Access-Control-Allow-Credentials of the header during cross-domain access.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_configuration_v1#http_cors_allow_credentials CssConfigurationV1#http_cors_allow_credentials}
    */
    readonly httpCorsAllowCredentials?: string;
    /**
    * Headers allowed for cross-domain access.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_configuration_v1#http_cors_allow_headers CssConfigurationV1#http_cors_allow_headers}
    */
    readonly httpCorsAllowHeaders?: string;
    /**
    * Methods allowed for cross-domain access.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_configuration_v1#http_cors_allow_methods CssConfigurationV1#http_cors_allow_methods}
    */
    readonly httpCorsAllowMethods?: string;
    /**
    * Origin IP address allowed for cross-domain access, for example, **122.122.122.122:9200**.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_configuration_v1#http_cors_allow_origin CssConfigurationV1#http_cors_allow_origin}
    */
    readonly httpCorsAllowOrigin?: string;
    /**
    * Whether to allow cross-domain access.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_configuration_v1#http_cors_enabled CssConfigurationV1#http_cors_enabled}
    */
    readonly httpCorsEnabled?: string;
    /**
    * Cache duration of the browser. The cache is automatically cleared after the time range you specify.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_configuration_v1#http_cors_max_age CssConfigurationV1#http_cors_max_age}
    */
    readonly httpCorsMaxAge?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_configuration_v1#id CssConfigurationV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Cache size in the query phase. Value range: **1** to **100**.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_configuration_v1#indices_queries_cache_size CssConfigurationV1#indices_queries_cache_size}
    */
    readonly indicesQueriesCacheSize?: string;
    /**
    * Configured for migrating data from the current cluster to the target cluster through the reindex API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_configuration_v1#reindex_remote_whitelist CssConfigurationV1#reindex_remote_whitelist}
    */
    readonly reindexRemoteWhitelist?: string;
    /**
    * Queue size in the force merge thread pool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_configuration_v1#thread_pool_force_merge_size CssConfigurationV1#thread_pool_force_merge_size}
    */
    readonly threadPoolForceMergeSize?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_configuration_v1#timeouts CssConfigurationV1#timeouts}
    */
    readonly timeouts?: CssConfigurationV1Timeouts;
}
export interface CssConfigurationV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_configuration_v1#create CssConfigurationV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_configuration_v1#delete CssConfigurationV1#delete}
    */
    readonly delete?: string;
}
export declare function cssConfigurationV1TimeoutsToTerraform(struct?: CssConfigurationV1Timeouts | cdktf.IResolvable): any;
export declare function cssConfigurationV1TimeoutsToHclTerraform(struct?: CssConfigurationV1Timeouts | cdktf.IResolvable): any;
export declare class CssConfigurationV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CssConfigurationV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: CssConfigurationV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_configuration_v1 opentelekomcloud_css_configuration_v1}
*/
export declare class CssConfigurationV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_css_configuration_v1";
    /**
    * Generates CDKTF code for importing a CssConfigurationV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CssConfigurationV1 to import
    * @param importFromId The id of the existing CssConfigurationV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_configuration_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CssConfigurationV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_configuration_v1 opentelekomcloud_css_configuration_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CssConfigurationV1Config
    */
    constructor(scope: Construct, id: string, config: CssConfigurationV1Config);
    private _autoCreateIndex?;
    get autoCreateIndex(): string;
    set autoCreateIndex(value: string);
    resetAutoCreateIndex(): void;
    get autoCreateIndexInput(): string | undefined;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _httpCorsAllowCredentials?;
    get httpCorsAllowCredentials(): string;
    set httpCorsAllowCredentials(value: string);
    resetHttpCorsAllowCredentials(): void;
    get httpCorsAllowCredentialsInput(): string | undefined;
    private _httpCorsAllowHeaders?;
    get httpCorsAllowHeaders(): string;
    set httpCorsAllowHeaders(value: string);
    resetHttpCorsAllowHeaders(): void;
    get httpCorsAllowHeadersInput(): string | undefined;
    private _httpCorsAllowMethods?;
    get httpCorsAllowMethods(): string;
    set httpCorsAllowMethods(value: string);
    resetHttpCorsAllowMethods(): void;
    get httpCorsAllowMethodsInput(): string | undefined;
    private _httpCorsAllowOrigin?;
    get httpCorsAllowOrigin(): string;
    set httpCorsAllowOrigin(value: string);
    resetHttpCorsAllowOrigin(): void;
    get httpCorsAllowOriginInput(): string | undefined;
    private _httpCorsEnabled?;
    get httpCorsEnabled(): string;
    set httpCorsEnabled(value: string);
    resetHttpCorsEnabled(): void;
    get httpCorsEnabledInput(): string | undefined;
    private _httpCorsMaxAge?;
    get httpCorsMaxAge(): string;
    set httpCorsMaxAge(value: string);
    resetHttpCorsMaxAge(): void;
    get httpCorsMaxAgeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _indicesQueriesCacheSize?;
    get indicesQueriesCacheSize(): string;
    set indicesQueriesCacheSize(value: string);
    resetIndicesQueriesCacheSize(): void;
    get indicesQueriesCacheSizeInput(): string | undefined;
    get region(): string;
    private _reindexRemoteWhitelist?;
    get reindexRemoteWhitelist(): string;
    set reindexRemoteWhitelist(value: string);
    resetReindexRemoteWhitelist(): void;
    get reindexRemoteWhitelistInput(): string | undefined;
    private _threadPoolForceMergeSize?;
    get threadPoolForceMergeSize(): string;
    set threadPoolForceMergeSize(value: string);
    resetThreadPoolForceMergeSize(): void;
    get threadPoolForceMergeSizeInput(): string | undefined;
    private _timeouts;
    get timeouts(): CssConfigurationV1TimeoutsOutputReference;
    putTimeouts(value: CssConfigurationV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | CssConfigurationV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudDehHostV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/deh_host_v1#availability_zone DataOpentelekomcloudDehHostV1#availability_zone}
    */
    readonly availabilityZone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/deh_host_v1#id DataOpentelekomcloudDehHostV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/deh_host_v1#name DataOpentelekomcloudDehHostV1#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/deh_host_v1#region DataOpentelekomcloudDehHostV1#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/deh_host_v1#status DataOpentelekomcloudDehHostV1#status}
    */
    readonly status?: string;
}
export interface DataOpentelekomcloudDehHostV1AvailableInstanceCapacities {
}
export declare function dataOpentelekomcloudDehHostV1AvailableInstanceCapacitiesToTerraform(struct?: DataOpentelekomcloudDehHostV1AvailableInstanceCapacities): any;
export declare function dataOpentelekomcloudDehHostV1AvailableInstanceCapacitiesToHclTerraform(struct?: DataOpentelekomcloudDehHostV1AvailableInstanceCapacities): any;
export declare class DataOpentelekomcloudDehHostV1AvailableInstanceCapacitiesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudDehHostV1AvailableInstanceCapacities | undefined;
    set internalValue(value: DataOpentelekomcloudDehHostV1AvailableInstanceCapacities | undefined);
    get flavor(): string;
}
export declare class DataOpentelekomcloudDehHostV1AvailableInstanceCapacitiesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudDehHostV1AvailableInstanceCapacitiesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/deh_host_v1 opentelekomcloud_deh_host_v1}
*/
export declare class DataOpentelekomcloudDehHostV1 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_deh_host_v1";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudDehHostV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudDehHostV1 to import
    * @param importFromId The id of the existing DataOpentelekomcloudDehHostV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/deh_host_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudDehHostV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/deh_host_v1 opentelekomcloud_deh_host_v1} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudDehHostV1Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudDehHostV1Config);
    get autoPlacement(): string;
    private _availabilityZone?;
    get availabilityZone(): string;
    set availabilityZone(value: string);
    resetAvailabilityZone(): void;
    get availabilityZoneInput(): string | undefined;
    private _availableInstanceCapacities;
    get availableInstanceCapacities(): DataOpentelekomcloudDehHostV1AvailableInstanceCapacitiesList;
    get availableMemory(): number;
    get availableVcpus(): number;
    get cores(): number;
    get hostType(): string;
    get hostTypeName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get instanceTotal(): number;
    get instanceUuids(): string[];
    get memory(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get sockets(): number;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    get tenantId(): string;
    get vcpus(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

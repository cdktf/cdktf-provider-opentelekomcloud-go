/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface SdrsReplicationPairV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/sdrs_replication_pair_v1#delete_target_volume SdrsReplicationPairV1#delete_target_volume}
    */
    readonly deleteTargetVolume?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/sdrs_replication_pair_v1#description SdrsReplicationPairV1#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/sdrs_replication_pair_v1#group_id SdrsReplicationPairV1#group_id}
    */
    readonly groupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/sdrs_replication_pair_v1#id SdrsReplicationPairV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/sdrs_replication_pair_v1#name SdrsReplicationPairV1#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/sdrs_replication_pair_v1#volume_id SdrsReplicationPairV1#volume_id}
    */
    readonly volumeId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/sdrs_replication_pair_v1#timeouts SdrsReplicationPairV1#timeouts}
    */
    readonly timeouts?: SdrsReplicationPairV1Timeouts;
}
export interface SdrsReplicationPairV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/sdrs_replication_pair_v1#create SdrsReplicationPairV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/sdrs_replication_pair_v1#delete SdrsReplicationPairV1#delete}
    */
    readonly delete?: string;
}
export declare function sdrsReplicationPairV1TimeoutsToTerraform(struct?: SdrsReplicationPairV1Timeouts | cdktf.IResolvable): any;
export declare function sdrsReplicationPairV1TimeoutsToHclTerraform(struct?: SdrsReplicationPairV1Timeouts | cdktf.IResolvable): any;
export declare class SdrsReplicationPairV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SdrsReplicationPairV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: SdrsReplicationPairV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/sdrs_replication_pair_v1 opentelekomcloud_sdrs_replication_pair_v1}
*/
export declare class SdrsReplicationPairV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_sdrs_replication_pair_v1";
    /**
    * Generates CDKTF code for importing a SdrsReplicationPairV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SdrsReplicationPairV1 to import
    * @param importFromId The id of the existing SdrsReplicationPairV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/sdrs_replication_pair_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SdrsReplicationPairV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/sdrs_replication_pair_v1 opentelekomcloud_sdrs_replication_pair_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SdrsReplicationPairV1Config
    */
    constructor(scope: Construct, id: string, config: SdrsReplicationPairV1Config);
    private _deleteTargetVolume?;
    get deleteTargetVolume(): boolean | cdktf.IResolvable;
    set deleteTargetVolume(value: boolean | cdktf.IResolvable);
    resetDeleteTargetVolume(): void;
    get deleteTargetVolumeInput(): boolean | cdktf.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get faultLevel(): string;
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    get groupIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get region(): string;
    get replicationModel(): string;
    get status(): string;
    get targetVolumeId(): string;
    private _volumeId?;
    get volumeId(): string;
    set volumeId(value: string);
    get volumeIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): SdrsReplicationPairV1TimeoutsOutputReference;
    putTimeouts(value: SdrsReplicationPairV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | SdrsReplicationPairV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

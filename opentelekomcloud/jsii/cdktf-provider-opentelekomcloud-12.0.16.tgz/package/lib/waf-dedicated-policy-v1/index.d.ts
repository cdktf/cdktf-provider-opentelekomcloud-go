/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface WafDedicatedPolicyV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#deep_inspection WafDedicatedPolicyV1#deep_inspection}
    */
    readonly deepInspection?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#full_detection WafDedicatedPolicyV1#full_detection}
    */
    readonly fullDetection?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#header_inspection WafDedicatedPolicyV1#header_inspection}
    */
    readonly headerInspection?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#id WafDedicatedPolicyV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#level WafDedicatedPolicyV1#level}
    */
    readonly level?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#name WafDedicatedPolicyV1#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#protection_mode WafDedicatedPolicyV1#protection_mode}
    */
    readonly protectionMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#region WafDedicatedPolicyV1#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#shiro_decryption_check WafDedicatedPolicyV1#shiro_decryption_check}
    */
    readonly shiroDecryptionCheck?: boolean | cdktf.IResolvable;
    /**
    * options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#options WafDedicatedPolicyV1#options}
    */
    readonly options?: WafDedicatedPolicyV1Options[] | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#timeouts WafDedicatedPolicyV1#timeouts}
    */
    readonly timeouts?: WafDedicatedPolicyV1Timeouts;
}
export interface WafDedicatedPolicyV1Options {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#anti_crawler WafDedicatedPolicyV1#anti_crawler}
    */
    readonly antiCrawler?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#anti_leakage WafDedicatedPolicyV1#anti_leakage}
    */
    readonly antiLeakage?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#anti_tamper WafDedicatedPolicyV1#anti_tamper}
    */
    readonly antiTamper?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#blacklist WafDedicatedPolicyV1#blacklist}
    */
    readonly blacklist?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#cc WafDedicatedPolicyV1#cc}
    */
    readonly cc?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#common WafDedicatedPolicyV1#common}
    */
    readonly common?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#crawler WafDedicatedPolicyV1#crawler}
    */
    readonly crawler?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#crawler_engine WafDedicatedPolicyV1#crawler_engine}
    */
    readonly crawlerEngine?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#crawler_other WafDedicatedPolicyV1#crawler_other}
    */
    readonly crawlerOther?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#crawler_scanner WafDedicatedPolicyV1#crawler_scanner}
    */
    readonly crawlerScanner?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#crawler_script WafDedicatedPolicyV1#crawler_script}
    */
    readonly crawlerScript?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#custom WafDedicatedPolicyV1#custom}
    */
    readonly custom?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#followed_action WafDedicatedPolicyV1#followed_action}
    */
    readonly followedAction?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#geolocation_access_control WafDedicatedPolicyV1#geolocation_access_control}
    */
    readonly geolocationAccessControl?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#ignore WafDedicatedPolicyV1#ignore}
    */
    readonly ignore?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#privacy WafDedicatedPolicyV1#privacy}
    */
    readonly privacy?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#web_attack WafDedicatedPolicyV1#web_attack}
    */
    readonly webAttack?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#web_shell WafDedicatedPolicyV1#web_shell}
    */
    readonly webShell?: boolean | cdktf.IResolvable;
}
export declare function wafDedicatedPolicyV1OptionsToTerraform(struct?: WafDedicatedPolicyV1Options | cdktf.IResolvable): any;
export declare function wafDedicatedPolicyV1OptionsToHclTerraform(struct?: WafDedicatedPolicyV1Options | cdktf.IResolvable): any;
export declare class WafDedicatedPolicyV1OptionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WafDedicatedPolicyV1Options | cdktf.IResolvable | undefined;
    set internalValue(value: WafDedicatedPolicyV1Options | cdktf.IResolvable | undefined);
    private _antiCrawler?;
    get antiCrawler(): boolean | cdktf.IResolvable;
    set antiCrawler(value: boolean | cdktf.IResolvable);
    resetAntiCrawler(): void;
    get antiCrawlerInput(): boolean | cdktf.IResolvable | undefined;
    private _antiLeakage?;
    get antiLeakage(): boolean | cdktf.IResolvable;
    set antiLeakage(value: boolean | cdktf.IResolvable);
    resetAntiLeakage(): void;
    get antiLeakageInput(): boolean | cdktf.IResolvable | undefined;
    private _antiTamper?;
    get antiTamper(): boolean | cdktf.IResolvable;
    set antiTamper(value: boolean | cdktf.IResolvable);
    resetAntiTamper(): void;
    get antiTamperInput(): boolean | cdktf.IResolvable | undefined;
    private _blacklist?;
    get blacklist(): boolean | cdktf.IResolvable;
    set blacklist(value: boolean | cdktf.IResolvable);
    resetBlacklist(): void;
    get blacklistInput(): boolean | cdktf.IResolvable | undefined;
    get botEnable(): cdktf.IResolvable;
    private _cc?;
    get cc(): boolean | cdktf.IResolvable;
    set cc(value: boolean | cdktf.IResolvable);
    resetCc(): void;
    get ccInput(): boolean | cdktf.IResolvable | undefined;
    private _common?;
    get common(): boolean | cdktf.IResolvable;
    set common(value: boolean | cdktf.IResolvable);
    resetCommon(): void;
    get commonInput(): boolean | cdktf.IResolvable | undefined;
    private _crawler?;
    get crawler(): boolean | cdktf.IResolvable;
    set crawler(value: boolean | cdktf.IResolvable);
    resetCrawler(): void;
    get crawlerInput(): boolean | cdktf.IResolvable | undefined;
    private _crawlerEngine?;
    get crawlerEngine(): boolean | cdktf.IResolvable;
    set crawlerEngine(value: boolean | cdktf.IResolvable);
    resetCrawlerEngine(): void;
    get crawlerEngineInput(): boolean | cdktf.IResolvable | undefined;
    private _crawlerOther?;
    get crawlerOther(): boolean | cdktf.IResolvable;
    set crawlerOther(value: boolean | cdktf.IResolvable);
    resetCrawlerOther(): void;
    get crawlerOtherInput(): boolean | cdktf.IResolvable | undefined;
    private _crawlerScanner?;
    get crawlerScanner(): boolean | cdktf.IResolvable;
    set crawlerScanner(value: boolean | cdktf.IResolvable);
    resetCrawlerScanner(): void;
    get crawlerScannerInput(): boolean | cdktf.IResolvable | undefined;
    private _crawlerScript?;
    get crawlerScript(): boolean | cdktf.IResolvable;
    set crawlerScript(value: boolean | cdktf.IResolvable);
    resetCrawlerScript(): void;
    get crawlerScriptInput(): boolean | cdktf.IResolvable | undefined;
    private _custom?;
    get custom(): boolean | cdktf.IResolvable;
    set custom(value: boolean | cdktf.IResolvable);
    resetCustom(): void;
    get customInput(): boolean | cdktf.IResolvable | undefined;
    private _followedAction?;
    get followedAction(): boolean | cdktf.IResolvable;
    set followedAction(value: boolean | cdktf.IResolvable);
    resetFollowedAction(): void;
    get followedActionInput(): boolean | cdktf.IResolvable | undefined;
    private _geolocationAccessControl?;
    get geolocationAccessControl(): boolean | cdktf.IResolvable;
    set geolocationAccessControl(value: boolean | cdktf.IResolvable);
    resetGeolocationAccessControl(): void;
    get geolocationAccessControlInput(): boolean | cdktf.IResolvable | undefined;
    private _ignore?;
    get ignore(): boolean | cdktf.IResolvable;
    set ignore(value: boolean | cdktf.IResolvable);
    resetIgnore(): void;
    get ignoreInput(): boolean | cdktf.IResolvable | undefined;
    get precise(): cdktf.IResolvable;
    private _privacy?;
    get privacy(): boolean | cdktf.IResolvable;
    set privacy(value: boolean | cdktf.IResolvable);
    resetPrivacy(): void;
    get privacyInput(): boolean | cdktf.IResolvable | undefined;
    private _webAttack?;
    get webAttack(): boolean | cdktf.IResolvable;
    set webAttack(value: boolean | cdktf.IResolvable);
    resetWebAttack(): void;
    get webAttackInput(): boolean | cdktf.IResolvable | undefined;
    private _webShell?;
    get webShell(): boolean | cdktf.IResolvable;
    set webShell(value: boolean | cdktf.IResolvable);
    resetWebShell(): void;
    get webShellInput(): boolean | cdktf.IResolvable | undefined;
}
export declare class WafDedicatedPolicyV1OptionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WafDedicatedPolicyV1Options[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WafDedicatedPolicyV1OptionsOutputReference;
}
export interface WafDedicatedPolicyV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#create WafDedicatedPolicyV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#delete WafDedicatedPolicyV1#delete}
    */
    readonly delete?: string;
}
export declare function wafDedicatedPolicyV1TimeoutsToTerraform(struct?: WafDedicatedPolicyV1Timeouts | cdktf.IResolvable): any;
export declare function wafDedicatedPolicyV1TimeoutsToHclTerraform(struct?: WafDedicatedPolicyV1Timeouts | cdktf.IResolvable): any;
export declare class WafDedicatedPolicyV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WafDedicatedPolicyV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: WafDedicatedPolicyV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1 opentelekomcloud_waf_dedicated_policy_v1}
*/
export declare class WafDedicatedPolicyV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_waf_dedicated_policy_v1";
    /**
    * Generates CDKTF code for importing a WafDedicatedPolicyV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WafDedicatedPolicyV1 to import
    * @param importFromId The id of the existing WafDedicatedPolicyV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WafDedicatedPolicyV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_policy_v1 opentelekomcloud_waf_dedicated_policy_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WafDedicatedPolicyV1Config
    */
    constructor(scope: Construct, id: string, config: WafDedicatedPolicyV1Config);
    get createdAt(): number;
    private _deepInspection?;
    get deepInspection(): boolean | cdktf.IResolvable;
    set deepInspection(value: boolean | cdktf.IResolvable);
    resetDeepInspection(): void;
    get deepInspectionInput(): boolean | cdktf.IResolvable | undefined;
    get domains(): string[];
    private _fullDetection?;
    get fullDetection(): boolean | cdktf.IResolvable;
    set fullDetection(value: boolean | cdktf.IResolvable);
    resetFullDetection(): void;
    get fullDetectionInput(): boolean | cdktf.IResolvable | undefined;
    private _headerInspection?;
    get headerInspection(): boolean | cdktf.IResolvable;
    set headerInspection(value: boolean | cdktf.IResolvable);
    resetHeaderInspection(): void;
    get headerInspectionInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _level?;
    get level(): number;
    set level(value: number);
    resetLevel(): void;
    get levelInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _protectionMode?;
    get protectionMode(): string;
    set protectionMode(value: string);
    resetProtectionMode(): void;
    get protectionModeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _shiroDecryptionCheck?;
    get shiroDecryptionCheck(): boolean | cdktf.IResolvable;
    set shiroDecryptionCheck(value: boolean | cdktf.IResolvable);
    resetShiroDecryptionCheck(): void;
    get shiroDecryptionCheckInput(): boolean | cdktf.IResolvable | undefined;
    private _options;
    get options(): WafDedicatedPolicyV1OptionsList;
    putOptions(value: WafDedicatedPolicyV1Options[] | cdktf.IResolvable): void;
    resetOptions(): void;
    get optionsInput(): cdktf.IResolvable | WafDedicatedPolicyV1Options[] | undefined;
    private _timeouts;
    get timeouts(): WafDedicatedPolicyV1TimeoutsOutputReference;
    putTimeouts(value: WafDedicatedPolicyV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | WafDedicatedPolicyV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

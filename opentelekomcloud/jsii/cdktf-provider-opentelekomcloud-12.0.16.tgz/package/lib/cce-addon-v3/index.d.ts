/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CceAddonV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_addon_v3#cluster_id CceAddonV3#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_addon_v3#id CceAddonV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_addon_v3#template_name CceAddonV3#template_name}
    */
    readonly templateName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_addon_v3#template_version CceAddonV3#template_version}
    */
    readonly templateVersion: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_addon_v3#timeouts CceAddonV3#timeouts}
    */
    readonly timeouts?: CceAddonV3Timeouts;
    /**
    * values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_addon_v3#values CceAddonV3#values}
    */
    readonly values: CceAddonV3Values;
}
export interface CceAddonV3Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_addon_v3#create CceAddonV3#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_addon_v3#delete CceAddonV3#delete}
    */
    readonly delete?: string;
}
export declare function cceAddonV3TimeoutsToTerraform(struct?: CceAddonV3Timeouts | cdktf.IResolvable): any;
export declare function cceAddonV3TimeoutsToHclTerraform(struct?: CceAddonV3Timeouts | cdktf.IResolvable): any;
export declare class CceAddonV3TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CceAddonV3Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: CceAddonV3Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
export interface CceAddonV3Values {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_addon_v3#basic CceAddonV3#basic}
    */
    readonly basic?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_addon_v3#basic_json CceAddonV3#basic_json}
    */
    readonly basicJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_addon_v3#custom CceAddonV3#custom}
    */
    readonly custom?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_addon_v3#custom_json CceAddonV3#custom_json}
    */
    readonly customJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_addon_v3#flavor CceAddonV3#flavor}
    */
    readonly flavor?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_addon_v3#flavor_json CceAddonV3#flavor_json}
    */
    readonly flavorJson?: string;
}
export declare function cceAddonV3ValuesToTerraform(struct?: CceAddonV3ValuesOutputReference | CceAddonV3Values): any;
export declare function cceAddonV3ValuesToHclTerraform(struct?: CceAddonV3ValuesOutputReference | CceAddonV3Values): any;
export declare class CceAddonV3ValuesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CceAddonV3Values | undefined;
    set internalValue(value: CceAddonV3Values | undefined);
    private _basic?;
    get basic(): {
        [key: string]: string;
    };
    set basic(value: {
        [key: string]: string;
    });
    resetBasic(): void;
    get basicInput(): {
        [key: string]: string;
    } | undefined;
    private _basicJson?;
    get basicJson(): string;
    set basicJson(value: string);
    resetBasicJson(): void;
    get basicJsonInput(): string | undefined;
    private _custom?;
    get custom(): {
        [key: string]: string;
    };
    set custom(value: {
        [key: string]: string;
    });
    resetCustom(): void;
    get customInput(): {
        [key: string]: string;
    } | undefined;
    private _customJson?;
    get customJson(): string;
    set customJson(value: string);
    resetCustomJson(): void;
    get customJsonInput(): string | undefined;
    private _flavor?;
    get flavor(): string;
    set flavor(value: string);
    resetFlavor(): void;
    get flavorInput(): string | undefined;
    private _flavorJson?;
    get flavorJson(): string;
    set flavorJson(value: string);
    resetFlavorJson(): void;
    get flavorJsonInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_addon_v3 opentelekomcloud_cce_addon_v3}
*/
export declare class CceAddonV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_cce_addon_v3";
    /**
    * Generates CDKTF code for importing a CceAddonV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CceAddonV3 to import
    * @param importFromId The id of the existing CceAddonV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_addon_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CceAddonV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cce_addon_v3 opentelekomcloud_cce_addon_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CceAddonV3Config
    */
    constructor(scope: Construct, id: string, config: CceAddonV3Config);
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    private _templateName?;
    get templateName(): string;
    set templateName(value: string);
    get templateNameInput(): string | undefined;
    private _templateVersion?;
    get templateVersion(): string;
    set templateVersion(value: string);
    get templateVersionInput(): string | undefined;
    private _timeouts;
    get timeouts(): CceAddonV3TimeoutsOutputReference;
    putTimeouts(value: CceAddonV3Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | CceAddonV3Timeouts | undefined;
    private _values;
    get values(): CceAddonV3ValuesOutputReference;
    putValues(value: CceAddonV3Values): void;
    get valuesInput(): CceAddonV3Values | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

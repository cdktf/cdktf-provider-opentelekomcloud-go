/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface TaurusdbMysqlProxyV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_proxy_v3#flavor TaurusdbMysqlProxyV3#flavor}
    */
    readonly flavor: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_proxy_v3#id TaurusdbMysqlProxyV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_proxy_v3#instance_id TaurusdbMysqlProxyV3#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_proxy_v3#node_num TaurusdbMysqlProxyV3#node_num}
    */
    readonly nodeNum: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_proxy_v3#proxy_mode TaurusdbMysqlProxyV3#proxy_mode}
    */
    readonly proxyMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_proxy_v3#proxy_name TaurusdbMysqlProxyV3#proxy_name}
    */
    readonly proxyName?: string;
    /**
    * master_node_weight block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_proxy_v3#master_node_weight TaurusdbMysqlProxyV3#master_node_weight}
    */
    readonly masterNodeWeight?: TaurusdbMysqlProxyV3MasterNodeWeight;
    /**
    * readonly_nodes_weight block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_proxy_v3#readonly_nodes_weight TaurusdbMysqlProxyV3#readonly_nodes_weight}
    */
    readonly readonlyNodesWeight?: TaurusdbMysqlProxyV3ReadonlyNodesWeight[] | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_proxy_v3#timeouts TaurusdbMysqlProxyV3#timeouts}
    */
    readonly timeouts?: TaurusdbMysqlProxyV3Timeouts;
}
export interface TaurusdbMysqlProxyV3Nodes {
}
export declare function taurusdbMysqlProxyV3NodesToTerraform(struct?: TaurusdbMysqlProxyV3Nodes): any;
export declare function taurusdbMysqlProxyV3NodesToHclTerraform(struct?: TaurusdbMysqlProxyV3Nodes): any;
export declare class TaurusdbMysqlProxyV3NodesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): TaurusdbMysqlProxyV3Nodes | undefined;
    set internalValue(value: TaurusdbMysqlProxyV3Nodes | undefined);
    get azCode(): string;
    get frozenFlag(): number;
    get id(): string;
    get name(): string;
    get role(): string;
    get status(): string;
}
export declare class TaurusdbMysqlProxyV3NodesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): TaurusdbMysqlProxyV3NodesOutputReference;
}
export interface TaurusdbMysqlProxyV3MasterNodeWeight {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_proxy_v3#id TaurusdbMysqlProxyV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_proxy_v3#weight TaurusdbMysqlProxyV3#weight}
    */
    readonly weight: number;
}
export declare function taurusdbMysqlProxyV3MasterNodeWeightToTerraform(struct?: TaurusdbMysqlProxyV3MasterNodeWeightOutputReference | TaurusdbMysqlProxyV3MasterNodeWeight): any;
export declare function taurusdbMysqlProxyV3MasterNodeWeightToHclTerraform(struct?: TaurusdbMysqlProxyV3MasterNodeWeightOutputReference | TaurusdbMysqlProxyV3MasterNodeWeight): any;
export declare class TaurusdbMysqlProxyV3MasterNodeWeightOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TaurusdbMysqlProxyV3MasterNodeWeight | undefined;
    set internalValue(value: TaurusdbMysqlProxyV3MasterNodeWeight | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _weight?;
    get weight(): number;
    set weight(value: number);
    get weightInput(): number | undefined;
}
export interface TaurusdbMysqlProxyV3ReadonlyNodesWeight {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_proxy_v3#id TaurusdbMysqlProxyV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_proxy_v3#weight TaurusdbMysqlProxyV3#weight}
    */
    readonly weight: number;
}
export declare function taurusdbMysqlProxyV3ReadonlyNodesWeightToTerraform(struct?: TaurusdbMysqlProxyV3ReadonlyNodesWeight | cdktf.IResolvable): any;
export declare function taurusdbMysqlProxyV3ReadonlyNodesWeightToHclTerraform(struct?: TaurusdbMysqlProxyV3ReadonlyNodesWeight | cdktf.IResolvable): any;
export declare class TaurusdbMysqlProxyV3ReadonlyNodesWeightOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): TaurusdbMysqlProxyV3ReadonlyNodesWeight | cdktf.IResolvable | undefined;
    set internalValue(value: TaurusdbMysqlProxyV3ReadonlyNodesWeight | cdktf.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _weight?;
    get weight(): number;
    set weight(value: number);
    get weightInput(): number | undefined;
}
export declare class TaurusdbMysqlProxyV3ReadonlyNodesWeightList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: TaurusdbMysqlProxyV3ReadonlyNodesWeight[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): TaurusdbMysqlProxyV3ReadonlyNodesWeightOutputReference;
}
export interface TaurusdbMysqlProxyV3Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_proxy_v3#create TaurusdbMysqlProxyV3#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_proxy_v3#delete TaurusdbMysqlProxyV3#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_proxy_v3#update TaurusdbMysqlProxyV3#update}
    */
    readonly update?: string;
}
export declare function taurusdbMysqlProxyV3TimeoutsToTerraform(struct?: TaurusdbMysqlProxyV3Timeouts | cdktf.IResolvable): any;
export declare function taurusdbMysqlProxyV3TimeoutsToHclTerraform(struct?: TaurusdbMysqlProxyV3Timeouts | cdktf.IResolvable): any;
export declare class TaurusdbMysqlProxyV3TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TaurusdbMysqlProxyV3Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: TaurusdbMysqlProxyV3Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_proxy_v3 opentelekomcloud_taurusdb_mysql_proxy_v3}
*/
export declare class TaurusdbMysqlProxyV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_taurusdb_mysql_proxy_v3";
    /**
    * Generates CDKTF code for importing a TaurusdbMysqlProxyV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TaurusdbMysqlProxyV3 to import
    * @param importFromId The id of the existing TaurusdbMysqlProxyV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_proxy_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TaurusdbMysqlProxyV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/taurusdb_mysql_proxy_v3 opentelekomcloud_taurusdb_mysql_proxy_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TaurusdbMysqlProxyV3Config
    */
    constructor(scope: Construct, id: string, config: TaurusdbMysqlProxyV3Config);
    get address(): string;
    private _flavor?;
    get flavor(): string;
    set flavor(value: string);
    get flavorInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _nodeNum?;
    get nodeNum(): number;
    set nodeNum(value: number);
    get nodeNumInput(): number | undefined;
    private _nodes;
    get nodes(): TaurusdbMysqlProxyV3NodesList;
    get port(): number;
    private _proxyMode?;
    get proxyMode(): string;
    set proxyMode(value: string);
    resetProxyMode(): void;
    get proxyModeInput(): string | undefined;
    private _proxyName?;
    get proxyName(): string;
    set proxyName(value: string);
    resetProxyName(): void;
    get proxyNameInput(): string | undefined;
    get region(): string;
    get status(): string;
    private _masterNodeWeight;
    get masterNodeWeight(): TaurusdbMysqlProxyV3MasterNodeWeightOutputReference;
    putMasterNodeWeight(value: TaurusdbMysqlProxyV3MasterNodeWeight): void;
    resetMasterNodeWeight(): void;
    get masterNodeWeightInput(): TaurusdbMysqlProxyV3MasterNodeWeight | undefined;
    private _readonlyNodesWeight;
    get readonlyNodesWeight(): TaurusdbMysqlProxyV3ReadonlyNodesWeightList;
    putReadonlyNodesWeight(value: TaurusdbMysqlProxyV3ReadonlyNodesWeight[] | cdktf.IResolvable): void;
    resetReadonlyNodesWeight(): void;
    get readonlyNodesWeightInput(): cdktf.IResolvable | TaurusdbMysqlProxyV3ReadonlyNodesWeight[] | undefined;
    private _timeouts;
    get timeouts(): TaurusdbMysqlProxyV3TimeoutsOutputReference;
    putTimeouts(value: TaurusdbMysqlProxyV3Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | TaurusdbMysqlProxyV3Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

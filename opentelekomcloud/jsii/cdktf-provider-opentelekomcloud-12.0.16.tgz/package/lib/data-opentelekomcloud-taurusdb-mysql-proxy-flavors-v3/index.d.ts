/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_proxy_flavors_v3#id DataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_proxy_flavors_v3#instance_id DataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3#instance_id}
    */
    readonly instanceId: string;
}
export interface DataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3FlavorGroupsFlavors {
}
export declare function dataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3FlavorGroupsFlavorsToTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3FlavorGroupsFlavors): any;
export declare function dataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3FlavorGroupsFlavorsToHclTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3FlavorGroupsFlavors): any;
export declare class DataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3FlavorGroupsFlavorsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3FlavorGroupsFlavors | undefined;
    set internalValue(value: DataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3FlavorGroupsFlavors | undefined);
    private _azStatus;
    get azStatus(): cdktf.StringMap;
    get dbType(): string;
    get id(): string;
    get ram(): string;
    get specCode(): string;
    get vcpus(): string;
}
export declare class DataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3FlavorGroupsFlavorsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3FlavorGroupsFlavorsOutputReference;
}
export interface DataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3FlavorGroups {
}
export declare function dataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3FlavorGroupsToTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3FlavorGroups): any;
export declare function dataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3FlavorGroupsToHclTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3FlavorGroups): any;
export declare class DataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3FlavorGroupsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3FlavorGroups | undefined;
    set internalValue(value: DataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3FlavorGroups | undefined);
    private _flavors;
    get flavors(): DataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3FlavorGroupsFlavorsList;
    get type(): string;
}
export declare class DataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3FlavorGroupsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3FlavorGroupsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_proxy_flavors_v3 opentelekomcloud_taurusdb_mysql_proxy_flavors_v3}
*/
export declare class DataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_taurusdb_mysql_proxy_flavors_v3";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3 to import
    * @param importFromId The id of the existing DataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_proxy_flavors_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_proxy_flavors_v3 opentelekomcloud_taurusdb_mysql_proxy_flavors_v3} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3Config
    */
    constructor(scope: Construct, id: string, config: DataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3Config);
    private _flavorGroups;
    get flavorGroups(): DataOpentelekomcloudTaurusdbMysqlProxyFlavorsV3FlavorGroupsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get region(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudGeminiInstanceTemplateV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/gemini_instance_template_v3#id DataOpentelekomcloudGeminiInstanceTemplateV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/gemini_instance_template_v3#instance_id DataOpentelekomcloudGeminiInstanceTemplateV3#instance_id}
    */
    readonly instanceId: string;
}
export interface DataOpentelekomcloudGeminiInstanceTemplateV3ConfigurationParameters {
}
export declare function dataOpentelekomcloudGeminiInstanceTemplateV3ConfigurationParametersToTerraform(struct?: DataOpentelekomcloudGeminiInstanceTemplateV3ConfigurationParameters): any;
export declare function dataOpentelekomcloudGeminiInstanceTemplateV3ConfigurationParametersToHclTerraform(struct?: DataOpentelekomcloudGeminiInstanceTemplateV3ConfigurationParameters): any;
export declare class DataOpentelekomcloudGeminiInstanceTemplateV3ConfigurationParametersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudGeminiInstanceTemplateV3ConfigurationParameters | undefined;
    set internalValue(value: DataOpentelekomcloudGeminiInstanceTemplateV3ConfigurationParameters | undefined);
    get description(): string;
    get name(): string;
    get readonly(): cdktf.IResolvable;
    get restartRequired(): cdktf.IResolvable;
    get type(): string;
    get value(): string;
    get valueRange(): string;
}
export declare class DataOpentelekomcloudGeminiInstanceTemplateV3ConfigurationParametersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudGeminiInstanceTemplateV3ConfigurationParametersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/gemini_instance_template_v3 opentelekomcloud_gemini_instance_template_v3}
*/
export declare class DataOpentelekomcloudGeminiInstanceTemplateV3 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_gemini_instance_template_v3";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudGeminiInstanceTemplateV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudGeminiInstanceTemplateV3 to import
    * @param importFromId The id of the existing DataOpentelekomcloudGeminiInstanceTemplateV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/gemini_instance_template_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudGeminiInstanceTemplateV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/gemini_instance_template_v3 opentelekomcloud_gemini_instance_template_v3} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudGeminiInstanceTemplateV3Config
    */
    constructor(scope: Construct, id: string, config: DataOpentelekomcloudGeminiInstanceTemplateV3Config);
    private _configurationParameters;
    get configurationParameters(): DataOpentelekomcloudGeminiInstanceTemplateV3ConfigurationParametersList;
    get createdAt(): string;
    get datastoreName(): string;
    get datastoreVersionName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get mode(): string;
    get region(): string;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

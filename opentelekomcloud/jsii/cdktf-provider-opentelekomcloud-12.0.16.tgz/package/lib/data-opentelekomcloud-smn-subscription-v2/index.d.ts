/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudSmnSubscriptionV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/smn_subscription_v2#id DataOpentelekomcloudSmnSubscriptionV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/smn_subscription_v2#subscription_urn DataOpentelekomcloudSmnSubscriptionV2#subscription_urn}
    */
    readonly subscriptionUrn: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/smn_subscription_v2 opentelekomcloud_smn_subscription_v2}
*/
export declare class DataOpentelekomcloudSmnSubscriptionV2 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_smn_subscription_v2";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudSmnSubscriptionV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudSmnSubscriptionV2 to import
    * @param importFromId The id of the existing DataOpentelekomcloudSmnSubscriptionV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/smn_subscription_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudSmnSubscriptionV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/smn_subscription_v2 opentelekomcloud_smn_subscription_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudSmnSubscriptionV2Config
    */
    constructor(scope: Construct, id: string, config: DataOpentelekomcloudSmnSubscriptionV2Config);
    get description(): string;
    get endpoint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get owner(): string;
    get protocol(): string;
    get status(): number;
    private _subscriptionUrn?;
    get subscriptionUrn(): string;
    set subscriptionUrn(value: string);
    get subscriptionUrnInput(): string | undefined;
    get topicUrn(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

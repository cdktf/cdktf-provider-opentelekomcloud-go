/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DcVirtualGatewayV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_gateway_v2#asn DcVirtualGatewayV2#asn}
    */
    readonly asn?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_gateway_v2#description DcVirtualGatewayV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_gateway_v2#device_id DcVirtualGatewayV2#device_id}
    */
    readonly deviceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_gateway_v2#id DcVirtualGatewayV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_gateway_v2#name DcVirtualGatewayV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_gateway_v2#project_id DcVirtualGatewayV2#project_id}
    */
    readonly projectId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_gateway_v2#redundant_device_id DcVirtualGatewayV2#redundant_device_id}
    */
    readonly redundantDeviceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_gateway_v2#vpc_id DcVirtualGatewayV2#vpc_id}
    */
    readonly vpcId: string;
    /**
    * local_ep_group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_gateway_v2#local_ep_group DcVirtualGatewayV2#local_ep_group}
    */
    readonly localEpGroup?: DcVirtualGatewayV2LocalEpGroup;
    /**
    * local_ep_group_v6 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_gateway_v2#local_ep_group_v6 DcVirtualGatewayV2#local_ep_group_v6}
    */
    readonly localEpGroupV6?: DcVirtualGatewayV2LocalEpGroupV6;
}
export interface DcVirtualGatewayV2LocalEpGroup {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_gateway_v2#description DcVirtualGatewayV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_gateway_v2#endpoints DcVirtualGatewayV2#endpoints}
    */
    readonly endpoints: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_gateway_v2#name DcVirtualGatewayV2#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_gateway_v2#type DcVirtualGatewayV2#type}
    */
    readonly type?: string;
}
export declare function dcVirtualGatewayV2LocalEpGroupToTerraform(struct?: DcVirtualGatewayV2LocalEpGroupOutputReference | DcVirtualGatewayV2LocalEpGroup): any;
export declare function dcVirtualGatewayV2LocalEpGroupToHclTerraform(struct?: DcVirtualGatewayV2LocalEpGroupOutputReference | DcVirtualGatewayV2LocalEpGroup): any;
export declare class DcVirtualGatewayV2LocalEpGroupOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DcVirtualGatewayV2LocalEpGroup | undefined;
    set internalValue(value: DcVirtualGatewayV2LocalEpGroup | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _endpoints?;
    get endpoints(): string[];
    set endpoints(value: string[]);
    get endpointsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface DcVirtualGatewayV2LocalEpGroupV6 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_gateway_v2#description DcVirtualGatewayV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_gateway_v2#endpoints DcVirtualGatewayV2#endpoints}
    */
    readonly endpoints: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_gateway_v2#name DcVirtualGatewayV2#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_gateway_v2#type DcVirtualGatewayV2#type}
    */
    readonly type?: string;
}
export declare function dcVirtualGatewayV2LocalEpGroupV6ToTerraform(struct?: DcVirtualGatewayV2LocalEpGroupV6OutputReference | DcVirtualGatewayV2LocalEpGroupV6): any;
export declare function dcVirtualGatewayV2LocalEpGroupV6ToHclTerraform(struct?: DcVirtualGatewayV2LocalEpGroupV6OutputReference | DcVirtualGatewayV2LocalEpGroupV6): any;
export declare class DcVirtualGatewayV2LocalEpGroupV6OutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DcVirtualGatewayV2LocalEpGroupV6 | undefined;
    set internalValue(value: DcVirtualGatewayV2LocalEpGroupV6 | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _endpoints?;
    get endpoints(): string[];
    set endpoints(value: string[]);
    get endpointsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_gateway_v2 opentelekomcloud_dc_virtual_gateway_v2}
*/
export declare class DcVirtualGatewayV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_dc_virtual_gateway_v2";
    /**
    * Generates CDKTF code for importing a DcVirtualGatewayV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DcVirtualGatewayV2 to import
    * @param importFromId The id of the existing DcVirtualGatewayV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_gateway_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DcVirtualGatewayV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dc_virtual_gateway_v2 opentelekomcloud_dc_virtual_gateway_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DcVirtualGatewayV2Config
    */
    constructor(scope: Construct, id: string, config: DcVirtualGatewayV2Config);
    private _asn?;
    get asn(): number;
    set asn(value: number);
    resetAsn(): void;
    get asnInput(): number | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _deviceId?;
    get deviceId(): string;
    set deviceId(value: string);
    resetDeviceId(): void;
    get deviceIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get localEpGroupId(): string;
    get localEpGroupIpv6Id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _redundantDeviceId?;
    get redundantDeviceId(): string;
    set redundantDeviceId(value: string);
    resetRedundantDeviceId(): void;
    get redundantDeviceIdInput(): string | undefined;
    get status(): string;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    get vpcIdInput(): string | undefined;
    private _localEpGroup;
    get localEpGroup(): DcVirtualGatewayV2LocalEpGroupOutputReference;
    putLocalEpGroup(value: DcVirtualGatewayV2LocalEpGroup): void;
    resetLocalEpGroup(): void;
    get localEpGroupInput(): DcVirtualGatewayV2LocalEpGroup | undefined;
    private _localEpGroupV6;
    get localEpGroupV6(): DcVirtualGatewayV2LocalEpGroupV6OutputReference;
    putLocalEpGroupV6(value: DcVirtualGatewayV2LocalEpGroupV6): void;
    resetLocalEpGroupV6(): void;
    get localEpGroupV6Input(): DcVirtualGatewayV2LocalEpGroupV6 | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

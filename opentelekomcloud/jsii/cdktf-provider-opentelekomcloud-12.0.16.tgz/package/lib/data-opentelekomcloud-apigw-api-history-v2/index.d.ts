/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudApigwApiHistoryV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/apigw_api_history_v2#api_id DataOpentelekomcloudApigwApiHistoryV2#api_id}
    */
    readonly apiId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/apigw_api_history_v2#environment_id DataOpentelekomcloudApigwApiHistoryV2#environment_id}
    */
    readonly environmentId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/apigw_api_history_v2#environment_name DataOpentelekomcloudApigwApiHistoryV2#environment_name}
    */
    readonly environmentName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/apigw_api_history_v2#gateway_id DataOpentelekomcloudApigwApiHistoryV2#gateway_id}
    */
    readonly gatewayId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/apigw_api_history_v2#id DataOpentelekomcloudApigwApiHistoryV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataOpentelekomcloudApigwApiHistoryV2History {
}
export declare function dataOpentelekomcloudApigwApiHistoryV2HistoryToTerraform(struct?: DataOpentelekomcloudApigwApiHistoryV2History): any;
export declare function dataOpentelekomcloudApigwApiHistoryV2HistoryToHclTerraform(struct?: DataOpentelekomcloudApigwApiHistoryV2History): any;
export declare class DataOpentelekomcloudApigwApiHistoryV2HistoryOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudApigwApiHistoryV2History | undefined;
    set internalValue(value: DataOpentelekomcloudApigwApiHistoryV2History | undefined);
    get description(): string;
    get id(): string;
    get name(): string;
    get publishTime(): string;
    get status(): number;
}
export declare class DataOpentelekomcloudApigwApiHistoryV2HistoryList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudApigwApiHistoryV2HistoryOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/apigw_api_history_v2 opentelekomcloud_apigw_api_history_v2}
*/
export declare class DataOpentelekomcloudApigwApiHistoryV2 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_apigw_api_history_v2";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudApigwApiHistoryV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudApigwApiHistoryV2 to import
    * @param importFromId The id of the existing DataOpentelekomcloudApigwApiHistoryV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/apigw_api_history_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudApigwApiHistoryV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/apigw_api_history_v2 opentelekomcloud_apigw_api_history_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudApigwApiHistoryV2Config
    */
    constructor(scope: Construct, id: string, config: DataOpentelekomcloudApigwApiHistoryV2Config);
    private _apiId?;
    get apiId(): string;
    set apiId(value: string);
    get apiIdInput(): string | undefined;
    private _environmentId?;
    get environmentId(): string;
    set environmentId(value: string);
    resetEnvironmentId(): void;
    get environmentIdInput(): string | undefined;
    private _environmentName?;
    get environmentName(): string;
    set environmentName(value: string);
    resetEnvironmentName(): void;
    get environmentNameInput(): string | undefined;
    private _gatewayId?;
    get gatewayId(): string;
    set gatewayId(value: string);
    get gatewayIdInput(): string | undefined;
    private _history;
    get history(): DataOpentelekomcloudApigwApiHistoryV2HistoryList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get region(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

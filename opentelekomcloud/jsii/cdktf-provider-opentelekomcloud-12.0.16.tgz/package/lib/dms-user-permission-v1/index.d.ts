/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DmsUserPermissionV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_user_permission_v1#id DmsUserPermissionV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_user_permission_v1#instance_id DmsUserPermissionV1#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_user_permission_v1#topic_name DmsUserPermissionV1#topic_name}
    */
    readonly topicName: string;
    /**
    * policies block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_user_permission_v1#policies DmsUserPermissionV1#policies}
    */
    readonly policies: DmsUserPermissionV1Policies[] | cdktf.IResolvable;
}
export interface DmsUserPermissionV1Policies {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_user_permission_v1#access_policy DmsUserPermissionV1#access_policy}
    */
    readonly accessPolicy: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_user_permission_v1#username DmsUserPermissionV1#username}
    */
    readonly username: string;
}
export declare function dmsUserPermissionV1PoliciesToTerraform(struct?: DmsUserPermissionV1Policies | cdktf.IResolvable): any;
export declare function dmsUserPermissionV1PoliciesToHclTerraform(struct?: DmsUserPermissionV1Policies | cdktf.IResolvable): any;
export declare class DmsUserPermissionV1PoliciesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DmsUserPermissionV1Policies | cdktf.IResolvable | undefined;
    set internalValue(value: DmsUserPermissionV1Policies | cdktf.IResolvable | undefined);
    private _accessPolicy?;
    get accessPolicy(): string;
    set accessPolicy(value: string);
    get accessPolicyInput(): string | undefined;
    get owner(): cdktf.IResolvable;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
}
export declare class DmsUserPermissionV1PoliciesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DmsUserPermissionV1Policies[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DmsUserPermissionV1PoliciesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_user_permission_v1 opentelekomcloud_dms_user_permission_v1}
*/
export declare class DmsUserPermissionV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_dms_user_permission_v1";
    /**
    * Generates CDKTF code for importing a DmsUserPermissionV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DmsUserPermissionV1 to import
    * @param importFromId The id of the existing DmsUserPermissionV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_user_permission_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DmsUserPermissionV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_user_permission_v1 opentelekomcloud_dms_user_permission_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DmsUserPermissionV1Config
    */
    constructor(scope: Construct, id: string, config: DmsUserPermissionV1Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _topicName?;
    get topicName(): string;
    set topicName(value: string);
    get topicNameInput(): string | undefined;
    get topicType(): number;
    private _policies;
    get policies(): DmsUserPermissionV1PoliciesList;
    putPolicies(value: DmsUserPermissionV1Policies[] | cdktf.IResolvable): void;
    get policiesInput(): cdktf.IResolvable | DmsUserPermissionV1Policies[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

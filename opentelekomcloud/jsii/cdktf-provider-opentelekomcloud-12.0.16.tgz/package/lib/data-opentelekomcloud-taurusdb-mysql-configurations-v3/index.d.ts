/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudTaurusdbMysqlConfigurationsV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_configurations_v3#id DataOpentelekomcloudTaurusdbMysqlConfigurationsV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataOpentelekomcloudTaurusdbMysqlConfigurationsV3Configurations {
}
export declare function dataOpentelekomcloudTaurusdbMysqlConfigurationsV3ConfigurationsToTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlConfigurationsV3Configurations): any;
export declare function dataOpentelekomcloudTaurusdbMysqlConfigurationsV3ConfigurationsToHclTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlConfigurationsV3Configurations): any;
export declare class DataOpentelekomcloudTaurusdbMysqlConfigurationsV3ConfigurationsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudTaurusdbMysqlConfigurationsV3Configurations | undefined;
    set internalValue(value: DataOpentelekomcloudTaurusdbMysqlConfigurationsV3Configurations | undefined);
    get createdAt(): string;
    get datastoreName(): string;
    get datastoreVersionName(): string;
    get description(): string;
    get id(): string;
    get name(): string;
    get updatedAt(): string;
    get userDefined(): cdktf.IResolvable;
}
export declare class DataOpentelekomcloudTaurusdbMysqlConfigurationsV3ConfigurationsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudTaurusdbMysqlConfigurationsV3ConfigurationsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_configurations_v3 opentelekomcloud_taurusdb_mysql_configurations_v3}
*/
export declare class DataOpentelekomcloudTaurusdbMysqlConfigurationsV3 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_taurusdb_mysql_configurations_v3";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudTaurusdbMysqlConfigurationsV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudTaurusdbMysqlConfigurationsV3 to import
    * @param importFromId The id of the existing DataOpentelekomcloudTaurusdbMysqlConfigurationsV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_configurations_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudTaurusdbMysqlConfigurationsV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_configurations_v3 opentelekomcloud_taurusdb_mysql_configurations_v3} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudTaurusdbMysqlConfigurationsV3Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudTaurusdbMysqlConfigurationsV3Config);
    private _configurations;
    get configurations(): DataOpentelekomcloudTaurusdbMysqlConfigurationsV3ConfigurationsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get region(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

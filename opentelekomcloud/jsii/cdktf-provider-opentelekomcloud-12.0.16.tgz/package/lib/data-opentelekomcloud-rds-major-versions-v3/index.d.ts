/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudRdsMajorVersionsV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/rds_major_versions_v3#id DataOpentelekomcloudRdsMajorVersionsV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/rds_major_versions_v3#instance_id DataOpentelekomcloudRdsMajorVersionsV3#instance_id}
    */
    readonly instanceId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/rds_major_versions_v3 opentelekomcloud_rds_major_versions_v3}
*/
export declare class DataOpentelekomcloudRdsMajorVersionsV3 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_rds_major_versions_v3";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudRdsMajorVersionsV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudRdsMajorVersionsV3 to import
    * @param importFromId The id of the existing DataOpentelekomcloudRdsMajorVersionsV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/rds_major_versions_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudRdsMajorVersionsV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/rds_major_versions_v3 opentelekomcloud_rds_major_versions_v3} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudRdsMajorVersionsV3Config
    */
    constructor(scope: Construct, id: string, config: DataOpentelekomcloudRdsMajorVersionsV3Config);
    get availableVersions(): string[];
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

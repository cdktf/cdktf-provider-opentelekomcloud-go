/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CbrPolicyV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cbr_policy_v3#destination_project_id CbrPolicyV3#destination_project_id}
    */
    readonly destinationProjectId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cbr_policy_v3#destination_region CbrPolicyV3#destination_region}
    */
    readonly destinationRegion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cbr_policy_v3#enabled CbrPolicyV3#enabled}
    */
    readonly enabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cbr_policy_v3#id CbrPolicyV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cbr_policy_v3#name CbrPolicyV3#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cbr_policy_v3#operation_type CbrPolicyV3#operation_type}
    */
    readonly operationType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cbr_policy_v3#trigger_pattern CbrPolicyV3#trigger_pattern}
    */
    readonly triggerPattern: string[];
    /**
    * operation_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cbr_policy_v3#operation_definition CbrPolicyV3#operation_definition}
    */
    readonly operationDefinition?: CbrPolicyV3OperationDefinition;
}
export interface CbrPolicyV3OperationDefinition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cbr_policy_v3#day_backups CbrPolicyV3#day_backups}
    */
    readonly dayBackups?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cbr_policy_v3#max_backups CbrPolicyV3#max_backups}
    */
    readonly maxBackups?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cbr_policy_v3#month_backups CbrPolicyV3#month_backups}
    */
    readonly monthBackups?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cbr_policy_v3#retention_duration_days CbrPolicyV3#retention_duration_days}
    */
    readonly retentionDurationDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cbr_policy_v3#timezone CbrPolicyV3#timezone}
    */
    readonly timezone: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cbr_policy_v3#week_backups CbrPolicyV3#week_backups}
    */
    readonly weekBackups?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cbr_policy_v3#year_backups CbrPolicyV3#year_backups}
    */
    readonly yearBackups?: number;
}
export declare function cbrPolicyV3OperationDefinitionToTerraform(struct?: CbrPolicyV3OperationDefinitionOutputReference | CbrPolicyV3OperationDefinition): any;
export declare function cbrPolicyV3OperationDefinitionToHclTerraform(struct?: CbrPolicyV3OperationDefinitionOutputReference | CbrPolicyV3OperationDefinition): any;
export declare class CbrPolicyV3OperationDefinitionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CbrPolicyV3OperationDefinition | undefined;
    set internalValue(value: CbrPolicyV3OperationDefinition | undefined);
    private _dayBackups?;
    get dayBackups(): number;
    set dayBackups(value: number);
    resetDayBackups(): void;
    get dayBackupsInput(): number | undefined;
    private _maxBackups?;
    get maxBackups(): number;
    set maxBackups(value: number);
    resetMaxBackups(): void;
    get maxBackupsInput(): number | undefined;
    private _monthBackups?;
    get monthBackups(): number;
    set monthBackups(value: number);
    resetMonthBackups(): void;
    get monthBackupsInput(): number | undefined;
    private _retentionDurationDays?;
    get retentionDurationDays(): number;
    set retentionDurationDays(value: number);
    resetRetentionDurationDays(): void;
    get retentionDurationDaysInput(): number | undefined;
    private _timezone?;
    get timezone(): string;
    set timezone(value: string);
    get timezoneInput(): string | undefined;
    private _weekBackups?;
    get weekBackups(): number;
    set weekBackups(value: number);
    resetWeekBackups(): void;
    get weekBackupsInput(): number | undefined;
    private _yearBackups?;
    get yearBackups(): number;
    set yearBackups(value: number);
    resetYearBackups(): void;
    get yearBackupsInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cbr_policy_v3 opentelekomcloud_cbr_policy_v3}
*/
export declare class CbrPolicyV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_cbr_policy_v3";
    /**
    * Generates CDKTF code for importing a CbrPolicyV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CbrPolicyV3 to import
    * @param importFromId The id of the existing CbrPolicyV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cbr_policy_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CbrPolicyV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cbr_policy_v3 opentelekomcloud_cbr_policy_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CbrPolicyV3Config
    */
    constructor(scope: Construct, id: string, config: CbrPolicyV3Config);
    private _destinationProjectId?;
    get destinationProjectId(): string;
    set destinationProjectId(value: string);
    resetDestinationProjectId(): void;
    get destinationProjectIdInput(): string | undefined;
    private _destinationRegion?;
    get destinationRegion(): string;
    set destinationRegion(value: string);
    resetDestinationRegion(): void;
    get destinationRegionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operationType?;
    get operationType(): string;
    set operationType(value: string);
    get operationTypeInput(): string | undefined;
    get region(): string;
    private _triggerPattern?;
    get triggerPattern(): string[];
    set triggerPattern(value: string[]);
    get triggerPatternInput(): string[] | undefined;
    private _operationDefinition;
    get operationDefinition(): CbrPolicyV3OperationDefinitionOutputReference;
    putOperationDefinition(value: CbrPolicyV3OperationDefinition): void;
    resetOperationDefinition(): void;
    get operationDefinitionInput(): CbrPolicyV3OperationDefinition | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudIdentityTemporaryAkskV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/identity_temporary_aksk_v3#agency_name DataOpentelekomcloudIdentityTemporaryAkskV3#agency_name}
    */
    readonly agencyName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/identity_temporary_aksk_v3#duration_seconds DataOpentelekomcloudIdentityTemporaryAkskV3#duration_seconds}
    */
    readonly durationSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/identity_temporary_aksk_v3#id DataOpentelekomcloudIdentityTemporaryAkskV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/identity_temporary_aksk_v3 opentelekomcloud_identity_temporary_aksk_v3}
*/
export declare class DataOpentelekomcloudIdentityTemporaryAkskV3 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_identity_temporary_aksk_v3";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudIdentityTemporaryAkskV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudIdentityTemporaryAkskV3 to import
    * @param importFromId The id of the existing DataOpentelekomcloudIdentityTemporaryAkskV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/identity_temporary_aksk_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudIdentityTemporaryAkskV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/identity_temporary_aksk_v3 opentelekomcloud_identity_temporary_aksk_v3} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudIdentityTemporaryAkskV3Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudIdentityTemporaryAkskV3Config);
    get access(): string;
    private _agencyName?;
    get agencyName(): string;
    set agencyName(value: string);
    resetAgencyName(): void;
    get agencyNameInput(): string | undefined;
    private _durationSeconds?;
    get durationSeconds(): number;
    set durationSeconds(value: number);
    resetDurationSeconds(): void;
    get durationSecondsInput(): number | undefined;
    get expiresAt(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get secret(): string;
    get securityToken(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

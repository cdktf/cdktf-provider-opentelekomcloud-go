/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudEvsVolumesV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/evs_volumes_v2#availability_zone DataOpentelekomcloudEvsVolumesV2#availability_zone}
    */
    readonly availabilityZone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/evs_volumes_v2#id DataOpentelekomcloudEvsVolumesV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/evs_volumes_v2#name DataOpentelekomcloudEvsVolumesV2#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/evs_volumes_v2#server_id DataOpentelekomcloudEvsVolumesV2#server_id}
    */
    readonly serverId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/evs_volumes_v2#shareable DataOpentelekomcloudEvsVolumesV2#shareable}
    */
    readonly shareable?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/evs_volumes_v2#status DataOpentelekomcloudEvsVolumesV2#status}
    */
    readonly status?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/evs_volumes_v2#tags DataOpentelekomcloudEvsVolumesV2#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/evs_volumes_v2#volume_id DataOpentelekomcloudEvsVolumesV2#volume_id}
    */
    readonly volumeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/evs_volumes_v2#volume_type_id DataOpentelekomcloudEvsVolumesV2#volume_type_id}
    */
    readonly volumeTypeId?: string;
}
export interface DataOpentelekomcloudEvsVolumesV2VolumesAttachments {
}
export declare function dataOpentelekomcloudEvsVolumesV2VolumesAttachmentsToTerraform(struct?: DataOpentelekomcloudEvsVolumesV2VolumesAttachments): any;
export declare function dataOpentelekomcloudEvsVolumesV2VolumesAttachmentsToHclTerraform(struct?: DataOpentelekomcloudEvsVolumesV2VolumesAttachments): any;
export declare class DataOpentelekomcloudEvsVolumesV2VolumesAttachmentsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudEvsVolumesV2VolumesAttachments | undefined;
    set internalValue(value: DataOpentelekomcloudEvsVolumesV2VolumesAttachments | undefined);
    get attachedAt(): string;
    get attachedMode(): string;
    get deviceName(): string;
    get id(): string;
    get serverId(): string;
}
export declare class DataOpentelekomcloudEvsVolumesV2VolumesAttachmentsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudEvsVolumesV2VolumesAttachmentsOutputReference;
}
export interface DataOpentelekomcloudEvsVolumesV2Volumes {
}
export declare function dataOpentelekomcloudEvsVolumesV2VolumesToTerraform(struct?: DataOpentelekomcloudEvsVolumesV2Volumes): any;
export declare function dataOpentelekomcloudEvsVolumesV2VolumesToHclTerraform(struct?: DataOpentelekomcloudEvsVolumesV2Volumes): any;
export declare class DataOpentelekomcloudEvsVolumesV2VolumesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudEvsVolumesV2Volumes | undefined;
    set internalValue(value: DataOpentelekomcloudEvsVolumesV2Volumes | undefined);
    private _attachments;
    get attachments(): DataOpentelekomcloudEvsVolumesV2VolumesAttachmentsList;
    get availabilityZone(): string;
    get bootable(): cdktf.IResolvable;
    get createAt(): string;
    get description(): string;
    get id(): string;
    get name(): string;
    get serviceType(): string;
    get shareable(): cdktf.IResolvable;
    get size(): number;
    get status(): string;
    private _tags;
    get tags(): cdktf.StringMap;
    get updateAt(): string;
    get volumeType(): string;
    get wwn(): string;
}
export declare class DataOpentelekomcloudEvsVolumesV2VolumesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudEvsVolumesV2VolumesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/evs_volumes_v2 opentelekomcloud_evs_volumes_v2}
*/
export declare class DataOpentelekomcloudEvsVolumesV2 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_evs_volumes_v2";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudEvsVolumesV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudEvsVolumesV2 to import
    * @param importFromId The id of the existing DataOpentelekomcloudEvsVolumesV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/evs_volumes_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudEvsVolumesV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/evs_volumes_v2 opentelekomcloud_evs_volumes_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudEvsVolumesV2Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudEvsVolumesV2Config);
    private _availabilityZone?;
    get availabilityZone(): string;
    set availabilityZone(value: string);
    resetAvailabilityZone(): void;
    get availabilityZoneInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _serverId?;
    get serverId(): string;
    set serverId(value: string);
    resetServerId(): void;
    get serverIdInput(): string | undefined;
    private _shareable?;
    get shareable(): boolean | cdktf.IResolvable;
    set shareable(value: boolean | cdktf.IResolvable);
    resetShareable(): void;
    get shareableInput(): boolean | cdktf.IResolvable | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _volumeId?;
    get volumeId(): string;
    set volumeId(value: string);
    resetVolumeId(): void;
    get volumeIdInput(): string | undefined;
    private _volumeTypeId?;
    get volumeTypeId(): string;
    set volumeTypeId(value: string);
    resetVolumeTypeId(): void;
    get volumeTypeIdInput(): string | undefined;
    private _volumes;
    get volumes(): DataOpentelekomcloudEvsVolumesV2VolumesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

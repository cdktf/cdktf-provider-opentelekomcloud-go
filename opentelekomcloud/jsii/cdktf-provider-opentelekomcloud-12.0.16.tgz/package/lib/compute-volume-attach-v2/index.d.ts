/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ComputeVolumeAttachV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_volume_attach_v2#device ComputeVolumeAttachV2#device}
    */
    readonly device?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_volume_attach_v2#force_detach ComputeVolumeAttachV2#force_detach}
    */
    readonly forceDetach?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_volume_attach_v2#id ComputeVolumeAttachV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_volume_attach_v2#instance_id ComputeVolumeAttachV2#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_volume_attach_v2#region ComputeVolumeAttachV2#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_volume_attach_v2#volume_id ComputeVolumeAttachV2#volume_id}
    */
    readonly volumeId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_volume_attach_v2#timeouts ComputeVolumeAttachV2#timeouts}
    */
    readonly timeouts?: ComputeVolumeAttachV2Timeouts;
}
export interface ComputeVolumeAttachV2Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_volume_attach_v2#create ComputeVolumeAttachV2#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_volume_attach_v2#delete ComputeVolumeAttachV2#delete}
    */
    readonly delete?: string;
}
export declare function computeVolumeAttachV2TimeoutsToTerraform(struct?: ComputeVolumeAttachV2Timeouts | cdktf.IResolvable): any;
export declare function computeVolumeAttachV2TimeoutsToHclTerraform(struct?: ComputeVolumeAttachV2Timeouts | cdktf.IResolvable): any;
export declare class ComputeVolumeAttachV2TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeVolumeAttachV2Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: ComputeVolumeAttachV2Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_volume_attach_v2 opentelekomcloud_compute_volume_attach_v2}
*/
export declare class ComputeVolumeAttachV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_compute_volume_attach_v2";
    /**
    * Generates CDKTF code for importing a ComputeVolumeAttachV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeVolumeAttachV2 to import
    * @param importFromId The id of the existing ComputeVolumeAttachV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_volume_attach_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeVolumeAttachV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_volume_attach_v2 opentelekomcloud_compute_volume_attach_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeVolumeAttachV2Config
    */
    constructor(scope: Construct, id: string, config: ComputeVolumeAttachV2Config);
    private _device?;
    get device(): string;
    set device(value: string);
    resetDevice(): void;
    get deviceInput(): string | undefined;
    private _forceDetach?;
    get forceDetach(): boolean | cdktf.IResolvable;
    set forceDetach(value: boolean | cdktf.IResolvable);
    resetForceDetach(): void;
    get forceDetachInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _volumeId?;
    get volumeId(): string;
    set volumeId(value: string);
    get volumeIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): ComputeVolumeAttachV2TimeoutsOutputReference;
    putTimeouts(value: ComputeVolumeAttachV2Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | ComputeVolumeAttachV2Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

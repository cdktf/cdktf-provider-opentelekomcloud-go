/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudTaurusdbMysqlEngineVersionsV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_engine_versions_v3#database_name DataOpentelekomcloudTaurusdbMysqlEngineVersionsV3#database_name}
    */
    readonly databaseName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_engine_versions_v3#id DataOpentelekomcloudTaurusdbMysqlEngineVersionsV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataOpentelekomcloudTaurusdbMysqlEngineVersionsV3Datastores {
}
export declare function dataOpentelekomcloudTaurusdbMysqlEngineVersionsV3DatastoresToTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlEngineVersionsV3Datastores): any;
export declare function dataOpentelekomcloudTaurusdbMysqlEngineVersionsV3DatastoresToHclTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlEngineVersionsV3Datastores): any;
export declare class DataOpentelekomcloudTaurusdbMysqlEngineVersionsV3DatastoresOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudTaurusdbMysqlEngineVersionsV3Datastores | undefined;
    set internalValue(value: DataOpentelekomcloudTaurusdbMysqlEngineVersionsV3Datastores | undefined);
    get id(): string;
    get name(): string;
}
export declare class DataOpentelekomcloudTaurusdbMysqlEngineVersionsV3DatastoresList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudTaurusdbMysqlEngineVersionsV3DatastoresOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_engine_versions_v3 opentelekomcloud_taurusdb_mysql_engine_versions_v3}
*/
export declare class DataOpentelekomcloudTaurusdbMysqlEngineVersionsV3 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_taurusdb_mysql_engine_versions_v3";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudTaurusdbMysqlEngineVersionsV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudTaurusdbMysqlEngineVersionsV3 to import
    * @param importFromId The id of the existing DataOpentelekomcloudTaurusdbMysqlEngineVersionsV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_engine_versions_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudTaurusdbMysqlEngineVersionsV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_engine_versions_v3 opentelekomcloud_taurusdb_mysql_engine_versions_v3} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudTaurusdbMysqlEngineVersionsV3Config
    */
    constructor(scope: Construct, id: string, config: DataOpentelekomcloudTaurusdbMysqlEngineVersionsV3Config);
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _datastores;
    get datastores(): DataOpentelekomcloudTaurusdbMysqlEngineVersionsV3DatastoresList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get region(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

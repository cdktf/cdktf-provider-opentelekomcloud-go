/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface IdentityUserV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_user_v3#access_type IdentityUserV3#access_type}
    */
    readonly accessType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_user_v3#country_code IdentityUserV3#country_code}
    */
    readonly countryCode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_user_v3#description IdentityUserV3#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_user_v3#email IdentityUserV3#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_user_v3#enabled IdentityUserV3#enabled}
    */
    readonly enabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_user_v3#id IdentityUserV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_user_v3#name IdentityUserV3#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_user_v3#password IdentityUserV3#password}
    */
    readonly password?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_user_v3#phone IdentityUserV3#phone}
    */
    readonly phone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_user_v3#pwd_reset IdentityUserV3#pwd_reset}
    */
    readonly pwdReset?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_user_v3#send_welcome_email IdentityUserV3#send_welcome_email}
    */
    readonly sendWelcomeEmail?: boolean | cdktf.IResolvable;
    /**
    * login_protection block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_user_v3#login_protection IdentityUserV3#login_protection}
    */
    readonly loginProtection?: IdentityUserV3LoginProtection;
}
export interface IdentityUserV3LoginProtection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_user_v3#enabled IdentityUserV3#enabled}
    */
    readonly enabled: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_user_v3#verification_method IdentityUserV3#verification_method}
    */
    readonly verificationMethod: string;
}
export declare function identityUserV3LoginProtectionToTerraform(struct?: IdentityUserV3LoginProtectionOutputReference | IdentityUserV3LoginProtection): any;
export declare function identityUserV3LoginProtectionToHclTerraform(struct?: IdentityUserV3LoginProtectionOutputReference | IdentityUserV3LoginProtection): any;
export declare class IdentityUserV3LoginProtectionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IdentityUserV3LoginProtection | undefined;
    set internalValue(value: IdentityUserV3LoginProtection | undefined);
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _verificationMethod?;
    get verificationMethod(): string;
    set verificationMethod(value: string);
    get verificationMethodInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_user_v3 opentelekomcloud_identity_user_v3}
*/
export declare class IdentityUserV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_identity_user_v3";
    /**
    * Generates CDKTF code for importing a IdentityUserV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IdentityUserV3 to import
    * @param importFromId The id of the existing IdentityUserV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_user_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IdentityUserV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_user_v3 opentelekomcloud_identity_user_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IdentityUserV3Config
    */
    constructor(scope: Construct, id: string, config: IdentityUserV3Config);
    private _accessType?;
    get accessType(): string;
    set accessType(value: string);
    resetAccessType(): void;
    get accessTypeInput(): string | undefined;
    private _countryCode?;
    get countryCode(): string;
    set countryCode(value: string);
    resetCountryCode(): void;
    get countryCodeInput(): string | undefined;
    get createTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get domainId(): string;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastLogin(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    get passwordStrength(): string;
    private _phone?;
    get phone(): string;
    set phone(value: string);
    resetPhone(): void;
    get phoneInput(): string | undefined;
    private _pwdReset?;
    get pwdReset(): boolean | cdktf.IResolvable;
    set pwdReset(value: boolean | cdktf.IResolvable);
    resetPwdReset(): void;
    get pwdResetInput(): boolean | cdktf.IResolvable | undefined;
    private _sendWelcomeEmail?;
    get sendWelcomeEmail(): boolean | cdktf.IResolvable;
    set sendWelcomeEmail(value: boolean | cdktf.IResolvable);
    resetSendWelcomeEmail(): void;
    get sendWelcomeEmailInput(): boolean | cdktf.IResolvable | undefined;
    get xuserId(): string;
    get xuserType(): string;
    private _loginProtection;
    get loginProtection(): IdentityUserV3LoginProtectionOutputReference;
    putLoginProtection(value: IdentityUserV3LoginProtection): void;
    resetLoginProtection(): void;
    get loginProtectionInput(): IdentityUserV3LoginProtection | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

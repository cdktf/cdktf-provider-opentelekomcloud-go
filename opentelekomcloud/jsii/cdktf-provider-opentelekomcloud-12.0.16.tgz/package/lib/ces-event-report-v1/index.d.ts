/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CesEventReportV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_event_report_v1#event_name CesEventReportV1#event_name}
    */
    readonly eventName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_event_report_v1#event_source CesEventReportV1#event_source}
    */
    readonly eventSource: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_event_report_v1#id CesEventReportV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_event_report_v1#time CesEventReportV1#time}
    */
    readonly time: number;
    /**
    * detail block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_event_report_v1#detail CesEventReportV1#detail}
    */
    readonly detail: CesEventReportV1Detail;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_event_report_v1#timeouts CesEventReportV1#timeouts}
    */
    readonly timeouts?: CesEventReportV1Timeouts;
}
export interface CesEventReportV1Detail {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_event_report_v1#content CesEventReportV1#content}
    */
    readonly content?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_event_report_v1#event_level CesEventReportV1#event_level}
    */
    readonly eventLevel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_event_report_v1#event_state CesEventReportV1#event_state}
    */
    readonly eventState?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_event_report_v1#event_type CesEventReportV1#event_type}
    */
    readonly eventType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_event_report_v1#event_user CesEventReportV1#event_user}
    */
    readonly eventUser?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_event_report_v1#group_id CesEventReportV1#group_id}
    */
    readonly groupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_event_report_v1#resource_id CesEventReportV1#resource_id}
    */
    readonly resourceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_event_report_v1#resource_name CesEventReportV1#resource_name}
    */
    readonly resourceName?: string;
}
export declare function cesEventReportV1DetailToTerraform(struct?: CesEventReportV1DetailOutputReference | CesEventReportV1Detail): any;
export declare function cesEventReportV1DetailToHclTerraform(struct?: CesEventReportV1DetailOutputReference | CesEventReportV1Detail): any;
export declare class CesEventReportV1DetailOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesEventReportV1Detail | undefined;
    set internalValue(value: CesEventReportV1Detail | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    resetContent(): void;
    get contentInput(): string | undefined;
    private _eventLevel?;
    get eventLevel(): string;
    set eventLevel(value: string);
    resetEventLevel(): void;
    get eventLevelInput(): string | undefined;
    private _eventState?;
    get eventState(): string;
    set eventState(value: string);
    resetEventState(): void;
    get eventStateInput(): string | undefined;
    private _eventType?;
    get eventType(): string;
    set eventType(value: string);
    resetEventType(): void;
    get eventTypeInput(): string | undefined;
    private _eventUser?;
    get eventUser(): string;
    set eventUser(value: string);
    resetEventUser(): void;
    get eventUserInput(): string | undefined;
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    resetGroupId(): void;
    get groupIdInput(): string | undefined;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    resetResourceId(): void;
    get resourceIdInput(): string | undefined;
    private _resourceName?;
    get resourceName(): string;
    set resourceName(value: string);
    resetResourceName(): void;
    get resourceNameInput(): string | undefined;
}
export interface CesEventReportV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_event_report_v1#create CesEventReportV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_event_report_v1#delete CesEventReportV1#delete}
    */
    readonly delete?: string;
}
export declare function cesEventReportV1TimeoutsToTerraform(struct?: CesEventReportV1Timeouts | cdktf.IResolvable): any;
export declare function cesEventReportV1TimeoutsToHclTerraform(struct?: CesEventReportV1Timeouts | cdktf.IResolvable): any;
export declare class CesEventReportV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesEventReportV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: CesEventReportV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_event_report_v1 opentelekomcloud_ces_event_report_v1}
*/
export declare class CesEventReportV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_ces_event_report_v1";
    /**
    * Generates CDKTF code for importing a CesEventReportV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CesEventReportV1 to import
    * @param importFromId The id of the existing CesEventReportV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_event_report_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CesEventReportV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ces_event_report_v1 opentelekomcloud_ces_event_report_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CesEventReportV1Config
    */
    constructor(scope: Construct, id: string, config: CesEventReportV1Config);
    get eventId(): string;
    private _eventName?;
    get eventName(): string;
    set eventName(value: string);
    get eventNameInput(): string | undefined;
    private _eventSource?;
    get eventSource(): string;
    set eventSource(value: string);
    get eventSourceInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _time?;
    get time(): number;
    set time(value: number);
    get timeInput(): number | undefined;
    private _detail;
    get detail(): CesEventReportV1DetailOutputReference;
    putDetail(value: CesEventReportV1Detail): void;
    get detailInput(): CesEventReportV1Detail | undefined;
    private _timeouts;
    get timeouts(): CesEventReportV1TimeoutsOutputReference;
    putTimeouts(value: CesEventReportV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | CesEventReportV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

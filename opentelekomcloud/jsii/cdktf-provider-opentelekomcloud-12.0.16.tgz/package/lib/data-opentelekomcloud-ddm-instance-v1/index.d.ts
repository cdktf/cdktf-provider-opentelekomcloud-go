/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudDdmInstanceV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ddm_instance_v1#id DataOpentelekomcloudDdmInstanceV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ddm_instance_v1#instance_id DataOpentelekomcloudDdmInstanceV1#instance_id}
    */
    readonly instanceId: string;
}
export interface DataOpentelekomcloudDdmInstanceV1Nodes {
}
export declare function dataOpentelekomcloudDdmInstanceV1NodesToTerraform(struct?: DataOpentelekomcloudDdmInstanceV1Nodes): any;
export declare function dataOpentelekomcloudDdmInstanceV1NodesToHclTerraform(struct?: DataOpentelekomcloudDdmInstanceV1Nodes): any;
export declare class DataOpentelekomcloudDdmInstanceV1NodesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudDdmInstanceV1Nodes | undefined;
    set internalValue(value: DataOpentelekomcloudDdmInstanceV1Nodes | undefined);
    get ip(): string;
    get port(): string;
    get status(): string;
}
export declare class DataOpentelekomcloudDdmInstanceV1NodesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudDdmInstanceV1NodesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ddm_instance_v1 opentelekomcloud_ddm_instance_v1}
*/
export declare class DataOpentelekomcloudDdmInstanceV1 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_ddm_instance_v1";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudDdmInstanceV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudDdmInstanceV1 to import
    * @param importFromId The id of the existing DataOpentelekomcloudDdmInstanceV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ddm_instance_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudDdmInstanceV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/ddm_instance_v1 opentelekomcloud_ddm_instance_v1} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudDdmInstanceV1Config
    */
    constructor(scope: Construct, id: string, config: DataOpentelekomcloudDdmInstanceV1Config);
    get accessIp(): string;
    get accessPort(): string;
    get availabilityZone(): string;
    get createdAt(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get name(): string;
    get nodeNum(): number;
    get nodeStatus(): string;
    private _nodes;
    get nodes(): DataOpentelekomcloudDdmInstanceV1NodesList;
    get region(): string;
    get securityGroupId(): string;
    get status(): string;
    get subnetId(): string;
    get updatedAt(): string;
    get username(): string;
    get vpcId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

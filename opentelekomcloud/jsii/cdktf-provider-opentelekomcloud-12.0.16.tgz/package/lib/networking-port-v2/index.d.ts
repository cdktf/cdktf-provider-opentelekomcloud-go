/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface NetworkingPortV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_port_v2#admin_state_up NetworkingPortV2#admin_state_up}
    */
    readonly adminStateUp?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_port_v2#device_id NetworkingPortV2#device_id}
    */
    readonly deviceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_port_v2#device_owner NetworkingPortV2#device_owner}
    */
    readonly deviceOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_port_v2#id NetworkingPortV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_port_v2#name NetworkingPortV2#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_port_v2#network_id NetworkingPortV2#network_id}
    */
    readonly networkId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_port_v2#no_security_groups NetworkingPortV2#no_security_groups}
    */
    readonly noSecurityGroups?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_port_v2#port_security_enabled NetworkingPortV2#port_security_enabled}
    */
    readonly portSecurityEnabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_port_v2#region NetworkingPortV2#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_port_v2#security_group_ids NetworkingPortV2#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_port_v2#value_specs NetworkingPortV2#value_specs}
    */
    readonly valueSpecs?: {
        [key: string]: string;
    };
    /**
    * allowed_address_pairs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_port_v2#allowed_address_pairs NetworkingPortV2#allowed_address_pairs}
    */
    readonly allowedAddressPairs?: NetworkingPortV2AllowedAddressPairs[] | cdktf.IResolvable;
    /**
    * extra_dhcp_option block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_port_v2#extra_dhcp_option NetworkingPortV2#extra_dhcp_option}
    */
    readonly extraDhcpOption?: NetworkingPortV2ExtraDhcpOption[] | cdktf.IResolvable;
    /**
    * fixed_ip block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_port_v2#fixed_ip NetworkingPortV2#fixed_ip}
    */
    readonly fixedIp?: NetworkingPortV2FixedIp;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_port_v2#timeouts NetworkingPortV2#timeouts}
    */
    readonly timeouts?: NetworkingPortV2Timeouts;
}
export interface NetworkingPortV2AllowedAddressPairs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_port_v2#ip_address NetworkingPortV2#ip_address}
    */
    readonly ipAddress: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_port_v2#mac_address NetworkingPortV2#mac_address}
    */
    readonly macAddress?: string;
}
export declare function networkingPortV2AllowedAddressPairsToTerraform(struct?: NetworkingPortV2AllowedAddressPairs | cdktf.IResolvable): any;
export declare function networkingPortV2AllowedAddressPairsToHclTerraform(struct?: NetworkingPortV2AllowedAddressPairs | cdktf.IResolvable): any;
export declare class NetworkingPortV2AllowedAddressPairsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NetworkingPortV2AllowedAddressPairs | cdktf.IResolvable | undefined;
    set internalValue(value: NetworkingPortV2AllowedAddressPairs | cdktf.IResolvable | undefined);
    private _ipAddress?;
    get ipAddress(): string;
    set ipAddress(value: string);
    get ipAddressInput(): string | undefined;
    private _macAddress?;
    get macAddress(): string;
    set macAddress(value: string);
    resetMacAddress(): void;
    get macAddressInput(): string | undefined;
}
export declare class NetworkingPortV2AllowedAddressPairsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: NetworkingPortV2AllowedAddressPairs[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NetworkingPortV2AllowedAddressPairsOutputReference;
}
export interface NetworkingPortV2ExtraDhcpOption {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_port_v2#name NetworkingPortV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_port_v2#value NetworkingPortV2#value}
    */
    readonly value: string;
}
export declare function networkingPortV2ExtraDhcpOptionToTerraform(struct?: NetworkingPortV2ExtraDhcpOption | cdktf.IResolvable): any;
export declare function networkingPortV2ExtraDhcpOptionToHclTerraform(struct?: NetworkingPortV2ExtraDhcpOption | cdktf.IResolvable): any;
export declare class NetworkingPortV2ExtraDhcpOptionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NetworkingPortV2ExtraDhcpOption | cdktf.IResolvable | undefined;
    set internalValue(value: NetworkingPortV2ExtraDhcpOption | cdktf.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class NetworkingPortV2ExtraDhcpOptionList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: NetworkingPortV2ExtraDhcpOption[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NetworkingPortV2ExtraDhcpOptionOutputReference;
}
export interface NetworkingPortV2FixedIp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_port_v2#ip_address NetworkingPortV2#ip_address}
    */
    readonly ipAddress?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_port_v2#subnet_id NetworkingPortV2#subnet_id}
    */
    readonly subnetId: string;
}
export declare function networkingPortV2FixedIpToTerraform(struct?: NetworkingPortV2FixedIpOutputReference | NetworkingPortV2FixedIp): any;
export declare function networkingPortV2FixedIpToHclTerraform(struct?: NetworkingPortV2FixedIpOutputReference | NetworkingPortV2FixedIp): any;
export declare class NetworkingPortV2FixedIpOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NetworkingPortV2FixedIp | undefined;
    set internalValue(value: NetworkingPortV2FixedIp | undefined);
    private _ipAddress?;
    get ipAddress(): string;
    set ipAddress(value: string);
    resetIpAddress(): void;
    get ipAddressInput(): string | undefined;
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    get subnetIdInput(): string | undefined;
}
export interface NetworkingPortV2Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_port_v2#create NetworkingPortV2#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_port_v2#delete NetworkingPortV2#delete}
    */
    readonly delete?: string;
}
export declare function networkingPortV2TimeoutsToTerraform(struct?: NetworkingPortV2Timeouts | cdktf.IResolvable): any;
export declare function networkingPortV2TimeoutsToHclTerraform(struct?: NetworkingPortV2Timeouts | cdktf.IResolvable): any;
export declare class NetworkingPortV2TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NetworkingPortV2Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: NetworkingPortV2Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_port_v2 opentelekomcloud_networking_port_v2}
*/
export declare class NetworkingPortV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_networking_port_v2";
    /**
    * Generates CDKTF code for importing a NetworkingPortV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the NetworkingPortV2 to import
    * @param importFromId The id of the existing NetworkingPortV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_port_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the NetworkingPortV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/networking_port_v2 opentelekomcloud_networking_port_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NetworkingPortV2Config
    */
    constructor(scope: Construct, id: string, config: NetworkingPortV2Config);
    private _adminStateUp?;
    get adminStateUp(): boolean | cdktf.IResolvable;
    set adminStateUp(value: boolean | cdktf.IResolvable);
    resetAdminStateUp(): void;
    get adminStateUpInput(): boolean | cdktf.IResolvable | undefined;
    get allFixedIps(): string[];
    private _deviceId?;
    get deviceId(): string;
    set deviceId(value: string);
    resetDeviceId(): void;
    get deviceIdInput(): string | undefined;
    private _deviceOwner?;
    get deviceOwner(): string;
    set deviceOwner(value: string);
    resetDeviceOwner(): void;
    get deviceOwnerInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get macAddress(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _networkId?;
    get networkId(): string;
    set networkId(value: string);
    get networkIdInput(): string | undefined;
    private _noSecurityGroups?;
    get noSecurityGroups(): boolean | cdktf.IResolvable;
    set noSecurityGroups(value: boolean | cdktf.IResolvable);
    resetNoSecurityGroups(): void;
    get noSecurityGroupsInput(): boolean | cdktf.IResolvable | undefined;
    private _portSecurityEnabled?;
    get portSecurityEnabled(): boolean | cdktf.IResolvable;
    set portSecurityEnabled(value: boolean | cdktf.IResolvable);
    resetPortSecurityEnabled(): void;
    get portSecurityEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _valueSpecs?;
    get valueSpecs(): {
        [key: string]: string;
    };
    set valueSpecs(value: {
        [key: string]: string;
    });
    resetValueSpecs(): void;
    get valueSpecsInput(): {
        [key: string]: string;
    } | undefined;
    private _allowedAddressPairs;
    get allowedAddressPairs(): NetworkingPortV2AllowedAddressPairsList;
    putAllowedAddressPairs(value: NetworkingPortV2AllowedAddressPairs[] | cdktf.IResolvable): void;
    resetAllowedAddressPairs(): void;
    get allowedAddressPairsInput(): cdktf.IResolvable | NetworkingPortV2AllowedAddressPairs[] | undefined;
    private _extraDhcpOption;
    get extraDhcpOption(): NetworkingPortV2ExtraDhcpOptionList;
    putExtraDhcpOption(value: NetworkingPortV2ExtraDhcpOption[] | cdktf.IResolvable): void;
    resetExtraDhcpOption(): void;
    get extraDhcpOptionInput(): cdktf.IResolvable | NetworkingPortV2ExtraDhcpOption[] | undefined;
    private _fixedIp;
    get fixedIp(): NetworkingPortV2FixedIpOutputReference;
    putFixedIp(value: NetworkingPortV2FixedIp): void;
    resetFixedIp(): void;
    get fixedIpInput(): NetworkingPortV2FixedIp | undefined;
    private _timeouts;
    get timeouts(): NetworkingPortV2TimeoutsOutputReference;
    putTimeouts(value: NetworkingPortV2Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | NetworkingPortV2Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

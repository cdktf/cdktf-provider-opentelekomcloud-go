/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudRmsPolicyStatesV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/rms_policy_states_v1#compliance_state DataOpentelekomcloudRmsPolicyStatesV1#compliance_state}
    */
    readonly complianceState?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/rms_policy_states_v1#id DataOpentelekomcloudRmsPolicyStatesV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/rms_policy_states_v1#policy_assignment_id DataOpentelekomcloudRmsPolicyStatesV1#policy_assignment_id}
    */
    readonly policyAssignmentId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/rms_policy_states_v1#resource_id DataOpentelekomcloudRmsPolicyStatesV1#resource_id}
    */
    readonly resourceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/rms_policy_states_v1#resource_name DataOpentelekomcloudRmsPolicyStatesV1#resource_name}
    */
    readonly resourceName?: string;
}
export interface DataOpentelekomcloudRmsPolicyStatesV1States {
}
export declare function dataOpentelekomcloudRmsPolicyStatesV1StatesToTerraform(struct?: DataOpentelekomcloudRmsPolicyStatesV1States): any;
export declare function dataOpentelekomcloudRmsPolicyStatesV1StatesToHclTerraform(struct?: DataOpentelekomcloudRmsPolicyStatesV1States): any;
export declare class DataOpentelekomcloudRmsPolicyStatesV1StatesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudRmsPolicyStatesV1States | undefined;
    set internalValue(value: DataOpentelekomcloudRmsPolicyStatesV1States | undefined);
    get complianceState(): string;
    get domainId(): string;
    get evaluationTime(): string;
    get policyAssignmentId(): string;
    get policyAssignmentName(): string;
    get policyDefinitionId(): string;
    get regionId(): string;
    get resourceId(): string;
    get resourceName(): string;
    get resourceProvider(): string;
    get resourceType(): string;
    get triggerType(): string;
}
export declare class DataOpentelekomcloudRmsPolicyStatesV1StatesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudRmsPolicyStatesV1StatesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/rms_policy_states_v1 opentelekomcloud_rms_policy_states_v1}
*/
export declare class DataOpentelekomcloudRmsPolicyStatesV1 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_rms_policy_states_v1";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudRmsPolicyStatesV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudRmsPolicyStatesV1 to import
    * @param importFromId The id of the existing DataOpentelekomcloudRmsPolicyStatesV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/rms_policy_states_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudRmsPolicyStatesV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/rms_policy_states_v1 opentelekomcloud_rms_policy_states_v1} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudRmsPolicyStatesV1Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudRmsPolicyStatesV1Config);
    private _complianceState?;
    get complianceState(): string;
    set complianceState(value: string);
    resetComplianceState(): void;
    get complianceStateInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _policyAssignmentId?;
    get policyAssignmentId(): string;
    set policyAssignmentId(value: string);
    resetPolicyAssignmentId(): void;
    get policyAssignmentIdInput(): string | undefined;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    resetResourceId(): void;
    get resourceIdInput(): string | undefined;
    private _resourceName?;
    get resourceName(): string;
    set resourceName(value: string);
    resetResourceName(): void;
    get resourceNameInput(): string | undefined;
    private _states;
    get states(): DataOpentelekomcloudRmsPolicyStatesV1StatesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

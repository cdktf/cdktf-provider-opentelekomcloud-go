/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DmsSmartConnectTaskActionV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_action_v2#action DmsSmartConnectTaskActionV2#action}
    */
    readonly action: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_action_v2#id DmsSmartConnectTaskActionV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_action_v2#instance_id DmsSmartConnectTaskActionV2#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_action_v2#task_id DmsSmartConnectTaskActionV2#task_id}
    */
    readonly taskId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_action_v2#timeouts DmsSmartConnectTaskActionV2#timeouts}
    */
    readonly timeouts?: DmsSmartConnectTaskActionV2Timeouts;
}
export interface DmsSmartConnectTaskActionV2Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_action_v2#create DmsSmartConnectTaskActionV2#create}
    */
    readonly create?: string;
}
export declare function dmsSmartConnectTaskActionV2TimeoutsToTerraform(struct?: DmsSmartConnectTaskActionV2Timeouts | cdktf.IResolvable): any;
export declare function dmsSmartConnectTaskActionV2TimeoutsToHclTerraform(struct?: DmsSmartConnectTaskActionV2Timeouts | cdktf.IResolvable): any;
export declare class DmsSmartConnectTaskActionV2TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DmsSmartConnectTaskActionV2Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DmsSmartConnectTaskActionV2Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_action_v2 opentelekomcloud_dms_smart_connect_task_action_v2}
*/
export declare class DmsSmartConnectTaskActionV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_dms_smart_connect_task_action_v2";
    /**
    * Generates CDKTF code for importing a DmsSmartConnectTaskActionV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DmsSmartConnectTaskActionV2 to import
    * @param importFromId The id of the existing DmsSmartConnectTaskActionV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_action_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DmsSmartConnectTaskActionV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_action_v2 opentelekomcloud_dms_smart_connect_task_action_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DmsSmartConnectTaskActionV2Config
    */
    constructor(scope: Construct, id: string, config: DmsSmartConnectTaskActionV2Config);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get region(): string;
    private _taskId?;
    get taskId(): string;
    set taskId(value: string);
    get taskIdInput(): string | undefined;
    get taskStatus(): string;
    private _timeouts;
    get timeouts(): DmsSmartConnectTaskActionV2TimeoutsOutputReference;
    putTimeouts(value: DmsSmartConnectTaskActionV2Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DmsSmartConnectTaskActionV2Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

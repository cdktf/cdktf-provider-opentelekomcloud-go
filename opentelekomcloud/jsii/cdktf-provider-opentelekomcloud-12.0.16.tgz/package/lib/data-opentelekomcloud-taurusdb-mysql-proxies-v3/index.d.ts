/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudTaurusdbMysqlProxiesV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_proxies_v3#id DataOpentelekomcloudTaurusdbMysqlProxiesV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_proxies_v3#instance_id DataOpentelekomcloudTaurusdbMysqlProxiesV3#instance_id}
    */
    readonly instanceId: string;
}
export interface DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListMasterNodeWeight {
}
export declare function dataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListMasterNodeWeightToTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListMasterNodeWeight): any;
export declare function dataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListMasterNodeWeightToHclTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListMasterNodeWeight): any;
export declare class DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListMasterNodeWeightOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListMasterNodeWeight | undefined;
    set internalValue(value: DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListMasterNodeWeight | undefined);
    get id(): string;
    get name(): string;
    get weight(): number;
}
export declare class DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListMasterNodeWeightList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListMasterNodeWeightOutputReference;
}
export interface DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListNodes {
}
export declare function dataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListNodesToTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListNodes): any;
export declare function dataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListNodesToHclTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListNodes): any;
export declare class DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListNodesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListNodes | undefined;
    set internalValue(value: DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListNodes | undefined);
    get azCode(): string;
    get frozenFlag(): number;
    get id(): string;
    get name(): string;
    get role(): string;
    get status(): string;
}
export declare class DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListNodesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListNodesOutputReference;
}
export interface DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListReadonlyNodesWeight {
}
export declare function dataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListReadonlyNodesWeightToTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListReadonlyNodesWeight): any;
export declare function dataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListReadonlyNodesWeightToHclTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListReadonlyNodesWeight): any;
export declare class DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListReadonlyNodesWeightOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListReadonlyNodesWeight | undefined;
    set internalValue(value: DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListReadonlyNodesWeight | undefined);
    get id(): string;
    get name(): string;
    get weight(): number;
}
export declare class DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListReadonlyNodesWeightList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListReadonlyNodesWeightOutputReference;
}
export interface DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListStruct {
}
export declare function dataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListStructToTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListStruct): any;
export declare function dataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListStructToHclTerraform(struct?: DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListStruct): any;
export declare class DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListStructOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListStruct | undefined;
    set internalValue(value: DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListStruct | undefined);
    get address(): string;
    get delayThresholdInSeconds(): number;
    get elbVip(): string;
    get flavor(): string;
    get id(): string;
    private _masterNodeWeight;
    get masterNodeWeight(): DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListMasterNodeWeightList;
    get mode(): string;
    get name(): string;
    get nodeNum(): number;
    private _nodes;
    get nodes(): DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListNodesList;
    get port(): number;
    get ram(): string;
    private _readonlyNodesWeight;
    get readonlyNodesWeight(): DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListReadonlyNodesWeightList;
    get status(): string;
    get transactionSplit(): string;
    get vcpus(): string;
}
export declare class DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListStructList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListStructOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_proxies_v3 opentelekomcloud_taurusdb_mysql_proxies_v3}
*/
export declare class DataOpentelekomcloudTaurusdbMysqlProxiesV3 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_taurusdb_mysql_proxies_v3";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudTaurusdbMysqlProxiesV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudTaurusdbMysqlProxiesV3 to import
    * @param importFromId The id of the existing DataOpentelekomcloudTaurusdbMysqlProxiesV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_proxies_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudTaurusdbMysqlProxiesV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/taurusdb_mysql_proxies_v3 opentelekomcloud_taurusdb_mysql_proxies_v3} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudTaurusdbMysqlProxiesV3Config
    */
    constructor(scope: Construct, id: string, config: DataOpentelekomcloudTaurusdbMysqlProxiesV3Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _proxyList;
    get proxyList(): DataOpentelekomcloudTaurusdbMysqlProxiesV3ProxyListStructList;
    get region(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudAsmServiceMeshV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/asm_service_mesh_v1#id DataOpentelekomcloudAsmServiceMeshV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataOpentelekomcloudAsmServiceMeshV1ServiceMeshesProxyConfig {
}
export declare function dataOpentelekomcloudAsmServiceMeshV1ServiceMeshesProxyConfigToTerraform(struct?: DataOpentelekomcloudAsmServiceMeshV1ServiceMeshesProxyConfig): any;
export declare function dataOpentelekomcloudAsmServiceMeshV1ServiceMeshesProxyConfigToHclTerraform(struct?: DataOpentelekomcloudAsmServiceMeshV1ServiceMeshesProxyConfig): any;
export declare class DataOpentelekomcloudAsmServiceMeshV1ServiceMeshesProxyConfigOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudAsmServiceMeshV1ServiceMeshesProxyConfig | undefined;
    set internalValue(value: DataOpentelekomcloudAsmServiceMeshV1ServiceMeshesProxyConfig | undefined);
    get excludeInboundPorts(): string;
    get excludeIpRanges(): string;
    get excludeOutboundPorts(): string;
    get includeInboundPorts(): string;
    get includeIpRanges(): string;
    get includeOutboundPorts(): string;
}
export declare class DataOpentelekomcloudAsmServiceMeshV1ServiceMeshesProxyConfigList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudAsmServiceMeshV1ServiceMeshesProxyConfigOutputReference;
}
export interface DataOpentelekomcloudAsmServiceMeshV1ServiceMeshesTelemetryConfigTracingExtensionProviders {
}
export declare function dataOpentelekomcloudAsmServiceMeshV1ServiceMeshesTelemetryConfigTracingExtensionProvidersToTerraform(struct?: DataOpentelekomcloudAsmServiceMeshV1ServiceMeshesTelemetryConfigTracingExtensionProviders): any;
export declare function dataOpentelekomcloudAsmServiceMeshV1ServiceMeshesTelemetryConfigTracingExtensionProvidersToHclTerraform(struct?: DataOpentelekomcloudAsmServiceMeshV1ServiceMeshesTelemetryConfigTracingExtensionProviders): any;
export declare class DataOpentelekomcloudAsmServiceMeshV1ServiceMeshesTelemetryConfigTracingExtensionProvidersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudAsmServiceMeshV1ServiceMeshesTelemetryConfigTracingExtensionProviders | undefined;
    set internalValue(value: DataOpentelekomcloudAsmServiceMeshV1ServiceMeshesTelemetryConfigTracingExtensionProviders | undefined);
    get name(): string;
    get zipkinServiceAddr(): string;
    get zipkinServicePort(): number;
}
export declare class DataOpentelekomcloudAsmServiceMeshV1ServiceMeshesTelemetryConfigTracingExtensionProvidersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudAsmServiceMeshV1ServiceMeshesTelemetryConfigTracingExtensionProvidersOutputReference;
}
export interface DataOpentelekomcloudAsmServiceMeshV1ServiceMeshesTelemetryConfigTracing {
}
export declare function dataOpentelekomcloudAsmServiceMeshV1ServiceMeshesTelemetryConfigTracingToTerraform(struct?: DataOpentelekomcloudAsmServiceMeshV1ServiceMeshesTelemetryConfigTracing): any;
export declare function dataOpentelekomcloudAsmServiceMeshV1ServiceMeshesTelemetryConfigTracingToHclTerraform(struct?: DataOpentelekomcloudAsmServiceMeshV1ServiceMeshesTelemetryConfigTracing): any;
export declare class DataOpentelekomcloudAsmServiceMeshV1ServiceMeshesTelemetryConfigTracingOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudAsmServiceMeshV1ServiceMeshesTelemetryConfigTracing | undefined;
    set internalValue(value: DataOpentelekomcloudAsmServiceMeshV1ServiceMeshesTelemetryConfigTracing | undefined);
    get defaultProviders(): string[];
    private _extensionProviders;
    get extensionProviders(): DataOpentelekomcloudAsmServiceMeshV1ServiceMeshesTelemetryConfigTracingExtensionProvidersList;
    get randomSamplingPercentage(): number;
}
export declare class DataOpentelekomcloudAsmServiceMeshV1ServiceMeshesTelemetryConfigTracingList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudAsmServiceMeshV1ServiceMeshesTelemetryConfigTracingOutputReference;
}
export interface DataOpentelekomcloudAsmServiceMeshV1ServiceMeshes {
}
export declare function dataOpentelekomcloudAsmServiceMeshV1ServiceMeshesToTerraform(struct?: DataOpentelekomcloudAsmServiceMeshV1ServiceMeshes): any;
export declare function dataOpentelekomcloudAsmServiceMeshV1ServiceMeshesToHclTerraform(struct?: DataOpentelekomcloudAsmServiceMeshV1ServiceMeshes): any;
export declare class DataOpentelekomcloudAsmServiceMeshV1ServiceMeshesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudAsmServiceMeshV1ServiceMeshes | undefined;
    set internalValue(value: DataOpentelekomcloudAsmServiceMeshV1ServiceMeshes | undefined);
    get clusterIds(): string[];
    get creationTimestamp(): string;
    get id(): string;
    get ipv6Enable(): cdktf.IResolvable;
    get name(): string;
    private _proxyConfig;
    get proxyConfig(): DataOpentelekomcloudAsmServiceMeshV1ServiceMeshesProxyConfigList;
    get status(): string;
    private _telemetryConfigTracing;
    get telemetryConfigTracing(): DataOpentelekomcloudAsmServiceMeshV1ServiceMeshesTelemetryConfigTracingList;
    get type(): string;
    get version(): string;
}
export declare class DataOpentelekomcloudAsmServiceMeshV1ServiceMeshesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudAsmServiceMeshV1ServiceMeshesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/asm_service_mesh_v1 opentelekomcloud_asm_service_mesh_v1}
*/
export declare class DataOpentelekomcloudAsmServiceMeshV1 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_asm_service_mesh_v1";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudAsmServiceMeshV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudAsmServiceMeshV1 to import
    * @param importFromId The id of the existing DataOpentelekomcloudAsmServiceMeshV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/asm_service_mesh_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudAsmServiceMeshV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/asm_service_mesh_v1 opentelekomcloud_asm_service_mesh_v1} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudAsmServiceMeshV1Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudAsmServiceMeshV1Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _serviceMeshes;
    get serviceMeshes(): DataOpentelekomcloudAsmServiceMeshV1ServiceMeshesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

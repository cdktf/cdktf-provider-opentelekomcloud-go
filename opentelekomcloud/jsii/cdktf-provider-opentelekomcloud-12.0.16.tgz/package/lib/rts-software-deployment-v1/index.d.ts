/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface RtsSoftwareDeploymentV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rts_software_deployment_v1#action RtsSoftwareDeploymentV1#action}
    */
    readonly action?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rts_software_deployment_v1#config_id RtsSoftwareDeploymentV1#config_id}
    */
    readonly configId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rts_software_deployment_v1#id RtsSoftwareDeploymentV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rts_software_deployment_v1#input_values RtsSoftwareDeploymentV1#input_values}
    */
    readonly inputValues?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rts_software_deployment_v1#output_values RtsSoftwareDeploymentV1#output_values}
    */
    readonly outputValues?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rts_software_deployment_v1#region RtsSoftwareDeploymentV1#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rts_software_deployment_v1#server_id RtsSoftwareDeploymentV1#server_id}
    */
    readonly serverId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rts_software_deployment_v1#status RtsSoftwareDeploymentV1#status}
    */
    readonly status?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rts_software_deployment_v1#status_reason RtsSoftwareDeploymentV1#status_reason}
    */
    readonly statusReason?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rts_software_deployment_v1#tenant_id RtsSoftwareDeploymentV1#tenant_id}
    */
    readonly tenantId?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rts_software_deployment_v1#timeouts RtsSoftwareDeploymentV1#timeouts}
    */
    readonly timeouts?: RtsSoftwareDeploymentV1Timeouts;
}
export interface RtsSoftwareDeploymentV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rts_software_deployment_v1#create RtsSoftwareDeploymentV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rts_software_deployment_v1#delete RtsSoftwareDeploymentV1#delete}
    */
    readonly delete?: string;
}
export declare function rtsSoftwareDeploymentV1TimeoutsToTerraform(struct?: RtsSoftwareDeploymentV1Timeouts | cdktf.IResolvable): any;
export declare function rtsSoftwareDeploymentV1TimeoutsToHclTerraform(struct?: RtsSoftwareDeploymentV1Timeouts | cdktf.IResolvable): any;
export declare class RtsSoftwareDeploymentV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RtsSoftwareDeploymentV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: RtsSoftwareDeploymentV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rts_software_deployment_v1 opentelekomcloud_rts_software_deployment_v1}
*/
export declare class RtsSoftwareDeploymentV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_rts_software_deployment_v1";
    /**
    * Generates CDKTF code for importing a RtsSoftwareDeploymentV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RtsSoftwareDeploymentV1 to import
    * @param importFromId The id of the existing RtsSoftwareDeploymentV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rts_software_deployment_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RtsSoftwareDeploymentV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rts_software_deployment_v1 opentelekomcloud_rts_software_deployment_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RtsSoftwareDeploymentV1Config
    */
    constructor(scope: Construct, id: string, config: RtsSoftwareDeploymentV1Config);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _configId?;
    get configId(): string;
    set configId(value: string);
    get configIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _inputValues?;
    get inputValues(): {
        [key: string]: string;
    };
    set inputValues(value: {
        [key: string]: string;
    });
    resetInputValues(): void;
    get inputValuesInput(): {
        [key: string]: string;
    } | undefined;
    private _outputValues?;
    get outputValues(): {
        [key: string]: string;
    };
    set outputValues(value: {
        [key: string]: string;
    });
    resetOutputValues(): void;
    get outputValuesInput(): {
        [key: string]: string;
    } | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serverId?;
    get serverId(): string;
    set serverId(value: string);
    get serverIdInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _statusReason?;
    get statusReason(): string;
    set statusReason(value: string);
    resetStatusReason(): void;
    get statusReasonInput(): string | undefined;
    private _tenantId?;
    get tenantId(): string;
    set tenantId(value: string);
    resetTenantId(): void;
    get tenantIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): RtsSoftwareDeploymentV1TimeoutsOutputReference;
    putTimeouts(value: RtsSoftwareDeploymentV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | RtsSoftwareDeploymentV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

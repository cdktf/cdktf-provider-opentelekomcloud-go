/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudComputeInstanceV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/compute_instance_v2#id DataOpentelekomcloudComputeInstanceV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/compute_instance_v2#name DataOpentelekomcloudComputeInstanceV2#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/compute_instance_v2#region DataOpentelekomcloudComputeInstanceV2#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/compute_instance_v2#ssh_private_key_path DataOpentelekomcloudComputeInstanceV2#ssh_private_key_path}
    */
    readonly sshPrivateKeyPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/compute_instance_v2#tags DataOpentelekomcloudComputeInstanceV2#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/compute_instance_v2#user_data DataOpentelekomcloudComputeInstanceV2#user_data}
    */
    readonly userData?: string;
    /**
    * network block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/compute_instance_v2#network DataOpentelekomcloudComputeInstanceV2#network}
    */
    readonly network?: DataOpentelekomcloudComputeInstanceV2Network[] | cdktf.IResolvable;
}
export interface DataOpentelekomcloudComputeInstanceV2Network {
}
export declare function dataOpentelekomcloudComputeInstanceV2NetworkToTerraform(struct?: DataOpentelekomcloudComputeInstanceV2Network | cdktf.IResolvable): any;
export declare function dataOpentelekomcloudComputeInstanceV2NetworkToHclTerraform(struct?: DataOpentelekomcloudComputeInstanceV2Network | cdktf.IResolvable): any;
export declare class DataOpentelekomcloudComputeInstanceV2NetworkOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudComputeInstanceV2Network | cdktf.IResolvable | undefined;
    set internalValue(value: DataOpentelekomcloudComputeInstanceV2Network | cdktf.IResolvable | undefined);
    get fixedIpV4(): string;
    get fixedIpV6(): string;
    get mac(): string;
    get name(): string;
    get port(): string;
    get uuid(): string;
}
export declare class DataOpentelekomcloudComputeInstanceV2NetworkList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataOpentelekomcloudComputeInstanceV2Network[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudComputeInstanceV2NetworkOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/compute_instance_v2 opentelekomcloud_compute_instance_v2}
*/
export declare class DataOpentelekomcloudComputeInstanceV2 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_compute_instance_v2";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudComputeInstanceV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudComputeInstanceV2 to import
    * @param importFromId The id of the existing DataOpentelekomcloudComputeInstanceV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/compute_instance_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudComputeInstanceV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/compute_instance_v2 opentelekomcloud_compute_instance_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudComputeInstanceV2Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudComputeInstanceV2Config);
    get accessIpV4(): string;
    get accessIpV6(): string;
    get adminPass(): string;
    get availabilityZone(): string;
    get description(): string;
    get encryptedPassword(): string;
    get flavorId(): string;
    get flavorName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get imageId(): string;
    get imageName(): string;
    get keyPair(): string;
    private _metadata;
    get metadata(): cdktf.StringMap;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get password(): string;
    get powerState(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get securityGroups(): string[];
    private _sshPrivateKeyPath?;
    get sshPrivateKeyPath(): string;
    set sshPrivateKeyPath(value: string);
    resetSshPrivateKeyPath(): void;
    get sshPrivateKeyPathInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _userData?;
    get userData(): string;
    set userData(value: string);
    resetUserData(): void;
    get userDataInput(): string | undefined;
    private _network;
    get network(): DataOpentelekomcloudComputeInstanceV2NetworkList;
    putNetwork(value: DataOpentelekomcloudComputeInstanceV2Network[] | cdktf.IResolvable): void;
    resetNetwork(): void;
    get networkInput(): cdktf.IResolvable | DataOpentelekomcloudComputeInstanceV2Network[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

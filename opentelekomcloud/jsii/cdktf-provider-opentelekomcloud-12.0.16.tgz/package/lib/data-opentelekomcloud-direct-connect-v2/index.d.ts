/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudDirectConnectV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/direct_connect_v2#bandwidth DataOpentelekomcloudDirectConnectV2#bandwidth}
    */
    readonly bandwidth?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/direct_connect_v2#description DataOpentelekomcloudDirectConnectV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/direct_connect_v2#device_id DataOpentelekomcloudDirectConnectV2#device_id}
    */
    readonly deviceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/direct_connect_v2#id DataOpentelekomcloudDirectConnectV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/direct_connect_v2#location DataOpentelekomcloudDirectConnectV2#location}
    */
    readonly location?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/direct_connect_v2#name DataOpentelekomcloudDirectConnectV2#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/direct_connect_v2#port_type DataOpentelekomcloudDirectConnectV2#port_type}
    */
    readonly portType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/direct_connect_v2#region DataOpentelekomcloudDirectConnectV2#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/direct_connect_v2#vlan DataOpentelekomcloudDirectConnectV2#vlan}
    */
    readonly vlan?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/direct_connect_v2 opentelekomcloud_direct_connect_v2}
*/
export declare class DataOpentelekomcloudDirectConnectV2 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_direct_connect_v2";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudDirectConnectV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudDirectConnectV2 to import
    * @param importFromId The id of the existing DataOpentelekomcloudDirectConnectV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/direct_connect_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudDirectConnectV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/direct_connect_v2 opentelekomcloud_direct_connect_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudDirectConnectV2Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudDirectConnectV2Config);
    get adminStateUp(): cdktf.IResolvable;
    get applicant(): string;
    get applyTime(): string;
    private _bandwidth?;
    get bandwidth(): number;
    set bandwidth(value: number);
    resetBandwidth(): void;
    get bandwidthInput(): number | undefined;
    get buildingLineProductId(): string;
    get cableLabel(): string;
    get chargeMode(): string;
    get createTime(): string;
    get deleteTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _deviceId?;
    get deviceId(): string;
    set deviceId(value: string);
    resetDeviceId(): void;
    get deviceIdInput(): string | undefined;
    get email(): string;
    get hostingId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get interfaceName(): string;
    get lagId(): string;
    get lastOnestopProductId(): string;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    get mobile(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get onestopProductId(): string;
    get orderId(): string;
    get peerLocation(): string;
    get peerPortType(): string;
    get peerProvider(): string;
    get periodNum(): number;
    get periodType(): number;
    private _portType?;
    get portType(): string;
    set portType(value: string);
    resetPortType(): void;
    get portTypeInput(): string | undefined;
    get productId(): string;
    get providerName(): string;
    get providerStatus(): string;
    get reason(): string;
    get redundantId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get regionId(): string;
    get serviceKey(): string;
    get specCode(): string;
    get status(): string;
    get tenantId(): string;
    get type(): string;
    get vgwType(): string;
    private _vlan?;
    get vlan(): number;
    set vlan(value: number);
    resetVlan(): void;
    get vlanInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

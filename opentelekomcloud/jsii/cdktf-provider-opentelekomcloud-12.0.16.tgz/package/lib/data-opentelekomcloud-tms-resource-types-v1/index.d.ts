/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudTmsResourceTypesV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/tms_resource_types_v1#id DataOpentelekomcloudTmsResourceTypesV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/tms_resource_types_v1#region DataOpentelekomcloudTmsResourceTypesV1#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/tms_resource_types_v1#service_name DataOpentelekomcloudTmsResourceTypesV1#service_name}
    */
    readonly serviceName?: string;
}
export interface DataOpentelekomcloudTmsResourceTypesV1Types {
}
export declare function dataOpentelekomcloudTmsResourceTypesV1TypesToTerraform(struct?: DataOpentelekomcloudTmsResourceTypesV1Types): any;
export declare function dataOpentelekomcloudTmsResourceTypesV1TypesToHclTerraform(struct?: DataOpentelekomcloudTmsResourceTypesV1Types): any;
export declare class DataOpentelekomcloudTmsResourceTypesV1TypesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudTmsResourceTypesV1Types | undefined;
    set internalValue(value: DataOpentelekomcloudTmsResourceTypesV1Types | undefined);
    get displayName(): string;
    get isGlobal(): cdktf.IResolvable;
    get name(): string;
    get serviceName(): string;
}
export declare class DataOpentelekomcloudTmsResourceTypesV1TypesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudTmsResourceTypesV1TypesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/tms_resource_types_v1 opentelekomcloud_tms_resource_types_v1}
*/
export declare class DataOpentelekomcloudTmsResourceTypesV1 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_tms_resource_types_v1";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudTmsResourceTypesV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudTmsResourceTypesV1 to import
    * @param importFromId The id of the existing DataOpentelekomcloudTmsResourceTypesV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/tms_resource_types_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudTmsResourceTypesV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/tms_resource_types_v1 opentelekomcloud_tms_resource_types_v1} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudTmsResourceTypesV1Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudTmsResourceTypesV1Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serviceName?;
    get serviceName(): string;
    set serviceName(value: string);
    resetServiceName(): void;
    get serviceNameInput(): string | undefined;
    private _types;
    get types(): DataOpentelekomcloudTmsResourceTypesV1TypesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudHssIntrusionEventsV5Config extends cdktf.TerraformMetaArguments {
    /**
    * Customized start time of a segment. The timestamp is accurate to seconds. The begin_time should be no more than two days earlier than the end_time. This parameter is mutually exclusive with the queried duration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_intrusion_events_v5#begin_time DataOpentelekomcloudHssIntrusionEventsV5#begin_time}
    */
    readonly beginTime?: string;
    /**
    * Event category. Its value can be: host (host security event) or container (container security event).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_intrusion_events_v5#category DataOpentelekomcloudHssIntrusionEventsV5#category}
    */
    readonly category: string;
    /**
    * Container instance name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_intrusion_events_v5#container_name DataOpentelekomcloudHssIntrusionEventsV5#container_name}
    */
    readonly containerName?: string;
    /**
    * Number of days to be queried. This parameter is mutually exclusive with begin_time and end_time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_intrusion_events_v5#days DataOpentelekomcloudHssIntrusionEventsV5#days}
    */
    readonly days?: number;
    /**
    * Customized end time of a segment. The timestamp is accurate to seconds. The begin_time should be no more than two days earlier than the end_time. This parameter is mutually exclusive with the queried duration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_intrusion_events_v5#end_time DataOpentelekomcloudHssIntrusionEventsV5#end_time}
    */
    readonly endTime?: string;
    /**
    * Enterprise project ID. The value 0 indicates the default enterprise project. To query all enterprise projects, set this parameter to all_granted_eps.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_intrusion_events_v5#enterprise_project_id DataOpentelekomcloudHssIntrusionEventsV5#enterprise_project_id}
    */
    readonly enterpriseProjectId?: string;
    /**
    * Intrusion types. Possible values include:
    * 1001: Malware
    * 1010: Rootkit
    * 1011: Ransomware
    * 1015: Web shell
    * 1017: Reverse shell
    * 2001: Common vulnerability exploit
    * 3002: File privilege escalation
    * 3003: Process privilege escalation
    * 3004: Important file change
    * 3005: File/Directory change
    * 3007: Abnormal process behavior
    * 3015: High-risk command execution
    * 3018: Abnormal shell
    * 3027: Suspicious crontab tasks
    * 4002: Brute-force attack
    * 4004: Abnormal login
    * 4006: Invalid system account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_intrusion_events_v5#event_types DataOpentelekomcloudHssIntrusionEventsV5#event_types}
    */
    readonly eventTypes?: string[];
    /**
    * Status. Possible values: unhandled, handled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_intrusion_events_v5#handle_status DataOpentelekomcloudHssIntrusionEventsV5#handle_status}
    */
    readonly handleStatus?: string;
    /**
    * Host ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_intrusion_events_v5#host_id DataOpentelekomcloudHssIntrusionEventsV5#host_id}
    */
    readonly hostId?: string;
    /**
    * Server name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_intrusion_events_v5#host_name DataOpentelekomcloudHssIntrusionEventsV5#host_name}
    */
    readonly hostName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_intrusion_events_v5#id DataOpentelekomcloudHssIntrusionEventsV5#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Server IP address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_intrusion_events_v5#private_ip DataOpentelekomcloudHssIntrusionEventsV5#private_ip}
    */
    readonly privateIp?: string;
    /**
    * Threat level. Possible values: Security, Low, Medium, High, Critical.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_intrusion_events_v5#severity DataOpentelekomcloudHssIntrusionEventsV5#severity}
    */
    readonly severity?: string;
}
export interface DataOpentelekomcloudHssIntrusionEventsV5EventsFileInfoListStruct {
}
export declare function dataOpentelekomcloudHssIntrusionEventsV5EventsFileInfoListStructToTerraform(struct?: DataOpentelekomcloudHssIntrusionEventsV5EventsFileInfoListStruct): any;
export declare function dataOpentelekomcloudHssIntrusionEventsV5EventsFileInfoListStructToHclTerraform(struct?: DataOpentelekomcloudHssIntrusionEventsV5EventsFileInfoListStruct): any;
export declare class DataOpentelekomcloudHssIntrusionEventsV5EventsFileInfoListStructOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudHssIntrusionEventsV5EventsFileInfoListStruct | undefined;
    set internalValue(value: DataOpentelekomcloudHssIntrusionEventsV5EventsFileInfoListStruct | undefined);
    get fdCount(): string;
    get fdInfo(): string;
    get fileAction(): string;
    get fileAlias(): string;
    get fileAtime(): string;
    get fileAttr(): string;
    get fileChangeAttr(): string;
    get fileContent(): string;
    get fileCtime(): string;
    get fileDesc(): string;
    get fileHash(): string;
    get fileKeyWord(): string;
    get fileMd5(): string;
    get fileMtime(): string;
    get fileNewPath(): string;
    get fileOperation(): string;
    get filePath(): string;
    get fileSha256(): string;
    get fileSize(): number;
    get fileType(): string;
    get isDir(): string;
}
export declare class DataOpentelekomcloudHssIntrusionEventsV5EventsFileInfoListStructList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudHssIntrusionEventsV5EventsFileInfoListStructOutputReference;
}
export interface DataOpentelekomcloudHssIntrusionEventsV5EventsOperateDetailListStruct {
}
export declare function dataOpentelekomcloudHssIntrusionEventsV5EventsOperateDetailListStructToTerraform(struct?: DataOpentelekomcloudHssIntrusionEventsV5EventsOperateDetailListStruct): any;
export declare function dataOpentelekomcloudHssIntrusionEventsV5EventsOperateDetailListStructToHclTerraform(struct?: DataOpentelekomcloudHssIntrusionEventsV5EventsOperateDetailListStruct): any;
export declare class DataOpentelekomcloudHssIntrusionEventsV5EventsOperateDetailListStructOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudHssIntrusionEventsV5EventsOperateDetailListStruct | undefined;
    set internalValue(value: DataOpentelekomcloudHssIntrusionEventsV5EventsOperateDetailListStruct | undefined);
    get agentId(): string;
    get fileAttr(): string;
    get fileHash(): string;
    get filePath(): string;
    get hash(): string;
    get isParent(): cdktf.IResolvable;
    get keyword(): string;
    get loginIp(): string;
    get loginUserName(): string;
    get privateIp(): string;
    get processPid(): number;
}
export declare class DataOpentelekomcloudHssIntrusionEventsV5EventsOperateDetailListStructList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudHssIntrusionEventsV5EventsOperateDetailListStructOutputReference;
}
export interface DataOpentelekomcloudHssIntrusionEventsV5EventsProcessInfoListStruct {
}
export declare function dataOpentelekomcloudHssIntrusionEventsV5EventsProcessInfoListStructToTerraform(struct?: DataOpentelekomcloudHssIntrusionEventsV5EventsProcessInfoListStruct): any;
export declare function dataOpentelekomcloudHssIntrusionEventsV5EventsProcessInfoListStructToHclTerraform(struct?: DataOpentelekomcloudHssIntrusionEventsV5EventsProcessInfoListStruct): any;
export declare class DataOpentelekomcloudHssIntrusionEventsV5EventsProcessInfoListStructOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudHssIntrusionEventsV5EventsProcessInfoListStruct | undefined;
    set internalValue(value: DataOpentelekomcloudHssIntrusionEventsV5EventsProcessInfoListStruct | undefined);
    get childProcessCmdline(): string;
    get childProcessEgid(): number;
    get childProcessEuid(): number;
    get childProcessFilename(): string;
    get childProcessGid(): number;
    get childProcessName(): string;
    get childProcessPath(): string;
    get childProcessPid(): number;
    get childProcessStartTime(): number;
    get childProcessUid(): number;
    get escapeCmd(): string;
    get escapeMode(): string;
    get parentProcessCmdline(): string;
    get parentProcessEgid(): number;
    get parentProcessEuid(): number;
    get parentProcessFilename(): string;
    get parentProcessGid(): number;
    get parentProcessName(): string;
    get parentProcessPath(): string;
    get parentProcessPid(): number;
    get parentProcessStartTime(): number;
    get parentProcessUid(): number;
    get processCmdline(): string;
    get processEgid(): number;
    get processEuid(): number;
    get processFilename(): string;
    get processGid(): number;
    get processHash(): string;
    get processName(): string;
    get processPath(): string;
    get processPid(): number;
    get processStartTime(): number;
    get processUid(): number;
    get processUsername(): string;
    get virtCmd(): string;
    get virtProcessName(): string;
}
export declare class DataOpentelekomcloudHssIntrusionEventsV5EventsProcessInfoListStructList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudHssIntrusionEventsV5EventsProcessInfoListStructOutputReference;
}
export interface DataOpentelekomcloudHssIntrusionEventsV5EventsResourceInfo {
}
export declare function dataOpentelekomcloudHssIntrusionEventsV5EventsResourceInfoToTerraform(struct?: DataOpentelekomcloudHssIntrusionEventsV5EventsResourceInfo): any;
export declare function dataOpentelekomcloudHssIntrusionEventsV5EventsResourceInfoToHclTerraform(struct?: DataOpentelekomcloudHssIntrusionEventsV5EventsResourceInfo): any;
export declare class DataOpentelekomcloudHssIntrusionEventsV5EventsResourceInfoOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudHssIntrusionEventsV5EventsResourceInfo | undefined;
    set internalValue(value: DataOpentelekomcloudHssIntrusionEventsV5EventsResourceInfo | undefined);
    get containerId(): string;
    get domainId(): string;
    get ecsId(): string;
    get enterpriseProjectId(): string;
    get hostAttr(): string;
    get imageId(): string;
    get imageName(): string;
    get microservice(): string;
    get osBit(): string;
    get osName(): string;
    get osType(): string;
    get osVersion(): string;
    get projectId(): string;
    get regionName(): string;
    get service(): string;
    get sysArch(): string;
    get vmName(): string;
    get vmUuid(): string;
    get vpcId(): string;
}
export declare class DataOpentelekomcloudHssIntrusionEventsV5EventsResourceInfoList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudHssIntrusionEventsV5EventsResourceInfoOutputReference;
}
export interface DataOpentelekomcloudHssIntrusionEventsV5EventsUserInfoListStruct {
}
export declare function dataOpentelekomcloudHssIntrusionEventsV5EventsUserInfoListStructToTerraform(struct?: DataOpentelekomcloudHssIntrusionEventsV5EventsUserInfoListStruct): any;
export declare function dataOpentelekomcloudHssIntrusionEventsV5EventsUserInfoListStructToHclTerraform(struct?: DataOpentelekomcloudHssIntrusionEventsV5EventsUserInfoListStruct): any;
export declare class DataOpentelekomcloudHssIntrusionEventsV5EventsUserInfoListStructOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudHssIntrusionEventsV5EventsUserInfoListStruct | undefined;
    set internalValue(value: DataOpentelekomcloudHssIntrusionEventsV5EventsUserInfoListStruct | undefined);
    get loginFailCount(): number;
    get loginIp(): string;
    get loginLastTime(): number;
    get loginMode(): number;
    get pwdHash(): string;
    get pwdMaxDays(): number;
    get pwdMinDays(): number;
    get pwdUsedDays(): number;
    get pwdWarnLeftDays(): number;
    get pwdWithFuzzing(): string;
    get servicePort(): number;
    get serviceType(): string;
    get userGid(): number;
    get userGroupName(): string;
    get userHomeDir(): string;
    get userId(): number;
    get userName(): string;
}
export declare class DataOpentelekomcloudHssIntrusionEventsV5EventsUserInfoListStructList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudHssIntrusionEventsV5EventsUserInfoListStructOutputReference;
}
export interface DataOpentelekomcloudHssIntrusionEventsV5Events {
}
export declare function dataOpentelekomcloudHssIntrusionEventsV5EventsToTerraform(struct?: DataOpentelekomcloudHssIntrusionEventsV5Events): any;
export declare function dataOpentelekomcloudHssIntrusionEventsV5EventsToHclTerraform(struct?: DataOpentelekomcloudHssIntrusionEventsV5Events): any;
export declare class DataOpentelekomcloudHssIntrusionEventsV5EventsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudHssIntrusionEventsV5Events | undefined;
    set internalValue(value: DataOpentelekomcloudHssIntrusionEventsV5Events | undefined);
    get agentStatus(): string;
    get assetValue(): string;
    get attackPhase(): string;
    get attackTag(): string;
    get containerName(): string;
    get eventClassId(): string;
    get eventDetails(): string;
    get eventName(): string;
    get eventType(): number;
    private _fileInfoList;
    get fileInfoList(): DataOpentelekomcloudHssIntrusionEventsV5EventsFileInfoListStructList;
    get handleMethod(): string;
    get handleStatus(): string;
    get handleTime(): number;
    get handler(): string;
    get hostId(): string;
    get hostName(): string;
    get hostStatus(): string;
    get id(): string;
    get imageName(): string;
    get occurTime(): number;
    get operateAcceptList(): string[];
    private _operateDetailList;
    get operateDetailList(): DataOpentelekomcloudHssIntrusionEventsV5EventsOperateDetailListStructList;
    get osType(): string;
    get privateIp(): string;
    private _processInfoList;
    get processInfoList(): DataOpentelekomcloudHssIntrusionEventsV5EventsProcessInfoListStructList;
    get protectStatus(): string;
    get publicIp(): string;
    get recommendation(): string;
    private _resourceInfo;
    get resourceInfo(): DataOpentelekomcloudHssIntrusionEventsV5EventsResourceInfoList;
    get severity(): string;
    private _userInfoList;
    get userInfoList(): DataOpentelekomcloudHssIntrusionEventsV5EventsUserInfoListStructList;
}
export declare class DataOpentelekomcloudHssIntrusionEventsV5EventsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudHssIntrusionEventsV5EventsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_intrusion_events_v5 opentelekomcloud_hss_intrusion_events_v5}
*/
export declare class DataOpentelekomcloudHssIntrusionEventsV5 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_hss_intrusion_events_v5";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudHssIntrusionEventsV5 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudHssIntrusionEventsV5 to import
    * @param importFromId The id of the existing DataOpentelekomcloudHssIntrusionEventsV5 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_intrusion_events_v5#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudHssIntrusionEventsV5 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/hss_intrusion_events_v5 opentelekomcloud_hss_intrusion_events_v5} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudHssIntrusionEventsV5Config
    */
    constructor(scope: Construct, id: string, config: DataOpentelekomcloudHssIntrusionEventsV5Config);
    private _beginTime?;
    get beginTime(): string;
    set beginTime(value: string);
    resetBeginTime(): void;
    get beginTimeInput(): string | undefined;
    private _category?;
    get category(): string;
    set category(value: string);
    get categoryInput(): string | undefined;
    private _containerName?;
    get containerName(): string;
    set containerName(value: string);
    resetContainerName(): void;
    get containerNameInput(): string | undefined;
    private _days?;
    get days(): number;
    set days(value: number);
    resetDays(): void;
    get daysInput(): number | undefined;
    private _endTime?;
    get endTime(): string;
    set endTime(value: string);
    resetEndTime(): void;
    get endTimeInput(): string | undefined;
    private _enterpriseProjectId?;
    get enterpriseProjectId(): string;
    set enterpriseProjectId(value: string);
    resetEnterpriseProjectId(): void;
    get enterpriseProjectIdInput(): string | undefined;
    private _eventTypes?;
    get eventTypes(): string[];
    set eventTypes(value: string[]);
    resetEventTypes(): void;
    get eventTypesInput(): string[] | undefined;
    private _events;
    get events(): DataOpentelekomcloudHssIntrusionEventsV5EventsList;
    private _handleStatus?;
    get handleStatus(): string;
    set handleStatus(value: string);
    resetHandleStatus(): void;
    get handleStatusInput(): string | undefined;
    private _hostId?;
    get hostId(): string;
    set hostId(value: string);
    resetHostId(): void;
    get hostIdInput(): string | undefined;
    private _hostName?;
    get hostName(): string;
    set hostName(value: string);
    resetHostName(): void;
    get hostNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _privateIp?;
    get privateIp(): string;
    set privateIp(value: string);
    resetPrivateIp(): void;
    get privateIpInput(): string | undefined;
    get region(): string;
    private _severity?;
    get severity(): string;
    set severity(value: string);
    resetSeverity(): void;
    get severityInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

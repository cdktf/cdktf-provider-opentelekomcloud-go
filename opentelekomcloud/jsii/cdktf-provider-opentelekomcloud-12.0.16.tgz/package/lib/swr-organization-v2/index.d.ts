/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface SwrOrganizationV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/swr_organization_v2#id SwrOrganizationV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/swr_organization_v2#name SwrOrganizationV2#name}
    */
    readonly name: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/swr_organization_v2#timeouts SwrOrganizationV2#timeouts}
    */
    readonly timeouts?: SwrOrganizationV2Timeouts;
}
export interface SwrOrganizationV2Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/swr_organization_v2#create SwrOrganizationV2#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/swr_organization_v2#delete SwrOrganizationV2#delete}
    */
    readonly delete?: string;
}
export declare function swrOrganizationV2TimeoutsToTerraform(struct?: SwrOrganizationV2Timeouts | cdktf.IResolvable): any;
export declare function swrOrganizationV2TimeoutsToHclTerraform(struct?: SwrOrganizationV2Timeouts | cdktf.IResolvable): any;
export declare class SwrOrganizationV2TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SwrOrganizationV2Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: SwrOrganizationV2Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/swr_organization_v2 opentelekomcloud_swr_organization_v2}
*/
export declare class SwrOrganizationV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_swr_organization_v2";
    /**
    * Generates CDKTF code for importing a SwrOrganizationV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SwrOrganizationV2 to import
    * @param importFromId The id of the existing SwrOrganizationV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/swr_organization_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SwrOrganizationV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/swr_organization_v2 opentelekomcloud_swr_organization_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SwrOrganizationV2Config
    */
    constructor(scope: Construct, id: string, config: SwrOrganizationV2Config);
    get auth(): number;
    get creatorName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get organizationId(): number;
    private _timeouts;
    get timeouts(): SwrOrganizationV2TimeoutsOutputReference;
    putTimeouts(value: SwrOrganizationV2Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | SwrOrganizationV2Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

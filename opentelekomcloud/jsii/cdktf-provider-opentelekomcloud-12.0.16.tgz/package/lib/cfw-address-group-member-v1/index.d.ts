/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CfwAddressGroupMemberV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_address_group_member_v1#address CfwAddressGroupMemberV1#address}
    */
    readonly address: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_address_group_member_v1#address_type CfwAddressGroupMemberV1#address_type}
    */
    readonly addressType?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_address_group_member_v1#description CfwAddressGroupMemberV1#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_address_group_member_v1#set_id CfwAddressGroupMemberV1#set_id}
    */
    readonly setId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_address_group_member_v1#timeouts CfwAddressGroupMemberV1#timeouts}
    */
    readonly timeouts?: CfwAddressGroupMemberV1Timeouts;
}
export interface CfwAddressGroupMemberV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_address_group_member_v1#create CfwAddressGroupMemberV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_address_group_member_v1#delete CfwAddressGroupMemberV1#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_address_group_member_v1#update CfwAddressGroupMemberV1#update}
    */
    readonly update?: string;
}
export declare function cfwAddressGroupMemberV1TimeoutsToTerraform(struct?: CfwAddressGroupMemberV1Timeouts | cdktf.IResolvable): any;
export declare function cfwAddressGroupMemberV1TimeoutsToHclTerraform(struct?: CfwAddressGroupMemberV1Timeouts | cdktf.IResolvable): any;
export declare class CfwAddressGroupMemberV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CfwAddressGroupMemberV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: CfwAddressGroupMemberV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_address_group_member_v1 opentelekomcloud_cfw_address_group_member_v1}
*/
export declare class CfwAddressGroupMemberV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_cfw_address_group_member_v1";
    /**
    * Generates CDKTF code for importing a CfwAddressGroupMemberV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CfwAddressGroupMemberV1 to import
    * @param importFromId The id of the existing CfwAddressGroupMemberV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_address_group_member_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CfwAddressGroupMemberV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_address_group_member_v1 opentelekomcloud_cfw_address_group_member_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CfwAddressGroupMemberV1Config
    */
    constructor(scope: Construct, id: string, config: CfwAddressGroupMemberV1Config);
    private _address?;
    get address(): string;
    set address(value: string);
    get addressInput(): string | undefined;
    private _addressType?;
    get addressType(): number;
    set addressType(value: number);
    resetAddressType(): void;
    get addressTypeInput(): number | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get name(): string;
    private _setId?;
    get setId(): string;
    set setId(value: string);
    get setIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): CfwAddressGroupMemberV1TimeoutsOutputReference;
    putTimeouts(value: CfwAddressGroupMemberV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | CfwAddressGroupMemberV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

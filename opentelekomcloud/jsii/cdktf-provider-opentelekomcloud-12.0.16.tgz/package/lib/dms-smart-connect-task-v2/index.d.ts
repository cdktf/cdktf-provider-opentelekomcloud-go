/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DmsSmartConnectTaskV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#destination_type DmsSmartConnectTaskV2#destination_type}
    */
    readonly destinationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#id DmsSmartConnectTaskV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#instance_id DmsSmartConnectTaskV2#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#source_type DmsSmartConnectTaskV2#source_type}
    */
    readonly sourceType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#start_later DmsSmartConnectTaskV2#start_later}
    */
    readonly startLater?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#task_name DmsSmartConnectTaskV2#task_name}
    */
    readonly taskName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#topics DmsSmartConnectTaskV2#topics}
    */
    readonly topics?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#topics_regex DmsSmartConnectTaskV2#topics_regex}
    */
    readonly topicsRegex?: string;
    /**
    * destination_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#destination_task DmsSmartConnectTaskV2#destination_task}
    */
    readonly destinationTask?: DmsSmartConnectTaskV2DestinationTask;
    /**
    * source_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#source_task DmsSmartConnectTaskV2#source_task}
    */
    readonly sourceTask?: DmsSmartConnectTaskV2SourceTask;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#timeouts DmsSmartConnectTaskV2#timeouts}
    */
    readonly timeouts?: DmsSmartConnectTaskV2Timeouts;
}
export interface DmsSmartConnectTaskV2DestinationTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#access_key DmsSmartConnectTaskV2#access_key}
    */
    readonly accessKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#consumer_strategy DmsSmartConnectTaskV2#consumer_strategy}
    */
    readonly consumerStrategy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#deliver_time_interval DmsSmartConnectTaskV2#deliver_time_interval}
    */
    readonly deliverTimeInterval?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#destination_file_type DmsSmartConnectTaskV2#destination_file_type}
    */
    readonly destinationFileType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#obs_bucket_name DmsSmartConnectTaskV2#obs_bucket_name}
    */
    readonly obsBucketName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#obs_path DmsSmartConnectTaskV2#obs_path}
    */
    readonly obsPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#partition_format DmsSmartConnectTaskV2#partition_format}
    */
    readonly partitionFormat?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#record_delimiter DmsSmartConnectTaskV2#record_delimiter}
    */
    readonly recordDelimiter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#secret_key DmsSmartConnectTaskV2#secret_key}
    */
    readonly secretKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#store_keys DmsSmartConnectTaskV2#store_keys}
    */
    readonly storeKeys?: boolean | cdktf.IResolvable;
}
export declare function dmsSmartConnectTaskV2DestinationTaskToTerraform(struct?: DmsSmartConnectTaskV2DestinationTaskOutputReference | DmsSmartConnectTaskV2DestinationTask): any;
export declare function dmsSmartConnectTaskV2DestinationTaskToHclTerraform(struct?: DmsSmartConnectTaskV2DestinationTaskOutputReference | DmsSmartConnectTaskV2DestinationTask): any;
export declare class DmsSmartConnectTaskV2DestinationTaskOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DmsSmartConnectTaskV2DestinationTask | undefined;
    set internalValue(value: DmsSmartConnectTaskV2DestinationTask | undefined);
    private _accessKey?;
    get accessKey(): string;
    set accessKey(value: string);
    resetAccessKey(): void;
    get accessKeyInput(): string | undefined;
    private _consumerStrategy?;
    get consumerStrategy(): string;
    set consumerStrategy(value: string);
    resetConsumerStrategy(): void;
    get consumerStrategyInput(): string | undefined;
    private _deliverTimeInterval?;
    get deliverTimeInterval(): number;
    set deliverTimeInterval(value: number);
    resetDeliverTimeInterval(): void;
    get deliverTimeIntervalInput(): number | undefined;
    private _destinationFileType?;
    get destinationFileType(): string;
    set destinationFileType(value: string);
    resetDestinationFileType(): void;
    get destinationFileTypeInput(): string | undefined;
    private _obsBucketName?;
    get obsBucketName(): string;
    set obsBucketName(value: string);
    resetObsBucketName(): void;
    get obsBucketNameInput(): string | undefined;
    private _obsPath?;
    get obsPath(): string;
    set obsPath(value: string);
    resetObsPath(): void;
    get obsPathInput(): string | undefined;
    private _partitionFormat?;
    get partitionFormat(): string;
    set partitionFormat(value: string);
    resetPartitionFormat(): void;
    get partitionFormatInput(): string | undefined;
    private _recordDelimiter?;
    get recordDelimiter(): string;
    set recordDelimiter(value: string);
    resetRecordDelimiter(): void;
    get recordDelimiterInput(): string | undefined;
    private _secretKey?;
    get secretKey(): string;
    set secretKey(value: string);
    resetSecretKey(): void;
    get secretKeyInput(): string | undefined;
    private _storeKeys?;
    get storeKeys(): boolean | cdktf.IResolvable;
    set storeKeys(value: boolean | cdktf.IResolvable);
    resetStoreKeys(): void;
    get storeKeysInput(): boolean | cdktf.IResolvable | undefined;
}
export interface DmsSmartConnectTaskV2SourceTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#compression_type DmsSmartConnectTaskV2#compression_type}
    */
    readonly compressionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#consumer_strategy DmsSmartConnectTaskV2#consumer_strategy}
    */
    readonly consumerStrategy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#current_instance_alias DmsSmartConnectTaskV2#current_instance_alias}
    */
    readonly currentInstanceAlias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#direction DmsSmartConnectTaskV2#direction}
    */
    readonly direction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#password DmsSmartConnectTaskV2#password}
    */
    readonly password?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#peer_instance_address DmsSmartConnectTaskV2#peer_instance_address}
    */
    readonly peerInstanceAddress?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#peer_instance_alias DmsSmartConnectTaskV2#peer_instance_alias}
    */
    readonly peerInstanceAlias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#peer_instance_id DmsSmartConnectTaskV2#peer_instance_id}
    */
    readonly peerInstanceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#provenance_header_enabled DmsSmartConnectTaskV2#provenance_header_enabled}
    */
    readonly provenanceHeaderEnabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#rename_topic_enabled DmsSmartConnectTaskV2#rename_topic_enabled}
    */
    readonly renameTopicEnabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#replication_factor DmsSmartConnectTaskV2#replication_factor}
    */
    readonly replicationFactor?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#sasl_mechanism DmsSmartConnectTaskV2#sasl_mechanism}
    */
    readonly saslMechanism?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#security_protocol DmsSmartConnectTaskV2#security_protocol}
    */
    readonly securityProtocol?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#sync_consumer_offsets_enabled DmsSmartConnectTaskV2#sync_consumer_offsets_enabled}
    */
    readonly syncConsumerOffsetsEnabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#task_num DmsSmartConnectTaskV2#task_num}
    */
    readonly taskNum?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#topics_mapping DmsSmartConnectTaskV2#topics_mapping}
    */
    readonly topicsMapping?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#user_name DmsSmartConnectTaskV2#user_name}
    */
    readonly userName?: string;
}
export declare function dmsSmartConnectTaskV2SourceTaskToTerraform(struct?: DmsSmartConnectTaskV2SourceTaskOutputReference | DmsSmartConnectTaskV2SourceTask): any;
export declare function dmsSmartConnectTaskV2SourceTaskToHclTerraform(struct?: DmsSmartConnectTaskV2SourceTaskOutputReference | DmsSmartConnectTaskV2SourceTask): any;
export declare class DmsSmartConnectTaskV2SourceTaskOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DmsSmartConnectTaskV2SourceTask | undefined;
    set internalValue(value: DmsSmartConnectTaskV2SourceTask | undefined);
    private _compressionType?;
    get compressionType(): string;
    set compressionType(value: string);
    resetCompressionType(): void;
    get compressionTypeInput(): string | undefined;
    private _consumerStrategy?;
    get consumerStrategy(): string;
    set consumerStrategy(value: string);
    resetConsumerStrategy(): void;
    get consumerStrategyInput(): string | undefined;
    private _currentInstanceAlias?;
    get currentInstanceAlias(): string;
    set currentInstanceAlias(value: string);
    resetCurrentInstanceAlias(): void;
    get currentInstanceAliasInput(): string | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _peerInstanceAddress?;
    get peerInstanceAddress(): string[];
    set peerInstanceAddress(value: string[]);
    resetPeerInstanceAddress(): void;
    get peerInstanceAddressInput(): string[] | undefined;
    private _peerInstanceAlias?;
    get peerInstanceAlias(): string;
    set peerInstanceAlias(value: string);
    resetPeerInstanceAlias(): void;
    get peerInstanceAliasInput(): string | undefined;
    private _peerInstanceId?;
    get peerInstanceId(): string;
    set peerInstanceId(value: string);
    resetPeerInstanceId(): void;
    get peerInstanceIdInput(): string | undefined;
    private _provenanceHeaderEnabled?;
    get provenanceHeaderEnabled(): boolean | cdktf.IResolvable;
    set provenanceHeaderEnabled(value: boolean | cdktf.IResolvable);
    resetProvenanceHeaderEnabled(): void;
    get provenanceHeaderEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _renameTopicEnabled?;
    get renameTopicEnabled(): boolean | cdktf.IResolvable;
    set renameTopicEnabled(value: boolean | cdktf.IResolvable);
    resetRenameTopicEnabled(): void;
    get renameTopicEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _replicationFactor?;
    get replicationFactor(): number;
    set replicationFactor(value: number);
    resetReplicationFactor(): void;
    get replicationFactorInput(): number | undefined;
    private _saslMechanism?;
    get saslMechanism(): string;
    set saslMechanism(value: string);
    resetSaslMechanism(): void;
    get saslMechanismInput(): string | undefined;
    private _securityProtocol?;
    get securityProtocol(): string;
    set securityProtocol(value: string);
    resetSecurityProtocol(): void;
    get securityProtocolInput(): string | undefined;
    private _syncConsumerOffsetsEnabled?;
    get syncConsumerOffsetsEnabled(): boolean | cdktf.IResolvable;
    set syncConsumerOffsetsEnabled(value: boolean | cdktf.IResolvable);
    resetSyncConsumerOffsetsEnabled(): void;
    get syncConsumerOffsetsEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _taskNum?;
    get taskNum(): number;
    set taskNum(value: number);
    resetTaskNum(): void;
    get taskNumInput(): number | undefined;
    private _topicsMapping?;
    get topicsMapping(): string[];
    set topicsMapping(value: string[]);
    resetTopicsMapping(): void;
    get topicsMappingInput(): string[] | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    resetUserName(): void;
    get userNameInput(): string | undefined;
}
export interface DmsSmartConnectTaskV2Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#create DmsSmartConnectTaskV2#create}
    */
    readonly create?: string;
}
export declare function dmsSmartConnectTaskV2TimeoutsToTerraform(struct?: DmsSmartConnectTaskV2Timeouts | cdktf.IResolvable): any;
export declare function dmsSmartConnectTaskV2TimeoutsToHclTerraform(struct?: DmsSmartConnectTaskV2Timeouts | cdktf.IResolvable): any;
export declare class DmsSmartConnectTaskV2TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DmsSmartConnectTaskV2Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DmsSmartConnectTaskV2Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2 opentelekomcloud_dms_smart_connect_task_v2}
*/
export declare class DmsSmartConnectTaskV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_dms_smart_connect_task_v2";
    /**
    * Generates CDKTF code for importing a DmsSmartConnectTaskV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DmsSmartConnectTaskV2 to import
    * @param importFromId The id of the existing DmsSmartConnectTaskV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DmsSmartConnectTaskV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dms_smart_connect_task_v2 opentelekomcloud_dms_smart_connect_task_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DmsSmartConnectTaskV2Config
    */
    constructor(scope: Construct, id: string, config: DmsSmartConnectTaskV2Config);
    get createdAt(): string;
    private _destinationType?;
    get destinationType(): string;
    set destinationType(value: string);
    resetDestinationType(): void;
    get destinationTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get region(): string;
    private _sourceType?;
    get sourceType(): string;
    set sourceType(value: string);
    resetSourceType(): void;
    get sourceTypeInput(): string | undefined;
    private _startLater?;
    get startLater(): boolean | cdktf.IResolvable;
    set startLater(value: boolean | cdktf.IResolvable);
    resetStartLater(): void;
    get startLaterInput(): boolean | cdktf.IResolvable | undefined;
    get status(): string;
    private _taskName?;
    get taskName(): string;
    set taskName(value: string);
    get taskNameInput(): string | undefined;
    private _topics?;
    get topics(): string[];
    set topics(value: string[]);
    resetTopics(): void;
    get topicsInput(): string[] | undefined;
    private _topicsRegex?;
    get topicsRegex(): string;
    set topicsRegex(value: string);
    resetTopicsRegex(): void;
    get topicsRegexInput(): string | undefined;
    private _destinationTask;
    get destinationTask(): DmsSmartConnectTaskV2DestinationTaskOutputReference;
    putDestinationTask(value: DmsSmartConnectTaskV2DestinationTask): void;
    resetDestinationTask(): void;
    get destinationTaskInput(): DmsSmartConnectTaskV2DestinationTask | undefined;
    private _sourceTask;
    get sourceTask(): DmsSmartConnectTaskV2SourceTaskOutputReference;
    putSourceTask(value: DmsSmartConnectTaskV2SourceTask): void;
    resetSourceTask(): void;
    get sourceTaskInput(): DmsSmartConnectTaskV2SourceTask | undefined;
    private _timeouts;
    get timeouts(): DmsSmartConnectTaskV2TimeoutsOutputReference;
    putTimeouts(value: DmsSmartConnectTaskV2Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DmsSmartConnectTaskV2Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

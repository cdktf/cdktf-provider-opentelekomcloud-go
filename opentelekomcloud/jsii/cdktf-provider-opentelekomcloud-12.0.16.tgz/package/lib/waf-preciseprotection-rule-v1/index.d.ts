/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface WafPreciseprotectionRuleV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_preciseprotection_rule_v1#action_category WafPreciseprotectionRuleV1#action_category}
    */
    readonly actionCategory: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_preciseprotection_rule_v1#end WafPreciseprotectionRuleV1#end}
    */
    readonly end?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_preciseprotection_rule_v1#id WafPreciseprotectionRuleV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_preciseprotection_rule_v1#name WafPreciseprotectionRuleV1#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_preciseprotection_rule_v1#policy_id WafPreciseprotectionRuleV1#policy_id}
    */
    readonly policyId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_preciseprotection_rule_v1#priority WafPreciseprotectionRuleV1#priority}
    */
    readonly priority?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_preciseprotection_rule_v1#start WafPreciseprotectionRuleV1#start}
    */
    readonly start?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_preciseprotection_rule_v1#time WafPreciseprotectionRuleV1#time}
    */
    readonly time?: boolean | cdktf.IResolvable;
    /**
    * conditions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_preciseprotection_rule_v1#conditions WafPreciseprotectionRuleV1#conditions}
    */
    readonly conditions: WafPreciseprotectionRuleV1Conditions[] | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_preciseprotection_rule_v1#timeouts WafPreciseprotectionRuleV1#timeouts}
    */
    readonly timeouts?: WafPreciseprotectionRuleV1Timeouts;
}
export interface WafPreciseprotectionRuleV1Conditions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_preciseprotection_rule_v1#category WafPreciseprotectionRuleV1#category}
    */
    readonly category: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_preciseprotection_rule_v1#contents WafPreciseprotectionRuleV1#contents}
    */
    readonly contents: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_preciseprotection_rule_v1#index WafPreciseprotectionRuleV1#index}
    */
    readonly index?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_preciseprotection_rule_v1#logic WafPreciseprotectionRuleV1#logic}
    */
    readonly logic: string;
}
export declare function wafPreciseprotectionRuleV1ConditionsToTerraform(struct?: WafPreciseprotectionRuleV1Conditions | cdktf.IResolvable): any;
export declare function wafPreciseprotectionRuleV1ConditionsToHclTerraform(struct?: WafPreciseprotectionRuleV1Conditions | cdktf.IResolvable): any;
export declare class WafPreciseprotectionRuleV1ConditionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WafPreciseprotectionRuleV1Conditions | cdktf.IResolvable | undefined;
    set internalValue(value: WafPreciseprotectionRuleV1Conditions | cdktf.IResolvable | undefined);
    private _category?;
    get category(): string;
    set category(value: string);
    get categoryInput(): string | undefined;
    private _contents?;
    get contents(): string[];
    set contents(value: string[]);
    get contentsInput(): string[] | undefined;
    private _index?;
    get index(): string;
    set index(value: string);
    resetIndex(): void;
    get indexInput(): string | undefined;
    private _logic?;
    get logic(): string;
    set logic(value: string);
    get logicInput(): string | undefined;
}
export declare class WafPreciseprotectionRuleV1ConditionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WafPreciseprotectionRuleV1Conditions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WafPreciseprotectionRuleV1ConditionsOutputReference;
}
export interface WafPreciseprotectionRuleV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_preciseprotection_rule_v1#create WafPreciseprotectionRuleV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_preciseprotection_rule_v1#delete WafPreciseprotectionRuleV1#delete}
    */
    readonly delete?: string;
}
export declare function wafPreciseprotectionRuleV1TimeoutsToTerraform(struct?: WafPreciseprotectionRuleV1Timeouts | cdktf.IResolvable): any;
export declare function wafPreciseprotectionRuleV1TimeoutsToHclTerraform(struct?: WafPreciseprotectionRuleV1Timeouts | cdktf.IResolvable): any;
export declare class WafPreciseprotectionRuleV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WafPreciseprotectionRuleV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: WafPreciseprotectionRuleV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_preciseprotection_rule_v1 opentelekomcloud_waf_preciseprotection_rule_v1}
*/
export declare class WafPreciseprotectionRuleV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_waf_preciseprotection_rule_v1";
    /**
    * Generates CDKTF code for importing a WafPreciseprotectionRuleV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WafPreciseprotectionRuleV1 to import
    * @param importFromId The id of the existing WafPreciseprotectionRuleV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_preciseprotection_rule_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WafPreciseprotectionRuleV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_preciseprotection_rule_v1 opentelekomcloud_waf_preciseprotection_rule_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WafPreciseprotectionRuleV1Config
    */
    constructor(scope: Construct, id: string, config: WafPreciseprotectionRuleV1Config);
    private _actionCategory?;
    get actionCategory(): string;
    set actionCategory(value: string);
    get actionCategoryInput(): string | undefined;
    private _end?;
    get end(): string;
    set end(value: string);
    resetEnd(): void;
    get endInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    get policyIdInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    resetPriority(): void;
    get priorityInput(): number | undefined;
    private _start?;
    get start(): string;
    set start(value: string);
    resetStart(): void;
    get startInput(): string | undefined;
    private _time?;
    get time(): boolean | cdktf.IResolvable;
    set time(value: boolean | cdktf.IResolvable);
    resetTime(): void;
    get timeInput(): boolean | cdktf.IResolvable | undefined;
    private _conditions;
    get conditions(): WafPreciseprotectionRuleV1ConditionsList;
    putConditions(value: WafPreciseprotectionRuleV1Conditions[] | cdktf.IResolvable): void;
    get conditionsInput(): cdktf.IResolvable | WafPreciseprotectionRuleV1Conditions[] | undefined;
    private _timeouts;
    get timeouts(): WafPreciseprotectionRuleV1TimeoutsOutputReference;
    putTimeouts(value: WafPreciseprotectionRuleV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | WafPreciseprotectionRuleV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

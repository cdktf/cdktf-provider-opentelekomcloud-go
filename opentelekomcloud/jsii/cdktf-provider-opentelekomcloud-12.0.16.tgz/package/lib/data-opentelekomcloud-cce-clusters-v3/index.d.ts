/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudCceClustersV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/cce_clusters_v3#cluster_id DataOpentelekomcloudCceClustersV3#cluster_id}
    */
    readonly clusterId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/cce_clusters_v3#cluster_type DataOpentelekomcloudCceClustersV3#cluster_type}
    */
    readonly clusterType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/cce_clusters_v3#enterprise_project_id DataOpentelekomcloudCceClustersV3#enterprise_project_id}
    */
    readonly enterpriseProjectId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/cce_clusters_v3#id DataOpentelekomcloudCceClustersV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/cce_clusters_v3#name DataOpentelekomcloudCceClustersV3#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/cce_clusters_v3#region DataOpentelekomcloudCceClustersV3#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/cce_clusters_v3#status DataOpentelekomcloudCceClustersV3#status}
    */
    readonly status?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/cce_clusters_v3#vpc_id DataOpentelekomcloudCceClustersV3#vpc_id}
    */
    readonly vpcId?: string;
}
export interface DataOpentelekomcloudCceClustersV3ClustersCertificateClusters {
}
export declare function dataOpentelekomcloudCceClustersV3ClustersCertificateClustersToTerraform(struct?: DataOpentelekomcloudCceClustersV3ClustersCertificateClusters): any;
export declare function dataOpentelekomcloudCceClustersV3ClustersCertificateClustersToHclTerraform(struct?: DataOpentelekomcloudCceClustersV3ClustersCertificateClusters): any;
export declare class DataOpentelekomcloudCceClustersV3ClustersCertificateClustersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudCceClustersV3ClustersCertificateClusters | undefined;
    set internalValue(value: DataOpentelekomcloudCceClustersV3ClustersCertificateClusters | undefined);
    get certificateAuthorityData(): string;
    get name(): string;
    get server(): string;
}
export declare class DataOpentelekomcloudCceClustersV3ClustersCertificateClustersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudCceClustersV3ClustersCertificateClustersOutputReference;
}
export interface DataOpentelekomcloudCceClustersV3ClustersCertificateUsers {
}
export declare function dataOpentelekomcloudCceClustersV3ClustersCertificateUsersToTerraform(struct?: DataOpentelekomcloudCceClustersV3ClustersCertificateUsers): any;
export declare function dataOpentelekomcloudCceClustersV3ClustersCertificateUsersToHclTerraform(struct?: DataOpentelekomcloudCceClustersV3ClustersCertificateUsers): any;
export declare class DataOpentelekomcloudCceClustersV3ClustersCertificateUsersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudCceClustersV3ClustersCertificateUsers | undefined;
    set internalValue(value: DataOpentelekomcloudCceClustersV3ClustersCertificateUsers | undefined);
    get clientCertificateData(): string;
    get clientKeyData(): string;
    get name(): string;
}
export declare class DataOpentelekomcloudCceClustersV3ClustersCertificateUsersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudCceClustersV3ClustersCertificateUsersOutputReference;
}
export interface DataOpentelekomcloudCceClustersV3ClustersEndpoints {
}
export declare function dataOpentelekomcloudCceClustersV3ClustersEndpointsToTerraform(struct?: DataOpentelekomcloudCceClustersV3ClustersEndpoints): any;
export declare function dataOpentelekomcloudCceClustersV3ClustersEndpointsToHclTerraform(struct?: DataOpentelekomcloudCceClustersV3ClustersEndpoints): any;
export declare class DataOpentelekomcloudCceClustersV3ClustersEndpointsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudCceClustersV3ClustersEndpoints | undefined;
    set internalValue(value: DataOpentelekomcloudCceClustersV3ClustersEndpoints | undefined);
    get type(): string;
    get url(): string;
}
export declare class DataOpentelekomcloudCceClustersV3ClustersEndpointsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudCceClustersV3ClustersEndpointsOutputReference;
}
export interface DataOpentelekomcloudCceClustersV3ClustersMasters {
}
export declare function dataOpentelekomcloudCceClustersV3ClustersMastersToTerraform(struct?: DataOpentelekomcloudCceClustersV3ClustersMasters): any;
export declare function dataOpentelekomcloudCceClustersV3ClustersMastersToHclTerraform(struct?: DataOpentelekomcloudCceClustersV3ClustersMasters): any;
export declare class DataOpentelekomcloudCceClustersV3ClustersMastersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudCceClustersV3ClustersMasters | undefined;
    set internalValue(value: DataOpentelekomcloudCceClustersV3ClustersMasters | undefined);
    get availabilityZone(): string;
}
export declare class DataOpentelekomcloudCceClustersV3ClustersMastersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudCceClustersV3ClustersMastersOutputReference;
}
export interface DataOpentelekomcloudCceClustersV3Clusters {
}
export declare function dataOpentelekomcloudCceClustersV3ClustersToTerraform(struct?: DataOpentelekomcloudCceClustersV3Clusters): any;
export declare function dataOpentelekomcloudCceClustersV3ClustersToHclTerraform(struct?: DataOpentelekomcloudCceClustersV3Clusters): any;
export declare class DataOpentelekomcloudCceClustersV3ClustersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudCceClustersV3Clusters | undefined;
    set internalValue(value: DataOpentelekomcloudCceClustersV3Clusters | undefined);
    get authenticationMode(): string;
    get billingMode(): number;
    private _certificateClusters;
    get certificateClusters(): DataOpentelekomcloudCceClustersV3ClustersCertificateClustersList;
    private _certificateUsers;
    get certificateUsers(): DataOpentelekomcloudCceClustersV3ClustersCertificateUsersList;
    get clusterType(): string;
    get clusterVersion(): string;
    get containerNetworkCidr(): string;
    get containerNetworkType(): string;
    get description(): string;
    private _endpoints;
    get endpoints(): DataOpentelekomcloudCceClustersV3ClustersEndpointsList;
    get eniSubnetCidr(): string;
    get eniSubnetId(): string;
    get enterpriseProjectId(): string;
    get flavorId(): string;
    get id(): string;
    get kubeConfigRaw(): string;
    private _masters;
    get masters(): DataOpentelekomcloudCceClustersV3ClustersMastersList;
    get name(): string;
    get securityGroupId(): string;
    get serviceNetworkCidr(): string;
    get status(): string;
    get subnetId(): string;
    get vpcId(): string;
}
export declare class DataOpentelekomcloudCceClustersV3ClustersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudCceClustersV3ClustersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/cce_clusters_v3 opentelekomcloud_cce_clusters_v3}
*/
export declare class DataOpentelekomcloudCceClustersV3 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_cce_clusters_v3";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudCceClustersV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudCceClustersV3 to import
    * @param importFromId The id of the existing DataOpentelekomcloudCceClustersV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/cce_clusters_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudCceClustersV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/cce_clusters_v3 opentelekomcloud_cce_clusters_v3} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudCceClustersV3Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudCceClustersV3Config);
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    resetClusterId(): void;
    get clusterIdInput(): string | undefined;
    private _clusterType?;
    get clusterType(): string;
    set clusterType(value: string);
    resetClusterType(): void;
    get clusterTypeInput(): string | undefined;
    private _clusters;
    get clusters(): DataOpentelekomcloudCceClustersV3ClustersList;
    private _enterpriseProjectId?;
    get enterpriseProjectId(): string;
    set enterpriseProjectId(value: string);
    resetEnterpriseProjectId(): void;
    get enterpriseProjectIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ids(): string[];
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    resetVpcId(): void;
    get vpcIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

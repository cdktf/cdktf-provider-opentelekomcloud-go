/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface EnterpriseVpnGatewayV5Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#access_private_ip_1 EnterpriseVpnGatewayV5#access_private_ip_1}
    */
    readonly accessPrivateIp1?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#access_private_ip_2 EnterpriseVpnGatewayV5#access_private_ip_2}
    */
    readonly accessPrivateIp2?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#access_subnet_id EnterpriseVpnGatewayV5#access_subnet_id}
    */
    readonly accessSubnetId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#access_vpc_id EnterpriseVpnGatewayV5#access_vpc_id}
    */
    readonly accessVpcId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#asn EnterpriseVpnGatewayV5#asn}
    */
    readonly asn?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#attachment_type EnterpriseVpnGatewayV5#attachment_type}
    */
    readonly attachmentType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#availability_zones EnterpriseVpnGatewayV5#availability_zones}
    */
    readonly availabilityZones: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#connect_subnet EnterpriseVpnGatewayV5#connect_subnet}
    */
    readonly connectSubnet?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#delete_eip EnterpriseVpnGatewayV5#delete_eip}
    */
    readonly deleteEip?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#er_id EnterpriseVpnGatewayV5#er_id}
    */
    readonly erId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#flavor EnterpriseVpnGatewayV5#flavor}
    */
    readonly flavor?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#ha_mode EnterpriseVpnGatewayV5#ha_mode}
    */
    readonly haMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#id EnterpriseVpnGatewayV5#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#local_subnets EnterpriseVpnGatewayV5#local_subnets}
    */
    readonly localSubnets?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#name EnterpriseVpnGatewayV5#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#network_type EnterpriseVpnGatewayV5#network_type}
    */
    readonly networkType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#tags EnterpriseVpnGatewayV5#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#vpc_id EnterpriseVpnGatewayV5#vpc_id}
    */
    readonly vpcId?: string;
    /**
    * eip1 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#eip1 EnterpriseVpnGatewayV5#eip1}
    */
    readonly eip1?: EnterpriseVpnGatewayV5Eip1;
    /**
    * eip2 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#eip2 EnterpriseVpnGatewayV5#eip2}
    */
    readonly eip2?: EnterpriseVpnGatewayV5Eip2;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#timeouts EnterpriseVpnGatewayV5#timeouts}
    */
    readonly timeouts?: EnterpriseVpnGatewayV5Timeouts;
}
export interface EnterpriseVpnGatewayV5Eip1 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#bandwidth_name EnterpriseVpnGatewayV5#bandwidth_name}
    */
    readonly bandwidthName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#bandwidth_size EnterpriseVpnGatewayV5#bandwidth_size}
    */
    readonly bandwidthSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#charge_mode EnterpriseVpnGatewayV5#charge_mode}
    */
    readonly chargeMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#id EnterpriseVpnGatewayV5#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#type EnterpriseVpnGatewayV5#type}
    */
    readonly type?: string;
}
export declare function enterpriseVpnGatewayV5Eip1ToTerraform(struct?: EnterpriseVpnGatewayV5Eip1OutputReference | EnterpriseVpnGatewayV5Eip1): any;
export declare function enterpriseVpnGatewayV5Eip1ToHclTerraform(struct?: EnterpriseVpnGatewayV5Eip1OutputReference | EnterpriseVpnGatewayV5Eip1): any;
export declare class EnterpriseVpnGatewayV5Eip1OutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EnterpriseVpnGatewayV5Eip1 | undefined;
    set internalValue(value: EnterpriseVpnGatewayV5Eip1 | undefined);
    get bandwidthId(): string;
    private _bandwidthName?;
    get bandwidthName(): string;
    set bandwidthName(value: string);
    resetBandwidthName(): void;
    get bandwidthNameInput(): string | undefined;
    private _bandwidthSize?;
    get bandwidthSize(): number;
    set bandwidthSize(value: number);
    resetBandwidthSize(): void;
    get bandwidthSizeInput(): number | undefined;
    private _chargeMode?;
    get chargeMode(): string;
    set chargeMode(value: string);
    resetChargeMode(): void;
    get chargeModeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ipAddress(): string;
    get ipVersion(): number;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface EnterpriseVpnGatewayV5Eip2 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#bandwidth_name EnterpriseVpnGatewayV5#bandwidth_name}
    */
    readonly bandwidthName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#bandwidth_size EnterpriseVpnGatewayV5#bandwidth_size}
    */
    readonly bandwidthSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#charge_mode EnterpriseVpnGatewayV5#charge_mode}
    */
    readonly chargeMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#id EnterpriseVpnGatewayV5#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#type EnterpriseVpnGatewayV5#type}
    */
    readonly type?: string;
}
export declare function enterpriseVpnGatewayV5Eip2ToTerraform(struct?: EnterpriseVpnGatewayV5Eip2OutputReference | EnterpriseVpnGatewayV5Eip2): any;
export declare function enterpriseVpnGatewayV5Eip2ToHclTerraform(struct?: EnterpriseVpnGatewayV5Eip2OutputReference | EnterpriseVpnGatewayV5Eip2): any;
export declare class EnterpriseVpnGatewayV5Eip2OutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EnterpriseVpnGatewayV5Eip2 | undefined;
    set internalValue(value: EnterpriseVpnGatewayV5Eip2 | undefined);
    get bandwidthId(): string;
    private _bandwidthName?;
    get bandwidthName(): string;
    set bandwidthName(value: string);
    resetBandwidthName(): void;
    get bandwidthNameInput(): string | undefined;
    private _bandwidthSize?;
    get bandwidthSize(): number;
    set bandwidthSize(value: number);
    resetBandwidthSize(): void;
    get bandwidthSizeInput(): number | undefined;
    private _chargeMode?;
    get chargeMode(): string;
    set chargeMode(value: string);
    resetChargeMode(): void;
    get chargeModeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ipAddress(): string;
    get ipVersion(): number;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface EnterpriseVpnGatewayV5Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#create EnterpriseVpnGatewayV5#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#delete EnterpriseVpnGatewayV5#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#update EnterpriseVpnGatewayV5#update}
    */
    readonly update?: string;
}
export declare function enterpriseVpnGatewayV5TimeoutsToTerraform(struct?: EnterpriseVpnGatewayV5Timeouts | cdktf.IResolvable): any;
export declare function enterpriseVpnGatewayV5TimeoutsToHclTerraform(struct?: EnterpriseVpnGatewayV5Timeouts | cdktf.IResolvable): any;
export declare class EnterpriseVpnGatewayV5TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EnterpriseVpnGatewayV5Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: EnterpriseVpnGatewayV5Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5 opentelekomcloud_enterprise_vpn_gateway_v5}
*/
export declare class EnterpriseVpnGatewayV5 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_enterprise_vpn_gateway_v5";
    /**
    * Generates CDKTF code for importing a EnterpriseVpnGatewayV5 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EnterpriseVpnGatewayV5 to import
    * @param importFromId The id of the existing EnterpriseVpnGatewayV5 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EnterpriseVpnGatewayV5 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/enterprise_vpn_gateway_v5 opentelekomcloud_enterprise_vpn_gateway_v5} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EnterpriseVpnGatewayV5Config
    */
    constructor(scope: Construct, id: string, config: EnterpriseVpnGatewayV5Config);
    private _accessPrivateIp1?;
    get accessPrivateIp1(): string;
    set accessPrivateIp1(value: string);
    resetAccessPrivateIp1(): void;
    get accessPrivateIp1Input(): string | undefined;
    private _accessPrivateIp2?;
    get accessPrivateIp2(): string;
    set accessPrivateIp2(value: string);
    resetAccessPrivateIp2(): void;
    get accessPrivateIp2Input(): string | undefined;
    private _accessSubnetId?;
    get accessSubnetId(): string;
    set accessSubnetId(value: string);
    resetAccessSubnetId(): void;
    get accessSubnetIdInput(): string | undefined;
    private _accessVpcId?;
    get accessVpcId(): string;
    set accessVpcId(value: string);
    resetAccessVpcId(): void;
    get accessVpcIdInput(): string | undefined;
    private _asn?;
    get asn(): number;
    set asn(value: number);
    resetAsn(): void;
    get asnInput(): number | undefined;
    private _attachmentType?;
    get attachmentType(): string;
    set attachmentType(value: string);
    resetAttachmentType(): void;
    get attachmentTypeInput(): string | undefined;
    private _availabilityZones?;
    get availabilityZones(): string[];
    set availabilityZones(value: string[]);
    get availabilityZonesInput(): string[] | undefined;
    private _connectSubnet?;
    get connectSubnet(): string;
    set connectSubnet(value: string);
    resetConnectSubnet(): void;
    get connectSubnetInput(): string | undefined;
    get createdAt(): string;
    private _deleteEip?;
    get deleteEip(): boolean | cdktf.IResolvable;
    set deleteEip(value: boolean | cdktf.IResolvable);
    resetDeleteEip(): void;
    get deleteEipInput(): boolean | cdktf.IResolvable | undefined;
    get erAttachmentId(): string;
    private _erId?;
    get erId(): string;
    set erId(value: string);
    resetErId(): void;
    get erIdInput(): string | undefined;
    private _flavor?;
    get flavor(): string;
    set flavor(value: string);
    resetFlavor(): void;
    get flavorInput(): string | undefined;
    private _haMode?;
    get haMode(): string;
    set haMode(value: string);
    resetHaMode(): void;
    get haModeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _localSubnets?;
    get localSubnets(): string[];
    set localSubnets(value: string[]);
    resetLocalSubnets(): void;
    get localSubnetsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _networkType?;
    get networkType(): string;
    set networkType(value: string);
    resetNetworkType(): void;
    get networkTypeInput(): string | undefined;
    get region(): string;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get updatedAt(): string;
    get usedConnectionGroup(): number;
    get usedConnectionNumber(): number;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    resetVpcId(): void;
    get vpcIdInput(): string | undefined;
    private _eip1;
    get eip1(): EnterpriseVpnGatewayV5Eip1OutputReference;
    putEip1(value: EnterpriseVpnGatewayV5Eip1): void;
    resetEip1(): void;
    get eip1Input(): EnterpriseVpnGatewayV5Eip1 | undefined;
    private _eip2;
    get eip2(): EnterpriseVpnGatewayV5Eip2OutputReference;
    putEip2(value: EnterpriseVpnGatewayV5Eip2): void;
    resetEip2(): void;
    get eip2Input(): EnterpriseVpnGatewayV5Eip2 | undefined;
    private _timeouts;
    get timeouts(): EnterpriseVpnGatewayV5TimeoutsOutputReference;
    putTimeouts(value: EnterpriseVpnGatewayV5Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | EnterpriseVpnGatewayV5Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface SwrRepositoryV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/swr_repository_v2#category SwrRepositoryV2#category}
    */
    readonly category?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/swr_repository_v2#description SwrRepositoryV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/swr_repository_v2#id SwrRepositoryV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/swr_repository_v2#is_public SwrRepositoryV2#is_public}
    */
    readonly isPublic: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/swr_repository_v2#name SwrRepositoryV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/swr_repository_v2#organization SwrRepositoryV2#organization}
    */
    readonly organization: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/swr_repository_v2#timeouts SwrRepositoryV2#timeouts}
    */
    readonly timeouts?: SwrRepositoryV2Timeouts;
}
export interface SwrRepositoryV2Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/swr_repository_v2#default SwrRepositoryV2#default}
    */
    readonly default?: string;
}
export declare function swrRepositoryV2TimeoutsToTerraform(struct?: SwrRepositoryV2Timeouts | cdktf.IResolvable): any;
export declare function swrRepositoryV2TimeoutsToHclTerraform(struct?: SwrRepositoryV2Timeouts | cdktf.IResolvable): any;
export declare class SwrRepositoryV2TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SwrRepositoryV2Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: SwrRepositoryV2Timeouts | cdktf.IResolvable | undefined);
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/swr_repository_v2 opentelekomcloud_swr_repository_v2}
*/
export declare class SwrRepositoryV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_swr_repository_v2";
    /**
    * Generates CDKTF code for importing a SwrRepositoryV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SwrRepositoryV2 to import
    * @param importFromId The id of the existing SwrRepositoryV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/swr_repository_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SwrRepositoryV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/swr_repository_v2 opentelekomcloud_swr_repository_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SwrRepositoryV2Config
    */
    constructor(scope: Construct, id: string, config: SwrRepositoryV2Config);
    private _category?;
    get category(): string;
    set category(value: string);
    resetCategory(): void;
    get categoryInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get internalPath(): string;
    private _isPublic?;
    get isPublic(): boolean | cdktf.IResolvable;
    set isPublic(value: boolean | cdktf.IResolvable);
    get isPublicInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get numImages(): number;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    get path(): string;
    get repositoryId(): number;
    get size(): number;
    private _timeouts;
    get timeouts(): SwrRepositoryV2TimeoutsOutputReference;
    putTimeouts(value: SwrRepositoryV2Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | SwrRepositoryV2Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CfwAclRuleV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#action_type CfwAclRuleV1#action_type}
    */
    readonly actionType: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#address_type CfwAclRuleV1#address_type}
    */
    readonly addressType: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#applications CfwAclRuleV1#applications}
    */
    readonly applications?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#applications_json_string CfwAclRuleV1#applications_json_string}
    */
    readonly applicationsJsonString?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#description CfwAclRuleV1#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#direction CfwAclRuleV1#direction}
    */
    readonly direction?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#long_connect_enable CfwAclRuleV1#long_connect_enable}
    */
    readonly longConnectEnable: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#long_connect_time CfwAclRuleV1#long_connect_time}
    */
    readonly longConnectTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#long_connect_time_hour CfwAclRuleV1#long_connect_time_hour}
    */
    readonly longConnectTimeHour?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#long_connect_time_minute CfwAclRuleV1#long_connect_time_minute}
    */
    readonly longConnectTimeMinute?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#long_connect_time_second CfwAclRuleV1#long_connect_time_second}
    */
    readonly longConnectTimeSecond?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#name CfwAclRuleV1#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#object_id CfwAclRuleV1#object_id}
    */
    readonly objectId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#status CfwAclRuleV1#status}
    */
    readonly status: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#type CfwAclRuleV1#type}
    */
    readonly type: number;
    /**
    * destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#destination CfwAclRuleV1#destination}
    */
    readonly destination: CfwAclRuleV1Destination;
    /**
    * sequence block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#sequence CfwAclRuleV1#sequence}
    */
    readonly sequence: CfwAclRuleV1Sequence;
    /**
    * service block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#service CfwAclRuleV1#service}
    */
    readonly service: CfwAclRuleV1Service;
    /**
    * source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#source CfwAclRuleV1#source}
    */
    readonly source: CfwAclRuleV1Source;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#timeouts CfwAclRuleV1#timeouts}
    */
    readonly timeouts?: CfwAclRuleV1Timeouts;
}
export interface CfwAclRuleV1DestinationRegionListStruct {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#region_id CfwAclRuleV1#region_id}
    */
    readonly regionId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#region_type CfwAclRuleV1#region_type}
    */
    readonly regionType?: number;
}
export declare function cfwAclRuleV1DestinationRegionListStructToTerraform(struct?: CfwAclRuleV1DestinationRegionListStruct | cdktf.IResolvable): any;
export declare function cfwAclRuleV1DestinationRegionListStructToHclTerraform(struct?: CfwAclRuleV1DestinationRegionListStruct | cdktf.IResolvable): any;
export declare class CfwAclRuleV1DestinationRegionListStructOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CfwAclRuleV1DestinationRegionListStruct | cdktf.IResolvable | undefined;
    set internalValue(value: CfwAclRuleV1DestinationRegionListStruct | cdktf.IResolvable | undefined);
    private _regionId?;
    get regionId(): string;
    set regionId(value: string);
    resetRegionId(): void;
    get regionIdInput(): string | undefined;
    private _regionType?;
    get regionType(): number;
    set regionType(value: number);
    resetRegionType(): void;
    get regionTypeInput(): number | undefined;
}
export declare class CfwAclRuleV1DestinationRegionListStructList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: CfwAclRuleV1DestinationRegionListStruct[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CfwAclRuleV1DestinationRegionListStructOutputReference;
}
export interface CfwAclRuleV1Destination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#address CfwAclRuleV1#address}
    */
    readonly address?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#address_group CfwAclRuleV1#address_group}
    */
    readonly addressGroup?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#address_set_id CfwAclRuleV1#address_set_id}
    */
    readonly addressSetId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#address_set_name CfwAclRuleV1#address_set_name}
    */
    readonly addressSetName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#address_set_type CfwAclRuleV1#address_set_type}
    */
    readonly addressSetType?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#address_type CfwAclRuleV1#address_type}
    */
    readonly addressType?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#domain_address_name CfwAclRuleV1#domain_address_name}
    */
    readonly domainAddressName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#domain_set_id CfwAclRuleV1#domain_set_id}
    */
    readonly domainSetId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#domain_set_name CfwAclRuleV1#domain_set_name}
    */
    readonly domainSetName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#ip_address CfwAclRuleV1#ip_address}
    */
    readonly ipAddress?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#predefined_group CfwAclRuleV1#predefined_group}
    */
    readonly predefinedGroup?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#region_list_json CfwAclRuleV1#region_list_json}
    */
    readonly regionListJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#type CfwAclRuleV1#type}
    */
    readonly type: number;
    /**
    * region_list block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#region_list CfwAclRuleV1#region_list}
    */
    readonly regionList?: CfwAclRuleV1DestinationRegionListStruct[] | cdktf.IResolvable;
}
export declare function cfwAclRuleV1DestinationToTerraform(struct?: CfwAclRuleV1DestinationOutputReference | CfwAclRuleV1Destination): any;
export declare function cfwAclRuleV1DestinationToHclTerraform(struct?: CfwAclRuleV1DestinationOutputReference | CfwAclRuleV1Destination): any;
export declare class CfwAclRuleV1DestinationOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CfwAclRuleV1Destination | undefined;
    set internalValue(value: CfwAclRuleV1Destination | undefined);
    private _address?;
    get address(): string;
    set address(value: string);
    resetAddress(): void;
    get addressInput(): string | undefined;
    private _addressGroup?;
    get addressGroup(): string[];
    set addressGroup(value: string[]);
    resetAddressGroup(): void;
    get addressGroupInput(): string[] | undefined;
    private _addressSetId?;
    get addressSetId(): string;
    set addressSetId(value: string);
    resetAddressSetId(): void;
    get addressSetIdInput(): string | undefined;
    private _addressSetName?;
    get addressSetName(): string;
    set addressSetName(value: string);
    resetAddressSetName(): void;
    get addressSetNameInput(): string | undefined;
    private _addressSetType?;
    get addressSetType(): number;
    set addressSetType(value: number);
    resetAddressSetType(): void;
    get addressSetTypeInput(): number | undefined;
    private _addressType?;
    get addressType(): number;
    set addressType(value: number);
    resetAddressType(): void;
    get addressTypeInput(): number | undefined;
    private _domainAddressName?;
    get domainAddressName(): string;
    set domainAddressName(value: string);
    resetDomainAddressName(): void;
    get domainAddressNameInput(): string | undefined;
    private _domainSetId?;
    get domainSetId(): string;
    set domainSetId(value: string);
    resetDomainSetId(): void;
    get domainSetIdInput(): string | undefined;
    private _domainSetName?;
    get domainSetName(): string;
    set domainSetName(value: string);
    resetDomainSetName(): void;
    get domainSetNameInput(): string | undefined;
    private _ipAddress?;
    get ipAddress(): string[];
    set ipAddress(value: string[]);
    resetIpAddress(): void;
    get ipAddressInput(): string[] | undefined;
    private _predefinedGroup?;
    get predefinedGroup(): string[];
    set predefinedGroup(value: string[]);
    resetPredefinedGroup(): void;
    get predefinedGroupInput(): string[] | undefined;
    private _regionListJson?;
    get regionListJson(): string;
    set regionListJson(value: string);
    resetRegionListJson(): void;
    get regionListJsonInput(): string | undefined;
    private _type?;
    get type(): number;
    set type(value: number);
    get typeInput(): number | undefined;
    private _regionList;
    get regionList(): CfwAclRuleV1DestinationRegionListStructList;
    putRegionList(value: CfwAclRuleV1DestinationRegionListStruct[] | cdktf.IResolvable): void;
    resetRegionList(): void;
    get regionListInput(): cdktf.IResolvable | CfwAclRuleV1DestinationRegionListStruct[] | undefined;
}
export interface CfwAclRuleV1Sequence {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#bottom CfwAclRuleV1#bottom}
    */
    readonly bottom?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#dest_rule_id CfwAclRuleV1#dest_rule_id}
    */
    readonly destRuleId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#top CfwAclRuleV1#top}
    */
    readonly top?: number;
}
export declare function cfwAclRuleV1SequenceToTerraform(struct?: CfwAclRuleV1SequenceOutputReference | CfwAclRuleV1Sequence): any;
export declare function cfwAclRuleV1SequenceToHclTerraform(struct?: CfwAclRuleV1SequenceOutputReference | CfwAclRuleV1Sequence): any;
export declare class CfwAclRuleV1SequenceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CfwAclRuleV1Sequence | undefined;
    set internalValue(value: CfwAclRuleV1Sequence | undefined);
    private _bottom?;
    get bottom(): number;
    set bottom(value: number);
    resetBottom(): void;
    get bottomInput(): number | undefined;
    private _destRuleId?;
    get destRuleId(): string;
    set destRuleId(value: string);
    resetDestRuleId(): void;
    get destRuleIdInput(): string | undefined;
    private _top?;
    get top(): number;
    set top(value: number);
    resetTop(): void;
    get topInput(): number | undefined;
}
export interface CfwAclRuleV1ServiceCustomService {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#description CfwAclRuleV1#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#dest_port CfwAclRuleV1#dest_port}
    */
    readonly destPort?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#name CfwAclRuleV1#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#protocol CfwAclRuleV1#protocol}
    */
    readonly protocol?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#source_port CfwAclRuleV1#source_port}
    */
    readonly sourcePort?: string;
}
export declare function cfwAclRuleV1ServiceCustomServiceToTerraform(struct?: CfwAclRuleV1ServiceCustomService | cdktf.IResolvable): any;
export declare function cfwAclRuleV1ServiceCustomServiceToHclTerraform(struct?: CfwAclRuleV1ServiceCustomService | cdktf.IResolvable): any;
export declare class CfwAclRuleV1ServiceCustomServiceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CfwAclRuleV1ServiceCustomService | cdktf.IResolvable | undefined;
    set internalValue(value: CfwAclRuleV1ServiceCustomService | cdktf.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _destPort?;
    get destPort(): string;
    set destPort(value: string);
    resetDestPort(): void;
    get destPortInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _protocol?;
    get protocol(): number;
    set protocol(value: number);
    resetProtocol(): void;
    get protocolInput(): number | undefined;
    private _sourcePort?;
    get sourcePort(): string;
    set sourcePort(value: string);
    resetSourcePort(): void;
    get sourcePortInput(): string | undefined;
}
export declare class CfwAclRuleV1ServiceCustomServiceList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: CfwAclRuleV1ServiceCustomService[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CfwAclRuleV1ServiceCustomServiceOutputReference;
}
export interface CfwAclRuleV1ServiceServiceGroupNames {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#name CfwAclRuleV1#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#protocols CfwAclRuleV1#protocols}
    */
    readonly protocols?: number[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#service_set_type CfwAclRuleV1#service_set_type}
    */
    readonly serviceSetType?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#set_id CfwAclRuleV1#set_id}
    */
    readonly setId?: string;
}
export declare function cfwAclRuleV1ServiceServiceGroupNamesToTerraform(struct?: CfwAclRuleV1ServiceServiceGroupNames | cdktf.IResolvable): any;
export declare function cfwAclRuleV1ServiceServiceGroupNamesToHclTerraform(struct?: CfwAclRuleV1ServiceServiceGroupNames | cdktf.IResolvable): any;
export declare class CfwAclRuleV1ServiceServiceGroupNamesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CfwAclRuleV1ServiceServiceGroupNames | cdktf.IResolvable | undefined;
    set internalValue(value: CfwAclRuleV1ServiceServiceGroupNames | cdktf.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _protocols?;
    get protocols(): number[];
    set protocols(value: number[]);
    resetProtocols(): void;
    get protocolsInput(): number[] | undefined;
    private _serviceSetType?;
    get serviceSetType(): number;
    set serviceSetType(value: number);
    resetServiceSetType(): void;
    get serviceSetTypeInput(): number | undefined;
    private _setId?;
    get setId(): string;
    set setId(value: string);
    resetSetId(): void;
    get setIdInput(): string | undefined;
}
export declare class CfwAclRuleV1ServiceServiceGroupNamesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: CfwAclRuleV1ServiceServiceGroupNames[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CfwAclRuleV1ServiceServiceGroupNamesOutputReference;
}
export interface CfwAclRuleV1Service {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#dest_port CfwAclRuleV1#dest_port}
    */
    readonly destPort?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#predefined_group CfwAclRuleV1#predefined_group}
    */
    readonly predefinedGroup?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#protocol CfwAclRuleV1#protocol}
    */
    readonly protocol?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#protocols CfwAclRuleV1#protocols}
    */
    readonly protocols?: number[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#service_group CfwAclRuleV1#service_group}
    */
    readonly serviceGroup?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#service_set_id CfwAclRuleV1#service_set_id}
    */
    readonly serviceSetId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#service_set_name CfwAclRuleV1#service_set_name}
    */
    readonly serviceSetName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#service_set_type CfwAclRuleV1#service_set_type}
    */
    readonly serviceSetType?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#source_port CfwAclRuleV1#source_port}
    */
    readonly sourcePort?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#type CfwAclRuleV1#type}
    */
    readonly type: number;
    /**
    * custom_service block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#custom_service CfwAclRuleV1#custom_service}
    */
    readonly customService?: CfwAclRuleV1ServiceCustomService[] | cdktf.IResolvable;
    /**
    * service_group_names block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#service_group_names CfwAclRuleV1#service_group_names}
    */
    readonly serviceGroupNames?: CfwAclRuleV1ServiceServiceGroupNames[] | cdktf.IResolvable;
}
export declare function cfwAclRuleV1ServiceToTerraform(struct?: CfwAclRuleV1ServiceOutputReference | CfwAclRuleV1Service): any;
export declare function cfwAclRuleV1ServiceToHclTerraform(struct?: CfwAclRuleV1ServiceOutputReference | CfwAclRuleV1Service): any;
export declare class CfwAclRuleV1ServiceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CfwAclRuleV1Service | undefined;
    set internalValue(value: CfwAclRuleV1Service | undefined);
    private _destPort?;
    get destPort(): string;
    set destPort(value: string);
    resetDestPort(): void;
    get destPortInput(): string | undefined;
    private _predefinedGroup?;
    get predefinedGroup(): string[];
    set predefinedGroup(value: string[]);
    resetPredefinedGroup(): void;
    get predefinedGroupInput(): string[] | undefined;
    private _protocol?;
    get protocol(): number;
    set protocol(value: number);
    resetProtocol(): void;
    get protocolInput(): number | undefined;
    private _protocols?;
    get protocols(): number[];
    set protocols(value: number[]);
    resetProtocols(): void;
    get protocolsInput(): number[] | undefined;
    private _serviceGroup?;
    get serviceGroup(): string[];
    set serviceGroup(value: string[]);
    resetServiceGroup(): void;
    get serviceGroupInput(): string[] | undefined;
    private _serviceSetId?;
    get serviceSetId(): string;
    set serviceSetId(value: string);
    resetServiceSetId(): void;
    get serviceSetIdInput(): string | undefined;
    private _serviceSetName?;
    get serviceSetName(): string;
    set serviceSetName(value: string);
    resetServiceSetName(): void;
    get serviceSetNameInput(): string | undefined;
    private _serviceSetType?;
    get serviceSetType(): number;
    set serviceSetType(value: number);
    resetServiceSetType(): void;
    get serviceSetTypeInput(): number | undefined;
    private _sourcePort?;
    get sourcePort(): string;
    set sourcePort(value: string);
    resetSourcePort(): void;
    get sourcePortInput(): string | undefined;
    private _type?;
    get type(): number;
    set type(value: number);
    get typeInput(): number | undefined;
    private _customService;
    get customService(): CfwAclRuleV1ServiceCustomServiceList;
    putCustomService(value: CfwAclRuleV1ServiceCustomService[] | cdktf.IResolvable): void;
    resetCustomService(): void;
    get customServiceInput(): cdktf.IResolvable | CfwAclRuleV1ServiceCustomService[] | undefined;
    private _serviceGroupNames;
    get serviceGroupNames(): CfwAclRuleV1ServiceServiceGroupNamesList;
    putServiceGroupNames(value: CfwAclRuleV1ServiceServiceGroupNames[] | cdktf.IResolvable): void;
    resetServiceGroupNames(): void;
    get serviceGroupNamesInput(): cdktf.IResolvable | CfwAclRuleV1ServiceServiceGroupNames[] | undefined;
}
export interface CfwAclRuleV1SourceRegionListStruct {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#region_id CfwAclRuleV1#region_id}
    */
    readonly regionId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#region_type CfwAclRuleV1#region_type}
    */
    readonly regionType?: number;
}
export declare function cfwAclRuleV1SourceRegionListStructToTerraform(struct?: CfwAclRuleV1SourceRegionListStruct | cdktf.IResolvable): any;
export declare function cfwAclRuleV1SourceRegionListStructToHclTerraform(struct?: CfwAclRuleV1SourceRegionListStruct | cdktf.IResolvable): any;
export declare class CfwAclRuleV1SourceRegionListStructOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CfwAclRuleV1SourceRegionListStruct | cdktf.IResolvable | undefined;
    set internalValue(value: CfwAclRuleV1SourceRegionListStruct | cdktf.IResolvable | undefined);
    private _regionId?;
    get regionId(): string;
    set regionId(value: string);
    resetRegionId(): void;
    get regionIdInput(): string | undefined;
    private _regionType?;
    get regionType(): number;
    set regionType(value: number);
    resetRegionType(): void;
    get regionTypeInput(): number | undefined;
}
export declare class CfwAclRuleV1SourceRegionListStructList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: CfwAclRuleV1SourceRegionListStruct[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CfwAclRuleV1SourceRegionListStructOutputReference;
}
export interface CfwAclRuleV1Source {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#address CfwAclRuleV1#address}
    */
    readonly address?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#address_group CfwAclRuleV1#address_group}
    */
    readonly addressGroup?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#address_set_id CfwAclRuleV1#address_set_id}
    */
    readonly addressSetId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#address_set_name CfwAclRuleV1#address_set_name}
    */
    readonly addressSetName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#address_set_type CfwAclRuleV1#address_set_type}
    */
    readonly addressSetType?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#address_type CfwAclRuleV1#address_type}
    */
    readonly addressType?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#domain_address_name CfwAclRuleV1#domain_address_name}
    */
    readonly domainAddressName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#domain_set_id CfwAclRuleV1#domain_set_id}
    */
    readonly domainSetId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#domain_set_name CfwAclRuleV1#domain_set_name}
    */
    readonly domainSetName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#ip_address CfwAclRuleV1#ip_address}
    */
    readonly ipAddress?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#predefined_group CfwAclRuleV1#predefined_group}
    */
    readonly predefinedGroup?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#region_list_json CfwAclRuleV1#region_list_json}
    */
    readonly regionListJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#type CfwAclRuleV1#type}
    */
    readonly type: number;
    /**
    * region_list block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#region_list CfwAclRuleV1#region_list}
    */
    readonly regionList?: CfwAclRuleV1SourceRegionListStruct[] | cdktf.IResolvable;
}
export declare function cfwAclRuleV1SourceToTerraform(struct?: CfwAclRuleV1SourceOutputReference | CfwAclRuleV1Source): any;
export declare function cfwAclRuleV1SourceToHclTerraform(struct?: CfwAclRuleV1SourceOutputReference | CfwAclRuleV1Source): any;
export declare class CfwAclRuleV1SourceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CfwAclRuleV1Source | undefined;
    set internalValue(value: CfwAclRuleV1Source | undefined);
    private _address?;
    get address(): string;
    set address(value: string);
    resetAddress(): void;
    get addressInput(): string | undefined;
    private _addressGroup?;
    get addressGroup(): string[];
    set addressGroup(value: string[]);
    resetAddressGroup(): void;
    get addressGroupInput(): string[] | undefined;
    private _addressSetId?;
    get addressSetId(): string;
    set addressSetId(value: string);
    resetAddressSetId(): void;
    get addressSetIdInput(): string | undefined;
    private _addressSetName?;
    get addressSetName(): string;
    set addressSetName(value: string);
    resetAddressSetName(): void;
    get addressSetNameInput(): string | undefined;
    private _addressSetType?;
    get addressSetType(): number;
    set addressSetType(value: number);
    resetAddressSetType(): void;
    get addressSetTypeInput(): number | undefined;
    private _addressType?;
    get addressType(): number;
    set addressType(value: number);
    resetAddressType(): void;
    get addressTypeInput(): number | undefined;
    private _domainAddressName?;
    get domainAddressName(): string;
    set domainAddressName(value: string);
    resetDomainAddressName(): void;
    get domainAddressNameInput(): string | undefined;
    private _domainSetId?;
    get domainSetId(): string;
    set domainSetId(value: string);
    resetDomainSetId(): void;
    get domainSetIdInput(): string | undefined;
    private _domainSetName?;
    get domainSetName(): string;
    set domainSetName(value: string);
    resetDomainSetName(): void;
    get domainSetNameInput(): string | undefined;
    private _ipAddress?;
    get ipAddress(): string[];
    set ipAddress(value: string[]);
    resetIpAddress(): void;
    get ipAddressInput(): string[] | undefined;
    private _predefinedGroup?;
    get predefinedGroup(): string[];
    set predefinedGroup(value: string[]);
    resetPredefinedGroup(): void;
    get predefinedGroupInput(): string[] | undefined;
    private _regionListJson?;
    get regionListJson(): string;
    set regionListJson(value: string);
    resetRegionListJson(): void;
    get regionListJsonInput(): string | undefined;
    private _type?;
    get type(): number;
    set type(value: number);
    get typeInput(): number | undefined;
    private _regionList;
    get regionList(): CfwAclRuleV1SourceRegionListStructList;
    putRegionList(value: CfwAclRuleV1SourceRegionListStruct[] | cdktf.IResolvable): void;
    resetRegionList(): void;
    get regionListInput(): cdktf.IResolvable | CfwAclRuleV1SourceRegionListStruct[] | undefined;
}
export interface CfwAclRuleV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#create CfwAclRuleV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#delete CfwAclRuleV1#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#update CfwAclRuleV1#update}
    */
    readonly update?: string;
}
export declare function cfwAclRuleV1TimeoutsToTerraform(struct?: CfwAclRuleV1Timeouts | cdktf.IResolvable): any;
export declare function cfwAclRuleV1TimeoutsToHclTerraform(struct?: CfwAclRuleV1Timeouts | cdktf.IResolvable): any;
export declare class CfwAclRuleV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CfwAclRuleV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: CfwAclRuleV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1 opentelekomcloud_cfw_acl_rule_v1}
*/
export declare class CfwAclRuleV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_cfw_acl_rule_v1";
    /**
    * Generates CDKTF code for importing a CfwAclRuleV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CfwAclRuleV1 to import
    * @param importFromId The id of the existing CfwAclRuleV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CfwAclRuleV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_acl_rule_v1 opentelekomcloud_cfw_acl_rule_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CfwAclRuleV1Config
    */
    constructor(scope: Construct, id: string, config: CfwAclRuleV1Config);
    private _actionType?;
    get actionType(): number;
    set actionType(value: number);
    get actionTypeInput(): number | undefined;
    private _addressType?;
    get addressType(): number;
    set addressType(value: number);
    get addressTypeInput(): number | undefined;
    private _applications?;
    get applications(): string[];
    set applications(value: string[]);
    resetApplications(): void;
    get applicationsInput(): string[] | undefined;
    private _applicationsJsonString?;
    get applicationsJsonString(): string;
    set applicationsJsonString(value: string);
    resetApplicationsJsonString(): void;
    get applicationsJsonStringInput(): string | undefined;
    get createdDate(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _direction?;
    get direction(): number;
    set direction(value: number);
    resetDirection(): void;
    get directionInput(): number | undefined;
    get id(): string;
    get lastOpenTime(): string;
    private _longConnectEnable?;
    get longConnectEnable(): number;
    set longConnectEnable(value: number);
    get longConnectEnableInput(): number | undefined;
    private _longConnectTime?;
    get longConnectTime(): number;
    set longConnectTime(value: number);
    resetLongConnectTime(): void;
    get longConnectTimeInput(): number | undefined;
    private _longConnectTimeHour?;
    get longConnectTimeHour(): number;
    set longConnectTimeHour(value: number);
    resetLongConnectTimeHour(): void;
    get longConnectTimeHourInput(): number | undefined;
    private _longConnectTimeMinute?;
    get longConnectTimeMinute(): number;
    set longConnectTimeMinute(value: number);
    resetLongConnectTimeMinute(): void;
    get longConnectTimeMinuteInput(): number | undefined;
    private _longConnectTimeSecond?;
    get longConnectTimeSecond(): number;
    set longConnectTimeSecond(value: number);
    resetLongConnectTimeSecond(): void;
    get longConnectTimeSecondInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _objectId?;
    get objectId(): string;
    set objectId(value: string);
    get objectIdInput(): string | undefined;
    private _status?;
    get status(): number;
    set status(value: number);
    get statusInput(): number | undefined;
    private _type?;
    get type(): number;
    set type(value: number);
    get typeInput(): number | undefined;
    private _destination;
    get destination(): CfwAclRuleV1DestinationOutputReference;
    putDestination(value: CfwAclRuleV1Destination): void;
    get destinationInput(): CfwAclRuleV1Destination | undefined;
    private _sequence;
    get sequence(): CfwAclRuleV1SequenceOutputReference;
    putSequence(value: CfwAclRuleV1Sequence): void;
    get sequenceInput(): CfwAclRuleV1Sequence | undefined;
    private _service;
    get service(): CfwAclRuleV1ServiceOutputReference;
    putService(value: CfwAclRuleV1Service): void;
    get serviceInput(): CfwAclRuleV1Service | undefined;
    private _source;
    get source(): CfwAclRuleV1SourceOutputReference;
    putSource(value: CfwAclRuleV1Source): void;
    get sourceInput(): CfwAclRuleV1Source | undefined;
    private _timeouts;
    get timeouts(): CfwAclRuleV1TimeoutsOutputReference;
    putTimeouts(value: CfwAclRuleV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | CfwAclRuleV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

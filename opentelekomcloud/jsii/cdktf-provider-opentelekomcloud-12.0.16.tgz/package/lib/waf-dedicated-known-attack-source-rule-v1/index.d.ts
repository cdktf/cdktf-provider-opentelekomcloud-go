/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface WafDedicatedKnownAttackSourceRuleV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_known_attack_source_rule_v1#block_time WafDedicatedKnownAttackSourceRuleV1#block_time}
    */
    readonly blockTime: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_known_attack_source_rule_v1#category WafDedicatedKnownAttackSourceRuleV1#category}
    */
    readonly category: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_known_attack_source_rule_v1#description WafDedicatedKnownAttackSourceRuleV1#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_known_attack_source_rule_v1#id WafDedicatedKnownAttackSourceRuleV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_known_attack_source_rule_v1#policy_id WafDedicatedKnownAttackSourceRuleV1#policy_id}
    */
    readonly policyId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_known_attack_source_rule_v1#timeouts WafDedicatedKnownAttackSourceRuleV1#timeouts}
    */
    readonly timeouts?: WafDedicatedKnownAttackSourceRuleV1Timeouts;
}
export interface WafDedicatedKnownAttackSourceRuleV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_known_attack_source_rule_v1#create WafDedicatedKnownAttackSourceRuleV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_known_attack_source_rule_v1#delete WafDedicatedKnownAttackSourceRuleV1#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_known_attack_source_rule_v1#update WafDedicatedKnownAttackSourceRuleV1#update}
    */
    readonly update?: string;
}
export declare function wafDedicatedKnownAttackSourceRuleV1TimeoutsToTerraform(struct?: WafDedicatedKnownAttackSourceRuleV1Timeouts | cdktf.IResolvable): any;
export declare function wafDedicatedKnownAttackSourceRuleV1TimeoutsToHclTerraform(struct?: WafDedicatedKnownAttackSourceRuleV1Timeouts | cdktf.IResolvable): any;
export declare class WafDedicatedKnownAttackSourceRuleV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WafDedicatedKnownAttackSourceRuleV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: WafDedicatedKnownAttackSourceRuleV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_known_attack_source_rule_v1 opentelekomcloud_waf_dedicated_known_attack_source_rule_v1}
*/
export declare class WafDedicatedKnownAttackSourceRuleV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_waf_dedicated_known_attack_source_rule_v1";
    /**
    * Generates CDKTF code for importing a WafDedicatedKnownAttackSourceRuleV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WafDedicatedKnownAttackSourceRuleV1 to import
    * @param importFromId The id of the existing WafDedicatedKnownAttackSourceRuleV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_known_attack_source_rule_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WafDedicatedKnownAttackSourceRuleV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/waf_dedicated_known_attack_source_rule_v1 opentelekomcloud_waf_dedicated_known_attack_source_rule_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WafDedicatedKnownAttackSourceRuleV1Config
    */
    constructor(scope: Construct, id: string, config: WafDedicatedKnownAttackSourceRuleV1Config);
    private _blockTime?;
    get blockTime(): number;
    set blockTime(value: number);
    get blockTimeInput(): number | undefined;
    private _category?;
    get category(): string;
    set category(value: string);
    get categoryInput(): string | undefined;
    get createdAt(): number;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    get policyIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): WafDedicatedKnownAttackSourceRuleV1TimeoutsOutputReference;
    putTimeouts(value: WafDedicatedKnownAttackSourceRuleV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | WafDedicatedKnownAttackSourceRuleV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

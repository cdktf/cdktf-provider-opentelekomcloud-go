/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudTmsResourceTagKeysV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/tms_resource_tag_keys_v1#id DataOpentelekomcloudTmsResourceTagKeysV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/tms_resource_tag_keys_v1#region_id DataOpentelekomcloudTmsResourceTagKeysV1#region_id}
    */
    readonly regionId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/tms_resource_tag_keys_v1 opentelekomcloud_tms_resource_tag_keys_v1}
*/
export declare class DataOpentelekomcloudTmsResourceTagKeysV1 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_tms_resource_tag_keys_v1";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudTmsResourceTagKeysV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudTmsResourceTagKeysV1 to import
    * @param importFromId The id of the existing DataOpentelekomcloudTmsResourceTagKeysV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/tms_resource_tag_keys_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudTmsResourceTagKeysV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/tms_resource_tag_keys_v1 opentelekomcloud_tms_resource_tag_keys_v1} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudTmsResourceTagKeysV1Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudTmsResourceTagKeysV1Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get keys(): string[];
    private _regionId?;
    get regionId(): string;
    set regionId(value: string);
    resetRegionId(): void;
    get regionIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

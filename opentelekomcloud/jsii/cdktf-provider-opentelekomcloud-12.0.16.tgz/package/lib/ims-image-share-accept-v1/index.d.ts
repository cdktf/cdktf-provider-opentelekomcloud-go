/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ImsImageShareAcceptV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ims_image_share_accept_v1#id ImsImageShareAcceptV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ims_image_share_accept_v1#image_id ImsImageShareAcceptV1#image_id}
    */
    readonly imageId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ims_image_share_accept_v1#vault_id ImsImageShareAcceptV1#vault_id}
    */
    readonly vaultId?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ims_image_share_accept_v1#timeouts ImsImageShareAcceptV1#timeouts}
    */
    readonly timeouts?: ImsImageShareAcceptV1Timeouts;
}
export interface ImsImageShareAcceptV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ims_image_share_accept_v1#create ImsImageShareAcceptV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ims_image_share_accept_v1#delete ImsImageShareAcceptV1#delete}
    */
    readonly delete?: string;
}
export declare function imsImageShareAcceptV1TimeoutsToTerraform(struct?: ImsImageShareAcceptV1Timeouts | cdktf.IResolvable): any;
export declare function imsImageShareAcceptV1TimeoutsToHclTerraform(struct?: ImsImageShareAcceptV1Timeouts | cdktf.IResolvable): any;
export declare class ImsImageShareAcceptV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ImsImageShareAcceptV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: ImsImageShareAcceptV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ims_image_share_accept_v1 opentelekomcloud_ims_image_share_accept_v1}
*/
export declare class ImsImageShareAcceptV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_ims_image_share_accept_v1";
    /**
    * Generates CDKTF code for importing a ImsImageShareAcceptV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ImsImageShareAcceptV1 to import
    * @param importFromId The id of the existing ImsImageShareAcceptV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ims_image_share_accept_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ImsImageShareAcceptV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ims_image_share_accept_v1 opentelekomcloud_ims_image_share_accept_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ImsImageShareAcceptV1Config
    */
    constructor(scope: Construct, id: string, config: ImsImageShareAcceptV1Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _imageId?;
    get imageId(): string;
    set imageId(value: string);
    get imageIdInput(): string | undefined;
    get region(): string;
    private _vaultId?;
    get vaultId(): string;
    set vaultId(value: string);
    resetVaultId(): void;
    get vaultIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): ImsImageShareAcceptV1TimeoutsOutputReference;
    putTimeouts(value: ImsImageShareAcceptV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | ImsImageShareAcceptV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

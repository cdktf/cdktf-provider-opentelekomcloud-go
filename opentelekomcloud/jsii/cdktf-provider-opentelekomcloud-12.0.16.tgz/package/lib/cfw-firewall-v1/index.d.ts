/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CfwFirewallV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_firewall_v1#name CfwFirewallV1#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_firewall_v1#service_type CfwFirewallV1#service_type}
    */
    readonly serviceType?: string;
    /**
    * charge_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_firewall_v1#charge_info CfwFirewallV1#charge_info}
    */
    readonly chargeInfo: CfwFirewallV1ChargeInfo;
    /**
    * flavor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_firewall_v1#flavor CfwFirewallV1#flavor}
    */
    readonly flavor: CfwFirewallV1Flavor;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_firewall_v1#timeouts CfwFirewallV1#timeouts}
    */
    readonly timeouts?: CfwFirewallV1Timeouts;
}
export interface CfwFirewallV1ProtectObjects {
}
export declare function cfwFirewallV1ProtectObjectsToTerraform(struct?: CfwFirewallV1ProtectObjects): any;
export declare function cfwFirewallV1ProtectObjectsToHclTerraform(struct?: CfwFirewallV1ProtectObjects): any;
export declare class CfwFirewallV1ProtectObjectsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CfwFirewallV1ProtectObjects | undefined;
    set internalValue(value: CfwFirewallV1ProtectObjects | undefined);
    get objectId(): string;
    get objectName(): string;
    get type(): number;
}
export declare class CfwFirewallV1ProtectObjectsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CfwFirewallV1ProtectObjectsOutputReference;
}
export interface CfwFirewallV1Resources {
}
export declare function cfwFirewallV1ResourcesToTerraform(struct?: CfwFirewallV1Resources): any;
export declare function cfwFirewallV1ResourcesToHclTerraform(struct?: CfwFirewallV1Resources): any;
export declare class CfwFirewallV1ResourcesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CfwFirewallV1Resources | undefined;
    set internalValue(value: CfwFirewallV1Resources | undefined);
    get cloudServiceType(): string;
    get resourceId(): string;
    get resourceSize(): number;
    get resourceSizeMeasureId(): number;
    get resourceSpecCode(): string;
    get resourceType(): string;
}
export declare class CfwFirewallV1ResourcesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CfwFirewallV1ResourcesOutputReference;
}
export interface CfwFirewallV1ChargeInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_firewall_v1#charge_mode CfwFirewallV1#charge_mode}
    */
    readonly chargeMode: string;
}
export declare function cfwFirewallV1ChargeInfoToTerraform(struct?: CfwFirewallV1ChargeInfoOutputReference | CfwFirewallV1ChargeInfo): any;
export declare function cfwFirewallV1ChargeInfoToHclTerraform(struct?: CfwFirewallV1ChargeInfoOutputReference | CfwFirewallV1ChargeInfo): any;
export declare class CfwFirewallV1ChargeInfoOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CfwFirewallV1ChargeInfo | undefined;
    set internalValue(value: CfwFirewallV1ChargeInfo | undefined);
    private _chargeMode?;
    get chargeMode(): string;
    set chargeMode(value: string);
    get chargeModeInput(): string | undefined;
}
export interface CfwFirewallV1Flavor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_firewall_v1#version CfwFirewallV1#version}
    */
    readonly version: string;
}
export declare function cfwFirewallV1FlavorToTerraform(struct?: CfwFirewallV1FlavorOutputReference | CfwFirewallV1Flavor): any;
export declare function cfwFirewallV1FlavorToHclTerraform(struct?: CfwFirewallV1FlavorOutputReference | CfwFirewallV1Flavor): any;
export declare class CfwFirewallV1FlavorOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CfwFirewallV1Flavor | undefined;
    set internalValue(value: CfwFirewallV1Flavor | undefined);
    get bandwidth(): number;
    get defaultBandwidth(): number;
    get defaultEipCount(): number;
    get defaultLogStorage(): number;
    get defaultVpcCount(): number;
    get eipCount(): number;
    get logStorage(): number;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
    get versionCode(): number;
    get vpcCount(): number;
}
export interface CfwFirewallV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_firewall_v1#create CfwFirewallV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_firewall_v1#delete CfwFirewallV1#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_firewall_v1#update CfwFirewallV1#update}
    */
    readonly update?: string;
}
export declare function cfwFirewallV1TimeoutsToTerraform(struct?: CfwFirewallV1Timeouts | cdktf.IResolvable): any;
export declare function cfwFirewallV1TimeoutsToHclTerraform(struct?: CfwFirewallV1Timeouts | cdktf.IResolvable): any;
export declare class CfwFirewallV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CfwFirewallV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: CfwFirewallV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_firewall_v1 opentelekomcloud_cfw_firewall_v1}
*/
export declare class CfwFirewallV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_cfw_firewall_v1";
    /**
    * Generates CDKTF code for importing a CfwFirewallV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CfwFirewallV1 to import
    * @param importFromId The id of the existing CfwFirewallV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_firewall_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CfwFirewallV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_firewall_v1 opentelekomcloud_cfw_firewall_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CfwFirewallV1Config
    */
    constructor(scope: Construct, id: string, config: CfwFirewallV1Config);
    get chargeMode(): number;
    get engineType(): number;
    get enterpriseProjectId(): string;
    private _featureToggle;
    get featureToggle(): cdktf.BooleanMap;
    get haType(): number;
    get id(): string;
    get isAvailableObs(): cdktf.IResolvable;
    get isOldFirewallInstance(): cdktf.IResolvable;
    get isSupportThreatTags(): cdktf.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _protectObjects;
    get protectObjects(): CfwFirewallV1ProtectObjectsList;
    get resourceId(): string;
    private _resources;
    get resources(): CfwFirewallV1ResourcesList;
    private _serviceType?;
    get serviceType(): string;
    set serviceType(value: string);
    resetServiceType(): void;
    get serviceTypeInput(): string | undefined;
    get status(): number;
    get supportIpv6(): cdktf.IResolvable;
    get supportUrlFiltering(): cdktf.IResolvable;
    private _chargeInfo;
    get chargeInfo(): CfwFirewallV1ChargeInfoOutputReference;
    putChargeInfo(value: CfwFirewallV1ChargeInfo): void;
    get chargeInfoInput(): CfwFirewallV1ChargeInfo | undefined;
    private _flavor;
    get flavor(): CfwFirewallV1FlavorOutputReference;
    putFlavor(value: CfwFirewallV1Flavor): void;
    get flavorInput(): CfwFirewallV1Flavor | undefined;
    private _timeouts;
    get timeouts(): CfwFirewallV1TimeoutsOutputReference;
    putTimeouts(value: CfwFirewallV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | CfwFirewallV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

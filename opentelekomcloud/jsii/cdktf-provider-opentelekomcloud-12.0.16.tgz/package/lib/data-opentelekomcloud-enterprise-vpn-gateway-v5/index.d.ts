/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudEnterpriseVpnGatewayV5Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/enterprise_vpn_gateway_v5#id DataOpentelekomcloudEnterpriseVpnGatewayV5#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataOpentelekomcloudEnterpriseVpnGatewayV5Eip1 {
}
export declare function dataOpentelekomcloudEnterpriseVpnGatewayV5Eip1ToTerraform(struct?: DataOpentelekomcloudEnterpriseVpnGatewayV5Eip1): any;
export declare function dataOpentelekomcloudEnterpriseVpnGatewayV5Eip1ToHclTerraform(struct?: DataOpentelekomcloudEnterpriseVpnGatewayV5Eip1): any;
export declare class DataOpentelekomcloudEnterpriseVpnGatewayV5Eip1OutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudEnterpriseVpnGatewayV5Eip1 | undefined;
    set internalValue(value: DataOpentelekomcloudEnterpriseVpnGatewayV5Eip1 | undefined);
    get bandwidthId(): string;
    get bandwidthName(): string;
    get bandwidthSize(): number;
    get chargeMode(): string;
    get id(): string;
    get ipAddress(): string;
    get ipVersion(): number;
    get type(): string;
}
export declare class DataOpentelekomcloudEnterpriseVpnGatewayV5Eip1List extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudEnterpriseVpnGatewayV5Eip1OutputReference;
}
export interface DataOpentelekomcloudEnterpriseVpnGatewayV5Eip2 {
}
export declare function dataOpentelekomcloudEnterpriseVpnGatewayV5Eip2ToTerraform(struct?: DataOpentelekomcloudEnterpriseVpnGatewayV5Eip2): any;
export declare function dataOpentelekomcloudEnterpriseVpnGatewayV5Eip2ToHclTerraform(struct?: DataOpentelekomcloudEnterpriseVpnGatewayV5Eip2): any;
export declare class DataOpentelekomcloudEnterpriseVpnGatewayV5Eip2OutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudEnterpriseVpnGatewayV5Eip2 | undefined;
    set internalValue(value: DataOpentelekomcloudEnterpriseVpnGatewayV5Eip2 | undefined);
    get bandwidthId(): string;
    get bandwidthName(): string;
    get bandwidthSize(): number;
    get chargeMode(): string;
    get id(): string;
    get ipAddress(): string;
    get ipVersion(): number;
    get type(): string;
}
export declare class DataOpentelekomcloudEnterpriseVpnGatewayV5Eip2List extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudEnterpriseVpnGatewayV5Eip2OutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/enterprise_vpn_gateway_v5 opentelekomcloud_enterprise_vpn_gateway_v5}
*/
export declare class DataOpentelekomcloudEnterpriseVpnGatewayV5 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_enterprise_vpn_gateway_v5";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudEnterpriseVpnGatewayV5 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudEnterpriseVpnGatewayV5 to import
    * @param importFromId The id of the existing DataOpentelekomcloudEnterpriseVpnGatewayV5 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/enterprise_vpn_gateway_v5#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudEnterpriseVpnGatewayV5 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/enterprise_vpn_gateway_v5 opentelekomcloud_enterprise_vpn_gateway_v5} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudEnterpriseVpnGatewayV5Config
    */
    constructor(scope: Construct, id: string, config: DataOpentelekomcloudEnterpriseVpnGatewayV5Config);
    get accessPrivateIp1(): string;
    get accessPrivateIp2(): string;
    get accessSubnetId(): string;
    get accessVpcId(): string;
    get asn(): number;
    get attachmentType(): string;
    get availabilityZones(): string[];
    get connectSubnet(): string;
    get createdAt(): string;
    private _eip1;
    get eip1(): DataOpentelekomcloudEnterpriseVpnGatewayV5Eip1List;
    private _eip2;
    get eip2(): DataOpentelekomcloudEnterpriseVpnGatewayV5Eip2List;
    get erId(): string;
    get flavor(): string;
    get haMode(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get localSubnets(): string[];
    get name(): string;
    get networkType(): string;
    get region(): string;
    get status(): string;
    get updatedAt(): string;
    get usedConnectionGroup(): number;
    get usedConnectionNumber(): number;
    get vpcId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CssClusterV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#admin_pass CssClusterV1#admin_pass}
    */
    readonly adminPass?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#enable_authority CssClusterV1#enable_authority}
    */
    readonly enableAuthority?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#enable_https CssClusterV1#enable_https}
    */
    readonly enableHttps?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#expect_node_num CssClusterV1#expect_node_num}
    */
    readonly expectNodeNum?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#id CssClusterV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#name CssClusterV1#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#tags CssClusterV1#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * backup_strategy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#backup_strategy CssClusterV1#backup_strategy}
    */
    readonly backupStrategy?: CssClusterV1BackupStrategy;
    /**
    * datastore block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#datastore CssClusterV1#datastore}
    */
    readonly datastore?: CssClusterV1Datastore;
    /**
    * node_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#node_config CssClusterV1#node_config}
    */
    readonly nodeConfig: CssClusterV1NodeConfig;
    /**
    * public_access block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#public_access CssClusterV1#public_access}
    */
    readonly publicAccess?: CssClusterV1PublicAccess;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#timeouts CssClusterV1#timeouts}
    */
    readonly timeouts?: CssClusterV1Timeouts;
}
export interface CssClusterV1Nodes {
}
export declare function cssClusterV1NodesToTerraform(struct?: CssClusterV1Nodes): any;
export declare function cssClusterV1NodesToHclTerraform(struct?: CssClusterV1Nodes): any;
export declare class CssClusterV1NodesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CssClusterV1Nodes | undefined;
    set internalValue(value: CssClusterV1Nodes | undefined);
    get id(): string;
    get name(): string;
    get type(): string;
}
export declare class CssClusterV1NodesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CssClusterV1NodesOutputReference;
}
export interface CssClusterV1BackupStrategy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#keep_days CssClusterV1#keep_days}
    */
    readonly keepDays: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#prefix CssClusterV1#prefix}
    */
    readonly prefix: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#start_time CssClusterV1#start_time}
    */
    readonly startTime: string;
}
export declare function cssClusterV1BackupStrategyToTerraform(struct?: CssClusterV1BackupStrategyOutputReference | CssClusterV1BackupStrategy): any;
export declare function cssClusterV1BackupStrategyToHclTerraform(struct?: CssClusterV1BackupStrategyOutputReference | CssClusterV1BackupStrategy): any;
export declare class CssClusterV1BackupStrategyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CssClusterV1BackupStrategy | undefined;
    set internalValue(value: CssClusterV1BackupStrategy | undefined);
    private _keepDays?;
    get keepDays(): number;
    set keepDays(value: number);
    get keepDaysInput(): number | undefined;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    get prefixInput(): string | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    get startTimeInput(): string | undefined;
}
export interface CssClusterV1Datastore {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#type CssClusterV1#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#version CssClusterV1#version}
    */
    readonly version?: string;
}
export declare function cssClusterV1DatastoreToTerraform(struct?: CssClusterV1DatastoreOutputReference | CssClusterV1Datastore): any;
export declare function cssClusterV1DatastoreToHclTerraform(struct?: CssClusterV1DatastoreOutputReference | CssClusterV1Datastore): any;
export declare class CssClusterV1DatastoreOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CssClusterV1Datastore | undefined;
    set internalValue(value: CssClusterV1Datastore | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export interface CssClusterV1NodeConfigNetworkInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#network_id CssClusterV1#network_id}
    */
    readonly networkId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#security_group_id CssClusterV1#security_group_id}
    */
    readonly securityGroupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#vpc_id CssClusterV1#vpc_id}
    */
    readonly vpcId: string;
}
export declare function cssClusterV1NodeConfigNetworkInfoToTerraform(struct?: CssClusterV1NodeConfigNetworkInfoOutputReference | CssClusterV1NodeConfigNetworkInfo): any;
export declare function cssClusterV1NodeConfigNetworkInfoToHclTerraform(struct?: CssClusterV1NodeConfigNetworkInfoOutputReference | CssClusterV1NodeConfigNetworkInfo): any;
export declare class CssClusterV1NodeConfigNetworkInfoOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CssClusterV1NodeConfigNetworkInfo | undefined;
    set internalValue(value: CssClusterV1NodeConfigNetworkInfo | undefined);
    private _networkId?;
    get networkId(): string;
    set networkId(value: string);
    get networkIdInput(): string | undefined;
    private _securityGroupId?;
    get securityGroupId(): string;
    set securityGroupId(value: string);
    get securityGroupIdInput(): string | undefined;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    get vpcIdInput(): string | undefined;
}
export interface CssClusterV1NodeConfigVolume {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#encryption_key CssClusterV1#encryption_key}
    */
    readonly encryptionKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#size CssClusterV1#size}
    */
    readonly size: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#volume_type CssClusterV1#volume_type}
    */
    readonly volumeType: string;
}
export declare function cssClusterV1NodeConfigVolumeToTerraform(struct?: CssClusterV1NodeConfigVolumeOutputReference | CssClusterV1NodeConfigVolume): any;
export declare function cssClusterV1NodeConfigVolumeToHclTerraform(struct?: CssClusterV1NodeConfigVolumeOutputReference | CssClusterV1NodeConfigVolume): any;
export declare class CssClusterV1NodeConfigVolumeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CssClusterV1NodeConfigVolume | undefined;
    set internalValue(value: CssClusterV1NodeConfigVolume | undefined);
    private _encryptionKey?;
    get encryptionKey(): string;
    set encryptionKey(value: string);
    resetEncryptionKey(): void;
    get encryptionKeyInput(): string | undefined;
    private _size?;
    get size(): number;
    set size(value: number);
    get sizeInput(): number | undefined;
    private _volumeType?;
    get volumeType(): string;
    set volumeType(value: string);
    get volumeTypeInput(): string | undefined;
}
export interface CssClusterV1NodeConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#availability_zone CssClusterV1#availability_zone}
    */
    readonly availabilityZone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#flavor CssClusterV1#flavor}
    */
    readonly flavor: string;
    /**
    * network_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#network_info CssClusterV1#network_info}
    */
    readonly networkInfo: CssClusterV1NodeConfigNetworkInfo;
    /**
    * volume block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#volume CssClusterV1#volume}
    */
    readonly volume: CssClusterV1NodeConfigVolume;
}
export declare function cssClusterV1NodeConfigToTerraform(struct?: CssClusterV1NodeConfigOutputReference | CssClusterV1NodeConfig): any;
export declare function cssClusterV1NodeConfigToHclTerraform(struct?: CssClusterV1NodeConfigOutputReference | CssClusterV1NodeConfig): any;
export declare class CssClusterV1NodeConfigOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CssClusterV1NodeConfig | undefined;
    set internalValue(value: CssClusterV1NodeConfig | undefined);
    private _availabilityZone?;
    get availabilityZone(): string;
    set availabilityZone(value: string);
    resetAvailabilityZone(): void;
    get availabilityZoneInput(): string | undefined;
    private _flavor?;
    get flavor(): string;
    set flavor(value: string);
    get flavorInput(): string | undefined;
    private _networkInfo;
    get networkInfo(): CssClusterV1NodeConfigNetworkInfoOutputReference;
    putNetworkInfo(value: CssClusterV1NodeConfigNetworkInfo): void;
    get networkInfoInput(): CssClusterV1NodeConfigNetworkInfo | undefined;
    private _volume;
    get volume(): CssClusterV1NodeConfigVolumeOutputReference;
    putVolume(value: CssClusterV1NodeConfigVolume): void;
    get volumeInput(): CssClusterV1NodeConfigVolume | undefined;
}
export interface CssClusterV1PublicAccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#bandwidth CssClusterV1#bandwidth}
    */
    readonly bandwidth: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#whitelist CssClusterV1#whitelist}
    */
    readonly whitelist?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#whitelist_enabled CssClusterV1#whitelist_enabled}
    */
    readonly whitelistEnabled: boolean | cdktf.IResolvable;
}
export declare function cssClusterV1PublicAccessToTerraform(struct?: CssClusterV1PublicAccessOutputReference | CssClusterV1PublicAccess): any;
export declare function cssClusterV1PublicAccessToHclTerraform(struct?: CssClusterV1PublicAccessOutputReference | CssClusterV1PublicAccess): any;
export declare class CssClusterV1PublicAccessOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CssClusterV1PublicAccess | undefined;
    set internalValue(value: CssClusterV1PublicAccess | undefined);
    private _bandwidth?;
    get bandwidth(): number;
    set bandwidth(value: number);
    get bandwidthInput(): number | undefined;
    get publicIp(): string;
    private _whitelist?;
    get whitelist(): string;
    set whitelist(value: string);
    resetWhitelist(): void;
    get whitelistInput(): string | undefined;
    private _whitelistEnabled?;
    get whitelistEnabled(): boolean | cdktf.IResolvable;
    set whitelistEnabled(value: boolean | cdktf.IResolvable);
    get whitelistEnabledInput(): boolean | cdktf.IResolvable | undefined;
}
export interface CssClusterV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#create CssClusterV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#update CssClusterV1#update}
    */
    readonly update?: string;
}
export declare function cssClusterV1TimeoutsToTerraform(struct?: CssClusterV1Timeouts | cdktf.IResolvable): any;
export declare function cssClusterV1TimeoutsToHclTerraform(struct?: CssClusterV1Timeouts | cdktf.IResolvable): any;
export declare class CssClusterV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CssClusterV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: CssClusterV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1 opentelekomcloud_css_cluster_v1}
*/
export declare class CssClusterV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_css_cluster_v1";
    /**
    * Generates CDKTF code for importing a CssClusterV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CssClusterV1 to import
    * @param importFromId The id of the existing CssClusterV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CssClusterV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/css_cluster_v1 opentelekomcloud_css_cluster_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CssClusterV1Config
    */
    constructor(scope: Construct, id: string, config: CssClusterV1Config);
    private _adminPass?;
    get adminPass(): string;
    set adminPass(value: string);
    resetAdminPass(): void;
    get adminPassInput(): string | undefined;
    get backupAvailable(): cdktf.IResolvable;
    get created(): string;
    private _enableAuthority?;
    get enableAuthority(): boolean | cdktf.IResolvable;
    set enableAuthority(value: boolean | cdktf.IResolvable);
    resetEnableAuthority(): void;
    get enableAuthorityInput(): boolean | cdktf.IResolvable | undefined;
    private _enableHttps?;
    get enableHttps(): boolean | cdktf.IResolvable;
    set enableHttps(value: boolean | cdktf.IResolvable);
    resetEnableHttps(): void;
    get enableHttpsInput(): boolean | cdktf.IResolvable | undefined;
    get endpoint(): string;
    private _expectNodeNum?;
    get expectNodeNum(): number;
    set expectNodeNum(value: number);
    resetExpectNodeNum(): void;
    get expectNodeNumInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _nodes;
    get nodes(): CssClusterV1NodesList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get updated(): string;
    private _backupStrategy;
    get backupStrategy(): CssClusterV1BackupStrategyOutputReference;
    putBackupStrategy(value: CssClusterV1BackupStrategy): void;
    resetBackupStrategy(): void;
    get backupStrategyInput(): CssClusterV1BackupStrategy | undefined;
    private _datastore;
    get datastore(): CssClusterV1DatastoreOutputReference;
    putDatastore(value: CssClusterV1Datastore): void;
    resetDatastore(): void;
    get datastoreInput(): CssClusterV1Datastore | undefined;
    private _nodeConfig;
    get nodeConfig(): CssClusterV1NodeConfigOutputReference;
    putNodeConfig(value: CssClusterV1NodeConfig): void;
    get nodeConfigInput(): CssClusterV1NodeConfig | undefined;
    private _publicAccess;
    get publicAccess(): CssClusterV1PublicAccessOutputReference;
    putPublicAccess(value: CssClusterV1PublicAccess): void;
    resetPublicAccess(): void;
    get publicAccessInput(): CssClusterV1PublicAccess | undefined;
    private _timeouts;
    get timeouts(): CssClusterV1TimeoutsOutputReference;
    putTimeouts(value: CssClusterV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | CssClusterV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ComputeInstanceV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#access_ip_v4 ComputeInstanceV2#access_ip_v4}
    */
    readonly accessIpV4?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#access_ip_v6 ComputeInstanceV2#access_ip_v6}
    */
    readonly accessIpV6?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#admin_pass ComputeInstanceV2#admin_pass}
    */
    readonly adminPass?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#auto_recovery ComputeInstanceV2#auto_recovery}
    */
    readonly autoRecovery?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#availability_zone ComputeInstanceV2#availability_zone}
    */
    readonly availabilityZone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#config_drive ComputeInstanceV2#config_drive}
    */
    readonly configDrive?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#description ComputeInstanceV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#flavor_id ComputeInstanceV2#flavor_id}
    */
    readonly flavorId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#flavor_name ComputeInstanceV2#flavor_name}
    */
    readonly flavorName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#id ComputeInstanceV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#image_id ComputeInstanceV2#image_id}
    */
    readonly imageId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#image_name ComputeInstanceV2#image_name}
    */
    readonly imageName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#key_pair ComputeInstanceV2#key_pair}
    */
    readonly keyPair?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#metadata ComputeInstanceV2#metadata}
    */
    readonly metadata?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#name ComputeInstanceV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#power_state ComputeInstanceV2#power_state}
    */
    readonly powerState?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#region ComputeInstanceV2#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#security_groups ComputeInstanceV2#security_groups}
    */
    readonly securityGroups?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#ssh_private_key_path ComputeInstanceV2#ssh_private_key_path}
    */
    readonly sshPrivateKeyPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#stop_before_destroy ComputeInstanceV2#stop_before_destroy}
    */
    readonly stopBeforeDestroy?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#tags ComputeInstanceV2#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#user_data ComputeInstanceV2#user_data}
    */
    readonly userData?: string;
    /**
    * block_device block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#block_device ComputeInstanceV2#block_device}
    */
    readonly blockDevice?: ComputeInstanceV2BlockDevice[] | cdktf.IResolvable;
    /**
    * network block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#network ComputeInstanceV2#network}
    */
    readonly network?: ComputeInstanceV2Network[] | cdktf.IResolvable;
    /**
    * scheduler_hints block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#scheduler_hints ComputeInstanceV2#scheduler_hints}
    */
    readonly schedulerHints?: ComputeInstanceV2SchedulerHints[] | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#timeouts ComputeInstanceV2#timeouts}
    */
    readonly timeouts?: ComputeInstanceV2Timeouts;
}
export interface ComputeInstanceV2VolumeAttached {
}
export declare function computeInstanceV2VolumeAttachedToTerraform(struct?: ComputeInstanceV2VolumeAttached): any;
export declare function computeInstanceV2VolumeAttachedToHclTerraform(struct?: ComputeInstanceV2VolumeAttached): any;
export declare class ComputeInstanceV2VolumeAttachedOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInstanceV2VolumeAttached | undefined;
    set internalValue(value: ComputeInstanceV2VolumeAttached | undefined);
    get id(): string;
}
export declare class ComputeInstanceV2VolumeAttachedList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInstanceV2VolumeAttachedOutputReference;
}
export interface ComputeInstanceV2BlockDevice {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#boot_index ComputeInstanceV2#boot_index}
    */
    readonly bootIndex?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#delete_on_termination ComputeInstanceV2#delete_on_termination}
    */
    readonly deleteOnTermination?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#destination_type ComputeInstanceV2#destination_type}
    */
    readonly destinationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#device_name ComputeInstanceV2#device_name}
    */
    readonly deviceName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#guest_format ComputeInstanceV2#guest_format}
    */
    readonly guestFormat?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#source_type ComputeInstanceV2#source_type}
    */
    readonly sourceType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#uuid ComputeInstanceV2#uuid}
    */
    readonly uuid?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#volume_size ComputeInstanceV2#volume_size}
    */
    readonly volumeSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#volume_type ComputeInstanceV2#volume_type}
    */
    readonly volumeType?: string;
}
export declare function computeInstanceV2BlockDeviceToTerraform(struct?: ComputeInstanceV2BlockDevice | cdktf.IResolvable): any;
export declare function computeInstanceV2BlockDeviceToHclTerraform(struct?: ComputeInstanceV2BlockDevice | cdktf.IResolvable): any;
export declare class ComputeInstanceV2BlockDeviceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInstanceV2BlockDevice | cdktf.IResolvable | undefined;
    set internalValue(value: ComputeInstanceV2BlockDevice | cdktf.IResolvable | undefined);
    private _bootIndex?;
    get bootIndex(): number;
    set bootIndex(value: number);
    resetBootIndex(): void;
    get bootIndexInput(): number | undefined;
    private _deleteOnTermination?;
    get deleteOnTermination(): boolean | cdktf.IResolvable;
    set deleteOnTermination(value: boolean | cdktf.IResolvable);
    resetDeleteOnTermination(): void;
    get deleteOnTerminationInput(): boolean | cdktf.IResolvable | undefined;
    private _destinationType?;
    get destinationType(): string;
    set destinationType(value: string);
    resetDestinationType(): void;
    get destinationTypeInput(): string | undefined;
    private _deviceName?;
    get deviceName(): string;
    set deviceName(value: string);
    resetDeviceName(): void;
    get deviceNameInput(): string | undefined;
    private _guestFormat?;
    get guestFormat(): string;
    set guestFormat(value: string);
    resetGuestFormat(): void;
    get guestFormatInput(): string | undefined;
    private _sourceType?;
    get sourceType(): string;
    set sourceType(value: string);
    get sourceTypeInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
    private _volumeSize?;
    get volumeSize(): number;
    set volumeSize(value: number);
    resetVolumeSize(): void;
    get volumeSizeInput(): number | undefined;
    private _volumeType?;
    get volumeType(): string;
    set volumeType(value: string);
    resetVolumeType(): void;
    get volumeTypeInput(): string | undefined;
}
export declare class ComputeInstanceV2BlockDeviceList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ComputeInstanceV2BlockDevice[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInstanceV2BlockDeviceOutputReference;
}
export interface ComputeInstanceV2Network {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#access_network ComputeInstanceV2#access_network}
    */
    readonly accessNetwork?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#fixed_ip_v4 ComputeInstanceV2#fixed_ip_v4}
    */
    readonly fixedIpV4?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#fixed_ip_v6 ComputeInstanceV2#fixed_ip_v6}
    */
    readonly fixedIpV6?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#name ComputeInstanceV2#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#port ComputeInstanceV2#port}
    */
    readonly port?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#uuid ComputeInstanceV2#uuid}
    */
    readonly uuid?: string;
}
export declare function computeInstanceV2NetworkToTerraform(struct?: ComputeInstanceV2Network | cdktf.IResolvable): any;
export declare function computeInstanceV2NetworkToHclTerraform(struct?: ComputeInstanceV2Network | cdktf.IResolvable): any;
export declare class ComputeInstanceV2NetworkOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInstanceV2Network | cdktf.IResolvable | undefined;
    set internalValue(value: ComputeInstanceV2Network | cdktf.IResolvable | undefined);
    private _accessNetwork?;
    get accessNetwork(): boolean | cdktf.IResolvable;
    set accessNetwork(value: boolean | cdktf.IResolvable);
    resetAccessNetwork(): void;
    get accessNetworkInput(): boolean | cdktf.IResolvable | undefined;
    private _fixedIpV4?;
    get fixedIpV4(): string;
    set fixedIpV4(value: string);
    resetFixedIpV4(): void;
    get fixedIpV4Input(): string | undefined;
    private _fixedIpV6?;
    get fixedIpV6(): string;
    set fixedIpV6(value: string);
    resetFixedIpV6(): void;
    get fixedIpV6Input(): string | undefined;
    get mac(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _port?;
    get port(): string;
    set port(value: string);
    resetPort(): void;
    get portInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class ComputeInstanceV2NetworkList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ComputeInstanceV2Network[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInstanceV2NetworkOutputReference;
}
export interface ComputeInstanceV2SchedulerHints {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#build_near_host_ip ComputeInstanceV2#build_near_host_ip}
    */
    readonly buildNearHostIp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#deh_id ComputeInstanceV2#deh_id}
    */
    readonly dehId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#different_host ComputeInstanceV2#different_host}
    */
    readonly differentHost?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#group ComputeInstanceV2#group}
    */
    readonly group?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#query ComputeInstanceV2#query}
    */
    readonly query?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#same_host ComputeInstanceV2#same_host}
    */
    readonly sameHost?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#target_cell ComputeInstanceV2#target_cell}
    */
    readonly targetCell?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#tenancy ComputeInstanceV2#tenancy}
    */
    readonly tenancy?: string;
}
export declare function computeInstanceV2SchedulerHintsToTerraform(struct?: ComputeInstanceV2SchedulerHints | cdktf.IResolvable): any;
export declare function computeInstanceV2SchedulerHintsToHclTerraform(struct?: ComputeInstanceV2SchedulerHints | cdktf.IResolvable): any;
export declare class ComputeInstanceV2SchedulerHintsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInstanceV2SchedulerHints | cdktf.IResolvable | undefined;
    set internalValue(value: ComputeInstanceV2SchedulerHints | cdktf.IResolvable | undefined);
    private _buildNearHostIp?;
    get buildNearHostIp(): string;
    set buildNearHostIp(value: string);
    resetBuildNearHostIp(): void;
    get buildNearHostIpInput(): string | undefined;
    private _dehId?;
    get dehId(): string;
    set dehId(value: string);
    resetDehId(): void;
    get dehIdInput(): string | undefined;
    private _differentHost?;
    get differentHost(): string[];
    set differentHost(value: string[]);
    resetDifferentHost(): void;
    get differentHostInput(): string[] | undefined;
    private _group?;
    get group(): string;
    set group(value: string);
    resetGroup(): void;
    get groupInput(): string | undefined;
    private _query?;
    get query(): string[];
    set query(value: string[]);
    resetQuery(): void;
    get queryInput(): string[] | undefined;
    private _sameHost?;
    get sameHost(): string[];
    set sameHost(value: string[]);
    resetSameHost(): void;
    get sameHostInput(): string[] | undefined;
    private _targetCell?;
    get targetCell(): string;
    set targetCell(value: string);
    resetTargetCell(): void;
    get targetCellInput(): string | undefined;
    private _tenancy?;
    get tenancy(): string;
    set tenancy(value: string);
    resetTenancy(): void;
    get tenancyInput(): string | undefined;
}
export declare class ComputeInstanceV2SchedulerHintsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ComputeInstanceV2SchedulerHints[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInstanceV2SchedulerHintsOutputReference;
}
export interface ComputeInstanceV2Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#create ComputeInstanceV2#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#delete ComputeInstanceV2#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#update ComputeInstanceV2#update}
    */
    readonly update?: string;
}
export declare function computeInstanceV2TimeoutsToTerraform(struct?: ComputeInstanceV2Timeouts | cdktf.IResolvable): any;
export declare function computeInstanceV2TimeoutsToHclTerraform(struct?: ComputeInstanceV2Timeouts | cdktf.IResolvable): any;
export declare class ComputeInstanceV2TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceV2Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: ComputeInstanceV2Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2 opentelekomcloud_compute_instance_v2}
*/
export declare class ComputeInstanceV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_compute_instance_v2";
    /**
    * Generates CDKTF code for importing a ComputeInstanceV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeInstanceV2 to import
    * @param importFromId The id of the existing ComputeInstanceV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeInstanceV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/compute_instance_v2 opentelekomcloud_compute_instance_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeInstanceV2Config
    */
    constructor(scope: Construct, id: string, config: ComputeInstanceV2Config);
    private _accessIpV4?;
    get accessIpV4(): string;
    set accessIpV4(value: string);
    resetAccessIpV4(): void;
    get accessIpV4Input(): string | undefined;
    private _accessIpV6?;
    get accessIpV6(): string;
    set accessIpV6(value: string);
    resetAccessIpV6(): void;
    get accessIpV6Input(): string | undefined;
    private _adminPass?;
    get adminPass(): string;
    set adminPass(value: string);
    resetAdminPass(): void;
    get adminPassInput(): string | undefined;
    private _allMetadata;
    get allMetadata(): cdktf.StringMap;
    private _autoRecovery?;
    get autoRecovery(): boolean | cdktf.IResolvable;
    set autoRecovery(value: boolean | cdktf.IResolvable);
    resetAutoRecovery(): void;
    get autoRecoveryInput(): boolean | cdktf.IResolvable | undefined;
    private _availabilityZone?;
    get availabilityZone(): string;
    set availabilityZone(value: string);
    resetAvailabilityZone(): void;
    get availabilityZoneInput(): string | undefined;
    private _configDrive?;
    get configDrive(): boolean | cdktf.IResolvable;
    set configDrive(value: boolean | cdktf.IResolvable);
    resetConfigDrive(): void;
    get configDriveInput(): boolean | cdktf.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get encryptedPassword(): string;
    private _flavorId?;
    get flavorId(): string;
    set flavorId(value: string);
    resetFlavorId(): void;
    get flavorIdInput(): string | undefined;
    private _flavorName?;
    get flavorName(): string;
    set flavorName(value: string);
    resetFlavorName(): void;
    get flavorNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _imageId?;
    get imageId(): string;
    set imageId(value: string);
    resetImageId(): void;
    get imageIdInput(): string | undefined;
    private _imageName?;
    get imageName(): string;
    set imageName(value: string);
    resetImageName(): void;
    get imageNameInput(): string | undefined;
    private _keyPair?;
    get keyPair(): string;
    set keyPair(value: string);
    resetKeyPair(): void;
    get keyPairInput(): string | undefined;
    private _metadata?;
    get metadata(): {
        [key: string]: string;
    };
    set metadata(value: {
        [key: string]: string;
    });
    resetMetadata(): void;
    get metadataInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get password(): string;
    private _powerState?;
    get powerState(): string;
    set powerState(value: string);
    resetPowerState(): void;
    get powerStateInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _securityGroups?;
    get securityGroups(): string[];
    set securityGroups(value: string[]);
    resetSecurityGroups(): void;
    get securityGroupsInput(): string[] | undefined;
    private _sshPrivateKeyPath?;
    get sshPrivateKeyPath(): string;
    set sshPrivateKeyPath(value: string);
    resetSshPrivateKeyPath(): void;
    get sshPrivateKeyPathInput(): string | undefined;
    private _stopBeforeDestroy?;
    get stopBeforeDestroy(): boolean | cdktf.IResolvable;
    set stopBeforeDestroy(value: boolean | cdktf.IResolvable);
    resetStopBeforeDestroy(): void;
    get stopBeforeDestroyInput(): boolean | cdktf.IResolvable | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _userData?;
    get userData(): string;
    set userData(value: string);
    resetUserData(): void;
    get userDataInput(): string | undefined;
    private _volumeAttached;
    get volumeAttached(): ComputeInstanceV2VolumeAttachedList;
    private _blockDevice;
    get blockDevice(): ComputeInstanceV2BlockDeviceList;
    putBlockDevice(value: ComputeInstanceV2BlockDevice[] | cdktf.IResolvable): void;
    resetBlockDevice(): void;
    get blockDeviceInput(): cdktf.IResolvable | ComputeInstanceV2BlockDevice[] | undefined;
    private _network;
    get network(): ComputeInstanceV2NetworkList;
    putNetwork(value: ComputeInstanceV2Network[] | cdktf.IResolvable): void;
    resetNetwork(): void;
    get networkInput(): cdktf.IResolvable | ComputeInstanceV2Network[] | undefined;
    private _schedulerHints;
    get schedulerHints(): ComputeInstanceV2SchedulerHintsList;
    putSchedulerHints(value: ComputeInstanceV2SchedulerHints[] | cdktf.IResolvable): void;
    resetSchedulerHints(): void;
    get schedulerHintsInput(): cdktf.IResolvable | ComputeInstanceV2SchedulerHints[] | undefined;
    private _timeouts;
    get timeouts(): ComputeInstanceV2TimeoutsOutputReference;
    putTimeouts(value: ComputeInstanceV2Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | ComputeInstanceV2Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

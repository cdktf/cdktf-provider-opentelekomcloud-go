/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudCfwFirewallV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/cfw_firewall_v1#id DataOpentelekomcloudCfwFirewallV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/cfw_firewall_v1#service_type DataOpentelekomcloudCfwFirewallV1#service_type}
    */
    readonly serviceType?: string;
}
export interface DataOpentelekomcloudCfwFirewallV1Flavor {
}
export declare function dataOpentelekomcloudCfwFirewallV1FlavorToTerraform(struct?: DataOpentelekomcloudCfwFirewallV1Flavor): any;
export declare function dataOpentelekomcloudCfwFirewallV1FlavorToHclTerraform(struct?: DataOpentelekomcloudCfwFirewallV1Flavor): any;
export declare class DataOpentelekomcloudCfwFirewallV1FlavorOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudCfwFirewallV1Flavor | undefined;
    set internalValue(value: DataOpentelekomcloudCfwFirewallV1Flavor | undefined);
    get bandwidth(): number;
    get defaultBandwidth(): number;
    get defaultEipCount(): number;
    get defaultLogStorage(): number;
    get defaultVpcCount(): number;
    get eipCount(): number;
    get logStorage(): number;
    get versionCode(): number;
    get vpcCount(): number;
}
export declare class DataOpentelekomcloudCfwFirewallV1FlavorList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudCfwFirewallV1FlavorOutputReference;
}
export interface DataOpentelekomcloudCfwFirewallV1ProtectObjects {
}
export declare function dataOpentelekomcloudCfwFirewallV1ProtectObjectsToTerraform(struct?: DataOpentelekomcloudCfwFirewallV1ProtectObjects): any;
export declare function dataOpentelekomcloudCfwFirewallV1ProtectObjectsToHclTerraform(struct?: DataOpentelekomcloudCfwFirewallV1ProtectObjects): any;
export declare class DataOpentelekomcloudCfwFirewallV1ProtectObjectsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudCfwFirewallV1ProtectObjects | undefined;
    set internalValue(value: DataOpentelekomcloudCfwFirewallV1ProtectObjects | undefined);
    get objectId(): string;
    get objectName(): string;
    get type(): number;
}
export declare class DataOpentelekomcloudCfwFirewallV1ProtectObjectsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudCfwFirewallV1ProtectObjectsOutputReference;
}
export interface DataOpentelekomcloudCfwFirewallV1Resources {
}
export declare function dataOpentelekomcloudCfwFirewallV1ResourcesToTerraform(struct?: DataOpentelekomcloudCfwFirewallV1Resources): any;
export declare function dataOpentelekomcloudCfwFirewallV1ResourcesToHclTerraform(struct?: DataOpentelekomcloudCfwFirewallV1Resources): any;
export declare class DataOpentelekomcloudCfwFirewallV1ResourcesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudCfwFirewallV1Resources | undefined;
    set internalValue(value: DataOpentelekomcloudCfwFirewallV1Resources | undefined);
    get cloudServiceType(): string;
    get resourceId(): string;
    get resourceSize(): number;
    get resourceSizeMeasureId(): number;
    get resourceSpecCode(): string;
    get resourceType(): string;
}
export declare class DataOpentelekomcloudCfwFirewallV1ResourcesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudCfwFirewallV1ResourcesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/cfw_firewall_v1 opentelekomcloud_cfw_firewall_v1}
*/
export declare class DataOpentelekomcloudCfwFirewallV1 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_cfw_firewall_v1";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudCfwFirewallV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudCfwFirewallV1 to import
    * @param importFromId The id of the existing DataOpentelekomcloudCfwFirewallV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/cfw_firewall_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudCfwFirewallV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/cfw_firewall_v1 opentelekomcloud_cfw_firewall_v1} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudCfwFirewallV1Config
    */
    constructor(scope: Construct, id: string, config: DataOpentelekomcloudCfwFirewallV1Config);
    get chargeMode(): number;
    get engineType(): number;
    get enterpriseProjectId(): string;
    private _featureToggle;
    get featureToggle(): cdktf.BooleanMap;
    private _flavor;
    get flavor(): DataOpentelekomcloudCfwFirewallV1FlavorList;
    get haType(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get isAvailableObs(): cdktf.IResolvable;
    get isOldFirewallInstance(): cdktf.IResolvable;
    get isSupportThreatTags(): cdktf.IResolvable;
    get name(): string;
    private _protectObjects;
    get protectObjects(): DataOpentelekomcloudCfwFirewallV1ProtectObjectsList;
    get resourceId(): string;
    private _resources;
    get resources(): DataOpentelekomcloudCfwFirewallV1ResourcesList;
    private _serviceType?;
    get serviceType(): string;
    set serviceType(value: string);
    resetServiceType(): void;
    get serviceTypeInput(): string | undefined;
    get status(): number;
    get supportIpv6(): cdktf.IResolvable;
    get supportUrlFiltering(): cdktf.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

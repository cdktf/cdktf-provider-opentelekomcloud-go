/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudErInstancesV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/er_instances_v3#id DataOpentelekomcloudErInstancesV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/er_instances_v3#instance_id DataOpentelekomcloudErInstancesV3#instance_id}
    */
    readonly instanceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/er_instances_v3#name DataOpentelekomcloudErInstancesV3#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/er_instances_v3#region DataOpentelekomcloudErInstancesV3#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/er_instances_v3#status DataOpentelekomcloudErInstancesV3#status}
    */
    readonly status?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/er_instances_v3#tags DataOpentelekomcloudErInstancesV3#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
export interface DataOpentelekomcloudErInstancesV3Instances {
}
export declare function dataOpentelekomcloudErInstancesV3InstancesToTerraform(struct?: DataOpentelekomcloudErInstancesV3Instances): any;
export declare function dataOpentelekomcloudErInstancesV3InstancesToHclTerraform(struct?: DataOpentelekomcloudErInstancesV3Instances): any;
export declare class DataOpentelekomcloudErInstancesV3InstancesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudErInstancesV3Instances | undefined;
    set internalValue(value: DataOpentelekomcloudErInstancesV3Instances | undefined);
    get asn(): number;
    get autoAcceptSharedAttachments(): cdktf.IResolvable;
    get availabilityZones(): string[];
    get createdAt(): string;
    get defaultAssociationRouteTableId(): string;
    get defaultPropagationRouteTableId(): string;
    get description(): string;
    get enableDefaultAssociation(): cdktf.IResolvable;
    get enableDefaultPropagation(): cdktf.IResolvable;
    get id(): string;
    get name(): string;
    get status(): string;
    private _tags;
    get tags(): cdktf.StringMap;
    get updatedAt(): string;
}
export declare class DataOpentelekomcloudErInstancesV3InstancesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudErInstancesV3InstancesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/er_instances_v3 opentelekomcloud_er_instances_v3}
*/
export declare class DataOpentelekomcloudErInstancesV3 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_er_instances_v3";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudErInstancesV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudErInstancesV3 to import
    * @param importFromId The id of the existing DataOpentelekomcloudErInstancesV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/er_instances_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudErInstancesV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/er_instances_v3 opentelekomcloud_er_instances_v3} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudErInstancesV3Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudErInstancesV3Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    resetInstanceId(): void;
    get instanceIdInput(): string | undefined;
    private _instances;
    get instances(): DataOpentelekomcloudErInstancesV3InstancesList;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudGeminiInstancesV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/gemini_instances_v3#id DataOpentelekomcloudGeminiInstancesV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/gemini_instances_v3#name DataOpentelekomcloudGeminiInstancesV3#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/gemini_instances_v3#subnet_id DataOpentelekomcloudGeminiInstancesV3#subnet_id}
    */
    readonly subnetId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/gemini_instances_v3#vpc_id DataOpentelekomcloudGeminiInstancesV3#vpc_id}
    */
    readonly vpcId?: string;
}
export interface DataOpentelekomcloudGeminiInstancesV3InstancesBackupStrategy {
}
export declare function dataOpentelekomcloudGeminiInstancesV3InstancesBackupStrategyToTerraform(struct?: DataOpentelekomcloudGeminiInstancesV3InstancesBackupStrategy): any;
export declare function dataOpentelekomcloudGeminiInstancesV3InstancesBackupStrategyToHclTerraform(struct?: DataOpentelekomcloudGeminiInstancesV3InstancesBackupStrategy): any;
export declare class DataOpentelekomcloudGeminiInstancesV3InstancesBackupStrategyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudGeminiInstancesV3InstancesBackupStrategy | undefined;
    set internalValue(value: DataOpentelekomcloudGeminiInstancesV3InstancesBackupStrategy | undefined);
    get keepDays(): number;
    get startTime(): string;
}
export declare class DataOpentelekomcloudGeminiInstancesV3InstancesBackupStrategyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudGeminiInstancesV3InstancesBackupStrategyOutputReference;
}
export interface DataOpentelekomcloudGeminiInstancesV3InstancesDatastore {
}
export declare function dataOpentelekomcloudGeminiInstancesV3InstancesDatastoreToTerraform(struct?: DataOpentelekomcloudGeminiInstancesV3InstancesDatastore): any;
export declare function dataOpentelekomcloudGeminiInstancesV3InstancesDatastoreToHclTerraform(struct?: DataOpentelekomcloudGeminiInstancesV3InstancesDatastore): any;
export declare class DataOpentelekomcloudGeminiInstancesV3InstancesDatastoreOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudGeminiInstancesV3InstancesDatastore | undefined;
    set internalValue(value: DataOpentelekomcloudGeminiInstancesV3InstancesDatastore | undefined);
    get engine(): string;
    get storageEngine(): string;
    get version(): string;
}
export declare class DataOpentelekomcloudGeminiInstancesV3InstancesDatastoreList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudGeminiInstancesV3InstancesDatastoreOutputReference;
}
export interface DataOpentelekomcloudGeminiInstancesV3InstancesNodes {
}
export declare function dataOpentelekomcloudGeminiInstancesV3InstancesNodesToTerraform(struct?: DataOpentelekomcloudGeminiInstancesV3InstancesNodes): any;
export declare function dataOpentelekomcloudGeminiInstancesV3InstancesNodesToHclTerraform(struct?: DataOpentelekomcloudGeminiInstancesV3InstancesNodes): any;
export declare class DataOpentelekomcloudGeminiInstancesV3InstancesNodesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudGeminiInstancesV3InstancesNodes | undefined;
    set internalValue(value: DataOpentelekomcloudGeminiInstancesV3InstancesNodes | undefined);
    get availabilityZone(): string;
    get id(): string;
    get name(): string;
    get privateIp(): string;
    get status(): string;
    get supportReduce(): cdktf.IResolvable;
}
export declare class DataOpentelekomcloudGeminiInstancesV3InstancesNodesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudGeminiInstancesV3InstancesNodesOutputReference;
}
export interface DataOpentelekomcloudGeminiInstancesV3Instances {
}
export declare function dataOpentelekomcloudGeminiInstancesV3InstancesToTerraform(struct?: DataOpentelekomcloudGeminiInstancesV3Instances): any;
export declare function dataOpentelekomcloudGeminiInstancesV3InstancesToHclTerraform(struct?: DataOpentelekomcloudGeminiInstancesV3Instances): any;
export declare class DataOpentelekomcloudGeminiInstancesV3InstancesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudGeminiInstancesV3Instances | undefined;
    set internalValue(value: DataOpentelekomcloudGeminiInstancesV3Instances | undefined);
    get availabilityZone(): string;
    private _backupStrategy;
    get backupStrategy(): DataOpentelekomcloudGeminiInstancesV3InstancesBackupStrategyList;
    private _datastore;
    get datastore(): DataOpentelekomcloudGeminiInstancesV3InstancesDatastoreList;
    get dbUserName(): string;
    get enterpriseProjectId(): string;
    get flavor(): string;
    get id(): string;
    get mode(): string;
    get name(): string;
    get nodeNum(): number;
    private _nodes;
    get nodes(): DataOpentelekomcloudGeminiInstancesV3InstancesNodesList;
    get port(): number;
    get privateIps(): string[];
    get securityGroupId(): string;
    get status(): string;
    get subnetId(): string;
    private _tags;
    get tags(): cdktf.StringMap;
    get volumeSize(): number;
    get vpcId(): string;
}
export declare class DataOpentelekomcloudGeminiInstancesV3InstancesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudGeminiInstancesV3InstancesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/gemini_instances_v3 opentelekomcloud_gemini_instances_v3}
*/
export declare class DataOpentelekomcloudGeminiInstancesV3 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_gemini_instances_v3";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudGeminiInstancesV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudGeminiInstancesV3 to import
    * @param importFromId The id of the existing DataOpentelekomcloudGeminiInstancesV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/gemini_instances_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudGeminiInstancesV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/gemini_instances_v3 opentelekomcloud_gemini_instances_v3} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudGeminiInstancesV3Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataOpentelekomcloudGeminiInstancesV3Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instances;
    get instances(): DataOpentelekomcloudGeminiInstancesV3InstancesList;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    resetSubnetId(): void;
    get subnetIdInput(): string | undefined;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    resetVpcId(): void;
    get vpcIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

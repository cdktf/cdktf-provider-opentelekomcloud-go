/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface KmsKeyMaterialV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/kms_key_material_v1#encrypted_key_material KmsKeyMaterialV1#encrypted_key_material}
    */
    readonly encryptedKeyMaterial: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/kms_key_material_v1#expiration_time KmsKeyMaterialV1#expiration_time}
    */
    readonly expirationTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/kms_key_material_v1#id KmsKeyMaterialV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/kms_key_material_v1#import_token KmsKeyMaterialV1#import_token}
    */
    readonly importToken: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/kms_key_material_v1#key_id KmsKeyMaterialV1#key_id}
    */
    readonly keyId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/kms_key_material_v1 opentelekomcloud_kms_key_material_v1}
*/
export declare class KmsKeyMaterialV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_kms_key_material_v1";
    /**
    * Generates CDKTF code for importing a KmsKeyMaterialV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the KmsKeyMaterialV1 to import
    * @param importFromId The id of the existing KmsKeyMaterialV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/kms_key_material_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the KmsKeyMaterialV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/kms_key_material_v1 opentelekomcloud_kms_key_material_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options KmsKeyMaterialV1Config
    */
    constructor(scope: Construct, id: string, config: KmsKeyMaterialV1Config);
    private _encryptedKeyMaterial?;
    get encryptedKeyMaterial(): string;
    set encryptedKeyMaterial(value: string);
    get encryptedKeyMaterialInput(): string | undefined;
    private _expirationTime?;
    get expirationTime(): string;
    set expirationTime(value: string);
    resetExpirationTime(): void;
    get expirationTimeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _importToken?;
    get importToken(): string;
    set importToken(value: string);
    get importTokenInput(): string | undefined;
    private _keyId?;
    get keyId(): string;
    set keyId(value: string);
    get keyIdInput(): string | undefined;
    get keyState(): string;
    get region(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

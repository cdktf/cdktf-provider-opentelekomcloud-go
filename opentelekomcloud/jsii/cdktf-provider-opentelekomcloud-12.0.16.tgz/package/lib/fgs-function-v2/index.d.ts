/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface FgsFunctionV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#agency FgsFunctionV2#agency}
    */
    readonly agency?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#app FgsFunctionV2#app}
    */
    readonly app?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#app_agency FgsFunctionV2#app_agency}
    */
    readonly appAgency?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#code_filename FgsFunctionV2#code_filename}
    */
    readonly codeFilename?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#code_type FgsFunctionV2#code_type}
    */
    readonly codeType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#code_url FgsFunctionV2#code_url}
    */
    readonly codeUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#concurrency_num FgsFunctionV2#concurrency_num}
    */
    readonly concurrencyNum?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#depend_list FgsFunctionV2#depend_list}
    */
    readonly dependList?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#description FgsFunctionV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#dns_list FgsFunctionV2#dns_list}
    */
    readonly dnsList?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#enable_auth_in_header FgsFunctionV2#enable_auth_in_header}
    */
    readonly enableAuthInHeader?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#enable_class_isolation FgsFunctionV2#enable_class_isolation}
    */
    readonly enableClassIsolation?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#enable_dynamic_memory FgsFunctionV2#enable_dynamic_memory}
    */
    readonly enableDynamicMemory?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#enable_lts_log FgsFunctionV2#enable_lts_log}
    */
    readonly enableLtsLog?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#encrypted_user_data FgsFunctionV2#encrypted_user_data}
    */
    readonly encryptedUserData?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#enterprise_project_id FgsFunctionV2#enterprise_project_id}
    */
    readonly enterpriseProjectId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#ephemeral_storage FgsFunctionV2#ephemeral_storage}
    */
    readonly ephemeralStorage?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#func_code FgsFunctionV2#func_code}
    */
    readonly funcCode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#functiongraph_version FgsFunctionV2#functiongraph_version}
    */
    readonly functiongraphVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#gpu_memory FgsFunctionV2#gpu_memory}
    */
    readonly gpuMemory?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#handler FgsFunctionV2#handler}
    */
    readonly handler?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#heartbeat_handler FgsFunctionV2#heartbeat_handler}
    */
    readonly heartbeatHandler?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#id FgsFunctionV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#initializer_handler FgsFunctionV2#initializer_handler}
    */
    readonly initializerHandler?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#initializer_timeout FgsFunctionV2#initializer_timeout}
    */
    readonly initializerTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#log_group_id FgsFunctionV2#log_group_id}
    */
    readonly logGroupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#log_group_name FgsFunctionV2#log_group_name}
    */
    readonly logGroupName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#log_topic_id FgsFunctionV2#log_topic_id}
    */
    readonly logTopicId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#log_topic_name FgsFunctionV2#log_topic_name}
    */
    readonly logTopicName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#lts_custom_tag FgsFunctionV2#lts_custom_tag}
    */
    readonly ltsCustomTag?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#max_instance_num FgsFunctionV2#max_instance_num}
    */
    readonly maxInstanceNum?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#memory_size FgsFunctionV2#memory_size}
    */
    readonly memorySize: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#mount_user_group_id FgsFunctionV2#mount_user_group_id}
    */
    readonly mountUserGroupId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#mount_user_id FgsFunctionV2#mount_user_id}
    */
    readonly mountUserId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#name FgsFunctionV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#network_id FgsFunctionV2#network_id}
    */
    readonly networkId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#peering_cidr FgsFunctionV2#peering_cidr}
    */
    readonly peeringCidr?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#pre_stop_handler FgsFunctionV2#pre_stop_handler}
    */
    readonly preStopHandler?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#pre_stop_timeout FgsFunctionV2#pre_stop_timeout}
    */
    readonly preStopTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#restore_hook_handler FgsFunctionV2#restore_hook_handler}
    */
    readonly restoreHookHandler?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#restore_hook_timeout FgsFunctionV2#restore_hook_timeout}
    */
    readonly restoreHookTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#runtime FgsFunctionV2#runtime}
    */
    readonly runtime: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#tags FgsFunctionV2#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#timeout FgsFunctionV2#timeout}
    */
    readonly timeout: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#user_data FgsFunctionV2#user_data}
    */
    readonly userData?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#vpc_id FgsFunctionV2#vpc_id}
    */
    readonly vpcId?: string;
    /**
    * custom_image block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#custom_image FgsFunctionV2#custom_image}
    */
    readonly customImage?: FgsFunctionV2CustomImage;
    /**
    * func_mounts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#func_mounts FgsFunctionV2#func_mounts}
    */
    readonly funcMounts?: FgsFunctionV2FuncMounts[] | cdktf.IResolvable;
    /**
    * network_controller block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#network_controller FgsFunctionV2#network_controller}
    */
    readonly networkController?: FgsFunctionV2NetworkController;
    /**
    * reserved_instances block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#reserved_instances FgsFunctionV2#reserved_instances}
    */
    readonly reservedInstances?: FgsFunctionV2ReservedInstances[] | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#timeouts FgsFunctionV2#timeouts}
    */
    readonly timeouts?: FgsFunctionV2Timeouts;
    /**
    * versions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#versions FgsFunctionV2#versions}
    */
    readonly versions?: FgsFunctionV2Versions[] | cdktf.IResolvable;
}
export interface FgsFunctionV2CustomImage {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#args FgsFunctionV2#args}
    */
    readonly args?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#command FgsFunctionV2#command}
    */
    readonly command?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#url FgsFunctionV2#url}
    */
    readonly url: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#user_group_id FgsFunctionV2#user_group_id}
    */
    readonly userGroupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#user_id FgsFunctionV2#user_id}
    */
    readonly userId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#working_dir FgsFunctionV2#working_dir}
    */
    readonly workingDir?: string;
}
export declare function fgsFunctionV2CustomImageToTerraform(struct?: FgsFunctionV2CustomImageOutputReference | FgsFunctionV2CustomImage): any;
export declare function fgsFunctionV2CustomImageToHclTerraform(struct?: FgsFunctionV2CustomImageOutputReference | FgsFunctionV2CustomImage): any;
export declare class FgsFunctionV2CustomImageOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FgsFunctionV2CustomImage | undefined;
    set internalValue(value: FgsFunctionV2CustomImage | undefined);
    private _args?;
    get args(): string;
    set args(value: string);
    resetArgs(): void;
    get argsInput(): string | undefined;
    private _command?;
    get command(): string;
    set command(value: string);
    resetCommand(): void;
    get commandInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _userGroupId?;
    get userGroupId(): string;
    set userGroupId(value: string);
    resetUserGroupId(): void;
    get userGroupIdInput(): string | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    resetUserId(): void;
    get userIdInput(): string | undefined;
    private _workingDir?;
    get workingDir(): string;
    set workingDir(value: string);
    resetWorkingDir(): void;
    get workingDirInput(): string | undefined;
}
export interface FgsFunctionV2FuncMounts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#local_mount_path FgsFunctionV2#local_mount_path}
    */
    readonly localMountPath: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#mount_resource FgsFunctionV2#mount_resource}
    */
    readonly mountResource: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#mount_share_path FgsFunctionV2#mount_share_path}
    */
    readonly mountSharePath: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#mount_type FgsFunctionV2#mount_type}
    */
    readonly mountType: string;
}
export declare function fgsFunctionV2FuncMountsToTerraform(struct?: FgsFunctionV2FuncMounts | cdktf.IResolvable): any;
export declare function fgsFunctionV2FuncMountsToHclTerraform(struct?: FgsFunctionV2FuncMounts | cdktf.IResolvable): any;
export declare class FgsFunctionV2FuncMountsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): FgsFunctionV2FuncMounts | cdktf.IResolvable | undefined;
    set internalValue(value: FgsFunctionV2FuncMounts | cdktf.IResolvable | undefined);
    private _localMountPath?;
    get localMountPath(): string;
    set localMountPath(value: string);
    get localMountPathInput(): string | undefined;
    private _mountResource?;
    get mountResource(): string;
    set mountResource(value: string);
    get mountResourceInput(): string | undefined;
    private _mountSharePath?;
    get mountSharePath(): string;
    set mountSharePath(value: string);
    get mountSharePathInput(): string | undefined;
    private _mountType?;
    get mountType(): string;
    set mountType(value: string);
    get mountTypeInput(): string | undefined;
}
export declare class FgsFunctionV2FuncMountsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: FgsFunctionV2FuncMounts[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): FgsFunctionV2FuncMountsOutputReference;
}
export interface FgsFunctionV2NetworkControllerTriggerAccessVpcs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#vpc_id FgsFunctionV2#vpc_id}
    */
    readonly vpcId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#vpc_name FgsFunctionV2#vpc_name}
    */
    readonly vpcName?: string;
}
export declare function fgsFunctionV2NetworkControllerTriggerAccessVpcsToTerraform(struct?: FgsFunctionV2NetworkControllerTriggerAccessVpcs | cdktf.IResolvable): any;
export declare function fgsFunctionV2NetworkControllerTriggerAccessVpcsToHclTerraform(struct?: FgsFunctionV2NetworkControllerTriggerAccessVpcs | cdktf.IResolvable): any;
export declare class FgsFunctionV2NetworkControllerTriggerAccessVpcsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): FgsFunctionV2NetworkControllerTriggerAccessVpcs | cdktf.IResolvable | undefined;
    set internalValue(value: FgsFunctionV2NetworkControllerTriggerAccessVpcs | cdktf.IResolvable | undefined);
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    resetVpcId(): void;
    get vpcIdInput(): string | undefined;
    private _vpcName?;
    get vpcName(): string;
    set vpcName(value: string);
    resetVpcName(): void;
    get vpcNameInput(): string | undefined;
}
export declare class FgsFunctionV2NetworkControllerTriggerAccessVpcsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: FgsFunctionV2NetworkControllerTriggerAccessVpcs[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): FgsFunctionV2NetworkControllerTriggerAccessVpcsOutputReference;
}
export interface FgsFunctionV2NetworkController {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#disable_public_network FgsFunctionV2#disable_public_network}
    */
    readonly disablePublicNetwork?: boolean | cdktf.IResolvable;
    /**
    * trigger_access_vpcs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#trigger_access_vpcs FgsFunctionV2#trigger_access_vpcs}
    */
    readonly triggerAccessVpcs?: FgsFunctionV2NetworkControllerTriggerAccessVpcs[] | cdktf.IResolvable;
}
export declare function fgsFunctionV2NetworkControllerToTerraform(struct?: FgsFunctionV2NetworkControllerOutputReference | FgsFunctionV2NetworkController): any;
export declare function fgsFunctionV2NetworkControllerToHclTerraform(struct?: FgsFunctionV2NetworkControllerOutputReference | FgsFunctionV2NetworkController): any;
export declare class FgsFunctionV2NetworkControllerOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FgsFunctionV2NetworkController | undefined;
    set internalValue(value: FgsFunctionV2NetworkController | undefined);
    private _disablePublicNetwork?;
    get disablePublicNetwork(): boolean | cdktf.IResolvable;
    set disablePublicNetwork(value: boolean | cdktf.IResolvable);
    resetDisablePublicNetwork(): void;
    get disablePublicNetworkInput(): boolean | cdktf.IResolvable | undefined;
    private _triggerAccessVpcs;
    get triggerAccessVpcs(): FgsFunctionV2NetworkControllerTriggerAccessVpcsList;
    putTriggerAccessVpcs(value: FgsFunctionV2NetworkControllerTriggerAccessVpcs[] | cdktf.IResolvable): void;
    resetTriggerAccessVpcs(): void;
    get triggerAccessVpcsInput(): cdktf.IResolvable | FgsFunctionV2NetworkControllerTriggerAccessVpcs[] | undefined;
}
export interface FgsFunctionV2ReservedInstancesTacticsConfigCronConfigs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#count FgsFunctionV2#count}
    */
    readonly count: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#cron FgsFunctionV2#cron}
    */
    readonly cron: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#expired_time FgsFunctionV2#expired_time}
    */
    readonly expiredTime: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#name FgsFunctionV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#start_time FgsFunctionV2#start_time}
    */
    readonly startTime: number;
}
export declare function fgsFunctionV2ReservedInstancesTacticsConfigCronConfigsToTerraform(struct?: FgsFunctionV2ReservedInstancesTacticsConfigCronConfigs | cdktf.IResolvable): any;
export declare function fgsFunctionV2ReservedInstancesTacticsConfigCronConfigsToHclTerraform(struct?: FgsFunctionV2ReservedInstancesTacticsConfigCronConfigs | cdktf.IResolvable): any;
export declare class FgsFunctionV2ReservedInstancesTacticsConfigCronConfigsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): FgsFunctionV2ReservedInstancesTacticsConfigCronConfigs | cdktf.IResolvable | undefined;
    set internalValue(value: FgsFunctionV2ReservedInstancesTacticsConfigCronConfigs | cdktf.IResolvable | undefined);
    private _count?;
    get count(): number;
    set count(value: number);
    get countInput(): number | undefined;
    private _cron?;
    get cron(): string;
    set cron(value: string);
    get cronInput(): string | undefined;
    private _expiredTime?;
    get expiredTime(): number;
    set expiredTime(value: number);
    get expiredTimeInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _startTime?;
    get startTime(): number;
    set startTime(value: number);
    get startTimeInput(): number | undefined;
}
export declare class FgsFunctionV2ReservedInstancesTacticsConfigCronConfigsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: FgsFunctionV2ReservedInstancesTacticsConfigCronConfigs[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): FgsFunctionV2ReservedInstancesTacticsConfigCronConfigsOutputReference;
}
export interface FgsFunctionV2ReservedInstancesTacticsConfig {
    /**
    * cron_configs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#cron_configs FgsFunctionV2#cron_configs}
    */
    readonly cronConfigs?: FgsFunctionV2ReservedInstancesTacticsConfigCronConfigs[] | cdktf.IResolvable;
}
export declare function fgsFunctionV2ReservedInstancesTacticsConfigToTerraform(struct?: FgsFunctionV2ReservedInstancesTacticsConfigOutputReference | FgsFunctionV2ReservedInstancesTacticsConfig): any;
export declare function fgsFunctionV2ReservedInstancesTacticsConfigToHclTerraform(struct?: FgsFunctionV2ReservedInstancesTacticsConfigOutputReference | FgsFunctionV2ReservedInstancesTacticsConfig): any;
export declare class FgsFunctionV2ReservedInstancesTacticsConfigOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FgsFunctionV2ReservedInstancesTacticsConfig | undefined;
    set internalValue(value: FgsFunctionV2ReservedInstancesTacticsConfig | undefined);
    private _cronConfigs;
    get cronConfigs(): FgsFunctionV2ReservedInstancesTacticsConfigCronConfigsList;
    putCronConfigs(value: FgsFunctionV2ReservedInstancesTacticsConfigCronConfigs[] | cdktf.IResolvable): void;
    resetCronConfigs(): void;
    get cronConfigsInput(): cdktf.IResolvable | FgsFunctionV2ReservedInstancesTacticsConfigCronConfigs[] | undefined;
}
export interface FgsFunctionV2ReservedInstances {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#count FgsFunctionV2#count}
    */
    readonly count: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#idle_mode FgsFunctionV2#idle_mode}
    */
    readonly idleMode?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#qualifier_name FgsFunctionV2#qualifier_name}
    */
    readonly qualifierName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#qualifier_type FgsFunctionV2#qualifier_type}
    */
    readonly qualifierType: string;
    /**
    * tactics_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#tactics_config FgsFunctionV2#tactics_config}
    */
    readonly tacticsConfig?: FgsFunctionV2ReservedInstancesTacticsConfig;
}
export declare function fgsFunctionV2ReservedInstancesToTerraform(struct?: FgsFunctionV2ReservedInstances | cdktf.IResolvable): any;
export declare function fgsFunctionV2ReservedInstancesToHclTerraform(struct?: FgsFunctionV2ReservedInstances | cdktf.IResolvable): any;
export declare class FgsFunctionV2ReservedInstancesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): FgsFunctionV2ReservedInstances | cdktf.IResolvable | undefined;
    set internalValue(value: FgsFunctionV2ReservedInstances | cdktf.IResolvable | undefined);
    private _count?;
    get count(): number;
    set count(value: number);
    get countInput(): number | undefined;
    private _idleMode?;
    get idleMode(): boolean | cdktf.IResolvable;
    set idleMode(value: boolean | cdktf.IResolvable);
    resetIdleMode(): void;
    get idleModeInput(): boolean | cdktf.IResolvable | undefined;
    private _qualifierName?;
    get qualifierName(): string;
    set qualifierName(value: string);
    get qualifierNameInput(): string | undefined;
    private _qualifierType?;
    get qualifierType(): string;
    set qualifierType(value: string);
    get qualifierTypeInput(): string | undefined;
    private _tacticsConfig;
    get tacticsConfig(): FgsFunctionV2ReservedInstancesTacticsConfigOutputReference;
    putTacticsConfig(value: FgsFunctionV2ReservedInstancesTacticsConfig): void;
    resetTacticsConfig(): void;
    get tacticsConfigInput(): FgsFunctionV2ReservedInstancesTacticsConfig | undefined;
}
export declare class FgsFunctionV2ReservedInstancesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: FgsFunctionV2ReservedInstances[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): FgsFunctionV2ReservedInstancesOutputReference;
}
export interface FgsFunctionV2Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#create FgsFunctionV2#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#delete FgsFunctionV2#delete}
    */
    readonly delete?: string;
}
export declare function fgsFunctionV2TimeoutsToTerraform(struct?: FgsFunctionV2Timeouts | cdktf.IResolvable): any;
export declare function fgsFunctionV2TimeoutsToHclTerraform(struct?: FgsFunctionV2Timeouts | cdktf.IResolvable): any;
export declare class FgsFunctionV2TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FgsFunctionV2Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: FgsFunctionV2Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
export interface FgsFunctionV2VersionsAliases {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#description FgsFunctionV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#name FgsFunctionV2#name}
    */
    readonly name: string;
}
export declare function fgsFunctionV2VersionsAliasesToTerraform(struct?: FgsFunctionV2VersionsAliasesOutputReference | FgsFunctionV2VersionsAliases): any;
export declare function fgsFunctionV2VersionsAliasesToHclTerraform(struct?: FgsFunctionV2VersionsAliasesOutputReference | FgsFunctionV2VersionsAliases): any;
export declare class FgsFunctionV2VersionsAliasesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FgsFunctionV2VersionsAliases | undefined;
    set internalValue(value: FgsFunctionV2VersionsAliases | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface FgsFunctionV2Versions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#description FgsFunctionV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#name FgsFunctionV2#name}
    */
    readonly name: string;
    /**
    * aliases block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#aliases FgsFunctionV2#aliases}
    */
    readonly aliases?: FgsFunctionV2VersionsAliases;
}
export declare function fgsFunctionV2VersionsToTerraform(struct?: FgsFunctionV2Versions | cdktf.IResolvable): any;
export declare function fgsFunctionV2VersionsToHclTerraform(struct?: FgsFunctionV2Versions | cdktf.IResolvable): any;
export declare class FgsFunctionV2VersionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): FgsFunctionV2Versions | cdktf.IResolvable | undefined;
    set internalValue(value: FgsFunctionV2Versions | cdktf.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _aliases;
    get aliases(): FgsFunctionV2VersionsAliasesOutputReference;
    putAliases(value: FgsFunctionV2VersionsAliases): void;
    resetAliases(): void;
    get aliasesInput(): FgsFunctionV2VersionsAliases | undefined;
}
export declare class FgsFunctionV2VersionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: FgsFunctionV2Versions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): FgsFunctionV2VersionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2 opentelekomcloud_fgs_function_v2}
*/
export declare class FgsFunctionV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_fgs_function_v2";
    /**
    * Generates CDKTF code for importing a FgsFunctionV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the FgsFunctionV2 to import
    * @param importFromId The id of the existing FgsFunctionV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the FgsFunctionV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/fgs_function_v2 opentelekomcloud_fgs_function_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options FgsFunctionV2Config
    */
    constructor(scope: Construct, id: string, config: FgsFunctionV2Config);
    private _agency?;
    get agency(): string;
    set agency(value: string);
    resetAgency(): void;
    get agencyInput(): string | undefined;
    get allowEphemeralStorage(): cdktf.IResolvable;
    get apigRouteEnable(): cdktf.IResolvable;
    private _app?;
    get app(): string;
    set app(value: string);
    resetApp(): void;
    get appInput(): string | undefined;
    private _appAgency?;
    get appAgency(): string;
    set appAgency(value: string);
    resetAppAgency(): void;
    get appAgencyInput(): string | undefined;
    private _codeFilename?;
    get codeFilename(): string;
    set codeFilename(value: string);
    resetCodeFilename(): void;
    get codeFilenameInput(): string | undefined;
    private _codeType?;
    get codeType(): string;
    set codeType(value: string);
    resetCodeType(): void;
    get codeTypeInput(): string | undefined;
    private _codeUrl?;
    get codeUrl(): string;
    set codeUrl(value: string);
    resetCodeUrl(): void;
    get codeUrlInput(): string | undefined;
    private _concurrencyNum?;
    get concurrencyNum(): number;
    set concurrencyNum(value: number);
    resetConcurrencyNum(): void;
    get concurrencyNumInput(): number | undefined;
    private _dependList?;
    get dependList(): string[];
    set dependList(value: string[]);
    resetDependList(): void;
    get dependListInput(): string[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _dnsList?;
    get dnsList(): string;
    set dnsList(value: string);
    resetDnsList(): void;
    get dnsListInput(): string | undefined;
    private _enableAuthInHeader?;
    get enableAuthInHeader(): boolean | cdktf.IResolvable;
    set enableAuthInHeader(value: boolean | cdktf.IResolvable);
    resetEnableAuthInHeader(): void;
    get enableAuthInHeaderInput(): boolean | cdktf.IResolvable | undefined;
    private _enableClassIsolation?;
    get enableClassIsolation(): boolean | cdktf.IResolvable;
    set enableClassIsolation(value: boolean | cdktf.IResolvable);
    resetEnableClassIsolation(): void;
    get enableClassIsolationInput(): boolean | cdktf.IResolvable | undefined;
    private _enableDynamicMemory?;
    get enableDynamicMemory(): boolean | cdktf.IResolvable;
    set enableDynamicMemory(value: boolean | cdktf.IResolvable);
    resetEnableDynamicMemory(): void;
    get enableDynamicMemoryInput(): boolean | cdktf.IResolvable | undefined;
    private _enableLtsLog?;
    get enableLtsLog(): boolean | cdktf.IResolvable;
    set enableLtsLog(value: boolean | cdktf.IResolvable);
    resetEnableLtsLog(): void;
    get enableLtsLogInput(): boolean | cdktf.IResolvable | undefined;
    private _encryptedUserData?;
    get encryptedUserData(): string;
    set encryptedUserData(value: string);
    resetEncryptedUserData(): void;
    get encryptedUserDataInput(): string | undefined;
    private _enterpriseProjectId?;
    get enterpriseProjectId(): string;
    set enterpriseProjectId(value: string);
    resetEnterpriseProjectId(): void;
    get enterpriseProjectIdInput(): string | undefined;
    private _ephemeralStorage?;
    get ephemeralStorage(): number;
    set ephemeralStorage(value: number);
    resetEphemeralStorage(): void;
    get ephemeralStorageInput(): number | undefined;
    get extendConfig(): string;
    private _funcCode?;
    get funcCode(): string;
    set funcCode(value: string);
    resetFuncCode(): void;
    get funcCodeInput(): string | undefined;
    private _functiongraphVersion?;
    get functiongraphVersion(): string;
    set functiongraphVersion(value: string);
    resetFunctiongraphVersion(): void;
    get functiongraphVersionInput(): string | undefined;
    private _gpuMemory?;
    get gpuMemory(): number;
    set gpuMemory(value: number);
    resetGpuMemory(): void;
    get gpuMemoryInput(): number | undefined;
    get gpuType(): string;
    private _handler?;
    get handler(): string;
    set handler(value: string);
    resetHandler(): void;
    get handlerInput(): string | undefined;
    private _heartbeatHandler?;
    get heartbeatHandler(): string;
    set heartbeatHandler(value: string);
    resetHeartbeatHandler(): void;
    get heartbeatHandlerInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _initializerHandler?;
    get initializerHandler(): string;
    set initializerHandler(value: string);
    resetInitializerHandler(): void;
    get initializerHandlerInput(): string | undefined;
    private _initializerTimeout?;
    get initializerTimeout(): number;
    set initializerTimeout(value: number);
    resetInitializerTimeout(): void;
    get initializerTimeoutInput(): number | undefined;
    get isStatefulFunction(): cdktf.IResolvable;
    private _logGroupId?;
    get logGroupId(): string;
    set logGroupId(value: string);
    resetLogGroupId(): void;
    get logGroupIdInput(): string | undefined;
    private _logGroupName?;
    get logGroupName(): string;
    set logGroupName(value: string);
    resetLogGroupName(): void;
    get logGroupNameInput(): string | undefined;
    private _logTopicId?;
    get logTopicId(): string;
    set logTopicId(value: string);
    resetLogTopicId(): void;
    get logTopicIdInput(): string | undefined;
    private _logTopicName?;
    get logTopicName(): string;
    set logTopicName(value: string);
    resetLogTopicName(): void;
    get logTopicNameInput(): string | undefined;
    private _ltsCustomTag?;
    get ltsCustomTag(): {
        [key: string]: string;
    };
    set ltsCustomTag(value: {
        [key: string]: string;
    });
    resetLtsCustomTag(): void;
    get ltsCustomTagInput(): {
        [key: string]: string;
    } | undefined;
    private _maxInstanceNum?;
    get maxInstanceNum(): string;
    set maxInstanceNum(value: string);
    resetMaxInstanceNum(): void;
    get maxInstanceNumInput(): string | undefined;
    private _memorySize?;
    get memorySize(): number;
    set memorySize(value: number);
    get memorySizeInput(): number | undefined;
    private _mountUserGroupId?;
    get mountUserGroupId(): number;
    set mountUserGroupId(value: number);
    resetMountUserGroupId(): void;
    get mountUserGroupIdInput(): number | undefined;
    private _mountUserId?;
    get mountUserId(): number;
    set mountUserId(value: number);
    resetMountUserId(): void;
    get mountUserIdInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _networkId?;
    get networkId(): string;
    set networkId(value: string);
    resetNetworkId(): void;
    get networkIdInput(): string | undefined;
    private _peeringCidr?;
    get peeringCidr(): string;
    set peeringCidr(value: string);
    resetPeeringCidr(): void;
    get peeringCidrInput(): string | undefined;
    private _preStopHandler?;
    get preStopHandler(): string;
    set preStopHandler(value: string);
    resetPreStopHandler(): void;
    get preStopHandlerInput(): string | undefined;
    private _preStopTimeout?;
    get preStopTimeout(): number;
    set preStopTimeout(value: number);
    resetPreStopTimeout(): void;
    get preStopTimeoutInput(): number | undefined;
    get region(): string;
    private _restoreHookHandler?;
    get restoreHookHandler(): string;
    set restoreHookHandler(value: string);
    resetRestoreHookHandler(): void;
    get restoreHookHandlerInput(): string | undefined;
    private _restoreHookTimeout?;
    get restoreHookTimeout(): number;
    set restoreHookTimeout(value: number);
    resetRestoreHookTimeout(): void;
    get restoreHookTimeoutInput(): number | undefined;
    private _runtime?;
    get runtime(): string;
    set runtime(value: string);
    get runtimeInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    get timeoutInput(): number | undefined;
    get urn(): string;
    private _userData?;
    get userData(): string;
    set userData(value: string);
    resetUserData(): void;
    get userDataInput(): string | undefined;
    get version(): string;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    resetVpcId(): void;
    get vpcIdInput(): string | undefined;
    private _customImage;
    get customImage(): FgsFunctionV2CustomImageOutputReference;
    putCustomImage(value: FgsFunctionV2CustomImage): void;
    resetCustomImage(): void;
    get customImageInput(): FgsFunctionV2CustomImage | undefined;
    private _funcMounts;
    get funcMounts(): FgsFunctionV2FuncMountsList;
    putFuncMounts(value: FgsFunctionV2FuncMounts[] | cdktf.IResolvable): void;
    resetFuncMounts(): void;
    get funcMountsInput(): cdktf.IResolvable | FgsFunctionV2FuncMounts[] | undefined;
    private _networkController;
    get networkController(): FgsFunctionV2NetworkControllerOutputReference;
    putNetworkController(value: FgsFunctionV2NetworkController): void;
    resetNetworkController(): void;
    get networkControllerInput(): FgsFunctionV2NetworkController | undefined;
    private _reservedInstances;
    get reservedInstances(): FgsFunctionV2ReservedInstancesList;
    putReservedInstances(value: FgsFunctionV2ReservedInstances[] | cdktf.IResolvable): void;
    resetReservedInstances(): void;
    get reservedInstancesInput(): cdktf.IResolvable | FgsFunctionV2ReservedInstances[] | undefined;
    private _timeouts;
    get timeouts(): FgsFunctionV2TimeoutsOutputReference;
    putTimeouts(value: FgsFunctionV2Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | FgsFunctionV2Timeouts | undefined;
    private _versions;
    get versions(): FgsFunctionV2VersionsList;
    putVersions(value: FgsFunctionV2Versions[] | cdktf.IResolvable): void;
    resetVersions(): void;
    get versionsInput(): cdktf.IResolvable | FgsFunctionV2Versions[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

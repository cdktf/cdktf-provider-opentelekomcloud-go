/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface VpcepApprovalV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpcep_approval_v1#endpoints VpcepApprovalV1#endpoints}
    */
    readonly endpoints: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpcep_approval_v1#id VpcepApprovalV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpcep_approval_v1#service_id VpcepApprovalV1#service_id}
    */
    readonly serviceId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpcep_approval_v1#timeouts VpcepApprovalV1#timeouts}
    */
    readonly timeouts?: VpcepApprovalV1Timeouts;
}
export interface VpcepApprovalV1Connections {
}
export declare function vpcepApprovalV1ConnectionsToTerraform(struct?: VpcepApprovalV1Connections): any;
export declare function vpcepApprovalV1ConnectionsToHclTerraform(struct?: VpcepApprovalV1Connections): any;
export declare class VpcepApprovalV1ConnectionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): VpcepApprovalV1Connections | undefined;
    set internalValue(value: VpcepApprovalV1Connections | undefined);
    get createdAt(): string;
    get description(): string;
    get domainId(): string;
    get endpointId(): string;
    get packetId(): number;
    get status(): string;
    get updatedAt(): string;
}
export declare class VpcepApprovalV1ConnectionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): VpcepApprovalV1ConnectionsOutputReference;
}
export interface VpcepApprovalV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpcep_approval_v1#create VpcepApprovalV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpcep_approval_v1#delete VpcepApprovalV1#delete}
    */
    readonly delete?: string;
}
export declare function vpcepApprovalV1TimeoutsToTerraform(struct?: VpcepApprovalV1Timeouts | cdktf.IResolvable): any;
export declare function vpcepApprovalV1TimeoutsToHclTerraform(struct?: VpcepApprovalV1Timeouts | cdktf.IResolvable): any;
export declare class VpcepApprovalV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VpcepApprovalV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: VpcepApprovalV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpcep_approval_v1 opentelekomcloud_vpcep_approval_v1}
*/
export declare class VpcepApprovalV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_vpcep_approval_v1";
    /**
    * Generates CDKTF code for importing a VpcepApprovalV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VpcepApprovalV1 to import
    * @param importFromId The id of the existing VpcepApprovalV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpcep_approval_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VpcepApprovalV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpcep_approval_v1 opentelekomcloud_vpcep_approval_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VpcepApprovalV1Config
    */
    constructor(scope: Construct, id: string, config: VpcepApprovalV1Config);
    private _connections;
    get connections(): VpcepApprovalV1ConnectionsList;
    private _endpoints?;
    get endpoints(): string[];
    set endpoints(value: string[]);
    get endpointsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get region(): string;
    private _serviceId?;
    get serviceId(): string;
    set serviceId(value: string);
    get serviceIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): VpcepApprovalV1TimeoutsOutputReference;
    putTimeouts(value: VpcepApprovalV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | VpcepApprovalV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

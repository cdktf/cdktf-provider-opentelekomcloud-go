/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface RdsBackupV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_backup_v3#databases RdsBackupV3#databases}
    */
    readonly databases?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_backup_v3#id RdsBackupV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_backup_v3#instance_id RdsBackupV3#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_backup_v3#name RdsBackupV3#name}
    */
    readonly name: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_backup_v3#timeouts RdsBackupV3#timeouts}
    */
    readonly timeouts?: RdsBackupV3Timeouts;
}
export interface RdsBackupV3Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_backup_v3#create RdsBackupV3#create}
    */
    readonly create?: string;
}
export declare function rdsBackupV3TimeoutsToTerraform(struct?: RdsBackupV3Timeouts | cdktf.IResolvable): any;
export declare function rdsBackupV3TimeoutsToHclTerraform(struct?: RdsBackupV3Timeouts | cdktf.IResolvable): any;
export declare class RdsBackupV3TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RdsBackupV3Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: RdsBackupV3Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_backup_v3 opentelekomcloud_rds_backup_v3}
*/
export declare class RdsBackupV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_rds_backup_v3";
    /**
    * Generates CDKTF code for importing a RdsBackupV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RdsBackupV3 to import
    * @param importFromId The id of the existing RdsBackupV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_backup_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RdsBackupV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_backup_v3 opentelekomcloud_rds_backup_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RdsBackupV3Config
    */
    constructor(scope: Construct, id: string, config: RdsBackupV3Config);
    get backupId(): string;
    get beginTime(): string;
    private _databases?;
    get databases(): string[];
    set databases(value: string[]);
    resetDatabases(): void;
    get databasesInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get size(): number;
    get status(): string;
    get type(): string;
    private _timeouts;
    get timeouts(): RdsBackupV3TimeoutsOutputReference;
    putTimeouts(value: RdsBackupV3Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | RdsBackupV3Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

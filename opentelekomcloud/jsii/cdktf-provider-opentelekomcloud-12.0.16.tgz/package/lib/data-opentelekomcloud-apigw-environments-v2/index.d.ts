/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOpentelekomcloudApigwEnvironmentsV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/apigw_environments_v2#id DataOpentelekomcloudApigwEnvironmentsV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/apigw_environments_v2#instance_id DataOpentelekomcloudApigwEnvironmentsV2#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/apigw_environments_v2#name DataOpentelekomcloudApigwEnvironmentsV2#name}
    */
    readonly name?: string;
}
export interface DataOpentelekomcloudApigwEnvironmentsV2Environments {
}
export declare function dataOpentelekomcloudApigwEnvironmentsV2EnvironmentsToTerraform(struct?: DataOpentelekomcloudApigwEnvironmentsV2Environments): any;
export declare function dataOpentelekomcloudApigwEnvironmentsV2EnvironmentsToHclTerraform(struct?: DataOpentelekomcloudApigwEnvironmentsV2Environments): any;
export declare class DataOpentelekomcloudApigwEnvironmentsV2EnvironmentsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOpentelekomcloudApigwEnvironmentsV2Environments | undefined;
    set internalValue(value: DataOpentelekomcloudApigwEnvironmentsV2Environments | undefined);
    get createdAt(): string;
    get description(): string;
    get id(): string;
    get name(): string;
}
export declare class DataOpentelekomcloudApigwEnvironmentsV2EnvironmentsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOpentelekomcloudApigwEnvironmentsV2EnvironmentsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/apigw_environments_v2 opentelekomcloud_apigw_environments_v2}
*/
export declare class DataOpentelekomcloudApigwEnvironmentsV2 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "opentelekomcloud_apigw_environments_v2";
    /**
    * Generates CDKTF code for importing a DataOpentelekomcloudApigwEnvironmentsV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOpentelekomcloudApigwEnvironmentsV2 to import
    * @param importFromId The id of the existing DataOpentelekomcloudApigwEnvironmentsV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/apigw_environments_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOpentelekomcloudApigwEnvironmentsV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/data-sources/apigw_environments_v2 opentelekomcloud_apigw_environments_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOpentelekomcloudApigwEnvironmentsV2Config
    */
    constructor(scope: Construct, id: string, config: DataOpentelekomcloudApigwEnvironmentsV2Config);
    private _environments;
    get environments(): DataOpentelekomcloudApigwEnvironmentsV2EnvironmentsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get region(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

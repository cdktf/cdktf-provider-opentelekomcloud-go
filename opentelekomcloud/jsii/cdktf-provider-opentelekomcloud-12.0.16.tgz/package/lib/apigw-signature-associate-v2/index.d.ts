/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ApigwSignatureAssociateV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_signature_associate_v2#gateway_id ApigwSignatureAssociateV2#gateway_id}
    */
    readonly gatewayId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_signature_associate_v2#id ApigwSignatureAssociateV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_signature_associate_v2#publish_ids ApigwSignatureAssociateV2#publish_ids}
    */
    readonly publishIds: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_signature_associate_v2#signature_id ApigwSignatureAssociateV2#signature_id}
    */
    readonly signatureId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_signature_associate_v2#timeouts ApigwSignatureAssociateV2#timeouts}
    */
    readonly timeouts?: ApigwSignatureAssociateV2Timeouts;
}
export interface ApigwSignatureAssociateV2Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_signature_associate_v2#create ApigwSignatureAssociateV2#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_signature_associate_v2#delete ApigwSignatureAssociateV2#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_signature_associate_v2#update ApigwSignatureAssociateV2#update}
    */
    readonly update?: string;
}
export declare function apigwSignatureAssociateV2TimeoutsToTerraform(struct?: ApigwSignatureAssociateV2Timeouts | cdktf.IResolvable): any;
export declare function apigwSignatureAssociateV2TimeoutsToHclTerraform(struct?: ApigwSignatureAssociateV2Timeouts | cdktf.IResolvable): any;
export declare class ApigwSignatureAssociateV2TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigwSignatureAssociateV2Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: ApigwSignatureAssociateV2Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_signature_associate_v2 opentelekomcloud_apigw_signature_associate_v2}
*/
export declare class ApigwSignatureAssociateV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_apigw_signature_associate_v2";
    /**
    * Generates CDKTF code for importing a ApigwSignatureAssociateV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigwSignatureAssociateV2 to import
    * @param importFromId The id of the existing ApigwSignatureAssociateV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_signature_associate_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigwSignatureAssociateV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/apigw_signature_associate_v2 opentelekomcloud_apigw_signature_associate_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigwSignatureAssociateV2Config
    */
    constructor(scope: Construct, id: string, config: ApigwSignatureAssociateV2Config);
    private _gatewayId?;
    get gatewayId(): string;
    set gatewayId(value: string);
    get gatewayIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _publishIds?;
    get publishIds(): string[];
    set publishIds(value: string[]);
    get publishIdsInput(): string[] | undefined;
    get region(): string;
    private _signatureId?;
    get signatureId(): string;
    set signatureId(value: string);
    get signatureIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): ApigwSignatureAssociateV2TimeoutsOutputReference;
    putTimeouts(value: ApigwSignatureAssociateV2Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | ApigwSignatureAssociateV2Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CtsEventNotificationV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_event_notification_v3#id CtsEventNotificationV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_event_notification_v3#notification_name CtsEventNotificationV3#notification_name}
    */
    readonly notificationName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_event_notification_v3#operation_type CtsEventNotificationV3#operation_type}
    */
    readonly operationType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_event_notification_v3#status CtsEventNotificationV3#status}
    */
    readonly status?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_event_notification_v3#topic_id CtsEventNotificationV3#topic_id}
    */
    readonly topicId?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_event_notification_v3#filter CtsEventNotificationV3#filter}
    */
    readonly filter?: CtsEventNotificationV3Filter;
    /**
    * notify_user_list block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_event_notification_v3#notify_user_list CtsEventNotificationV3#notify_user_list}
    */
    readonly notifyUserList?: CtsEventNotificationV3NotifyUserListStruct[] | cdktf.IResolvable;
    /**
    * operations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_event_notification_v3#operations CtsEventNotificationV3#operations}
    */
    readonly operations?: CtsEventNotificationV3Operations[] | cdktf.IResolvable;
}
export interface CtsEventNotificationV3Filter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_event_notification_v3#condition CtsEventNotificationV3#condition}
    */
    readonly condition: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_event_notification_v3#rule CtsEventNotificationV3#rule}
    */
    readonly rule: string[];
}
export declare function ctsEventNotificationV3FilterToTerraform(struct?: CtsEventNotificationV3FilterOutputReference | CtsEventNotificationV3Filter): any;
export declare function ctsEventNotificationV3FilterToHclTerraform(struct?: CtsEventNotificationV3FilterOutputReference | CtsEventNotificationV3Filter): any;
export declare class CtsEventNotificationV3FilterOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CtsEventNotificationV3Filter | undefined;
    set internalValue(value: CtsEventNotificationV3Filter | undefined);
    private _condition?;
    get condition(): string;
    set condition(value: string);
    get conditionInput(): string | undefined;
    private _rule?;
    get rule(): string[];
    set rule(value: string[]);
    get ruleInput(): string[] | undefined;
}
export interface CtsEventNotificationV3NotifyUserListStruct {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_event_notification_v3#user_group CtsEventNotificationV3#user_group}
    */
    readonly userGroup: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_event_notification_v3#user_list CtsEventNotificationV3#user_list}
    */
    readonly userList: string[];
}
export declare function ctsEventNotificationV3NotifyUserListStructToTerraform(struct?: CtsEventNotificationV3NotifyUserListStruct | cdktf.IResolvable): any;
export declare function ctsEventNotificationV3NotifyUserListStructToHclTerraform(struct?: CtsEventNotificationV3NotifyUserListStruct | cdktf.IResolvable): any;
export declare class CtsEventNotificationV3NotifyUserListStructOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CtsEventNotificationV3NotifyUserListStruct | cdktf.IResolvable | undefined;
    set internalValue(value: CtsEventNotificationV3NotifyUserListStruct | cdktf.IResolvable | undefined);
    private _userGroup?;
    get userGroup(): string;
    set userGroup(value: string);
    get userGroupInput(): string | undefined;
    private _userList?;
    get userList(): string[];
    set userList(value: string[]);
    get userListInput(): string[] | undefined;
}
export declare class CtsEventNotificationV3NotifyUserListStructList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: CtsEventNotificationV3NotifyUserListStruct[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CtsEventNotificationV3NotifyUserListStructOutputReference;
}
export interface CtsEventNotificationV3Operations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_event_notification_v3#resource_type CtsEventNotificationV3#resource_type}
    */
    readonly resourceType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_event_notification_v3#service_type CtsEventNotificationV3#service_type}
    */
    readonly serviceType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_event_notification_v3#trace_names CtsEventNotificationV3#trace_names}
    */
    readonly traceNames: string[];
}
export declare function ctsEventNotificationV3OperationsToTerraform(struct?: CtsEventNotificationV3Operations | cdktf.IResolvable): any;
export declare function ctsEventNotificationV3OperationsToHclTerraform(struct?: CtsEventNotificationV3Operations | cdktf.IResolvable): any;
export declare class CtsEventNotificationV3OperationsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CtsEventNotificationV3Operations | cdktf.IResolvable | undefined;
    set internalValue(value: CtsEventNotificationV3Operations | cdktf.IResolvable | undefined);
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    get resourceTypeInput(): string | undefined;
    private _serviceType?;
    get serviceType(): string;
    set serviceType(value: string);
    get serviceTypeInput(): string | undefined;
    private _traceNames?;
    get traceNames(): string[];
    set traceNames(value: string[]);
    get traceNamesInput(): string[] | undefined;
}
export declare class CtsEventNotificationV3OperationsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: CtsEventNotificationV3Operations[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CtsEventNotificationV3OperationsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_event_notification_v3 opentelekomcloud_cts_event_notification_v3}
*/
export declare class CtsEventNotificationV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_cts_event_notification_v3";
    /**
    * Generates CDKTF code for importing a CtsEventNotificationV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CtsEventNotificationV3 to import
    * @param importFromId The id of the existing CtsEventNotificationV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_event_notification_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CtsEventNotificationV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cts_event_notification_v3 opentelekomcloud_cts_event_notification_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CtsEventNotificationV3Config
    */
    constructor(scope: Construct, id: string, config: CtsEventNotificationV3Config);
    get createTime(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get notificationId(): string;
    private _notificationName?;
    get notificationName(): string;
    set notificationName(value: string);
    get notificationNameInput(): string | undefined;
    get notificationType(): string;
    private _operationType?;
    get operationType(): string;
    set operationType(value: string);
    get operationTypeInput(): string | undefined;
    get projectId(): string;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _topicId?;
    get topicId(): string;
    set topicId(value: string);
    resetTopicId(): void;
    get topicIdInput(): string | undefined;
    private _filter;
    get filter(): CtsEventNotificationV3FilterOutputReference;
    putFilter(value: CtsEventNotificationV3Filter): void;
    resetFilter(): void;
    get filterInput(): CtsEventNotificationV3Filter | undefined;
    private _notifyUserList;
    get notifyUserList(): CtsEventNotificationV3NotifyUserListStructList;
    putNotifyUserList(value: CtsEventNotificationV3NotifyUserListStruct[] | cdktf.IResolvable): void;
    resetNotifyUserList(): void;
    get notifyUserListInput(): cdktf.IResolvable | CtsEventNotificationV3NotifyUserListStruct[] | undefined;
    private _operations;
    get operations(): CtsEventNotificationV3OperationsList;
    putOperations(value: CtsEventNotificationV3Operations[] | cdktf.IResolvable): void;
    resetOperations(): void;
    get operationsInput(): cdktf.IResolvable | CtsEventNotificationV3Operations[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DisCheckpointV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_checkpoint_v2#app_name DisCheckpointV2#app_name}
    */
    readonly appName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_checkpoint_v2#checkpoint_type DisCheckpointV2#checkpoint_type}
    */
    readonly checkpointType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_checkpoint_v2#id DisCheckpointV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_checkpoint_v2#metadata DisCheckpointV2#metadata}
    */
    readonly metadata?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_checkpoint_v2#partition_id DisCheckpointV2#partition_id}
    */
    readonly partitionId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_checkpoint_v2#sequence_number DisCheckpointV2#sequence_number}
    */
    readonly sequenceNumber: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_checkpoint_v2#stream_name DisCheckpointV2#stream_name}
    */
    readonly streamName: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_checkpoint_v2#timeouts DisCheckpointV2#timeouts}
    */
    readonly timeouts?: DisCheckpointV2Timeouts;
}
export interface DisCheckpointV2Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_checkpoint_v2#update DisCheckpointV2#update}
    */
    readonly update?: string;
}
export declare function disCheckpointV2TimeoutsToTerraform(struct?: DisCheckpointV2Timeouts | cdktf.IResolvable): any;
export declare function disCheckpointV2TimeoutsToHclTerraform(struct?: DisCheckpointV2Timeouts | cdktf.IResolvable): any;
export declare class DisCheckpointV2TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DisCheckpointV2Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DisCheckpointV2Timeouts | cdktf.IResolvable | undefined);
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_checkpoint_v2 opentelekomcloud_dis_checkpoint_v2}
*/
export declare class DisCheckpointV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_dis_checkpoint_v2";
    /**
    * Generates CDKTF code for importing a DisCheckpointV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DisCheckpointV2 to import
    * @param importFromId The id of the existing DisCheckpointV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_checkpoint_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DisCheckpointV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/dis_checkpoint_v2 opentelekomcloud_dis_checkpoint_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DisCheckpointV2Config
    */
    constructor(scope: Construct, id: string, config: DisCheckpointV2Config);
    private _appName?;
    get appName(): string;
    set appName(value: string);
    get appNameInput(): string | undefined;
    private _checkpointType?;
    get checkpointType(): string;
    set checkpointType(value: string);
    resetCheckpointType(): void;
    get checkpointTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metadata?;
    get metadata(): string;
    set metadata(value: string);
    resetMetadata(): void;
    get metadataInput(): string | undefined;
    private _partitionId?;
    get partitionId(): string;
    set partitionId(value: string);
    get partitionIdInput(): string | undefined;
    private _sequenceNumber?;
    get sequenceNumber(): string;
    set sequenceNumber(value: string);
    get sequenceNumberInput(): string | undefined;
    private _streamName?;
    get streamName(): string;
    set streamName(value: string);
    get streamNameInput(): string | undefined;
    private _timeouts;
    get timeouts(): DisCheckpointV2TimeoutsOutputReference;
    putTimeouts(value: DisCheckpointV2Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DisCheckpointV2Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

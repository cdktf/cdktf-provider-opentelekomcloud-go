/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface RdsPublicIpAssociateV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_public_ip_associate_v3#id RdsPublicIpAssociateV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_public_ip_associate_v3#instance_id RdsPublicIpAssociateV3#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_public_ip_associate_v3#public_ip RdsPublicIpAssociateV3#public_ip}
    */
    readonly publicIp: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_public_ip_associate_v3#public_ip_id RdsPublicIpAssociateV3#public_ip_id}
    */
    readonly publicIpId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_public_ip_associate_v3#timeouts RdsPublicIpAssociateV3#timeouts}
    */
    readonly timeouts?: RdsPublicIpAssociateV3Timeouts;
}
export interface RdsPublicIpAssociateV3Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_public_ip_associate_v3#create RdsPublicIpAssociateV3#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_public_ip_associate_v3#update RdsPublicIpAssociateV3#update}
    */
    readonly update?: string;
}
export declare function rdsPublicIpAssociateV3TimeoutsToTerraform(struct?: RdsPublicIpAssociateV3Timeouts | cdktf.IResolvable): any;
export declare function rdsPublicIpAssociateV3TimeoutsToHclTerraform(struct?: RdsPublicIpAssociateV3Timeouts | cdktf.IResolvable): any;
export declare class RdsPublicIpAssociateV3TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RdsPublicIpAssociateV3Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: RdsPublicIpAssociateV3Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_public_ip_associate_v3 opentelekomcloud_rds_public_ip_associate_v3}
*/
export declare class RdsPublicIpAssociateV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_rds_public_ip_associate_v3";
    /**
    * Generates CDKTF code for importing a RdsPublicIpAssociateV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RdsPublicIpAssociateV3 to import
    * @param importFromId The id of the existing RdsPublicIpAssociateV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_public_ip_associate_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RdsPublicIpAssociateV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/rds_public_ip_associate_v3 opentelekomcloud_rds_public_ip_associate_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RdsPublicIpAssociateV3Config
    */
    constructor(scope: Construct, id: string, config: RdsPublicIpAssociateV3Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _publicIp?;
    get publicIp(): string;
    set publicIp(value: string);
    get publicIpInput(): string | undefined;
    private _publicIpId?;
    get publicIpId(): string;
    set publicIpId(value: string);
    get publicIpIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): RdsPublicIpAssociateV3TimeoutsOutputReference;
    putTimeouts(value: RdsPublicIpAssociateV3Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | RdsPublicIpAssociateV3Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface VpcFlowLogV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpc_flow_log_v1#admin_state VpcFlowLogV1#admin_state}
    */
    readonly adminState?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpc_flow_log_v1#description VpcFlowLogV1#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpc_flow_log_v1#id VpcFlowLogV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpc_flow_log_v1#log_group_id VpcFlowLogV1#log_group_id}
    */
    readonly logGroupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpc_flow_log_v1#log_topic_id VpcFlowLogV1#log_topic_id}
    */
    readonly logTopicId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpc_flow_log_v1#name VpcFlowLogV1#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpc_flow_log_v1#resource_id VpcFlowLogV1#resource_id}
    */
    readonly resourceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpc_flow_log_v1#resource_type VpcFlowLogV1#resource_type}
    */
    readonly resourceType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpc_flow_log_v1#status VpcFlowLogV1#status}
    */
    readonly status?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpc_flow_log_v1#traffic_type VpcFlowLogV1#traffic_type}
    */
    readonly trafficType: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpc_flow_log_v1#timeouts VpcFlowLogV1#timeouts}
    */
    readonly timeouts?: VpcFlowLogV1Timeouts;
}
export interface VpcFlowLogV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpc_flow_log_v1#create VpcFlowLogV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpc_flow_log_v1#delete VpcFlowLogV1#delete}
    */
    readonly delete?: string;
}
export declare function vpcFlowLogV1TimeoutsToTerraform(struct?: VpcFlowLogV1Timeouts | cdktf.IResolvable): any;
export declare function vpcFlowLogV1TimeoutsToHclTerraform(struct?: VpcFlowLogV1Timeouts | cdktf.IResolvable): any;
export declare class VpcFlowLogV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VpcFlowLogV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: VpcFlowLogV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpc_flow_log_v1 opentelekomcloud_vpc_flow_log_v1}
*/
export declare class VpcFlowLogV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_vpc_flow_log_v1";
    /**
    * Generates CDKTF code for importing a VpcFlowLogV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VpcFlowLogV1 to import
    * @param importFromId The id of the existing VpcFlowLogV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpc_flow_log_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VpcFlowLogV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/vpc_flow_log_v1 opentelekomcloud_vpc_flow_log_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VpcFlowLogV1Config
    */
    constructor(scope: Construct, id: string, config: VpcFlowLogV1Config);
    private _adminState?;
    get adminState(): boolean | cdktf.IResolvable;
    set adminState(value: boolean | cdktf.IResolvable);
    resetAdminState(): void;
    get adminStateInput(): boolean | cdktf.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _logGroupId?;
    get logGroupId(): string;
    set logGroupId(value: string);
    get logGroupIdInput(): string | undefined;
    private _logTopicId?;
    get logTopicId(): string;
    set logTopicId(value: string);
    get logTopicIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    get resourceIdInput(): string | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    get resourceTypeInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _trafficType?;
    get trafficType(): string;
    set trafficType(value: string);
    get trafficTypeInput(): string | undefined;
    private _timeouts;
    get timeouts(): VpcFlowLogV1TimeoutsOutputReference;
    putTimeouts(value: VpcFlowLogV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | VpcFlowLogV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface LtsNotificationTemplateV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_notification_template_v2#description LtsNotificationTemplateV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_notification_template_v2#id LtsNotificationTemplateV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_notification_template_v2#language LtsNotificationTemplateV2#language}
    */
    readonly language: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_notification_template_v2#name LtsNotificationTemplateV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_notification_template_v2#source LtsNotificationTemplateV2#source}
    */
    readonly source: string;
    /**
    * templates block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_notification_template_v2#templates LtsNotificationTemplateV2#templates}
    */
    readonly templates: LtsNotificationTemplateV2Templates[] | cdktf.IResolvable;
}
export interface LtsNotificationTemplateV2Templates {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_notification_template_v2#content LtsNotificationTemplateV2#content}
    */
    readonly content: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_notification_template_v2#sub_type LtsNotificationTemplateV2#sub_type}
    */
    readonly subType: string;
}
export declare function ltsNotificationTemplateV2TemplatesToTerraform(struct?: LtsNotificationTemplateV2Templates | cdktf.IResolvable): any;
export declare function ltsNotificationTemplateV2TemplatesToHclTerraform(struct?: LtsNotificationTemplateV2Templates | cdktf.IResolvable): any;
export declare class LtsNotificationTemplateV2TemplatesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LtsNotificationTemplateV2Templates | cdktf.IResolvable | undefined;
    set internalValue(value: LtsNotificationTemplateV2Templates | cdktf.IResolvable | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    get contentInput(): string | undefined;
    private _subType?;
    get subType(): string;
    set subType(value: string);
    get subTypeInput(): string | undefined;
}
export declare class LtsNotificationTemplateV2TemplatesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: LtsNotificationTemplateV2Templates[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LtsNotificationTemplateV2TemplatesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_notification_template_v2 opentelekomcloud_lts_notification_template_v2}
*/
export declare class LtsNotificationTemplateV2 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_lts_notification_template_v2";
    /**
    * Generates CDKTF code for importing a LtsNotificationTemplateV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LtsNotificationTemplateV2 to import
    * @param importFromId The id of the existing LtsNotificationTemplateV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_notification_template_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LtsNotificationTemplateV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/lts_notification_template_v2 opentelekomcloud_lts_notification_template_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LtsNotificationTemplateV2Config
    */
    constructor(scope: Construct, id: string, config: LtsNotificationTemplateV2Config);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _language?;
    get language(): string;
    set language(value: string);
    get languageInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get region(): string;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
    private _templates;
    get templates(): LtsNotificationTemplateV2TemplatesList;
    putTemplates(value: LtsNotificationTemplateV2Templates[] | cdktf.IResolvable): void;
    get templatesInput(): cdktf.IResolvable | LtsNotificationTemplateV2Templates[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DdmSchemaV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ddm_schema_v1#id DdmSchemaV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ddm_schema_v1#instance_id DdmSchemaV1#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ddm_schema_v1#name DdmSchemaV1#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ddm_schema_v1#purge_rds_on_delete DdmSchemaV1#purge_rds_on_delete}
    */
    readonly purgeRdsOnDelete?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ddm_schema_v1#shard_mode DdmSchemaV1#shard_mode}
    */
    readonly shardMode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ddm_schema_v1#shard_number DdmSchemaV1#shard_number}
    */
    readonly shardNumber: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ddm_schema_v1#shard_unit DdmSchemaV1#shard_unit}
    */
    readonly shardUnit?: number;
    /**
    * rds block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ddm_schema_v1#rds DdmSchemaV1#rds}
    */
    readonly rds: DdmSchemaV1Rds[] | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ddm_schema_v1#timeouts DdmSchemaV1#timeouts}
    */
    readonly timeouts?: DdmSchemaV1Timeouts;
}
export interface DdmSchemaV1Databases {
}
export declare function ddmSchemaV1DatabasesToTerraform(struct?: DdmSchemaV1Databases): any;
export declare function ddmSchemaV1DatabasesToHclTerraform(struct?: DdmSchemaV1Databases): any;
export declare class DdmSchemaV1DatabasesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DdmSchemaV1Databases | undefined;
    set internalValue(value: DdmSchemaV1Databases | undefined);
    get createdAt(): number;
    get dbSlot(): number;
    get id(): string;
    get name(): string;
    get rdsName(): string;
    get status(): string;
    get updatedAt(): number;
}
export declare class DdmSchemaV1DatabasesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DdmSchemaV1DatabasesOutputReference;
}
export interface DdmSchemaV1UsedRds {
}
export declare function ddmSchemaV1UsedRdsToTerraform(struct?: DdmSchemaV1UsedRds): any;
export declare function ddmSchemaV1UsedRdsToHclTerraform(struct?: DdmSchemaV1UsedRds): any;
export declare class DdmSchemaV1UsedRdsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DdmSchemaV1UsedRds | undefined;
    set internalValue(value: DdmSchemaV1UsedRds | undefined);
    get id(): string;
    get name(): string;
    get status(): string;
}
export declare class DdmSchemaV1UsedRdsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DdmSchemaV1UsedRdsOutputReference;
}
export interface DdmSchemaV1Rds {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ddm_schema_v1#admin_password DdmSchemaV1#admin_password}
    */
    readonly adminPassword: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ddm_schema_v1#admin_username DdmSchemaV1#admin_username}
    */
    readonly adminUsername: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ddm_schema_v1#id DdmSchemaV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function ddmSchemaV1RdsToTerraform(struct?: DdmSchemaV1Rds | cdktf.IResolvable): any;
export declare function ddmSchemaV1RdsToHclTerraform(struct?: DdmSchemaV1Rds | cdktf.IResolvable): any;
export declare class DdmSchemaV1RdsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DdmSchemaV1Rds | cdktf.IResolvable | undefined;
    set internalValue(value: DdmSchemaV1Rds | cdktf.IResolvable | undefined);
    private _adminPassword?;
    get adminPassword(): string;
    set adminPassword(value: string);
    get adminPasswordInput(): string | undefined;
    private _adminUsername?;
    get adminUsername(): string;
    set adminUsername(value: string);
    get adminUsernameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class DdmSchemaV1RdsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DdmSchemaV1Rds[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DdmSchemaV1RdsOutputReference;
}
export interface DdmSchemaV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ddm_schema_v1#create DdmSchemaV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ddm_schema_v1#delete DdmSchemaV1#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ddm_schema_v1#update DdmSchemaV1#update}
    */
    readonly update?: string;
}
export declare function ddmSchemaV1TimeoutsToTerraform(struct?: DdmSchemaV1Timeouts | cdktf.IResolvable): any;
export declare function ddmSchemaV1TimeoutsToHclTerraform(struct?: DdmSchemaV1Timeouts | cdktf.IResolvable): any;
export declare class DdmSchemaV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DdmSchemaV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DdmSchemaV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ddm_schema_v1 opentelekomcloud_ddm_schema_v1}
*/
export declare class DdmSchemaV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_ddm_schema_v1";
    /**
    * Generates CDKTF code for importing a DdmSchemaV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DdmSchemaV1 to import
    * @param importFromId The id of the existing DdmSchemaV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ddm_schema_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DdmSchemaV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/ddm_schema_v1 opentelekomcloud_ddm_schema_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DdmSchemaV1Config
    */
    constructor(scope: Construct, id: string, config: DdmSchemaV1Config);
    get createdAt(): number;
    get dataVips(): string[];
    private _databases;
    get databases(): DdmSchemaV1DatabasesList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _purgeRdsOnDelete?;
    get purgeRdsOnDelete(): boolean | cdktf.IResolvable;
    set purgeRdsOnDelete(value: boolean | cdktf.IResolvable);
    resetPurgeRdsOnDelete(): void;
    get purgeRdsOnDeleteInput(): boolean | cdktf.IResolvable | undefined;
    get region(): string;
    private _shardMode?;
    get shardMode(): string;
    set shardMode(value: string);
    get shardModeInput(): string | undefined;
    private _shardNumber?;
    get shardNumber(): number;
    set shardNumber(value: number);
    get shardNumberInput(): number | undefined;
    private _shardUnit?;
    get shardUnit(): number;
    set shardUnit(value: number);
    resetShardUnit(): void;
    get shardUnitInput(): number | undefined;
    get status(): string;
    get updatedAt(): number;
    private _usedRds;
    get usedRds(): DdmSchemaV1UsedRdsList;
    private _rds;
    get rds(): DdmSchemaV1RdsList;
    putRds(value: DdmSchemaV1Rds[] | cdktf.IResolvable): void;
    get rdsInput(): cdktf.IResolvable | DdmSchemaV1Rds[] | undefined;
    private _timeouts;
    get timeouts(): DdmSchemaV1TimeoutsOutputReference;
    putTimeouts(value: DdmSchemaV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DdmSchemaV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface IdentityProtocolV3Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protocol_v3#id IdentityProtocolV3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protocol_v3#mapping_id IdentityProtocolV3#mapping_id}
    */
    readonly mappingId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protocol_v3#protocol IdentityProtocolV3#protocol}
    */
    readonly protocol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protocol_v3#provider_id IdentityProtocolV3#provider_id}
    */
    readonly providerId: string;
    /**
    * access_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protocol_v3#access_config IdentityProtocolV3#access_config}
    */
    readonly accessConfig?: IdentityProtocolV3AccessConfig;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protocol_v3#metadata IdentityProtocolV3#metadata}
    */
    readonly metadata?: IdentityProtocolV3Metadata;
}
export interface IdentityProtocolV3AccessConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protocol_v3#access_type IdentityProtocolV3#access_type}
    */
    readonly accessType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protocol_v3#authorization_endpoint IdentityProtocolV3#authorization_endpoint}
    */
    readonly authorizationEndpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protocol_v3#client_id IdentityProtocolV3#client_id}
    */
    readonly clientId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protocol_v3#provider_url IdentityProtocolV3#provider_url}
    */
    readonly providerUrl: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protocol_v3#response_mode IdentityProtocolV3#response_mode}
    */
    readonly responseMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protocol_v3#response_type IdentityProtocolV3#response_type}
    */
    readonly responseType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protocol_v3#scopes IdentityProtocolV3#scopes}
    */
    readonly scopes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protocol_v3#signing_key IdentityProtocolV3#signing_key}
    */
    readonly signingKey: string;
}
export declare function identityProtocolV3AccessConfigToTerraform(struct?: IdentityProtocolV3AccessConfigOutputReference | IdentityProtocolV3AccessConfig): any;
export declare function identityProtocolV3AccessConfigToHclTerraform(struct?: IdentityProtocolV3AccessConfigOutputReference | IdentityProtocolV3AccessConfig): any;
export declare class IdentityProtocolV3AccessConfigOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IdentityProtocolV3AccessConfig | undefined;
    set internalValue(value: IdentityProtocolV3AccessConfig | undefined);
    private _accessType?;
    get accessType(): string;
    set accessType(value: string);
    get accessTypeInput(): string | undefined;
    private _authorizationEndpoint?;
    get authorizationEndpoint(): string;
    set authorizationEndpoint(value: string);
    resetAuthorizationEndpoint(): void;
    get authorizationEndpointInput(): string | undefined;
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    get clientIdInput(): string | undefined;
    private _providerUrl?;
    get providerUrl(): string;
    set providerUrl(value: string);
    get providerUrlInput(): string | undefined;
    private _responseMode?;
    get responseMode(): string;
    set responseMode(value: string);
    resetResponseMode(): void;
    get responseModeInput(): string | undefined;
    private _responseType?;
    get responseType(): string;
    set responseType(value: string);
    resetResponseType(): void;
    get responseTypeInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
    private _signingKey?;
    get signingKey(): string;
    set signingKey(value: string);
    get signingKeyInput(): string | undefined;
}
export interface IdentityProtocolV3Metadata {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protocol_v3#domain_id IdentityProtocolV3#domain_id}
    */
    readonly domainId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protocol_v3#metadata IdentityProtocolV3#metadata}
    */
    readonly metadata: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protocol_v3#xaccount_type IdentityProtocolV3#xaccount_type}
    */
    readonly xaccountType?: string;
}
export declare function identityProtocolV3MetadataToTerraform(struct?: IdentityProtocolV3MetadataOutputReference | IdentityProtocolV3Metadata): any;
export declare function identityProtocolV3MetadataToHclTerraform(struct?: IdentityProtocolV3MetadataOutputReference | IdentityProtocolV3Metadata): any;
export declare class IdentityProtocolV3MetadataOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IdentityProtocolV3Metadata | undefined;
    set internalValue(value: IdentityProtocolV3Metadata | undefined);
    private _domainId?;
    get domainId(): string;
    set domainId(value: string);
    get domainIdInput(): string | undefined;
    private _metadata?;
    get metadata(): string;
    set metadata(value: string);
    get metadataInput(): string | undefined;
    private _xaccountType?;
    get xaccountType(): string;
    set xaccountType(value: string);
    resetXaccountType(): void;
    get xaccountTypeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protocol_v3 opentelekomcloud_identity_protocol_v3}
*/
export declare class IdentityProtocolV3 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_identity_protocol_v3";
    /**
    * Generates CDKTF code for importing a IdentityProtocolV3 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IdentityProtocolV3 to import
    * @param importFromId The id of the existing IdentityProtocolV3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protocol_v3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IdentityProtocolV3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/identity_protocol_v3 opentelekomcloud_identity_protocol_v3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IdentityProtocolV3Config
    */
    constructor(scope: Construct, id: string, config: IdentityProtocolV3Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _links;
    get links(): cdktf.StringMap;
    private _mappingId?;
    get mappingId(): string;
    set mappingId(value: string);
    get mappingIdInput(): string | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    get protocolInput(): string | undefined;
    private _providerId?;
    get providerId(): string;
    set providerId(value: string);
    get providerIdInput(): string | undefined;
    private _accessConfig;
    get accessConfig(): IdentityProtocolV3AccessConfigOutputReference;
    putAccessConfig(value: IdentityProtocolV3AccessConfig): void;
    resetAccessConfig(): void;
    get accessConfigInput(): IdentityProtocolV3AccessConfig | undefined;
    private _metadata;
    get metadata(): IdentityProtocolV3MetadataOutputReference;
    putMetadata(value: IdentityProtocolV3Metadata): void;
    resetMetadata(): void;
    get metadataInput(): IdentityProtocolV3Metadata | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

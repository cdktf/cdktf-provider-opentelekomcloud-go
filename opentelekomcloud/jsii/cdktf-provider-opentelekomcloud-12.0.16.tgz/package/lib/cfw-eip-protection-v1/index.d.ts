/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CfwEipProtectionV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_eip_protection_v1#eip_id CfwEipProtectionV1#eip_id}
    */
    readonly eipId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_eip_protection_v1#firewall_id CfwEipProtectionV1#firewall_id}
    */
    readonly firewallId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_eip_protection_v1#id CfwEipProtectionV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_eip_protection_v1#object_id CfwEipProtectionV1#object_id}
    */
    readonly objectId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_eip_protection_v1#public_ip CfwEipProtectionV1#public_ip}
    */
    readonly publicIp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_eip_protection_v1#public_ipv6 CfwEipProtectionV1#public_ipv6}
    */
    readonly publicIpv6?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_eip_protection_v1#status CfwEipProtectionV1#status}
    */
    readonly status: number;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_eip_protection_v1#timeouts CfwEipProtectionV1#timeouts}
    */
    readonly timeouts?: CfwEipProtectionV1Timeouts;
}
export interface CfwEipProtectionV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_eip_protection_v1#create CfwEipProtectionV1#create}
    */
    readonly create?: string;
}
export declare function cfwEipProtectionV1TimeoutsToTerraform(struct?: CfwEipProtectionV1Timeouts | cdktf.IResolvable): any;
export declare function cfwEipProtectionV1TimeoutsToHclTerraform(struct?: CfwEipProtectionV1Timeouts | cdktf.IResolvable): any;
export declare class CfwEipProtectionV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CfwEipProtectionV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: CfwEipProtectionV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_eip_protection_v1 opentelekomcloud_cfw_eip_protection_v1}
*/
export declare class CfwEipProtectionV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_cfw_eip_protection_v1";
    /**
    * Generates CDKTF code for importing a CfwEipProtectionV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CfwEipProtectionV1 to import
    * @param importFromId The id of the existing CfwEipProtectionV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_eip_protection_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CfwEipProtectionV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_eip_protection_v1 opentelekomcloud_cfw_eip_protection_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CfwEipProtectionV1Config
    */
    constructor(scope: Construct, id: string, config: CfwEipProtectionV1Config);
    private _eipId?;
    get eipId(): string;
    set eipId(value: string);
    get eipIdInput(): string | undefined;
    private _firewallId?;
    get firewallId(): string;
    set firewallId(value: string);
    get firewallIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _objectId?;
    get objectId(): string;
    set objectId(value: string);
    get objectIdInput(): string | undefined;
    private _publicIp?;
    get publicIp(): string;
    set publicIp(value: string);
    resetPublicIp(): void;
    get publicIpInput(): string | undefined;
    private _publicIpv6?;
    get publicIpv6(): string;
    set publicIpv6(value: string);
    resetPublicIpv6(): void;
    get publicIpv6Input(): string | undefined;
    private _status?;
    get status(): number;
    set status(value: number);
    get statusInput(): number | undefined;
    private _timeouts;
    get timeouts(): CfwEipProtectionV1TimeoutsOutputReference;
    putTimeouts(value: CfwEipProtectionV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | CfwEipProtectionV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CfwServiceGroupMemberV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_service_group_member_v1#description CfwServiceGroupMemberV1#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_service_group_member_v1#dest_port CfwServiceGroupMemberV1#dest_port}
    */
    readonly destPort: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_service_group_member_v1#protocol CfwServiceGroupMemberV1#protocol}
    */
    readonly protocol: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_service_group_member_v1#set_id CfwServiceGroupMemberV1#set_id}
    */
    readonly setId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_service_group_member_v1#source_port CfwServiceGroupMemberV1#source_port}
    */
    readonly sourcePort: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_service_group_member_v1#timeouts CfwServiceGroupMemberV1#timeouts}
    */
    readonly timeouts?: CfwServiceGroupMemberV1Timeouts;
}
export interface CfwServiceGroupMemberV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_service_group_member_v1#create CfwServiceGroupMemberV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_service_group_member_v1#delete CfwServiceGroupMemberV1#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_service_group_member_v1#update CfwServiceGroupMemberV1#update}
    */
    readonly update?: string;
}
export declare function cfwServiceGroupMemberV1TimeoutsToTerraform(struct?: CfwServiceGroupMemberV1Timeouts | cdktf.IResolvable): any;
export declare function cfwServiceGroupMemberV1TimeoutsToHclTerraform(struct?: CfwServiceGroupMemberV1Timeouts | cdktf.IResolvable): any;
export declare class CfwServiceGroupMemberV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CfwServiceGroupMemberV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: CfwServiceGroupMemberV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_service_group_member_v1 opentelekomcloud_cfw_service_group_member_v1}
*/
export declare class CfwServiceGroupMemberV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "opentelekomcloud_cfw_service_group_member_v1";
    /**
    * Generates CDKTF code for importing a CfwServiceGroupMemberV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CfwServiceGroupMemberV1 to import
    * @param importFromId The id of the existing CfwServiceGroupMemberV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_service_group_member_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CfwServiceGroupMemberV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/opentelekomcloud/opentelekomcloud/1.36.54/docs/resources/cfw_service_group_member_v1 opentelekomcloud_cfw_service_group_member_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CfwServiceGroupMemberV1Config
    */
    constructor(scope: Construct, id: string, config: CfwServiceGroupMemberV1Config);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _destPort?;
    get destPort(): string;
    set destPort(value: string);
    get destPortInput(): string | undefined;
    get id(): string;
    private _protocol?;
    get protocol(): number;
    set protocol(value: number);
    get protocolInput(): number | undefined;
    private _setId?;
    get setId(): string;
    set setId(value: string);
    get setIdInput(): string | undefined;
    private _sourcePort?;
    get sourcePort(): string;
    set sourcePort(value: string);
    get sourcePortInput(): string | undefined;
    private _timeouts;
    get timeouts(): CfwServiceGroupMemberV1TimeoutsOutputReference;
    putTimeouts(value: CfwServiceGroupMemberV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | CfwServiceGroupMemberV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
